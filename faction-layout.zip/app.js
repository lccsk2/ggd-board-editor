
'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 界面层（预览版 0.5.1.6）
 * 规则、草稿格式、随机抽取与判胜全部沿用 engine.js → faction-rules.js → camp-events.js → factions.js；已合入 0.4.0.4 的完整技能与交互修复。
 * 本文件只负责界面：五步流程、会议桌座位、阵营卡、胜利条件、角色卡、弹窗与本机存档。
 * “设置胜利”按阵营看：左边选阵营，右边是它的原有条件和额外胜利条件；数据按阵营写入 campEvents，草稿格式不变。
 * “添加胜利条件”弹窗里先选条件，再选它应用到哪些阵营（当前阵营默认选中），一个条件可以一次应用到多个阵营。
 * 额外条件一律“完成任意一个即可”；本页不新增阵营，新阵营只在“分配阵营”创建。
 * 新阵营只用额外胜利条件，不能选基础胜利条件；旧草稿里选过的在载入时取消。
 * 弹窗的阵营一栏带“分配给阵营 n / 总数”和“全选 / 全不选”。
 * “分配阵营”：左边选阵营，右边设置出场人数和候选角色。
 * 自创角色可以复制、粘贴（按钮，或 Ctrl/⌘ + C / V），剪贴板留在本机浏览器里。
 */
const E = window.EditorEngine, D = E.D;
// 托管版（发布成网页）由启动脚本标记 hosted。网页在沙盒框架里运行，不能自己触发下载：
// 导出改为“复制板子数据”，平台允许时再提供经确认的下载；导入增加“粘贴板子数据”。离线单文件版不走这些分支。
const HOSTED = !!(window.GgdOffline && window.GgdOffline.hosted);
let hostDownloads = null, hostDownloadsAsked = null;
const $ = s => document.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const clone = E.clone;
// 元黑的数字“1”是一条竖线，容易看成字母 I；标题里的数字改用典黑加粗。
const nums = html => String(html).replace(/&#?\w+;|<[^>]*>|\d+/g, m => /^\d+$/.test(m) ? `<span class="num">${m}</span>` : m);
const nameHtml = s => nums(esc(s));
const STORE = 'ggd-board-workshop-v1-faction-layout', AUTOSAVE = STORE + '-autosave', GUIDE_SEEN = STORE + '-guide-seen';
const STEPS = ['room', 'factions', 'roles', 'wins', 'review'];
const STEP_INFO = {
  room: {icon: 's-room', next: '下一步：分配阵营 →', hint: '默认设置已经备好，随时可以下一步。'},
  factions: {icon: 's-factions', next: '下一步：搭配技能 →', hint: '候选角色可以多选，按人数随机抽取。'},
  roles: {icon: 's-roles', next: '下一步：设置胜利 →', hint: '不想改技能？保留角色原本的技能即可。'},
  wins: {icon: 's-wins', next: '下一步：预览板子 →', hint: '无需改动原规则，也可以直接下一步。'},
  review: {icon: 's-review', next: '导出我的板子', hint: HOSTED ? '导出后，可以分享或再次导入编辑。' : '导出文件后，可以分享或再次导入编辑。'}
};
// 检查徽章与报错按钮共用同一条定位规则。
const CATEGORY_ICON = {'对抗与推理': 'swords', '行动与技能': 'bolt', '会议与生存': 'bell'};
// 每个胜利条件有自己的图标，便于在条件栏和预览卡片里一眼认出；未登记的条件退回分类图标。
const COND_ICON = {kills: 'swords', voteOuts: 'ballot', investigations: 'search', ballotsCast: 'check', reports: 'megaphone', skillUses: 'bolt', ventTrips: 'swap', crisisRepairs: 'gear', exploredRooms: 'map', distinctSkillUses: 'sparkle', surviveMeetings: 'shield', zeroVoteMeetings: 'ban', votedSurvivalMeetings: 'alert', emergencyCalls: 'bell', meetingsAttended: 'users', survivalTime: 'clock'};
const ROOM_ICON = {meeting_amount: 'bell', discuss_cd: 'users', vote_cd: 'ballot', first_bell_cd: 'clock', meeting_cd: 'refresh', meeting_hit_cd: 'swords', meeting_destroy_cd: 'bolt'};

let board = E.defaultBoard(), tab = 'room', selected = board.roles[1].uid, paramSkill = 0, dirty = false, toastTimer;
let rosterCollapsed = {}, rosterSearchCollapsed = {}, passiveExpanded = {};
let rosterSearch = '', skillSearch = '', skillModule = 'all', skillType = 'active', skillShowUnavailable = false, slotChoice = 'auto', careerSearch = '', careerCamp = 'all', careerLockedCamp = null, customRoleCamp = null;
let scenario = null, simRole = '', simulationRun = false, checkReport = [];
let drawResult = null, drawError = '', ruleCamp = 1, simGroup = '', roomMoreOpen = false, lastPageReset = null;
// addCond：“添加胜利条件”弹窗里尚未确认的选择；goalFresh：刚添加、需要高亮一下的条件卡片（事件 id）。
let addCond = null, goalFresh = null;
// roleClip：复制下来的自创角色（名称、出场上限、技能与参数）。存在本机浏览器里，换一块板子也能粘贴。
const ROLE_CLIP = STORE + '-role-clip';
let roleClip = readRoleClip();
let navigationContext = null;
let simOpen = false, justDrew = false, membersOpen = {}, markQueued = false, lastRenderTab = null, rendering = false, renderAgain = false;

/* ---------- 美术与图标 ---------- */
const ART = window.EDITOR_ART || {roles: {}, skills: {}, stages: {}, camps: {}};
const CUSTOM_ICON = ART.customRole || {src: "assets/custom-role.png", width: 512, height: 512};
const icon = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;
const stepArt = name => `<svg class="step-art" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><use href="#${name}"></use></svg>`;
const TONES = {1: ['#49b6ff', '#1e78cf'], 2: ['#ff5d5d', '#c3303c'], 3: ['#b98bff', '#7a4fe0']};
const CUSTOM_TONES = [['#2fd5c6', '#15978e'], ['#ff9f45', '#d06f18'], ['#ff6fb4', '#c93f86'], ['#9be15d', '#5c9f2c'], ['#f5d449', '#be9a12'], ['#5da9ff', '#2c6fd0'], ['#ff8a79', '#c9574a'], ['#c9a3ff', '#8a5fe0']];
function tone(id) {
  id = Number(id);
  if (!id) return ['#9c93d6', '#6c62b0'];
  return TONES[id] || CUSTOM_TONES[((id - 4) % CUSTOM_TONES.length + CUSTOM_TONES.length) % CUSTOM_TONES.length];
}
function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${n >> 8 & 255},${n & 255},${a})`; }
function toneStyle(id) { const [c, d] = tone(id); return `--fc:${c};--fc-deep:${d};--fc-soft:${rgba(c, .18)};--fc-line:${rgba(c, .55)}`; }
function artImage(a, cls = '', alt = '', lazy = true) {
  if (!a) return '';
  const source = a.optimizedSrc || a.src;
  return `<img class="${cls}" src="${esc(source)}" data-art-source="${esc(a.src)}" ${a.optimizedSrc ? `data-art-optimized="${esc(source)}"` : ''} width="${a.width}" height="${a.height}" alt="${esc(alt)}" loading="${lazy ? 'lazy' : 'eager'}" decoding="async" data-art-image>`;
}
function emblem(f, cls = '') {
  const art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
  return `<span class="emblem ${cls}" style="${toneStyle(f?.id)}" aria-hidden="true">${art ? artImage(art, '', '', false) : `<b>${esc([...(f?.name || '新')][0])}</b>`}</span>`;
}
function roleAvatar(id, camp = 0, cls = '') {
  const a = id === null ? {icon: CUSTOM_ICON} : ART.roles[id];
  return `<span class="avatar ${a?.icon ? 'has-art' : ''} ${cls}" style="${toneStyle(camp)}">${a?.icon ? artImage(a.icon, 'role-icon', '', true) : `<b>${esc(E.camps[camp]?.slice(0, 1) || '?')}</b>`}</span>`;
}
function skillIcon(id, cls = '') { const s = E.skills.get(Number(id)), a = ART.skills[id]?.icon; return a ? artImage(a, 'skill-icon ' + cls, '', true) : `<span class="skill-icon skill-text ${cls}" aria-label="${s?.type === 1 ? '被动技能' : '暂无图标'}">${s?.type === 1 ? '被' : '技'}</span>`; }
function rolePortrait(r) {
  if (E.isCustom(r)) return `<div class="portrait-frame icon-portrait" style="${toneStyle(r.camp)}">${artImage(CUSTOM_ICON, 'portrait-role-icon', r.name + '自创角色图标', false)}</div>`;
  const c = E.careers.get(r.templateCareerId), a = ART.roles[c.id];
  return `<div class="portrait-frame ${a?.portrait ? '' : 'icon-portrait'}" style="${toneStyle(r.camp)}">${a?.portrait ? artImage(a.portrait, 'role-portrait', c.name + '职业立绘', false) : artImage(a?.icon, 'portrait-role-icon', c.name + '职业图标', false)}</div>`;
}
function stageImages(id) { const a = ART.stages[id]; return a?.images?.length ? `<div class="stage-art">${a.images.map(x => `<figure>${artImage(x.image, 'stage-icon', a.name + ' · ' + (x.context === 'meeting' ? '会议图标' : '局内图标'), true)}<figcaption>${x.context === 'meeting' ? '会议图标' : '局内图标'}</figcaption></figure>`).join('')}</div>` : ''; }
function roleArtModal(){const r=role();if(!r)return;const c=E.isCustom(r)?{name:r.name}:E.careers.get(r.templateCareerId),a=E.isCustom(r)?{icon:CUSTOM_ICON}:ART.roles[c.id];modal(modalHead(esc(c.name)+' · 角色与技能素材')+`<div class="art-modal-hero"><div>${artImage(a?.icon,'modal-role-icon',c.name+'职业图标',false)}<p>职业图标</p></div>${a?.portrait?`<div>${artImage(a.portrait,'modal-portrait',c.name+'职业立绘',false)}<p>职业立绘</p></div>`:''}</div><h3 class="section-label">当前装备的技能</h3><div class="art-skill-grid">${E.equippedSkills(r,{type:'active'}).map(s=>`<article><div class="art-skill-heading">${skillIcon(s.id)}<strong>${esc(s.name)}</strong></div><p>${esc(s.des)}</p></article>`).join('')||'<p class="muted">还未装备技能</p>'}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">继续编辑</button></div>`);}
document.addEventListener('error', event => {
  const img = event.target;
  if (!(img instanceof HTMLImageElement) || !img.hasAttribute('data-art-image') || !img.isConnected) return;
  // A missing optimized asset falls back to the preserved original image.
  if (img.dataset.artOptimized && !img.dataset.artFallback) {
    img.dataset.artFallback = 'true';
    img.src = img.dataset.artSource;
    return;
  }
  const retries = Number(img.dataset.artRetries || 0);
  if (retries < 2) {
    img.dataset.artRetries = String(retries + 1);
    setTimeout(() => { if (!img.isConnected) return; const source = new URL(img.dataset.artSource, document.baseURI); if (source.protocol === 'http:' || source.protocol === 'https:') source.searchParams.set('artRetry', String(retries + 1)); img.src = source.href; }, 400 * (retries + 1));
    return;
  }
  const hint = document.createElement('span'); hint.className = 'art-unavailable'; hint.textContent = '图像暂不可用'; hint.title = img.alt; img.replaceWith(hint);
}, true);

function snapshotEditor(label,kind='page'){return {kind,tab,label,simOpen,membersOpen:clone(membersOpen),allocationCamp,rosterCollapsed:clone(rosterCollapsed),board:clone(board),selected,ruleCamp,drawResult:drawResult?clone(drawResult):null,drawError,scenario:scenario?clone(scenario):null,simulationRun,simGroup,simRole,rosterSearch,skillSearch,skillModule,roomMoreOpen,navigationContext:navigationContext?clone(navigationContext):null};}

function issueDestination(issue,b){const code=String(issue.code||''),text=String(issue.text||''),r=b.roles.find(r=>r.uid===(issue.uid||issue.roleUid));let camp=r?.camp??issue.camp;const uid=r?.uid;const roomLabels={total:'房间总人数',hit_cd:'击倒冷却',task:'房间总任务数',...Object.fromEntries(Object.entries(E.ROOM_FIELDS).map(([k,d])=>[k,d.label]))};const field=issue.field||Object.keys(roomLabels).find(k=>text.includes(k)||text.includes(roomLabels[k]));
 if(code==='NEUTRAL_ROLE_COUNT')return {tab:'roles',uid,camp:3,kind:'role-options'};
 if(code==='NEUTRAL_ROLE_DUPLICATE'||code==='NEUTRAL_PAIR_UNSUPPORTED')return {tab:'factions',camp:3,uid,kind:'candidates'};
 if(code==='ORIGINAL_OPENING')return {tab:'factions',camp:2,kind:'count'};
 if(code==='ORIGINAL_DUCK_OPENING')return {tab:'factions',camp:1,kind:'count'};
 if(code==='ORIGINAL_CAMP_OPENING')return {tab:'factions',camp:camp===1?2:1,kind:'count'};
 if(['CUSTOM_FACTION_LIMIT','CUSTOM_ROLE_LIMIT','CAMP_SUM','CAMP_COUNT','POOL_CAPACITY','POOL_INACTIVE','POOL_NO_COMBINATION','POOL_SEARCH_LIMIT','POOL_CONSTRAINTS','SKILL_FAMILY_POOL','EMPTY','CAREER_OUT_OF_SCOPE','CAREER_POOL'].includes(code))return {tab:'factions',camp,uid,kind:code.startsWith('CAMP_')?'count':'candidates'};
 if(code==='TOTAL_RANGE'||code.startsWith('ROOM_'))return {tab:'room',field:code==='TOTAL_RANGE'?'total':field};
 if(['COPY_CAP','CUSTOM_NEUTRAL_FORBIDDEN','CAMP_OVERRIDE','WIN_CAMP'].includes(code))return {tab:'roles',uid,camp,kind:'role-options'};
 if(code.startsWith('SKILL_')||['SNIPER_PAIR','ABILITY_COMPAT','CD_PARAM','SLOT_LAYOUT'].includes(code))return {tab:'roles',uid,camp,kind:'skills'};
 if(code==='BASE_DEPENDENCY'){const actor=r||b.roles.find(r=>r.camp===camp);return actor?{tab:'roles',uid:actor.uid,camp,kind:'skills'}:{tab:'factions',camp,kind:'candidates'};}
 if(/^(BASE_|EXTRA_|EVENT_|WIN_|FIXED_|LOSS_|OPENING_|EMPTY_WIN|EMPTY_LOSS|ZERO_THRESHOLD|CUSTOM_FACTION_NO_WIN|CUSTOM_NEUTRAL_NO_WIN|MEETING_GOAL_)/.test(code))return {tab:'wins',camp:camp??1,kind:code.startsWith('BASE_')?'base':'goals'};
 if(code==='SCHEMA'){if(field)return {tab:'room',field};if(/技能|槽位/.test(text))return {tab:'roles',uid,kind:'skills'};if(/胜利|目标|权重/.test(text))return {tab:'wins',camp:camp??1,kind:'goals'};if(/阵营|候选|角色/.test(text))return {tab:'factions',camp,kind:'candidates'};}
 return uid?{tab:'roles',uid,camp,kind:'skills'}:camp?{tab:'factions',camp,kind:'count'}:{tab:'room',field};
}

function reviewIssueLink(issue){const target=issueDestination(issue,board),index=checkReport.indexOf(issue),label={room:'设置房间',factions:'分配阵营',wins:'设置胜利',roles:'搭配技能'}[target.tab];return `<div class="issue-actions"><button class="btn btn-ghost btn-sm" data-issue-index="${index}" data-issue-code="${esc(issue.code)}" aria-label="查看${label}" title="前往${label}">查看</button>${issue.code==='MEETING_GOAL_UNREACHABLE'?`<button class="btn btn-ghost btn-sm" data-issue-room="${index}">会议设置</button>`:''}</div>`;}

function navigateTo(target,issue=null){if(!['room','factions','wins','roles','review'].includes(target.tab))return;closeModal();tab=target.tab;paramSkill=0;navigationContext=issue?{from:'review'}:null;
 if(target.uid&&board.roles.some(r=>r.uid===target.uid)){selected=target.uid;if(!target.keepSearch)rosterSearch='';}
 if(target.camp&&E.faction(board,target.camp))ruleCamp=Number(target.camp);
 if(target.tab==='roles'&&target.uid)revealRosterRole(role());
 if(target.tab==='factions'&&target.camp&&E.faction(board,target.camp))allocationCamp=Number(target.camp);
 if(target.tab==='factions'&&target.kind==='candidates')membersOpen[allocationCamp]=true;
 render();$('#content').scrollTop=0;
 if(tab==='factions')revealAllocationCamp();
 if(!issue&&!target.kind&&!target.uid&&!target.camp&&!target.field)return;
 let highlight=null,focus=null;
 if(tab==='factions'){
  const detail=$('.allocation-detail');
  highlight=target.camp||target.kind==='candidates'?detail:$('.allocation-overview');
  focus=target.kind==='candidates'?detail?.querySelector('[data-add-original-camp],[data-new-role-camp]'):detail?.querySelector('[data-count]');
 }
 else if(tab==='wins'){const named=issue?sortedEvents(ruleCamp).find(e=>issueNames(issue).includes(E.eventCatalog[e.type].name)):null,card=named?document.querySelector(`[data-goal="${CSS.escape(named.id)}"]`):null;highlight=card||$('.wins-editor');focus=(card?.querySelector('[data-event-value]')||$('.wins-editor [data-event-value]')||$('.wins-editor [data-action="add-cond"]:not(:disabled)'))||null;}
 else if(tab==='roles'){highlight=$('.role-workspace')||$('.empty-stage');focus=target.kind==='skills'?highlight?.querySelector('.skill-out-of-scope button[data-remove-skill],[data-action="choose-skills"]'):highlight?.querySelector('[data-role-field="name"]');}
 else if(tab==='room'){focus=target.field?document.querySelector(`[data-room="${CSS.escape(target.field)}"],[data-room-toggle="${CSS.escape(target.field)}"]`):null;highlight=focus?.closest('.panel')||$('.room-hero');}
 if(focus){for(let p=focus.parentElement;p&&p!==$('#content');p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;focus.scrollIntoView({block:'center'});focus.focus({preventScroll:true});}else highlight?.scrollIntoView({block:'start'});
 if((issue||tab==='wins'&&target.camp)&&highlight){highlight.classList.add('navigation-target');setTimeout(()=>highlight.classList.remove('navigation-target'),6000);}
 if(tab==='roles'&&target.kind==='role-options'&&role())roleOptions();
}

function resetAllModal(){modal(modalHead('重置全部设置？')+'<p class="reset-scope-copy">将当前板子的名称、房间、阵营、候选角色、胜利条件和技能恢复为初始设置。</p><p class="setting-hint">已保存的板子会保留。重置后可撤销，也可在“我的板子”中恢复替换前草稿。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-action="confirm-global-reset">确认重置全部</button></div>',true,'global-reset');}

function performGlobalReset(){const before=snapshotEditor('全部设置','global');let backedUp=false;try{localStorage.setItem(STORE+'-recovery',JSON.stringify(E.exportDraft(board)));backedUp=true;}catch{}
 rosterCollapsed={};rosterSearchCollapsed={};membersOpen={};simOpen=false;justDrew=false;allocationCamp=1;board=E.defaultBoard();tab='room';selected=board.roles[0]?.uid||'';ruleCamp=1;paramSkill=0;rosterSearch='';skillSearch='';skillModule='all';slotChoice='auto';careerSearch='';careerCamp='all';careerLockedCamp=null;customRoleCamp=null;roomMoreOpen=false;navigationContext=null;simRole='';simGroup='';scenario=null;simulationRun=false;drawResult=null;drawError='';mark();lastPageReset=before;closeModal();render();$('#content').scrollTop=0;toast(backedUp?'全部设置已重置，原草稿已备份':'全部设置已重置，可立即撤销');
}

function deleteRoleModal(uid=role()?.uid){const r=board.roles.find(r=>r.uid===uid);if(!r)return;modal(modalHead('删除「'+esc(r.name)+'」？')+'<p class="reset-scope-copy">从当前板子的候选池移除该角色及其技能设置。</p><p class="setting-hint">删除后可撤销。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-confirm-remove-role="'+esc(r.uid)+'">确认删除角色</button></div>',true,'delete-role');}

/* ---------- 状态 ---------- */
function role() { return board.roles.find(x => x.uid === selected) || board.roles[0]; }
function allocation() { const assigned = board.factions.reduce((n, f) => n + board.room.counts[f.id], 0); return {assigned, delta: board.room.total - assigned}; }
function factionLabel(id) { return E.campName(board, id); }
// 规则引擎的提示沿用“新增目标”一词；界面统一称“额外条件”。
const uiCopy = text => String(text ?? '').replace('请选择一种原有条件或添加新增目标', '请添加一个额外胜利条件').replace('添加新增目标', '添加额外条件').replaceAll('新增目标', '额外条件');
const RESET_WORDS = {'remove-role': ['已删除', '撤销删除', '已撤销删除'], 'remove-cond': ['已移除', '撤销移除', '已撤销移除']};
const resetWords = kind => RESET_WORDS[kind] || ['已重置', '撤销重置', '已撤销重置'];
function toast(s) {
  s = uiCopy(s);
  if ($('#modal').open && $('#dialog-status')) $('#dialog-status').textContent = s;
  $('#toast').textContent = s; $('#toast').classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.remove('show'), 3300);
}
function mark() {
  lastPageReset = null; $('.page-reset-feedback')?.remove();
  E.ensureCampRules(board); scenario = null; simulationRun = false; drawResult = null; drawError = ''; dirty = true; board.updatedAt = new Date().toISOString();
  try { localStorage.setItem(AUTOSAVE, JSON.stringify(E.exportDraft(board))); $('#save-state').textContent = '已自动保存'; } catch { $('#save-state').textContent = '未保存 · 请导出备份'; }
  header();
}
function scheduleMark() { if (markQueued) return; markQueued = true; requestAnimationFrame(() => { markQueued = false; mark(); refreshInline(); }); }
function issueStep(x) { return issueDestination(x, board).tab; }
function header() {
  checkReport = E.validate(board).filter(x => x.level === 'error' || !['ABILITY_COMPAT', 'SLOT_LAYOUT', 'SKILL_SLOT', 'CD_PARAM'].includes(x.code));
  const errors = checkReport.filter(x => x.level === 'error').length, warnings = checkReport.filter(x => x.level === 'warn').length;
  const nameInput = $('#board-name'); if (document.activeElement !== nameInput) nameInput.value = board.boardName;
  $('#board-summary').innerHTML = `<span class="sum-total">${nums(board.room.total)}人</span><span class="sum-sep"> · </span>` + board.factions.map((f, i) => `${i ? '<span class="sum-sep"> / </span>' : ''}<span class="sum-camp" style="${toneStyle(f.id)}"><i aria-hidden="true"></i>${esc(f.name.replace(/阵营$/, ''))} ${board.room.counts[f.id]}</span>`).join('');
  $('#issue-badge').textContent = errors || '';
  const perStep = {room: 0, factions: 0, wins: 0, roles: 0};
  for (const x of checkReport) if (x.level === 'error') { const s = issueStep(x); if (s in perStep) perStep[s]++; }
  for (const [s, n] of Object.entries(perStep)) { const b = $(`[data-step-badge="${s}"]`); if (b) { b.textContent = n || ''; b.title = n ? n + ' 项待修正' : ''; } }
  const status = $('#footer-status');
  status.innerHTML = nums(errors ? errors + ' 项待修正' : '人数与已知规则通过' + (warnings ? ' · ' + warnings + ' 项提醒' : ''));
  status.classList.toggle('has-errors', !!errors);
  $('#next-step').textContent = STEP_INFO[tab].next;
  $('#prev-step').hidden = tab === 'room';
  $('#footer-hint').textContent = STEP_INFO[tab].hint;
  document.body.dataset.step = tab;
  const idx = STEPS.indexOf(tab);
  $$('.steps [data-tab]').forEach(n => { const i = STEPS.indexOf(n.dataset.tab); n.classList.toggle('active', i === idx); n.classList.toggle('passed', i < idx); n.setAttribute('aria-current', i === idx ? 'step' : 'false'); });
}

/* ---------- 渲染 ---------- */
function captureSeats() { const m = new Map(); $$('.seat-ring .seat').forEach(s => m.set(s.dataset.seat, s.getBoundingClientRect())); return m; }
function playSeats(before) {
  if (!before || !Element.prototype.animate || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  $$('.seat-ring .seat').forEach(s => {
    const r0 = before.get(s.dataset.seat), r1 = s.getBoundingClientRect();
    if (!r0) { s.animate([{transform: 'translate(-50%,-50%) scale(.2)', opacity: 0}, {transform: 'translate(-50%,-50%) scale(1)', opacity: 1}], {duration: 280, easing: 'cubic-bezier(.2,1.3,.4,1)'}); return; }
    const dx = r0.left - r1.left, dy = r0.top - r1.top;
    if (Math.abs(dx) + Math.abs(dy) < 1) return;
    s.animate([{transform: `translate(calc(-50% + ${dx}px),calc(-50% + ${dy}px))`}, {transform: 'translate(-50%,-50%)'}], {duration: 300, easing: 'cubic-bezier(.3,.8,.3,1)'});
  });
}
function render() {
  // 替换内容时被移除的输入框可能再触发一次 change；重入时延后到本次绘制结束再画。
  if (rendering) { renderAgain = true; return; }
  rendering = true;
  try { paint(); } finally { rendering = false; }
  if (renderAgain) { renderAgain = false; render(); }
}
function paint() {
  const before = lastRenderTab === tab && !justDrew ? captureSeats() : null;
  header();
  const view = {room: roomView, factions: factionsView, wins: winsView, roles: rolesView, review: reviewView}[tab]();
  $('#content').innerHTML = `<div class="page page-${tab}">${view}</div>`;
  const page = $('#content .page');
  if(navigationContext && tab!=='review') $('#content .title-row').insertAdjacentHTML('afterend', '<div class="issue-navigation"><span>已定位到需要调整的设置</span><button class="btn btn-ghost btn-sm" data-action="back-review">返回预览</button></div>');
  if (tab === 'review') renderSimulation();
  if (tab === 'wins') revealCamp();
  if (lastPageReset && (lastPageReset.kind === 'global' || lastPageReset.tab === tab)) $('#content .title-row').insertAdjacentHTML('afterend', `<div class="page-reset-feedback" role="status">${icon('undo')}<span>${esc(lastPageReset.label)}${resetWords(lastPageReset.kind)[0]}</span><button class="btn btn-ghost btn-sm" data-action="undo-page-reset">${resetWords(lastPageReset.kind)[1]}</button></div>`);
  if (board.room.total < E.ROOM_LIMITS.min || board.room.total > E.ROOM_LIMITS.max) page.insertAdjacentHTML('afterbegin', `<div class="note warning" role="alert">此草稿为 ${board.room.total} 人，房间支持 ${E.ROOM_LIMITS.min}–${E.ROOM_LIMITS.max} 人，请调整人数及阵营分配。</div>`);
  if (board.roles.some(r => r.camp === 3 && E.isCustom(r))) page.insertAdjacentHTML('afterbegin', '<div class="note warning" role="alert">旧草稿中的空白中立角色已保留，请到“搭配技能”为其选择鹅、鸭或新阵营。</div>');
  $$('[data-room-range]').forEach(setPct);
  if (before) playSeats(before);
  lastRenderTab = tab; justDrew = false;
}
function renderInPlace() {
  const selectors = ['#content', '.roster-list', '.role-workspace', '.faction-list', '.wins-editor', '.faction-rail', '.strip-chips', '.room-col:first-child', '.room-col:last-child'];
  if (tab === 'factions') selectors.push('.allocation-faction-list', '.allocation-detail-scroll');
  const positions = selectors.map(selector => [selector, $(selector)?.scrollTop || 0]);
  const railLeft = $('.allocation-faction-list')?.scrollLeft;
  render();
  for (const [selector, top] of positions) { const node = $(selector); if (node) node.scrollTop = top; }
  if (railLeft != null && $('.allocation-faction-list')) $('.allocation-faction-list').scrollLeft = railLeft;
}
function go(next) { navigateTo({tab:next}); }
function openCamp(camp){navigateTo({tab:'wins',camp:Number(camp),kind:'goals'});}
function setPct(range) { const min = Number(range.min), max = Number(range.max), v = Math.min(max, Math.max(min, Number(range.value))); range.style.setProperty('--pct', ((v - min) / (max - min || 1) * 100).toFixed(1) + '%'); }

function number(label,value,data,min=0,max=100000){return numberField(label,value,data,'param-'+data.replace(/[^a-zA-Z0-9_-]+/g,'-'),min,max);}

/* ---------- 通用部件 ---------- */
function title(n, p) {
  return `<div class="title-row"><span class="title-badge" aria-hidden="true">${stepArt(STEP_INFO[tab].icon)}</span><div class="title-copy"><h2 class="page-title">${n}</h2><p>${p}</p></div><button class="btn btn-ghost btn-sm page-reset-button" data-action="reset-page" ${tab === 'roles' && !role() ? 'disabled' : ''}>${icon('undo')}<span>${tab === 'roles' ? '重置当前技能' : tab === 'review' ? '清空预览' : '重置本页'}</span></button></div>`;
}
const options = (obj, val) => Object.entries(obj).map(([k, v]) => `<option value="${esc(k)}" ${String(val) === String(k) ? 'selected' : ''}>${esc(v)}</option>`).join('');
function stepperHtml(inputHtml, id, step = 1, label = '', unit = '') {
  return `<span class="stepper"><button type="button" class="step-btn" data-step-for="${esc(id)}" data-delta="-${step}" aria-label="减少${esc(label)}">${icon('minus')}</button>${inputHtml}${unit ? `<span class="stepper-unit">${esc(unit)}</span>` : ''}<button type="button" class="step-btn" data-step-for="${esc(id)}" data-delta="${step}" aria-label="增加${esc(label)}">${icon('plus')}</button></span>`;
}
function numberField(label, value, data, id, min = 0, max = 100000, step = 1) {
  return `<div class="param-field"><span>${label}</span>${stepperHtml(`<input id="${esc(id)}" type="number" min="${min}" max="${max}" value="${value}" ${data} aria-label="${esc(label)}" inputmode="numeric">`, id, step, label)}</div>`;
}
function toggleField(key, label, value, on = '允许', off = '禁止') {
  return `<label class="toggle-field room-option"><span class="field-label">${label}</span><span class="switch"><input type="checkbox" role="switch" data-room-toggle="${key}" data-on="${on}" data-off="${off}" aria-label="${label}" ${value ? 'checked' : ''}><i aria-hidden="true"></i></span><em class="switch-state">${value ? on : off}</em></label>`;
}

/* ---------- 会议桌 ---------- */
function planTokens() {
  const list = [];
  for (const f of board.factions) for (let i = 0; i < (board.room.counts[f.id] || 0); i++) list.push({camp: f.id});
  while (list.length < board.room.total) list.push({camp: null});
  return list.map((t, i) => ({...t, over: i >= board.room.total}));
}
function ringPoint(i, n) { const a = -Math.PI / 2 + i * 2 * Math.PI / n; return [50 + 45.5 * Math.cos(a), 50 + 41.5 * Math.sin(a)]; }
function ringSize(n) { return n <= 10 ? 'ring-lg' : n <= 16 ? 'ring-md' : 'ring-sm'; }
function seatRing(tokens) {
  const n = Math.max(1, tokens.length);
  return `<div class="seat-ring ${ringSize(n)}" aria-hidden="true">${tokens.map((t, i) => {
    const [x, y] = ringPoint(i, n), f = t.camp != null ? E.faction(board, t.camp) : null, art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
    return `<span class="seat ${f ? '' : 'seat-open'} ${t.over ? 'seat-over' : ''}" data-seat="${i}" style="left:${x.toFixed(2)}%;top:${y.toFixed(2)}%;${f ? toneStyle(f.id) : ''}" title="${f ? esc(f.name) : '待分配'}">${art ? artImage(art, '', '', false) : `<b>${f ? esc([...f.name][0]) : '?'}</b>`}</span>`;
  }).join('')}</div>`;
}
function seatStrip() { return `<div class="seat-strip" aria-hidden="true">${planTokens().map(t => `<i class="${t.camp == null ? 'open' : ''} ${t.over ? 'over' : ''}" style="${t.camp != null ? toneStyle(t.camp) : ''}"></i>`).join('')}</div>`; }
function allocationSummary() {
  const {delta} = allocation();
  if (delta !== 0) return `<p class="alloc-note ${delta < 0 ? 'danger' : ''}" role="status">${icon('alert')}<span>${nums(delta > 0 ? '还需分配 ' + delta + ' 人' : '多分配了 ' + (-delta) + ' 人')}</span><button class="btn btn-ghost btn-sm" data-tab="factions">分配阵营 →</button></p>`;
  return `<div class="seat-legend">${board.factions.filter(f => board.room.counts[f.id] > 0).map(f => `<span style="${toneStyle(f.id)}"><i></i>${esc(f.name)} ${board.room.counts[f.id]}</span>`).join('')}</div>`;
}

/* ---------- 第 1 步：设置房间 ---------- */
function roomOption(key) {
  const d = E.ROOM_FIELDS[key], value = board.room[key];
  if (d.type === 'boolean') return toggleField(key, d.label, value);
  const range = D.custom[0][key], values = [...new Set([...d.choices, value])].sort((a, b) => a - b), custom = key !== 'meeting_amount';
  return `<label class="field room-option"><span class="field-label">${ROOM_ICON[key] ? icon(ROOM_ICON[key]) : ''}${d.label}</span><select data-room="${key}" aria-label="${d.label}">${options(Object.fromEntries(values.map(v => [v, v === 0 ? '关闭' : v + ' ' + d.unit])), value)}${custom ? '<option value="custom">自定义…</option>' : ''}</select>${custom ? `<input hidden type="number" data-room="${key}" aria-label="自定义${d.label}" min="${range[0]}" max="${range[1]}" value="${value}" inputmode="numeric">` : ''}</label>`;
}
function rangeField(key, label, ic) {
  const [min, max] = D.custom[0][key], v = board.room[key], id = 'room-' + key;
  return `<div class="range-field"><div class="range-top"><label class="field-label" for="${id}">${icon(ic)}${label}</label>${stepperHtml(`<input id="${id}" type="number" min="${min}" max="${max}" value="${v}" data-room="${key}" inputmode="numeric">`, id, 1, label)}</div><input type="range" min="${min}" max="${max}" value="${Math.min(max, Math.max(min, v))}" data-room-range="${key}" aria-label="${label}"><div class="range-scale"><span>${min}</span><span>${max}</span></div></div>`;
}
function roomView() {
  const r = board.room;
  return title('这局，想怎么玩？', '先选人数，其他设置可以先用默认。') + `
<div class="room-grid">
 <div class="room-col room-col-people">
 <section class="panel room-hero" aria-labelledby="room-people-title">
  <div class="panel-head"><div><h3 class="panel-title" id="room-people-title">房间人数</h3><p class="panel-sub">一起开一局</p></div><span class="tag">${icon('seat')}${E.ROOM_LIMITS.min}–${E.ROOM_LIMITS.max} 人</span></div>
  <div class="room-people-layout">
  <div class="seat-table">
   <div class="table-top" aria-hidden="true"></div>
   ${seatRing(planTokens())}
   <div class="table-center">
    <button class="round-btn" data-total-delta="-1" aria-label="减少房间人数" ${r.total <= E.ROOM_LIMITS.min ? 'disabled' : ''}>${icon('minus')}</button>
    <label class="people-number"><span class="sr-only">房间人数</span><input type="number" aria-label="房间人数" min="${E.ROOM_LIMITS.min}" max="${E.ROOM_LIMITS.max}" value="${r.total}" data-room="total" inputmode="numeric"><span>人</span></label>
    <button class="round-btn" data-total-delta="1" aria-label="增加房间人数" ${r.total >= E.ROOM_LIMITS.max ? 'disabled' : ''}>${icon('plus')}</button>
   </div>
  </div>
  <div class="room-people-controls">
  <div class="people-presets" role="group" aria-label="常用人数">${[E.ROOM_LIMITS.min, 6, 8, 10, 12, E.ROOM_LIMITS.max].map(n => `<button class="chip ${r.total === n ? 'selected' : ''}" data-total-preset="${n}" aria-pressed="${r.total === n}">${nums(n)} 人</button>`).join('')}</div>
  <div class="js-alloc">${allocationSummary()}</div>
  </div>
  </div>
 </section>

 </div>
 <div class="room-col room-col-settings">
  <section class="panel room-pace">
   <div class="panel-head"><h3 class="panel-title">对局节奏</h3></div>
   <div class="pace-fields">${rangeField('hit_cd', '击倒冷却（秒）', 'swords')}${rangeField('task', '房间总任务数', 'check')}</div>
  </section>
  <section class="panel meeting-settings">
   <div class="panel-head"><div><h3 class="panel-title">开会怎么聊？</h3><p class="panel-sub">决定讨论、投票和拍铃的节奏。</p></div><span class="tag">${icon('bell')}会议设置</span></div>
   <div class="meeting-grid meeting-main">${['meeting_amount', 'discuss_cd', 'vote_cd', 'first_bell_cd', 'meeting_cd'].map(roomOption).join('')}</div>
   <p class="setting-hint" style="margin-top:12px">拍铃次数全局共用，每人最多一次；报告鸡腿不占次数。</p>
   <details class="room-more" ${roomMoreOpen ? 'open' : ''}><summary class="disclosure">更多会议设置</summary>
    <div class="meeting-grid">${['meeting_hit_cd', 'meeting_destroy_cd'].map(roomOption).join('')}</div>
    <div class="toggle-list">${['allow_speak', 'discuss_chat', 'discuss_emojis', 'allow_report_dead'].map(roomOption).join('')}${toggleField('hide', '放逐后身份', board.room.hide, '隐藏', '公开')}</div>
   </details>
  </section>
  <section class="panel room-intro">
  <details class="board-description"><summary class="disclosure">写点玩法介绍 <span>选填</span></summary><label class="board-intro"><span class="sr-only">板子介绍</span><textarea maxlength="300" data-description placeholder="例如：侦探与炸弹的欢乐对决">${esc(board.description)}</textarea></label></details>
  </section>
 </div>
</div>`;
}

/* ---------- 第 2 步：分配阵营 ---------- */
function allocationStatus() {
  const {delta} = allocation();
  return `<span class="alloc-status ${delta === 0 ? 'ok' : 'danger'}" data-alloc-status>${icon(delta === 0 ? 'check' : 'alert')}<span>${nums(delta === 0 ? '人数齐了' : delta > 0 ? '还差 ' + delta + ' 人' : '多了 ' + (-delta) + ' 人')}</span></span>`;
}
// Only the faction allocation page uses this workspace and selection state.
let allocationCamp = 1;

function factionsView() {
  const current = E.faction(board, allocationCamp) || board.factions[0];
  allocationCamp = current.id;
  const full = E.customFactionCount(board) >= E.MAX_CUSTOM_FACTIONS;
  const total = `<strong>${nums(board.room.total)}<small> 人局</small></strong>`;
  return title('分配阵营', '先分人数，再挑候选。开局按阵营随机抽取。') + `
<div class="allocation-workspace">
 <aside class="allocation-sidebar" aria-label="阵营列表">
  <div class="allocation-overview">
   <div class="faction-total">${total}<button type="button" class="btn-link allocation-total-compact" data-tab="room" aria-label="修改总人数" title="修改总人数">${total}${icon('pencil')}</button>${allocationStatus()}</div>
   <div class="js-seat-strip">${seatStrip()}</div>
   <button type="button" class="btn-link allocation-room" data-tab="room" aria-label="修改总人数" title="修改总人数"><span>修改总人数</span>${icon('pencil')}</button>
  </div>
  <nav class="allocation-faction-list" aria-label="选择要编辑的阵营">${board.factions.map(f => `
   <button type="button" class="allocation-faction ${current.id === f.id ? 'selected' : ''}" data-allocation-camp="${f.id}" aria-pressed="${current.id === f.id}" aria-controls="allocation-detail" style="${toneStyle(f.id)}" title="${esc(f.name)}">
    ${emblem(f, 'sm')}<span class="allocation-faction-name" data-allocation-name="${f.id}">${nameHtml(f.name)}</span><span class="allocation-faction-count" data-allocation-count="${f.id}">${board.room.counts[f.id]} 人</span>
   </button>`).join('')}</nav>
  <div class="allocation-sidebar-footer"><button type="button" class="btn btn-gold" data-action="add-faction" ${full ? 'disabled' : ''} ${full ? `title="最多可创建 ${E.MAX_CUSTOM_FACTIONS} 个新阵营"` : ''}>${icon('plus')}${full ? '新阵营已满' : '新增阵营'}</button></div>
 </aside>
 ${factionCard(current)}
</div>`;
}

function factionCard(f) {
  const p = E.poolStats(board, f.id), members = board.roles.filter(r => r.camp === f.id), custom = f.kind === 'custom';
  const movable = f.id === 3 ? [] : board.roles.filter(r => E.isCustom(r) && r.camp !== f.id);
  const shown = membersOpen[f.id] !== false, moveState = E.customRoleAddStatus(board, f.id, '__moving__');
  return `<article id="allocation-detail" class="allocation-detail" data-faction-card="${f.id}" aria-label="${esc(f.name)}设置" style="${toneStyle(f.id)}">
   <header class="allocation-details-head">
    <div class="faction-head">${emblem(f)}<div>${custom ? `<label class="allocation-rename"><input aria-label="${esc(f.name)}名称" maxlength="20" value="${esc(f.name)}" data-faction-name="${f.id}">${icon('pencil')}</label>` : `<h3>${nameHtml(f.name)}</h3>`}<small>${f.id === 3 ? '各自获胜' : '共同获胜'}</small></div></div>
    <div class="faction-seats"><span>出场人数</span><span class="stepper"><button type="button" class="step-btn" data-count-step="${f.id}" data-delta="-1" aria-label="减少${esc(f.name)}人数" ${p.seats === 0 ? 'disabled' : ''}>${icon('minus')}</button><input aria-label="${esc(f.name)}人数" type="number" min="0" max="${E.ROOM_LIMITS.max}" value="${p.seats}" data-count="${f.id}" inputmode="numeric"><button type="button" class="step-btn" data-count-step="${f.id}" data-delta="1" aria-label="增加${esc(f.name)}人数" ${p.seats >= E.ROOM_LIMITS.max ? 'disabled' : ''}>${icon('plus')}</button></span></div>
   </header>
   <div class="allocation-pool-toolbar">
    <button type="button" class="allocation-pool-toggle" data-allocation-toggle="${f.id}" aria-expanded="${shown}" aria-controls="allocation-candidates">${icon('chevron')}<span data-pool-count="${f.id}">${p.candidates} 个候选 · 随机抽 ${p.seats} 人</span></button>
    ${custom ? '' : `<button type="button" class="btn btn-gold btn-sm" data-add-original-camp="${f.id}" aria-label="添加已有职业">${icon('plus')}加职业</button>`}
    ${f.id === 3 ? '' : `<button type="button" class="btn ${custom ? 'btn-gold' : 'btn-ghost'} btn-sm" data-new-role-camp="${f.id}" aria-label="创建空白角色" ${customRoleButtonAttrs(f.id)}>${artImage(CUSTOM_ICON, 'custom-entry-icon', '', false)}建角色</button>`}
   </div>
   <div class="allocation-detail-scroll">
    <div class="allocation-candidates" id="allocation-candidates" ${shown ? '' : 'hidden'}>
     ${members.map(r => `<div class="role-chip allocation-role-chip">
       <button type="button" class="role-chip-main" data-edit-role="${esc(r.uid)}" aria-label="编辑${esc(r.name)}" title="编辑${esc(r.name)}">${roleAvatar(r.templateCareerId,r.camp,'sm')}<span>${nameHtml(r.name)}</span>${r.count > 1 ? `<small class="copies" title="单局最多出现 ${r.count} 次">≤${r.count}</small>` : ''}</button>
       ${E.isCustom(r) ? `<button type="button" class="role-chip-copy" data-copy-role="${esc(r.uid)}" aria-label="复制${esc(r.name)}" title="复制角色">${icon('copy')}</button>` : ''}
       <button type="button" class="role-chip-x" data-remove-candidate="${esc(r.uid)}" aria-label="移除${esc(r.name)}" title="移出候选池">${icon('x')}</button>
     </div>`).join('') || `<p class="empty-pool">${f.id === 3 ? '还没有候选。点「加职业」添加中立职业。' : `还没有候选。点「${custom ? '建角色' : '加职业'}」开始添加。`}</p>`}
    </div>
    <div class="allocation-role-actions">
     ${roleClip && f.id !== 3 ? `<button type="button" class="btn btn-ghost btn-sm paste-role" data-paste-role-camp="${f.id}" aria-label="把「${esc(roleClip.name)}」粘贴到${esc(f.name)}" ${pasteRoleButtonAttrs(f.id)}>${icon('paste')}粘贴角色</button>` : ''}
     ${movable.length ? `<label class="assign-role"><span class="sr-only">移入自创角色</span><select aria-label="为${esc(f.name)}加入自创角色" data-assign-faction="${f.id}" ${moveState.allowed ? '' : `disabled title="${esc(moveState.reason)}"`}><option value="">移入自创角色…</option>${movable.map(r => `<option value="${esc(r.uid)}">${esc(r.name)}（${esc(factionLabel(r.camp))}）</option>`).join('')}</select></label>` : ''}
     <button type="button" class="btn-link" data-open-camp="${f.id}">设置此阵营的胜利 ${icon('chevron')}</button>
     ${custom ? `<button type="button" class="btn-link danger" data-delete-faction="${f.id}">${icon('trash')}删除空阵营</button>` : ''}
    </div>
   </div>
  </article>`;
}

// Reveal only inside the rail. Changing the selected team mustn't move the page.
function revealAllocationCamp() {
  const rail = $('.allocation-faction-list'), current = rail?.querySelector('.selected');
  if (!current) return;
  const outer = rail.getBoundingClientRect(), item = current.getBoundingClientRect();
  if (item.top < outer.top) rail.scrollTop -= outer.top - item.top + 3;
  if (item.bottom > outer.bottom) rail.scrollTop += item.bottom - outer.bottom + 3;
  if (item.left < outer.left) rail.scrollLeft -= outer.left - item.left + 3;
  if (item.right > outer.right) rail.scrollLeft += item.right - outer.right + 3;
}

function switchAllocationCamp(camp) {
  if (tab !== 'factions' || camp === allocationCamp || !E.faction(board, camp)) return;
  allocationCamp = camp;
  renderInPlace();
  const detail = $('.allocation-detail-scroll');
  if (detail) detail.scrollTop = 0;
  revealAllocationCamp();
  $(`[data-allocation-camp="${camp}"]`)?.focus({preventScroll: true});
}

function refreshAllocationRows() {
  if (tab !== 'factions') return;
  $$('[data-allocation-count]').forEach(node => { node.textContent = board.room.counts[node.dataset.allocationCount] + ' 人'; });
  $$('[data-allocation-name]').forEach(node => {
    const f = E.faction(board, Number(node.dataset.allocationName));
    if (!f) return;
    const button = node.closest('button');
    if (button.title !== f.name) {
      button.title = f.name;
      node.innerHTML = nameHtml(f.name);
      const emblemLetter = button.querySelector('.emblem b');
      if (emblemLetter) emblemLetter.textContent = [...f.name][0];
    }
  });
}
function toggleAllocationPool(camp, button) {
  if (tab !== 'factions' || camp !== allocationCamp) return;
  const pool = $('#allocation-candidates');
  membersOpen[camp] = pool.hidden;
  button.setAttribute('aria-expanded', String(membersOpen[camp]));
  pool.hidden = !membersOpen[camp];
}

function syncAllocationName(input) {
  const f = E.faction(board, Number(input.dataset.factionName));
  if (!f) return;
  input.value = f.name;
  input.setAttribute('aria-label', f.name + '名称');
  const detail = input.closest('.allocation-detail');
  detail.setAttribute('aria-label', f.name + '设置');
  detail.querySelector('.faction-head .emblem b').textContent = [...f.name][0];
  detail.querySelector('[data-count]').setAttribute('aria-label', f.name + '人数');
  detail.querySelector('[data-delta="-1"]').setAttribute('aria-label', '减少' + f.name + '人数');
  detail.querySelector('[data-delta="1"]').setAttribute('aria-label', '增加' + f.name + '人数');
}

function removeCandidate(uid){const index=board.roles.findIndex(r=>r.uid===uid);if(index<0)return;const before=snapshotEditor(board.roles[index].name,'remove-role'),camp=board.roles[index].camp,focusWasRemove=document.activeElement?.dataset.removeCandidate===uid;E.removeRole(board,uid);if(selected===uid){const visible=board.roles.filter(r=>!rosterSearch||(r.name+E.campName(board,r.camp)).includes(rosterSearch));if(!visible.length)rosterSearch='';selected=(visible.find(r=>board.roles.indexOf(r)>=index)||visible.at(-1)||board.roles[Math.min(index,board.roles.length-1)])?.uid||'';paramSkill=0;}mark();lastPageReset=before;renderInPlace();if(focusWasRemove){const card=document.querySelector(`[data-faction-card="${camp}"]`);card?.querySelector('[data-remove-candidate],[data-add-original-camp],[data-new-role-camp]')?.focus({preventScroll:true});}toast('已删除角色，可撤销');}

/* ---------- 自创角色的复制与粘贴 ----------
 * 只针对自创（空白）角色：复制名称、出场上限、技能和技能参数；粘贴时生成一个新角色，放进指定阵营。
 * 剪贴板留在本机浏览器里（内存 + localStorage），换一块板子也能粘贴；不读写系统剪贴板。 */
function readRoleClip() {
  try {
    const c = JSON.parse(localStorage.getItem(ROLE_CLIP) || 'null');
    return c && c.v === 1 && typeof c.name === 'string' && c.name.trim() && c.slots && typeof c.slots === 'object' ? c : null;
  } catch { return null; }
}
function copyRole(uid) {
  const r = board.roles.find(x => x.uid === uid); if (!r) return;
  if (!E.isCustom(r)) { toast('已有职业不能复制，只有自创角色可以'); return; }
  roleClip = {v: 1, name: r.name, count: r.count, camp: r.camp, slots: clone(r.slots), skillOverrides: clone(r.skillOverrides || {})};
  try { localStorage.setItem(ROLE_CLIP, JSON.stringify(roleClip)); } catch { /* 存不进本机不影响这一次粘贴 */ }
  const active = document.activeElement, back = active?.dataset?.copyRole ? `[data-copy-role="${CSS.escape(active.dataset.copyRole)}"]` : active?.dataset?.editRole ? `[data-edit-role="${CSS.escape(active.dataset.editRole)}"]` : active?.dataset?.selectRole ? `[data-select-role="${CSS.escape(active.dataset.selectRole)}"]` : '';
  renderInPlace(); if (back) $(back)?.focus({preventScroll: true});
  toast('已复制「' + r.name + '」。在鹅、鸭或新阵营里点“粘贴”，或按 Ctrl/⌘ + V');
}
// 粘贴出来的角色不与现有角色重名：原名没被占用就沿用，否则加“副本”。
function pastedRoleName(name) {
  const names = new Set(board.roles.map(r => r.name)), base = (String(name || '').trim() || '自创角色').replace(/ 副本\d*$/, '').slice(0, 20);
  if (!names.has(base)) return base;
  for (let n = 1; n < 1000; n++) { const suffix = ' 副本' + (n > 1 ? n : ''), candidate = base.slice(0, 20 - suffix.length) + suffix; if (!names.has(candidate)) return candidate; }
  return base;
}
// 粘贴到哪个阵营：指定的 → 复制时所在的 → 正在编辑的角色所在的 → 第一个能放自创角色的阵营。中立只收已有职业。
function pasteCamp(prefer) {
  const usable = id => Number.isInteger(id) && id !== 3 && !!E.faction(board, id);
  return [prefer, roleClip?.camp, tab === 'roles' ? role()?.camp : null, ...board.factions.map(f => f.id)].map(x => x == null ? NaN : Number(x)).find(usable) ?? null;
}
function pasteRole(prefer = null) {
  if (!roleClip) { toast('还没有复制角色：先在自创角色上点“复制”'); return; }
  if (prefer != null && Number(prefer) === 3) throw Error('中立阵营只能添加已有职业，请粘贴到鹅、鸭或新阵营');
  if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('候选池最多300个角色条目');
  const camp = pasteCamp(prefer); if (camp == null) throw Error('请先创建或选择一个阵营。');
  const r = E.makeCustomRole(board, camp);
  r.name = pastedRoleName(roleClip.name);
  try { E.setRoleCount(r, roleClip.count); } catch { /* 上限不合规时保持默认 1 */ }
  r.slots = {...r.slots, ...clone(roleClip.slots)}; r.skillOverrides = clone(roleClip.skillOverrides || {});
  // 剪贴板可能来自另一块板子或更早的版本：先在副本上按草稿规则检查，不合格就不粘贴。
  const trial = clone(board); trial.roles.push(clone(r));
  try { E.validateShape(clone(E.exportDraft(trial))); } catch (error) { throw Error('这个角色粘贴不了：' + error.message); }
  board.roles.push(r); mark();
  if (tab === 'roles') {
    selected = r.uid; rosterSearch = ''; revealRosterRole(r); paramSkill = 0; renderInPlace();
    const item = $(`[data-select-role="${CSS.escape(r.uid)}"]`); item?.scrollIntoView({block: 'nearest'}); item?.focus({preventScroll: true});
  } else {
    allocationCamp = camp; membersOpen[camp] = true; renderInPlace(); revealAllocationCamp();
    const roleButton = $(`[data-edit-role="${CSS.escape(r.uid)}"]`);
    roleButton?.scrollIntoView({block: 'nearest'}); roleButton?.focus({preventScroll: true});
  }
  toast('已粘贴「' + r.name + '」到' + E.campName(board, camp) + (E.compatibilityIssues(r).length ? '；有技能在这里暂不可用，请到“搭配技能”处理' : ''));
}

/* ---------- 第 4 步：设置胜利（左边选阵营，右边是这个阵营怎么赢） ---------- */
// 一级界面按阵营看：原有条件 + 额外胜利条件，目标和权重直接在卡片上改。
// 添加条件走“添加胜利条件”弹窗：先选一个条件，再决定它应用到哪些阵营（打开弹窗的阵营默认选中）。
// 数据仍然按阵营保存在 board.campEvents，草稿格式不变。
const condTypes = () => Object.keys(E.eventCatalog);
const condCategories = () => [...new Set(Object.values(E.eventCatalog).map(d => d.category))];
const condIcon = type => COND_ICON[type] || CATEGORY_ICON[E.eventCatalog[type]?.category] || 'target';
function activeCampRule() { return E.campRule(board, ruleCamp); }
function condHolders(type) { return board.factions.filter(f => E.campRule(board, f.id)?.events.some(e => e.type === type)); }
function findEvent(id) { for (const rule of board.campEvents) { const event = rule.events.find(e => e.id === id); if (event) return {rule, event}; } return null; }
function factionMissingWin(f) { return f.kind === 'custom' && !E.campRule(board, f.id)?.events.length; }
function sortedEvents(camp) { return [...(E.campRule(board, camp)?.events || [])].sort((a, b) => b.weight - a.weight); }
// 计数范围的说明分成“短句 + 补充”：位置窄时只显示短句。
function scopeParts(f, d) { return f.id === 3 ? (d.aggregation === 'personalMax' ? ['只看本人记录', '，各自获胜'] : ['每人各自累计', '，各自获胜']) : d.aggregation === 'personalMax' ? ['取个人最高记录', '，队友不相加'] : ['全队共享进度', '，达成后全员获胜']; }
function originalText(f) { return f.id === 3 ? '每个原角色保留自己的胜利条件。' : E.careers.get(f.id === 1 ? 1 : 101).win_condition_des; }
// 检查报告按阵营给出无法完成的条件名；这里据此在对应的条件卡片上就地提示。
function issueNames(issue) { const m = /「([^」]*)」无法/.exec(String(issue?.text || '')); return m ? m[1].split('、') : []; }
function blockedIssue(camp, type) { const name = E.eventCatalog[type].name; return checkReport.find(x => x.camp === camp && ['EXTRA_UNREACHABLE', 'MEETING_GOAL_UNREACHABLE'].includes(x.code) && issueNames(x).includes(name)) || null; }
function holderStack(holders, max = 3) {
  if (!holders.length) return '';
  return `<span class="holder-stack" title="已应用：${esc(holders.map(f => f.name).join('、'))}">${holders.slice(0, max).map(f => emblem(f, 'xs')).join('')}${holders.length > max ? `<b>+${holders.length - max}</b>` : ''}<span class="sr-only">已应用到 ${holders.length} 个阵营</span></span>`;
}
// 中立阵营各算各的：把条件说明里的“阵营／成员”换成“本人”。
function campEventCopy(text, camp = ruleCamp) { if (camp !== 3) return text; return text.replace('队友投中同一人只计一次。', '本人对同一目标只计一次。').replace('每个行动回合本阵营最多计一次。', '本人每个行动回合最多计一次。').replace('同一场会议本阵营最多计一次。', '本人每场会议最多计一次。').replaceAll('一名成员', '本人').replace('中立只看本人，', '').replace('仍存活成员的个人记录，不相加', '本人存活时的个人记录，不与其他中立相加').replace('存活成员个人连续记录', '本人存活时的连续记录'); }
function baseBlock(f) {
  // 新阵营没有基础胜利条件，只能靠额外胜利条件获胜：这里只放一句说明，不再提供选择。
  if (f.kind === 'custom') return `<div class="base-rule base-none" data-base-none="${f.id}"><span class="lock">${icon('info')}</span><div><h4>只用额外胜利条件 <span class="tag">新阵营</span></h4><p>新阵营没有基础胜利条件：至少添加一个额外条件，达成后阵营全员获胜。</p></div></div>`;
  if (f.id === 3) { const neutrals = E.D.eligibleCareerIds.map(id => E.careers.get(id)).filter(c => c.camp === 3); return `<div class="base-rule"><span class="lock">${icon('lock')}</span><div><h4>原胜利条件 <span class="tag">固定</span></h4><p>每个原角色保留自己的胜利条件。</p><button class="btn-link" data-action="view-original-neutrals">查看 ${neutrals.length} 种原条件</button></div></div>`; }
  return `<div class="base-rule"><span class="lock">${icon('lock')}</span><div><h4>原胜利条件 <span class="tag">固定</span></h4><p data-original-condition="${f.id}">${esc(originalText(f))}</p></div></div>`;
}
function winsView() {
  if (!E.faction(board, ruleCamp)) ruleCamp = 1;
  const g = activeCampRule(), f = E.faction(board, ruleCamp), neutral = ruleCamp === 3, custom = f.kind === 'custom';
  const events = sortedEvents(f.id), full = events.length >= E.MAX_CAMP_EVENTS;
  return title('怎样才算赢？', '原有规则始终生效；也可以给阵营添加优先达成的额外条件。') + `
<div class="wins-layout">
 <nav class="faction-rail faction-tabs" aria-label="选择阵营">
  <p class="rail-title">选择阵营</p>
  ${board.factions.map(x => `<button class="rail-item ${x.id === ruleCamp ? 'selected' : ''}" data-rule-camp="${x.id}" aria-pressed="${x.id === ruleCamp}" style="${toneStyle(x.id)}">${emblem(x, 'sm')}<span class="rail-text">${nameHtml(x.name)}<small>${x.id === 3 ? '各自获胜' : '共同获胜'}</small></span><b class="rail-count" title="额外胜利条件">${E.campRule(board, x.id)?.events.length || 0}</b></button>`).join('')}
 </nav>
 <section class="panel wins-editor" data-camp="${f.id}" style="${toneStyle(f.id)}">
  <header class="wins-head">${emblem(f, 'lg')}<div><h3>${nameHtml(f.name)}</h3><p>${neutral ? '所有中立职业适用，各自完成、各自获胜。' : '达成目标，阵营全员获胜。'}</p></div></header>
  ${baseBlock(f)}
  <div class="goals-header"><h3>额外胜利条件 <small class="${custom ? 'need' : ''}">${custom ? '至少一个' : '选填'}</small></h3><span class="goal-meter" style="--fill:${(g.events.length / E.MAX_CAMP_EVENTS * 100).toFixed(0)}%"><i></i>${g.events.length} / ${E.MAX_CAMP_EVENTS}</span></div>
  <p class="goal-priority-hint">${icon('crown')}<span>权重越大越优先；同时达成时，同权重可并列。${events.length > 1 ? '有多个额外条件时，完成任意一个即可获胜。' : ''}</span></p>
  ${events.length ? `<div class="goal-list">${events.map((e, i) => goalCard(f, e, i)).join('')}</div><button class="btn btn-ghost add-goal-button" data-action="add-cond" aria-haspopup="dialog" ${full ? 'disabled' : ''}>${icon('plus')}${full ? '已达 ' + E.MAX_CAMP_EVENTS + ' 个上限' : '添加胜利条件'}</button>` : `<div class="goal-empty">${icon('trophy')}<p>${custom ? '为新阵营选一个胜利条件。' : '沿用原有规则，直接下一步也可以。'}</p><button class="btn btn-gold" data-action="add-cond" aria-haspopup="dialog">${icon('plus')}添加胜利条件</button></div>`}
  <p class="goal-footnote">${neutral ? '达成额外条件时，本人须存活。' : '达成额外条件时，阵营须有人存活。'} ${custom ? '未达成的高权重条件不会阻挡其他条件。' : '额外条件优先于原有规则；未达成的高权重条件不会阻挡其他条件。'}</p>
 </section>
</div>`;
}
function campChip(f, type) {
  const e = E.campRule(board, f.id).events.find(x => x.type === type), d = E.eventCatalog[type];
  return `<span class="camp-chip" style="${toneStyle(f.id)}" title="${esc(f.name)} · ${esc(e.value + ' ' + d.unit)} · 权重 ${e.weight}">${emblem(f, 'xs')}<span>${nameHtml(f.name)}</span></span>`;
}
// 一张额外条件卡片：目标和权重直接改；下面一行说明这个条件还应用到了哪些阵营，并可以再打开弹窗调整。
function goalCard(f, e, i) {
  const d = E.eventCatalog[e.type], vid = 'goal-v-' + e.id, wid = 'goal-w-' + e.id, others = condHolders(e.type).filter(x => x.id !== f.id);
  return `<article class="goal-card ${goalFresh === e.id ? 'fresh' : ''}" data-goal="${esc(e.id)}" data-goal-type="${e.type}"><span class="goal-rank goal-number">${i + 1}</span>
 <div class="goal-copy"><div class="goal-title"><h4><span class="cat" title="${esc(d.category)}">${icon(condIcon(e.type))}</span>${esc(d.name)}</h4><div class="goal-apply">${others.length ? `<span class="goal-apply-label">同时应用于</span>${others.map(x => campChip(x, e.type)).join('')}` : ''}<button class="btn-link goal-apply-link" data-apply-cond="${e.type}" aria-haspopup="dialog" aria-label="调整「${esc(d.name)}」应用到哪些阵营">${others.length ? '调整应用阵营' : '应用到其他阵营'}</button></div></div><p>${esc(campEventCopy(d.description, f.id))}</p>${d.hint ? `<small class="ability-hint">${icon('info')}${esc(d.hint)}</small>` : ''}<details class="goal-detail"><summary>计数说明</summary><p>${esc(campEventCopy(d.detail || d.description, f.id))}</p></details>
  <p class="goal-warn" data-goal-warn="${f.id}" data-warn-type="${e.type}" role="status" ${blockedIssue(f.id, e.type) ? '' : 'hidden'}>${icon('alert')}<span>按当前人数或会议设置无法完成，请调低目标。</span></p>
 </div>
 <div class="goal-side"><div class="goal-controls"><div class="goal-target"><span>目标</span>${stepperHtml(`<input id="${esc(vid)}" aria-label="${esc(d.name)}目标" type="number" min="1" max="999" value="${e.value}" data-event-value="${esc(e.id)}" inputmode="numeric">`, vid, 1, d.name + '目标', d.unit)}</div><div class="goal-weight"><span>权重 · 优先级</span>${stepperHtml(`<input id="${esc(wid)}" aria-label="${esc(d.name)}权重" type="number" min="1" max="${E.MAX_EVENT_WEIGHT}" value="${e.weight}" data-event-weight="${esc(e.id)}" inputmode="numeric">`, wid, 10, d.name + '权重')}</div></div><button class="btn btn-ghost btn-sm danger goal-remove" data-remove-event="${esc(e.id)}" aria-label="从${esc(f.name)}移除${esc(d.name)}">${icon('trash')}移除</button></div>
</article>`;
}
// 把选中的阵营滚进阵营栏的可视范围；只动阵营栏自己，不带动整页。
function revealCamp() {
  const rail = $('.faction-rail'), item = rail?.querySelector('.rail-item.selected'); if (!item) return;
  const r = rail.getBoundingClientRect(), i = item.getBoundingClientRect();
  if (i.top < r.top) rail.scrollTop -= r.top - i.top + 8; else if (i.bottom > r.bottom) rail.scrollTop += i.bottom - r.bottom + 8;
  if (i.left < r.left) rail.scrollLeft -= r.left - i.left + 8; else if (i.right > r.right) rail.scrollLeft += i.right - r.right + 8;
}
function selectCamp(camp, focusRail = false) {
  if (!E.faction(board, Number(camp))) return;
  ruleCamp = Number(camp); renderInPlace();
  const editor = $('.wins-editor'); if (editor) editor.scrollTop = 0;
  revealCamp();
  if (focusRail) $('.faction-rail .rail-item.selected')?.focus({preventScroll: true});
}
// 只从这一个阵营移除；别的阵营里同名的条件不受影响。可以撤销。
function removeGoal(eventId) {
  const hit = findEvent(eventId); if (!hit) return;
  const camp = hit.rule.camp, name = E.eventCatalog[hit.event.type].name, index = sortedEvents(camp).findIndex(e => e.id === eventId);
  const before = snapshotEditor('「' + name + '」', 'remove-cond');
  E.removeCampEvent(board, camp, eventId); mark(); lastPageReset = before; renderInPlace();
  const rest = $$('.goal-card [data-remove-event]'); (rest[Math.min(index, rest.length - 1)] || $('[data-action="add-cond"]'))?.focus({preventScroll: true});
  toast('已从' + E.campName(board, camp) + '移除「' + name + '」，可撤销');
}
function refreshGoalWarnings() {
  if (tab !== 'wins') return;
  $$('[data-goal-warn]').forEach(node => { node.hidden = !blockedIssue(Number(node.dataset.goalWarn), node.dataset.warnType); });
}

/* ---------- “添加胜利条件”弹窗 ----------
 * 左边筛选并选一个条件，右边展开它应用到的阵营（开关、目标、权重）。
 * 从哪个阵营打开，那个阵营就排在最前并默认选中；也可以改成别的阵营，或同时应用到多个阵营。
 * 弹窗里的改动先存在 addCond 里，点“添加条件／保存修改”才写进板子；取消或关闭就丢弃。 */
const AC_ALL = 'all';
function addCondOpen(type = null, camp = null) {
  const home = E.faction(board, Number(camp)) ? Number(camp) : null;
  addCond = {search: '', category: AC_ALL, type: null, camps: {}, home};
  const cats = [[AC_ALL, '全部', condTypes().length], ...condCategories().map(c => [c, c, condTypes().filter(t => E.eventCatalog[t].category === c).length])];
  modal(modalHead(type ? '调整胜利条件' : '添加胜利条件') + `<div class="ac" data-step="pick">
 <section class="ac-pane ac-pick" aria-label="选择胜利条件">
  <p class="ac-step"><b>1</b>选一个胜利条件</p>
  <div class="search-box">${icon('search')}<input id="ac-search" type="search" aria-label="搜索胜利条件" placeholder="搜索胜利条件" autocomplete="off"></div>
  <div class="filter-chips" id="ac-cats" role="group" aria-label="按类别筛选">${cats.map(([key, label, n]) => `<button class="chip ${key === AC_ALL ? 'selected' : ''}" data-ac-cat="${esc(key)}" aria-pressed="${key === AC_ALL}">${esc(label)}<span>${n}</span></button>`).join('')}</div>
  <div class="ac-list" id="ac-list">${addCondItems()}</div>
 </section>
 <section class="ac-pane ac-detail" id="ac-detail" aria-label="应用到的阵营">${addCondDetail()}</section>
</div>
<div class="modal-actions"><span class="ac-summary" id="ac-summary" role="status"></span><span class="spacer"></span><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" id="ac-confirm" data-action="ac-confirm" disabled>添加条件</button></div>`, false, 'add-cond');
  // 触屏上不自动聚焦搜索框，免得一打开就弹出键盘。
  if (type && E.eventCatalog[type]) { addCondPick(type); $('#ac-list .ac-item.selected')?.scrollIntoView({block: 'nearest'}); }
  else { addCondRefreshState(); if (!matchMedia('(pointer: coarse)').matches) $('#ac-search').focus({preventScroll: true}); }
}
function addCondItems() {
  const q = addCond.search.trim().toLowerCase(), home = addCond.home;
  const match = t => { const d = E.eventCatalog[t]; return (addCond.category === AC_ALL || d.category === addCond.category) && (!q || (d.name + d.description + d.category + (d.hint || '')).toLowerCase().includes(q)); };
  const groups = condCategories().map(c => [c, condTypes().filter(t => E.eventCatalog[t].category === c && match(t))]).filter(([, list]) => list.length);
  if (!groups.length) return '<div class="empty">没有符合的胜利条件，换个关键词或类别试试。</div>';
  return groups.map(([category, list]) => `<p class="ac-group">${esc(category)}</p>` + list.map(t => {
    const d = E.eventCatalog[t], holders = condHolders(t), on = addCond.type === t, mine = home ? holders.some(f => f.id === home) : holders.length > 0;
    return `<button class="ac-item ${on ? 'selected' : ''} ${holders.length ? 'in-use' : ''} ${mine ? 'mine' : ''}" data-ac-pick="${t}" aria-pressed="${on}"><span class="cond-ic">${icon(condIcon(t))}</span><span class="ac-item-copy"><strong>${esc(d.name)}</strong><small>${esc(d.description)}</small></span>${holders.length ? `<span class="ac-item-state">${holderStack(holders)}${mine ? '<em>已添加</em>' : ''}</span>` : `<span class="ac-item-default">${esc(d.defaultValue + ' ' + d.unit)}</span>`}</button>`;
  }).join('')).join('');
}
// 打开弹窗的阵营排最前，其余按板子里的顺序。
function addCondFactions() { return [...board.factions].sort((a, b) => (b.id === addCond.home) - (a.id === addCond.home)); }
function addCondDetail() {
  const type = addCond.type;
  if (!type) return `<div class="ac-placeholder">${icon('target')}<p>先在左边选一个胜利条件，<br>这里会展开它应用到的阵营。</p></div>`;
  const d = E.eventCatalog[type];
  return `<button class="btn-link ac-back" data-action="ac-back">${icon('chevron-left')}重新选择条件</button>
 <p class="ac-step"><b>2</b>它影响哪些阵营</p>
 <div class="ac-cond"><span class="cond-badge" aria-hidden="true">${icon(condIcon(type))}</span><div><h3>${esc(d.name)}${d.hint ? `<span class="tag tag-gold">${icon('info')}${esc(d.hint)}</span>` : ''}</h3><p>${esc(d.description)}</p><small>${esc(d.detail || '')}</small></div></div>
 ${addCondAlloc()}
 <div class="ac-camps">${addCondFactions().map(draftRow).join('')}</div>`;
}
// “分配给阵营”一行：已选几个阵营 / 一共几个，旁边是“全选 / 全不选”。已满的阵营选不了，不算在“全选”里。
function addCondAlloc() {
  const list = board.factions, on = list.filter(f => addCond.camps[f.id].on).length;
  const open = list.filter(f => { const c = addCond.camps[f.id]; return c.had || E.campRule(board, f.id).events.length < E.MAX_CAMP_EVENTS; });
  const all = open.length > 0 && open.every(f => addCond.camps[f.id].on), none = on === 0;
  return `<div class="ac-alloc"><h4 id="ac-alloc-title">分配给阵营</h4><span class="goal-meter" style="--fill:${(on / list.length * 100).toFixed(0)}%" aria-label="已选 ${on} 个阵营，共 ${list.length} 个"><i></i><span id="ac-count">${on} / ${list.length}</span></span><div class="segmented ac-bulk" role="group" aria-labelledby="ac-alloc-title"><button data-ac-bulk="all" class="${all ? 'selected' : ''}" aria-pressed="${all}" ${open.length ? '' : 'disabled'}>全选</button><button data-ac-bulk="none" class="${none ? 'selected' : ''}" aria-pressed="${none}">全不选</button></div></div>`;
}
function addCondBulk(mode) {
  if (!addCond || !addCond.type) return;
  for (const f of board.factions) { const c = addCond.camps[f.id]; c.on = mode === 'all' ? c.had || E.campRule(board, f.id).events.length < E.MAX_CAMP_EVENTS : false; }
  const detail = $('#ac-detail'), top = detail.scrollTop;
  detail.innerHTML = addCondDetail(); detail.scrollTop = top; addCondRefreshState();
  $(`[data-ac-bulk="${mode}"]`)?.focus({preventScroll: true});
  const skipped = mode === 'all' ? board.factions.filter(f => !addCond.camps[f.id].on).length : 0;
  if (skipped) toast(skipped + ' 个阵营已有 ' + E.MAX_CAMP_EVENTS + ' 个额外条件，选不了');
}
function draftRow(f) {
  const type = addCond.type, d = E.eventCatalog[type], c = addCond.camps[f.id], rule = E.campRule(board, f.id), home = f.id === addCond.home;
  const full = !c.had && rule.events.length >= E.MAX_CAMP_EVENTS, sid = 'ac-camp-' + f.id, vid = 'ac-v-' + f.id, wid = 'ac-w-' + f.id;
  const count = rule.events.length - (c.had ? 1 : 0) + (c.on ? 1 : 0);
  const scope = scopeParts(f, d), caption = full ? nums(`已有 ${E.MAX_CAMP_EVENTS} 个额外条件，达到上限`) : c.on ? `${esc(scope[0])}<span class="cap-rest">${esc(scope[1])}</span>` : c.had ? '确认后移除这个条件' : f.id === 3 ? '各自获胜' : '共同获胜';
  return `<article class="ac-row ${c.on ? 'on' : ''} ${full ? 'full' : ''} ${home ? 'home' : ''}" data-ac-camp="${f.id}" style="${toneStyle(f.id)}">
 <label class="ac-who" for="${sid}">${emblem(f)}<span class="ac-name">${nameHtml(f.name)}${home ? '<span class="tag ac-home">当前阵营</span>' : ''}<small class="${!c.on && c.had ? 'warn' : ''}">${caption}</small></span></label>
 <span class="switch ac-switch"><input id="${sid}" type="checkbox" role="switch" data-ac-toggle="${f.id}" aria-label="「${esc(d.name)}」应用到${esc(f.name)}" ${c.on ? 'checked' : ''} ${full ? 'disabled' : ''}><i aria-hidden="true"></i></span>
 ${c.on ? `<div class="goal-controls"><div class="goal-target"><span>目标</span>${stepperHtml(`<input id="${vid}" aria-label="${esc(f.name)}的${esc(d.name)}目标" type="number" min="1" max="999" value="${c.value}" data-ac-value="${f.id}" inputmode="numeric">`, vid, 1, f.name + '的' + d.name + '目标', d.unit)}</div><div class="goal-weight"><span title="权重越大越优先">权重</span>${stepperHtml(`<input id="${wid}" aria-label="${esc(f.name)}的${esc(d.name)}权重" type="number" min="1" max="${E.MAX_EVENT_WEIGHT}" value="${c.weight}" data-ac-weight="${f.id}" inputmode="numeric">`, wid, 10, f.name + '的' + d.name + '权重')}</div></div>
 <p class="ac-warn" data-ac-warn="${f.id}" role="status" hidden>${icon('alert')}<span>按当前人数或会议设置无法完成，请调低目标。</span></p>${count > 1 ? `
 <p class="ac-effect">${nums(esc(`确认后${f.name}共 ${count} 个额外条件，完成任意一个即可获胜`))}</p>` : ''}` : ''}
</article>`;
}
// 把暂存的选择写进一块板子（真正的板子，或用来预先检查的副本）。返回是否有改动。
function applyAddCond(b) {
  const type = addCond.type; let changed = false;
  for (const f of b.factions) {
    const c = addCond.camps[f.id]; if (!c) continue;
    const rule = E.campRule(b, f.id); let e = rule.events.find(x => x.type === type);
    if (c.on) {
      if (!e) { e = E.addCampEvent(b, f.id, type); changed = true; }
      if (e.value !== c.value || e.weight !== c.weight) { e.value = c.value; e.weight = c.weight; changed = true; }
    } else if (e) { E.removeCampEvent(b, f.id, e.id); changed = true; }
  }
  return changed;
}
function addCondState() {
  const type = addCond && addCond.type;
  if (!type) return {ready: false, label: '添加条件', summary: '', blocked: new Set()};
  const on = addCondFactions().filter(f => addCond.camps[f.id].on), had = board.factions.filter(f => addCond.camps[f.id].had);
  const copy = clone(board), dirty = applyAddCond(copy), blocked = new Set(), name = E.eventCatalog[type].name;
  if (on.length) try { for (const x of E.validate(copy, {checkPool: false})) if (['EXTRA_UNREACHABLE', 'MEETING_GOAL_UNREACHABLE'].includes(x.code) && issueNames(x).includes(name)) blocked.add(x.camp); } catch { /* 预检查失败不拦着确认，正式检查仍在页面上 */ }
  return {ready: dirty, label: had.length ? '保存修改' : '添加条件', blocked, summary: on.length ? '影响 ' + on.length + ' 个阵营：' + on.map(f => f.name).join('、') : had.length ? '确认后，将从所有阵营移除这个条件' : '还没有选择阵营'};
}
function addCondRefreshState() {
  const st = addCondState(), button = $('#ac-confirm'); if (!button) return;
  button.disabled = !st.ready; button.textContent = st.label;
  $('#ac-summary').innerHTML = nums(esc(st.summary));
  $$('[data-ac-warn]').forEach(node => { node.hidden = !st.blocked.has(Number(node.dataset.acWarn)); });
}
function addCondRefreshList() {
  const list = $('#ac-list'); if (!list) return;
  const top = list.scrollTop; list.innerHTML = addCondItems(); list.scrollTop = top;
}
function addCondPick(type) {
  const d = E.eventCatalog[type]; if (!d || !addCond) return;
  addCond.type = type; addCond.camps = {};
  for (const f of board.factions) {
    const rule = E.campRule(board, f.id), e = rule.events.find(x => x.type === type);
    // 打开弹窗的阵营还没有这个条件时默认选中（除非它已经满了）。
    addCond.camps[f.id] = e ? {on: true, had: true, value: e.value, weight: e.weight} : {on: f.id === addCond.home && rule.events.length < E.MAX_CAMP_EVENTS, had: false, value: d.defaultValue, weight: E.DEFAULT_EVENT_WEIGHT};
  }
  $$('#ac-list .ac-item').forEach(b => { const on = b.dataset.acPick === type; b.classList.toggle('selected', on); b.setAttribute('aria-pressed', on); });
  const detail = $('#ac-detail'); detail.innerHTML = addCondDetail(); detail.scrollTop = 0;
  $('.ac').dataset.step = 'camps'; addCondRefreshState();
  // 窄屏一次只显示一栏：切到第二步后，把焦点交给第一个能操作的阵营开关。
  if (getComputedStyle($('.ac-pick')).display === 'none') (detail.querySelector('[data-ac-toggle]:not(:disabled)') || detail.querySelector('.ac-back'))?.focus({preventScroll: true});
}
function addCondToggle(input) {
  const c = addCond && addCond.camps[input.dataset.acToggle]; if (!c) return;
  c.on = input.checked; const id = input.id;
  const detail = $('#ac-detail'), top = detail.scrollTop;
  detail.innerHTML = addCondDetail(); detail.scrollTop = top; addCondRefreshState();
  document.getElementById(id)?.focus({preventScroll: true});
}
function addCondInput(t, final = false) {
  const camp = t.dataset.acValue || t.dataset.acWeight, key = t.dataset.acValue ? 'value' : 'weight', c = addCond && addCond.camps[camp]; if (!c) return;
  const n = t.valueAsNumber, min = Number(t.min), max = Number(t.max);
  if (Number.isInteger(n) && n >= min && n <= max) { c[key] = n; addCondRefreshState(); }
  else if (final) { t.value = c[key]; toast('请输入' + min + '–' + max + '的整数'); }
}
function addCondConfirm() {
  const type = addCond && addCond.type; if (!type || !addCondState().ready) return;
  const name = E.eventCatalog[type].name, wasNew = !condHolders(type).length;
  applyAddCond(board); mark();
  const holders = condHolders(type), mine = E.campRule(board, ruleCamp)?.events.find(e => e.type === type);
  addCond = null; closeModal();
  goalFresh = mine ? mine.id : null; renderInPlace(); goalFresh = null;
  // 焦点回到“添加胜利条件”按钮；刚加进当前阵营的那张卡片滚进视野并闪一下。
  ($('.add-goal-button:not(:disabled)') || $('[data-action="add-cond"]:not(:disabled)') || $('.faction-rail .rail-item.selected'))?.focus({preventScroll: true});
  if (mine) $(`[data-goal="${CSS.escape(mine.id)}"]`)?.scrollIntoView({block: 'nearest'});
  toast(holders.length ? (wasNew ? '已添加' : '已更新') + '「' + name + '」：' + holders.map(f => f.name).join('、') : '已移除「' + name + '」');
}
// 两条规则在载入板子时统一执行，旧草稿随之改写：
//   额外条件一律“完成任意一个即可”（原先的“全部完成”改回）；
//   新阵营只用额外胜利条件（原先选过的基础胜利条件取消）。
// 返回各改了几个阵营，供提示用。
function normalizeBoard(b) {
  let joins = 0, bases = 0;
  for (const rule of b.campEvents || []) if (rule.join !== 'any') { if (rule.events.length > 1) joins++; rule.join = 'any'; }
  for (const f of b.factions || []) if (f.kind === 'custom' && f.baseVictory) { f.baseVictory = null; bases++; }
  return {joins, bases};
}
function normalizeNote(fix) {
  return [fix.joins ? '原先设为“全部完成”的阵营已改为完成任意一个即可' : '', fix.bases ? '新阵营现在只用额外胜利条件，原先选的基础胜利条件已取消（' + fix.bases + ' 个阵营）' : ''].filter(Boolean).join('；');
}
function originalNeutralModal() {
  modal(modalHead('中立原胜利条件 · 全部只读') + `<div class="original-condition-list">${E.D.eligibleCareerIds.map(id => E.careers.get(id)).filter(c => c.camp === 3).map(c => `<div class="original-rule-row">${roleAvatar(c.id, 3)}<div><strong>${esc(c.name)}</strong><p>${esc(c.win_condition_des)}</p></div></div>`).join('')}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">知道了</button></div>`);
}

/* ---------- 第 3 步：搭配技能 ---------- */
function rosterGroups() {
  const query=rosterSearch.trim();
  const list=board.roles.filter(r=>!query||(r.name+E.campName(board,r.camp)).includes(query));
  return board.factions.map(f=>({f,rs:list.filter(r=>r.camp===f.id)})).filter(x=>x.rs.length);
}
function rosterCollapseState() { return rosterSearch.trim() ? rosterSearchCollapsed : rosterCollapsed; }
function revealRosterRole(r) { if(r){rosterCollapsed[r.camp]=false;rosterSearchCollapsed[r.camp]=false;} }
function rosterAllLabel() {
  const state=rosterCollapseState(),groups=rosterGroups();
  return groups.length&&groups.every(x=>state[x.f.id])?'全部展开':'全部收起';
}
function refreshRoster() {
  const list=$('.roster-list'); if(!list)return;const top=list.scrollTop;list.innerHTML=rosterItems();list.scrollTop=top;
  const all=$('[data-toggle-roster-all]');if(all){all.textContent=rosterAllLabel();all.disabled=!rosterGroups().length;}
}
function toggleRosterCamp(camp) {
  const state=rosterCollapseState();state[camp]=!state[camp];refreshRoster();
  $(`[data-toggle-roster-camp="${camp}"]`)?.focus({preventScroll:true});
}
function toggleRosterGroups() {
  const groups=rosterGroups(),state=rosterCollapseState(),collapse=!groups.every(x=>state[x.f.id]);
  for(const x of groups)state[x.f.id]=collapse;refreshRoster();
}
function rosterItems() {
  const groups=rosterGroups(),state=rosterCollapseState();
  const current = role()?.uid;
  const item = r => `<button class="roster-item camp-${r.camp} ${current === r.uid ? 'selected' : ''}" data-select-role="${r.uid}" aria-pressed="${current === r.uid}" style="${toneStyle(r.camp)}">${roleAvatar(r.templateCareerId, r.camp, 'sm')}<span class="name"><span>${nameHtml(r.name)}</span><small>${esc(E.campName(board, r.camp))}</small></span><span class="copies" title="单局最多出现${r.count}次">≤${r.count}</span></button>`;
  const grouped=groups.map(({f,rs})=>{
    const collapsed=!!state[f.id],editing=rs.some(r=>r.uid===current);
    return `<div class="roster-group" style="${toneStyle(f.id)}"><h4><button class="roster-group-toggle" data-toggle-roster-camp="${f.id}" aria-expanded="${!collapsed}" aria-controls="roster-camp-${f.id}" aria-label="${collapsed?'展开':'收起'}${esc(f.name)}角色"><i aria-hidden="true"></i><span class="roster-camp-name">${nameHtml(f.name)}</span>${collapsed&&editing?'<span class="roster-editing">编辑中</span>':''}<small>${rs.length}</small>${icon('chevron','roster-chevron')}</button></h4><div class="roster-group-body" id="roster-camp-${f.id}" ${collapsed?'hidden':''}>${rs.map(item).join('')}</div></div>`;
  }).join('');
  const other=board.roles.filter(r=>!E.faction(board,r.camp)&&(!rosterSearch.trim()||(r.name+E.campName(board,r.camp)).includes(rosterSearch.trim()))).map(item).join('');
  return grouped+other||'<p class="empty">没有找到角色</p>';
}
function rosterView() {
  return `<aside class="panel roster" aria-label="候选角色"><div class="roster-heading"><h3>选一个角色</h3><span>${board.roles.length}</span></div><div class="search-box">${icon('search')}<input id="roster-search" type="search" aria-label="搜索候选角色" placeholder="搜索角色或阵营" value="${esc(rosterSearch)}" autocomplete="off"></div><div class="roster-fold-tools"><span>按阵营查看</span><button class="btn-link" data-toggle-roster-all ${!rosterGroups().length?'disabled':''}>${rosterAllLabel()}</button></div><div class="roster-list">${rosterItems()}</div><div class="roster-bottom${roleClip ? ' has-paste' : ''}"><button class="btn btn-gold btn-sm roster-add" data-action="add-role" aria-label="添加已有职业" data-compact-label="加职业">${icon('plus')}添加已有职业</button><button class="btn btn-ghost btn-sm roster-add custom-role-add" data-action="new-custom-role" ${customRoleButtonAttrs()} aria-label="创建空白角色" data-compact-label="建角色">${artImage(CUSTOM_ICON, 'custom-entry-icon', '', false)}<span>创建空白角色</span></button>${roleClip ? `<button class="btn btn-ghost btn-sm roster-add roster-paste" data-action="paste-role" aria-label="粘贴角色「${esc(roleClip.name)}」" ${pasteRoleButtonAttrs()} data-compact-label="粘贴">${icon('paste')}<span>粘贴「${esc(roleClip.name)}」</span></button>` : ''}</div></aside>`;
}
function roleTop(r) {
  const custom = E.isCustom(r), f = E.faction(board, r.camp);
  return `<div class="role-hero" style="${toneStyle(r.camp)}">${rolePortrait(r)}<div class="role-hero-main"><div class="role-name-row"><span class="role-name-input"><input aria-label="角色名称" maxlength="20" value="${esc(r.name)}" data-role-field="name" autocomplete="off">${icon('pencil')}</span><span class="faction-tag"><i aria-hidden="true"></i>${nameHtml(f?.name || '')}${custom ? ' · 自创角色' : ''}</span></div><p class="role-desc">${custom ? '给你的新角色搭配技能。' : esc(E.careers.get(r.templateCareerId).des)}</p><div class="role-hero-actions${custom ? ' has-copy' : ''}"><button class="btn btn-violet btn-sm" data-action="role-options">${icon('gear')}角色设置</button>${custom ? `<button class="btn btn-ghost btn-sm" data-copy-role="${esc(r.uid)}" aria-label="复制${esc(r.name)}角色" title="复制这个自创角色（Ctrl/⌘ + C）">${icon('copy')}<span>复制角色</span></button>` : ''}<button class="btn btn-ghost btn-sm danger" data-action="remove-role" aria-label="删除${esc(r.name)}角色">${icon('trash')}删除角色</button><button class="btn btn-ghost btn-sm" data-action="role-art">${icon('image')}查看角色与技能素材</button><button class="btn-link" data-open-camp="${r.camp}">查看胜利条件 →</button></div></div></div>`;
}
function rolesView() {
  const r = role();
  if (!r) return title('给角色搭配技能', '先选角色，再选择想给他的能力。') + `<section class="panel empty-stage">${artImage(CUSTOM_ICON, 'workshop-mascot', '', false)}<h3>先添加一位角色</h3><p>已有职业可以直接使用，自创角色从空白开始。</p><div class="inline-actions"><button class="btn btn-gold" data-action="add-role">${icon('plus')}添加已有职业</button><button class="btn btn-ghost" data-action="new-custom-role" ${customRoleButtonAttrs()}>创建空白角色</button>${roleClip ? `<button class="btn btn-ghost" data-action="paste-role" ${pasteRoleButtonAttrs()}>${icon('paste')}粘贴「${esc(roleClip.name)}」</button>` : ''}</div></section>`;
  const active = E.equippedSkills(r,{type:'active'}), passive = E.equippedSkills(r,{type:'passive'});
  return title('给角色搭配技能', '选中角色，点击“添加技能”。已有职业也可以换一种玩法。') + `
<div class="roles-layout">${rosterView()}
 <section class="role-workspace">
  ${roleTop(r)}
  ${E.compatibilityIssues(r).length ? '<div class="note warning" role="alert">这个角色有暂不可用的技能，请移除标记项。</div>' : ''}
  <div class="equipped-heading"><div><h3>主动技能 <span>${active.length}</span></h3><p>添加主动或被动技能，搭配自己的玩法。</p></div><button class="btn btn-gold" data-action="choose-skills">${icon('plus')}添加技能</button></div>
  <div class="equipped-grid skill-scroll">${active.map(x => skillCard(r, x.id, x.slot, x.name)).join('') || '<div class="empty">还没有技能，先为角色挑一个吧。</div>'}<button class="add-skill-tile" data-action="choose-skills"><span aria-hidden="true">＋</span>添加技能</button></div>
  ${passive.length ? `<details class="native-effects" data-passive-role="${esc(r.uid)}" ${passiveExpanded[r.uid]!==false?'open':''}><summary class="disclosure">被动效果 <span>${passive.length} 项</span></summary><div class="equipped-grid">${passive.map(x => skillCard(r, x.id, x.slot, x.name)).join('')}</div></details>` : ''}
 </section>
</div>`;
}
function skillCard(r, id, slot, name) {
  const identity=E.playerSkill(id), entry=E.equippedSkills(r).find(x=>x.id===identity.id), s=entry||identity, info=E.skillScope(s.sourceId), outside=!info?.inScope, duplicate=E.equivalentSkillIssues(r).length&&s.equivalentIds.filter(key=>E.allIds(r).includes(key)).length>1, incomplete=!entry?.complete||entry?.hasRuntimeAction||duplicate, rawIds=[...s.memberIds,...s.runtimeIds,...s.equivalentIds].filter(key=>E.allIds(r).includes(key)), restricted=rawIds.some(key=>E.skillMountIssue(r,key)), disabled=outside||incomplete||restricted, tuned=[...s.memberIds,...s.equivalentIds].some(key=>r.skillOverrides[key]&&Object.keys(r.skillOverrides[key]).length); id=s.id;
  return `<article class="skill-card ${paramSkill === id ? 'active' : ''}${disabled ? ' skill-out-of-scope' : ''}"><div class="skill-title">${skillIcon(id)}<button class="skill-name" data-param="${id}" ${disabled?'disabled':''}>${esc(s.name)}</button><button class="btn btn-ghost btn-sm danger" data-remove-skill="${id}" data-slot="${slot}" aria-label="移除${esc(s.name)}技能">${icon('x')}移除</button></div><p>${esc(s.des)}</p>${outside||restricted ? '<p class="skill-boundary" role="alert">暂不可用，请移除。</p>' : incomplete?'<p class="skill-boundary" role="alert">技能配置不完整，请移除后重新添加。</p>':''}<div class="skill-meta"><span class="tag">${s.type === 1 ? '被动技能' : '主动技能'}${s.type!==1&&s.skill_kind === 0 ? ' · 会议中使用' : ''}</span>${tuned ? '<span class="tag tag-gold">已调整</span>' : ''}<button class="btn-link" data-param="${id}" ${disabled?'disabled':''}>${icon('gear')}调整</button></div></article>`;
}
function roleCountControl(r){
 if(!E.isUniqueNeutral(r))return numberField('本局最多出现几人',r.count,'data-role-field="count"','role-count',1,E.ROOM_LIMITS.max);
 return '<div class="neutral-copy-limit">'+icon('lock')+'同一中立职业，每局最多1人</div>'+(r.count!==1?'<button class="btn btn-gold btn-sm" data-reset-neutral-count="'+esc(r.uid)+'">将出场上限改为1人</button>':'');
}
function roleOptions() {
  const r = role(), custom = E.isCustom(r);
  modal(modalHead('角色设置') + `<div class="role-options-form"><p class="role-desc">${custom ? '给你的新角色搭配技能。' : esc(E.careers.get(r.templateCareerId).des)}</p>${custom ? `<label class="field"><span class="field-label">所属阵营</span><select data-role-field="camp" aria-label="归属阵营">${r.camp === 3 ? '<option value="3" disabled selected>请选择其他阵营</option>' : ''}${customCampOptions(r.camp, r.uid)}</select></label>` : `<p class="locked-role-camp">${icon('lock')}${esc(E.campName(board, r.camp))} · 原阵营固定</p>`}${roleCountControl(r)}<p class="setting-hint">这是此角色的出场上限，不会增加阵营人数。</p></div><div class="role-maintenance"><button class="btn btn-ghost btn-sm" data-action="role-art">${icon('image')}查看角色与技能素材</button>${custom ? `<button class="btn btn-ghost btn-sm" data-action="clear-custom-skills">${icon('trash')}清空技能</button>` : `<button class="btn btn-ghost btn-sm" data-action="restore-role">${icon('undo')}恢复原技能</button>`}<button class="btn btn-ghost btn-sm danger" data-action="remove-role">${icon('trash')}删除角色</button></div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成</button></div>`, true, 'role-options');
}
function skillPicker() {
  const r = role();
  const modules = skillPickerModules();
  if (skillModule !== 'all' && !modules.includes(skillModule)) skillModule = 'all';
  modal(modalHead('为「' + nameHtml(r.name) + '」添加技能') + `
    <div class="modal-toolbar skill-picker-toolbar">
      <div class="search-box">${icon('search')}<input id="skill-search" type="search" aria-label="搜索技能" placeholder="搜索想要的能力" value="${esc(skillSearch)}" autocomplete="off"></div>
      <div class="filter-chips" id="skill-types" role="group" aria-label="主动与被动技能">${skillTypeButtons()}</div>
      <select class="compact-module-picker" aria-label="技能模块" data-skill-module-select>${options(Object.fromEntries([['all', '全部类型'], ...modules.map(m => [m, m])]), skillModule)}</select>
    </div>
    <div class="filter-chips" id="skill-module" role="group" aria-label="技能模块">${skillModuleButtons()}</div>
    <div class="picker-summary skill-picker-summary"><span id="skill-picker-count"></span><label class="unopened-skills-toggle"><input type="checkbox" id="show-unopened-skills" ${skillShowUnavailable?'checked':''}>查看未开放</label><span id="skill-picker-status" role="status"></span></div>
    <div class="library-list skill-picker-list" id="library-list">${libraryItems(r)}</div>
    <div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成搭配</button></div>`, false, 'skills');
  updateSkillPickerSummary();
  $('#skill-search').focus();
}
function skillPickerBase(type = skillType) {
  return E.librarySkills({type}).filter(s => skillShowUnavailable || s.mountStatus === 'open');
}
function skillPickerModules() { return [...new Set(skillPickerBase().map(s => s.module || E.skillScope(s.id).module))]; }
function skillTypeButtons() {
  return [['active','主动'],['passive','被动'],['all','全部']].map(([type,label]) => `<button class="chip ${skillType === type?'selected':''}" data-skill-type="${type}" aria-pressed="${skillType === type}">${label}<span>${skillPickerBase(type).length}</span></button>`).join('');
}
function skillModuleButtons() {
  return [['all', '全部类型'], ...skillPickerModules().map(m => [m, m])].map(([value, label]) => `<button class="chip ${skillModule === value?'selected':''}" data-skill-module="${esc(value)}" aria-pressed="${skillModule === value}">${esc(label)}</button>`).join('');
}
function syncSkillPickerFilters() {
  const focusedType = document.activeElement?.dataset.skillType;
  const modules = skillPickerModules();
  if (skillModule !== 'all' && !modules.includes(skillModule)) skillModule = 'all';
  $('[data-skill-module-select]').innerHTML = options(Object.fromEntries([['all','全部类型'],...modules.map(m=>[m,m])]),skillModule);
  $('#skill-module').innerHTML = skillModuleButtons();
  $('#skill-types').innerHTML = skillTypeButtons();
  if (focusedType) $$('[data-skill-type]').find(b => b.dataset.skillType === focusedType)?.focus({preventScroll:true});
  updateSkillPicker(true);
}
function selectSkillModule(value) {
  skillModule = value;
  $$('[data-skill-module]').forEach(b => { b.classList.toggle('selected', b.dataset.skillModule === value); b.setAttribute('aria-pressed', b.dataset.skillModule === value); });
  const select = $('[data-skill-module-select]'); if (select) select.value = value;
  updateSkillPicker(true);
}
function skillPickerRows() {
  return E.librarySkills({search: skillSearch, type: skillType, module: skillModule}).filter(s => skillShowUnavailable || s.mountStatus === 'open');
}
function updateSkillPickerSummary() {
  const label = skillType === 'active' ? '主动技能' : skillType === 'passive' ? '被动技能' : '全部技能';
  $('#skill-picker-count').textContent = label+' · 显示 '+skillPickerRows().length+' 项';
  $('#skill-picker-status').textContent = '已装备 '+E.equippedSkills(role()).length+' 项 · 可连续添加';
}
function updateSkillPicker(resetScroll = false) {
  if ($('#modal').dataset.kind !== 'skills' || !$('#modal').open) return;
  refreshPickerList('#library-list', libraryItems(role()), 'data-add-skill');
  if (resetScroll) ($('#modal .modal-body') || $('#modal-content')).scrollTop = 0;
  updateSkillPickerSummary();
}
function libraryItems(r) {
  const equipped = E.equippedSkills(r).map(s=>s.id), list = skillPickerRows();
  const item = s => {
    const module = s.module || E.skillScope(s.id).module, compat = E.skillCompatibility(s.id, r), isEquipped = equipped.includes(s.id), blocked = compat.level === 'error', isPassive = s.type === 1;
    const reason = ['SKILL_STATE_DEADLOCK','SKILL_FAMILY_CONFLICT'].includes(compat.code) ? '与已装备技能冲突' : compat.code === 'SKILL_CONTEXT_ONLY' ? '需在对局中触发' : s.mountStatus === 'native-only' ? '仅限原职业使用' : '后续逐步开放';
    const blockedLabel = s.mountStatus === 'native-only' ? '原职业保留' : '暂未开放';
    return `<article class="library-item${blocked && !isEquipped ? ' skill-blocked' : ''}${isEquipped ? ' is-equipped' : ''}" data-library-skill="${s.id}"><div class="item-title">${skillIcon(s.id)}<strong>${esc(s.name)}</strong>${skillType === 'all' ? `<span class="skill-type-tag ${isPassive?'passive':'active'}">${isPassive?'被动':'主动'}</span>` : ''}</div><p>${esc(s.des || '暂无技能说明')}</p><div class="item-foot">${blocked && !isEquipped ? `<small class="skill-boundary">${esc(reason)}</small>` : `<span class="tag module-tag">${esc(module)}</span>`}<button class="btn ${isEquipped || blocked ? 'btn-ghost' : 'btn-gold'} btn-sm" data-add-skill="${s.id}" ${isEquipped || blocked ? 'disabled' : ''}>${isEquipped ? icon('check') + '已装备' : blocked ? blockedLabel : '＋ 添加'}</button></div></article>`;
  };
  return list.map(item).join('') || '<div class="empty">没有找到技能，试试其他分类或关键词。</div>';
}
function skillParameters(id){const r=role(),identity=E.playerSkill(id);paramSkill=E.equippedSkills(r).find(x=>x.id===identity?.id)?.sourceId||0;if(!E.allIds(r).includes(paramSkill)){toast('请移除不完整的技能后重新添加');return;}if(E.skillMountIssue(r,paramSkill)){toast('暂不可用，请移除这个技能');return;}const s=E.playerSkill(paramSkill);modal(modalHead((s.type===1?'被动效果「':'调整「')+esc(s.name)+'」')+parameterView(r)+'<div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成</button></div>',false,'parameters');}
function parameterView(r){
 if(!paramSkill||!E.allIds(r).includes(paramSkill))return '';
 const s=E.effective(r,paramSkill),st=s.stages[0],override=r.skillOverrides[paramSkill]||{},stageOverride=override.stages?.[st?.id]||{},uses=(label,key)=>`<label class="param-field">${label}<select data-skill-limit="${key}">${options(Object.fromEntries([...new Set([-1,0,1,2,3,5,10,s[key]])].sort((a,b)=>a-b).map(v=>[v,v===-1?'不限':v===0?'禁止使用':v+' 次'])),s[key])}</select></label>`;
 const passive=s.type===1,fields=[
  !passive||s.get_cd>0||override.get_cd!==undefined?number(passive?'生效等待（秒）':'首次可用等待（秒）',s.get_cd,'data-skill-param="get_cd"',0):'',
  !passive||s.use_time>0||override.use_time!==undefined?uses(passive?'整局触发次数':'整局使用次数','use_time'):'',
  !passive&&s.skill_kind===0?uses('每次会议使用次数','meeting_use_time'):'',
  st&&(!passive||st.meeting_cd>0||stageOverride.meeting_cd!==undefined)?number('会议后等待（秒）',st.meeting_cd,`data-stage="${st.id}" data-stage-param="meeting_cd"`):'',
  st?.cd_type<=1&&(!passive||st.cd_type_param_1>0||stageOverride.cd_type_param_1!==undefined)?number(st.cd_type===0?(passive?'触发冷却（秒）':'使用冷却（秒）'):'击倒冷却倍率（%）',st.cd_type_param_1,`data-stage="${st.id}" data-stage-param="cd_type_param_1"`):''
 ].join('');
 return `<div class="parameter-panel"><div class="inline-actions"><p class="muted">${passive?'满足条件时自动生效。':'调整会自动保存。'}</p><button class="btn btn-ghost btn-sm" data-action="reset-params">恢复默认</button></div>${passive?`<p class="passive-effect-description">${esc(E.playerSkill(paramSkill).des)}</p>`:''}${fields?`<div class="field-grid">${fields}</div>`:passive?'<p class="passive-parameter-note">这个被动无需设置使用次数或冷却。</p>':''}</div>`;
}

/* ---------- 第 5 步：预览板子 ---------- */
function drawRing() {
  const seats = drawResult.seats, n = seats.length;
  return `<div class="seat-ring ${ringSize(n)}" aria-hidden="true">${seats.map((s, i) => {
    const [x, y] = ringPoint(i, n), a = s.templateCareerId === null ? {icon: CUSTOM_ICON} : ART.roles[s.templateCareerId];
    return `<span class="seat seat-role ${justDrew ? 'reveal' : ''}" data-seat="${i}" style="left:${x.toFixed(2)}%;top:${y.toFixed(2)}%;${toneStyle(s.camp)};--d:${i * 70}ms" title="席位 ${i + 1} · ${esc(s.name)}">${a?.icon ? `<img src="${esc(a.icon.src)}" alt="" decoding="async">` : `<b>${esc(s.name.slice(0, 1))}</b>`}<span class="seat-no">${i + 1}</span></span>`;
  }).join('')}</div>`;
}
function drawPanel() {
  const blocked = checkReport.some(x => x.level === 'error');
  const stats = E.campIds(board).map(c => { const p = E.poolStats(board, c); return `<span class="pool-stat" style="${toneStyle(c)}"><i aria-hidden="true"></i>${esc(E.campName(board, c))}：${p.candidates}种候选 → 抽${p.seats}人</span>`; }).join('');
  let body;
  if (drawError) body = `<div class="note warning" role="alert" style="margin-top:16px">${esc(drawError)}</div>`;
  else if (drawResult) body = `<div class="draw-stage"><div class="seat-table"><div class="table-top" aria-hidden="true"></div>${drawRing()}<div class="draw-table-label"><strong>${drawResult.seats.length}</strong><span>人</span></div></div><div><div class="draw-camps">${E.campIds(board).map(c => `<article class="draw-camp camp-${c}" style="${toneStyle(c)}"><h4>${nameHtml(E.campName(board, c))} <span>${drawResult.seats.filter(s => s.camp === c).length} / ${board.room.counts[c]} 人</span></h4><ol>${drawResult.seats.filter(s => s.camp === c).map(s => `<li>${roleAvatar(s.templateCareerId, c, 'sm')}<div><strong>${nameHtml(s.name)}</strong><small>席位 ${drawResult.seats.indexOf(s) + 1}${s.copy > 1 ? ' · 同角色第' + s.copy + '份' : ''}</small></div></li>`).join('') || '<li class="muted">本局不分配席位</li>'}</ol></article>`).join('')}</div><p class="draw-meta">本次抽中 ${drawResult.seats.length} 席，${drawResult.omitted.length} 种候选未出场。</p></div></div>`;
  else body = `<div class="draw-stage"><div class="seat-table"><div class="table-top" aria-hidden="true"></div>${seatRing(planTokens())}<div class="draw-table-label"><strong>${board.room.total}</strong><span>人</span></div></div><div class="draw-empty">${blocked ? '请先修正下方配置问题，再随机抽取。' : '角色池已就绪。点击“随机抽取一桌”，按各阵营人数产生本局名单。'}</div></div>`;
  return `<section id="draw-panel" class="panel draw-panel"><div class="draw-heading"><div><h3>这一局，谁会出场？</h3><div class="pool-stats">${stats}</div></div><button class="btn btn-gold btn-lg" data-action="draw-pool" ${blocked ? 'disabled' : ''}>${icon('dice')}${drawResult ? '重新随机抽取' : '随机抽取一桌'}</button></div>${body}<small class="draw-foot">修改设置后，需要重新抽取。</small></section>`;
}
function issueButton(x) { return reviewIssueLink(x); }
// 预览页的胜利条件：每个阵营一张卡片，原有条件在上，额外条件按权重从高到低排成一组。
function winCard(f) {
  const events = sortedEvents(f.id), seats = board.room.counts[f.id] || 0, custom = f.kind === 'custom';
  const missing = factionMissingWin(f);
  let base;
  if (custom) base = missing ? `<p class="win-missing">${icon('alert')}<span>尚无胜利条件，这个阵营无法获胜。</span></p>` : '<p class="win-base-text muted">新阵营没有原有条件，只靠额外条件获胜。</p>';
  else if (f.id === 3) {
    const roles = board.roles.filter(r => r.camp === 3 && !E.isCustom(r));
    base = '<p class="win-base-text">每个角色按自己的原条件，各自获胜。</p>' + (roles.length ? `<ul class="win-roles">${roles.map(r => { const drawn = drawResult?.seats.some(s => s.roleUid === r.uid); return `<li class="${drawn ? 'drawn' : ''}">${roleAvatar(r.templateCareerId, 3, 'xs')}<span class="win-role-copy"><strong>${nameHtml(r.name)}${drawn ? '<em>本局出场</em>' : ''}</strong><small>${esc(E.careers.get(r.templateCareerId).win_condition_des)}</small></span></li>`; }).join('')}</ul>` : '');
  } else base = `<p class="win-base-text">${esc(originalText(f))}</p>`;
  const extra = events.length ? `<div class="win-block win-extra"><p class="win-block-title">${icon('crown')}<span>额外条件${events.length > 1 ? ' · 完成任意一个' : ''}</span><em>优先结算</em></p><ol class="win-goals ${events.length > 4 ? 'dense' : ''}">${events.map(e => { const d = E.eventCatalog[e.type]; return `<li class="win-goal" data-joint="或"><span class="cond-ic">${icon(condIcon(e.type))}</span><span class="win-goal-copy"><strong>${esc(d.name)}</strong><small>${nums('权重 ' + e.weight)}</small></span><span class="win-amount"><b>${e.value}</b>${esc(d.unit)}</span></li>`; }).join('')}</ol>${f.id === 3 ? '<p class="win-foot">每名中立各自累计，达成的那一位获胜。</p>' : ''}</div>` : '';
  return `<article class="win-card ${seats ? '' : 'idle'} ${missing ? 'missing' : ''}" data-win-card="${f.id}" style="${toneStyle(f.id)}">
 <header class="win-card-head">${emblem(f, 'sm')}<div class="win-card-name"><h4>${nameHtml(f.name)}</h4><small>${f.id === 3 ? '各自获胜' : '共同获胜'}</small></div><span class="win-seats">${seats ? nums(seats + ' 人') : '本局 ' + nums(0) + ' 人'}</span></header>
 <div class="win-card-body"><div class="win-block"><p class="win-block-title">${icon('lock')}<span>原有条件</span></p>${base}</div>${extra}</div>
 ${missing ? `<button class="btn btn-gold btn-sm win-fix" data-open-camp="${f.id}">去设置胜利条件</button>` : ''}
</article>`;
}
function reviewWins() {
  const extras = board.campEvents.reduce((n, r) => n + r.events.length, 0);
  return `<section class="panel review-wins" aria-labelledby="review-wins-title"><div class="review-wins-head"><div><h3 id="review-wins-title">这一局，怎样才算赢？</h3><p>${extras ? '额外条件先达成就先结算，权重大的优先；都没达成时，按原有条件判定。' : '各阵营沿用原有条件，没有添加额外条件。'}</p></div><button class="btn btn-ghost btn-sm" data-tab="wins">${icon('pencil')}调整胜利条件</button></div><div class="win-board">${board.factions.map(winCard).join('')}</div></section>`;
}
function reviewView() {
  const errors = checkReport.filter(x => x.level === 'error').length, warnings = checkReport.filter(x => x.level === 'warn').length;
  return title('看看这局会是什么样', '先试抽一局，确认无误后就能导出分享。') + drawPanel() + reviewWins() + `
<div class="review-grid">
 <section class="panel check-panel">
  <div class="check-top"><span class="check-mark ${errors ? 'bad' : 'ok'}">${icon(errors ? 'alert' : 'check')}</span><div><strong class="${errors ? '' : 'ok'}">${nums(errors ? errors + ' 项需要调整' : '可以继续保存')}</strong><p>${warnings} 项提醒 · ${board.roles.length} 种候选</p></div><button class="btn btn-ghost btn-sm" data-action="recheck">${icon('refresh')}重新检查</button></div>
  <div class="check-list">${checkReport.filter(x => x.level !== 'info').map(x => `<div class="issue ${x.level}"><b>${x.level === 'error' ? '调整' : '提醒'}</b><span>${esc(uiCopy(x.text))}</span>${issueButton(x)}</div>`).join('') || '<div class="note">人数、候选容量与已知规则检查通过。</div>'}</div>
 </section>
 <div class="review-side">
  <section class="panel export-card export-summary"><span class="ic-wrap">${icon('download')}</span><p>保存这套板子，分享给朋友。</p><button class="btn btn-gold" data-action="export">导出板子</button></section>
 </div>
</div>
<details class="panel simple-sim" ${simOpen ? 'open' : ''}><summary>试一试胜利判定${drawResult ? '' : `<span class="tag">${icon('dice')}先随机抽取一桌</span>`}</summary><div class="sim-body"><p class="muted">填入假设进度，检查额外条件与原有条件的先后关系。</p><div id="sim-inputs"></div><div id="sim-result" aria-live="polite"></div></div></details>`;
}
function newScenario() { return {progress: {}, eligibleAlive: true, originalWinner: ''}; }
function simGroups() {
  if (!drawResult) return [];
  return E.campIds(board).filter(c => c !== 3 && drawResult.seats.some(s => s.camp === c)).map(c => ({key: 'camp-' + c, camp: c, label: factionLabel(c)})).concat(drawResult.seats.filter(s => s.camp === 3).map(s => ({key: s.uid, camp: 3, roleUid: s.roleUid, seatId: s.uid, label: s.name + ' · 席位' + (drawResult.seats.indexOf(s) + 1)})));
}
function renderSimulation() {
  const el = $('#sim-inputs'); if (!el) return;
  const groups = simGroups();
  if (!groups.length) { el.innerHTML = '<div class="note" style="margin-top:12px">先在上方随机抽取一桌，再试算实际出场的阵营。</div>'; return; }
  if (!groups.some(g => g.key === simGroup)) simGroup = groups[0].key;
  if (!scenario) scenario = newScenario();
  const g = groups.find(g => g.key === simGroup), rule = E.campRule(board, g.camp, g.roleUid);
  el.innerHTML = `<div class="simple-sim-grid"><label class="param-field"><span>要试算的阵营／玩家</span><select id="sim-group">${groups.map(x => `<option value="${x.key}" ${x.key === simGroup ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select></label><label class="param-field"><span>假设原条件也已达成</span><select data-sim-original>${options({'': '暂未达成原条件', ...Object.fromEntries(groups.filter(x => x.camp > 3 ? !!E.faction(board, x.camp).baseVictory : x.camp !== 3 || !E.isCustom(board.roles.find(r => r.uid === x.roleUid))).map(x => [x.key, x.label]))}, scenario.originalWinner)}</select></label>${rule.events.map(e => { const d = E.eventCatalog[e.type], key = d.counter || e.type; return numberField(d.name + (g.camp !== 3 && d.aggregation === 'personalMax' ? '个人最高记录' : '已完成') + '（' + d.unit + '）', scenario.progress[key] || 0, `data-sim-progress="${key}"`, 'sim-' + key, 0, 999); }).join('')}</div><label class="sim-alive"><input type="checkbox" data-sim-alive ${scenario.eligibleAlive ? 'checked' : ''}>${g.camp === 3 ? '本人仍然存活' : '本阵营仍有成员存活'}</label><small class="scope-note">${g.camp === 3 ? '所有中立采用相同目标；这里仅填写该席位本人的进度，不与其他中立合并。' : '按每项目标的说明填写；个人目标填写一名存活成员的最高记录，其余填写阵营累计。'}</small><div class="sim-actions"><button class="btn btn-gold" data-action="simulate">${icon('trophy')}看看谁获胜</button></div>`;
  if (simulationRun) showResult(); else $('#sim-result').innerHTML = '';
}
function showResult() {
  const groups = simGroups(), g = groups.find(g => g.key === simGroup); if (!g) return;
  const seats = drawResult.seats, original = groups.find(x => x.key === scenario.originalWinner);
  const ids = x => x.camp === 3 ? [x.seatId] : seats.filter(s => s.camp === x.camp).map(s => s.uid), actorIds = ids(g);
  const state = {finalized: true, seats, campProgress: g.camp === 3 ? {} : {[g.camp]: scenario.progress}, playerProgress: g.camp === 3 ? {[g.seatId]: scenario.progress} : {}, aliveSeatIds: seats.map(s => s.uid).filter(id => scenario.eligibleAlive || !actorIds.includes(id)), originalWinners: original && original.camp <= 3 ? ids(original) : [], baseConditionMatches: original?.camp > 3 ? [{camp: original.camp, presetId: E.faction(board, original.camp).baseVictory, actorSeatId: ids(original)[0]}] : []};
  if (g.camp !== 3 && actorIds.length) { const p = {}; for (const [type, d] of Object.entries(E.eventCatalog)) if (d.aggregation === 'personalMax') p[type] = scenario.progress[type] || 0; state.playerProgress[actorIds[0]] = p; }
  const result = E.resolveVictory(board, state);
  $('#sim-result').innerHTML = `<div class="simulation-result"><h3>${result.source === 'extra' ? '额外条件优先获胜' : result.source === 'original' ? '按原条件获胜' : result.source === 'pending' ? '等待事件处理完成' : '暂时无人获胜'}</h3><p>${esc(uiCopy(result.invalid ? result.reason : result.source === 'extra' ? result.reason : result.source === 'original' ? '额外条件尚未达成，按原有条件获胜。' : result.source === 'none' ? '继续游戏。' : '等待结算。'))}</p>${result.winners.length ? `<p class="sim-winners">${result.winners.map(id => esc(seats.find(s => s.uid === id)?.name || id)).join('、')}</p>` : ''}</div>`;
}

/* ---------- 弹窗 ---------- */
function modal(html, compact = false, kind = '') {
  const d = $('#modal');
  d.classList.toggle('compact-dialog', compact); d.dataset.kind = kind; d.setAttribute('aria-labelledby', 'modal-title');
  const box = $('#modal-content');
  box.innerHTML = html;
  const status = document.createElement('p'); status.id = 'dialog-status'; status.className = 'dialog-status'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  const actions = [...box.children].reverse().find(n => n.classList.contains('modal-actions'));
  const body = document.createElement('div'); body.className = 'modal-body';
  const picker = ['skills', 'careers', 'events'].includes(kind);
  for (const node of [...box.children]) {
    if (node.classList.contains('modal-head') || node === actions || (picker && node.matches('.modal-toolbar,.filter-chips,.picker-summary'))) continue;
    body.appendChild(node);
  }
  box.insertBefore(body, actions || null);
  if (actions) box.insertBefore(status, actions); else box.appendChild(status);
  if (!d.open) d.showModal();
  if (!d.contains(document.activeElement)) d.querySelector('[autofocus],button,input,select,textarea,[tabindex="0"]')?.focus();
  box.scrollTop = 0;
}
function closeModal() { $('#modal').close(); }
function refreshPickerList(selector, html, attribute) {
  const list = $(selector); if (!list) return;
  const scroller = $('#modal .modal-body') || $('#modal-content'), top = list.scrollTop, outer = scroller.scrollTop;
  const active = document.activeElement, current = active?.closest('[' + attribute + ']');
  const hadFocus = list.contains(active), key = current?.getAttribute(attribute);
  const index = current ? [...list.querySelectorAll('[' + attribute + ']')].indexOf(current) : -1;
  list.innerHTML = html;
  if (hadFocus) {
    const buttons = [...list.querySelectorAll('[' + attribute + ']')];
    const same = buttons.find(b => b.getAttribute(attribute) === key && !b.disabled);
    const next = buttons.slice(Math.max(0, index)).find(b => !b.disabled) || buttons.find(b => !b.disabled);
    (same || next || $('#modal .modal-close'))?.focus({preventScroll: true});
  }
  list.scrollTop = top; scroller.scrollTop = outer;
}
const modalHead = t => `<div class="modal-head"><h2 id="modal-title">${t}</h2><button type="button" class="modal-close" data-action="close-modal" aria-label="关闭弹窗">${icon('x')}</button></div>`;
function addRoleModal(camp = null) {
  careerLockedCamp = camp === null ? null : Number(camp); careerSearch = ''; careerCamp = careerLockedCamp === null ? 'all' : String(careerLockedCamp);
  modal(modalHead(careerLockedCamp === null ? '添加已有职业' : nameHtml(E.campName(board, careerLockedCamp)) + ' · 添加职业') + `<div class="modal-toolbar ${careerLockedCamp === null ? '' : 'locked-camp-toolbar'}"><div class="search-box">${icon('search')}<input id="career-search" type="search" aria-label="搜索职业" placeholder="搜索职业" autocomplete="off"></div>${careerLockedCamp === null ? `<div class="filter-chips" id="career-camp" role="group" aria-label="筛选阵营">${[['all', '全部阵营'], ['1', '鹅阵营'], ['2', '鸭阵营'], ['3', '中立阵营']].map(([k, v]) => `<button class="chip ${careerCamp === k ? 'selected' : ''}" data-career-camp="${k}" aria-pressed="${careerCamp === k}">${v}</button>`).join('')}</div>` : ''}</div><div class="modal-grid" id="career-list">${careerItems()}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成选择</button></div>`, false, 'careers');
  $('#career-search').focus();
}
function careerItems() {
  const pooled = new Map(); board.roles.forEach(r => pooled.set(r.templateCareerId, (pooled.get(r.templateCareerId) || 0) + 1));
  return D.career.filter(c => E.classicCareerIds.has(c.id) && (careerLockedCamp === null || c.camp === careerLockedCamp) && (careerCamp === 'all' || c.camp === +careerCamp) && (!careerSearch || (c.name + String(c.id)).includes(careerSearch))).map(c => {
    const state=E.careerAddStatus(board,c.id), label=state.allowed?(pooled.has(c.id)?'已添加 '+pooled.get(c.id)+' 个 · 可继续添加':'添加角色'):state.reason;
    return '<button class="career-option camp-'+c.camp+'" data-add-career="'+c.id+'" style="'+toneStyle(c.camp)+'" '+(state.allowed?'':'disabled')+' title="'+esc(label)+'">'+roleAvatar(c.id,c.camp)+'<h3>'+esc(c.name)+'</h3><p>'+esc(c.des)+'</p><span class="chip-camp"><i aria-hidden="true"></i>'+esc(label)+'</span><span class="add-mark" aria-hidden="true">'+icon(state.allowed?'plus':pooled.has(c.id)?'check':'lock')+'</span></button>';
  }).join('') || '<div class="empty">没有匹配角色</div>';
}
function nextCustomRoleName() {
  let name = '自创角色', n = 2; const names = new Set(board.roles.map(r => r.name));
  while (names.has(name)) name = '自创角色' + n++;
  return name;
}
function customRoleButtonAttrs(camp = null) {
  const states = board.factions.filter(f => f.id !== 3 && (camp === null || f.id === Number(camp))).map(f => E.customRoleAddStatus(board, f.id));
  if (states.some(state => state.allowed)) return '';
  const reason = camp === null && board.roles.length < E.MAX_POOL_ROLES ? '各阵营空白角色已满，请先移除角色。' : states[0]?.reason || '请选择可创建角色的阵营。';
  return `disabled title="${esc(reason)}"`;
}
function pasteRoleButtonAttrs(prefer = null) {
  const state = E.customRoleAddStatus(board, pasteCamp(prefer));
  return state.allowed ? 'title="粘贴刚复制的自创角色（Ctrl/⌘ + V）"' : `disabled title="${esc(state.reason)}"`;
}
function customCampOptions(chosen, excludeUid = null) {
  return board.factions.filter(f => f.id !== 3).map(f => {
    const state = E.customRoleAddStatus(board, f.id, excludeUid);
    return `<option value="${f.id}" ${f.id === chosen ? 'selected' : ''} ${!state.allowed && f.id !== chosen ? 'disabled' : ''}>${esc(f.name)}${state.allowed || excludeUid && f.id === chosen ? '' : '（已满）'}</option>`;
  }).join('');
}
function refreshCustomRoleForm() {
  const form = $('#custom-role-form'); if (!form) return;
  const camp = customRoleCamp ?? Number($('#new-role-camp').value), state = E.customRoleAddStatus(board, camp);
  if (customRoleCamp === null) $('#new-role-camp').innerHTML = customCampOptions(camp);
  const count = E.customRoleCount(board, camp);
  $('#custom-role-capacity').textContent = count >= E.MAX_CUSTOM_ROLES_PER_FACTION ? `空白角色已满（${count}/${E.MAX_CUSTOM_ROLES_PER_FACTION}）` : `空白角色 ${count}/${E.MAX_CUSTOM_ROLES_PER_FACTION}`;
  const submit = form.querySelector('[type=submit]');
  submit.disabled = !state.allowed; submit.textContent = state.allowed ? '创建角色' : '已达上限';
  submit.title = state.reason;
  $('.custom-role-preview').innerHTML = roleAvatar(null, camp) + '<span>为新角色起个名字</span>';
}
function customRoleModal(camp = null) {
  const choices = board.factions.filter(f => f.id !== 3);
  if (camp !== null) {
    const state = E.customRoleAddStatus(board, camp); if (!state.allowed) throw Error(state.reason);
  }
  const chosen = camp ?? [role()?.camp, ...choices.map(f => f.id)].find(id => E.customRoleAddStatus(board, id).allowed);
  if (chosen === undefined) throw Error('各阵营空白角色已满，请先移除角色。');
  customRoleCamp = camp; const name = nextCustomRoleName();
  modal(modalHead('创建空白角色') + `<form id="custom-role-form"><div class="custom-role-preview">${roleAvatar(null, chosen)}<span>为新角色起个名字</span></div><div class="custom-role-fields"><label for="new-role-name">角色名称</label><input id="new-role-name" name="name" maxlength="20" required value="${esc(name)}" autocomplete="off"><label for="new-role-camp">所属阵营</label>${camp === null ? `<select id="new-role-camp" name="camp">${customCampOptions(chosen)}</select>` : `<input id="new-role-camp" value="${esc(E.campName(board, camp))}" readonly>`}</div><p class="setting-hint" id="custom-role-capacity" role="status" style="margin-top:12px"></p><p class="form-error" id="custom-role-error" role="alert" hidden></p><div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="close-modal">关闭</button><button type="submit" class="btn btn-gold">创建角色</button></div></form>`, true, 'custom-role');
  refreshCustomRoleForm(); $('#new-role-name').focus(); $('#new-role-name').select();
}
document.addEventListener('submit', e => {
  if (e.target.id !== 'custom-role-form') return; e.preventDefault();
  try {
    const name = $('#new-role-name').value.trim(); if (!name) throw Error('请输入角色名称'); if (name.length > 20) throw Error('角色名称最多20个字');
    const camp = customRoleCamp ?? Number($('#new-role-camp').value), r = E.makeCustomRole(board, camp); r.name = name;
    board.roles.push(r); selected = r.uid; rosterSearch = ''; revealRosterRole(r); paramSkill = 0; mark(); renderInPlace();
    $('#new-role-name').value = nextCustomRoleName(); $('#custom-role-error').hidden = true; refreshCustomRoleForm();
    const full = !E.customRoleAddStatus(board, camp).allowed;
    if (!full) { $('#new-role-name').focus({preventScroll: true}); $('#new-role-name').select(); }
    else if (customRoleCamp === null) $('#new-role-camp').focus({preventScroll: true});
    else $('#custom-role-form [data-action=close-modal]').focus({preventScroll: true});
    toast('已创建「' + r.name + '」' + (full ? '，已达该阵营上限' : '，可继续创建'));
  } catch (error) { const n = $('#custom-role-error'); n.textContent = error.message; n.hidden = false; refreshCustomRoleForm(); }
});

/* ---------- 按页重置 ---------- */
function resetPageData(source, page, roleUid) {
  const b = clone(source), defaults = E.defaultBoard();
  if (page === 'room') { b.room = {...defaults.room, counts: clone(b.room.counts)}; b.description = defaults.description; }
  else if (page === 'factions') {
    const previous = b.roles;
    b.factions = clone(defaults.factions);
    const total = Math.min(E.ROOM_LIMITS.max, Math.max(E.ROOM_LIMITS.min, b.room.total)), ducks = Math.max(1, Math.floor(total / 5)), neutral = Math.min(2, Math.floor(total / 5));
    b.room.counts = {1: total - ducks - neutral, 2: ducks, 3: neutral};
    b.roles = defaults.roles.map(r => clone(previous.find(p => !E.isCustom(p) && p.templateCareerId === r.templateCareerId) || r));
    for (const [camp, careerId] of [[1, 1], [2, 101]]) { const missing = b.room.counts[camp] - E.poolStats(b, camp).capacity; if (missing > 0) b.roles.find(r => r.templateCareerId === careerId).count += missing; }
    E.ensureCampRules(b);
  } else if (page === 'wins') {
    for (const f of b.factions) if (f.kind === 'custom') f.baseVictory = null;
    b.campEvents = b.factions.map(f => ({key: 'camp-' + f.id, camp: f.id, join: 'any', events: []}));
  } else if (page === 'roles') {
    const r = b.roles.find(r => r.uid === roleUid); if (!r) throw Error('请先选择角色。');
    const fresh = E.isCustom(r) ? E.makeCustomRole(b, 1) : E.makeRole(r.templateCareerId);
    r.slots = clone(fresh.slots); r.skillOverrides = {};
  } else if (page !== 'review') throw Error('当前页面不能重置。');
  return b;
}
function pageResetDetails() {
  const r = role();
  return {
    room: {label: '房间设置', copy: '恢复默认人数、会议参数、对局参数和玩法介绍。阵营分配、角色与胜利条件会保留。'},
    factions: {label: '阵营分配', copy: '按当前房间人数恢复鹅、鸭、中立及经典候选角色。自建阵营及被移除角色的设置会一并移除。保留角色的技能、原三阵营的额外条件和房间参数不变。'},
    wins: {label: '胜利设置', copy: '清空所有阵营的额外胜利条件。鹅、鸭、中立的原有胜利条件仍固定，阵营与技能保持原样。'},
    roles: {label: r ? r.name + '的技能' : '当前角色技能', copy: r ? (E.isCustom(r) ? '清空「' + r.name + '」的技能和技能参数调整。' : '恢复「' + r.name + '」的原技能，清除技能参数调整。') : '请先选择角色。'},
    review: {label: '预览结果', copy: '清空本次抽取名单和胜利试算结果，已配置的板子保持原样。'}
  }[tab];
}
function pageResetModal() {
  const d = pageResetDetails(); if (tab === 'roles' && !role()) return;
  modal(modalHead('重置' + nameHtml(d.label) + '？') + '<p class="reset-scope-copy">' + esc(d.copy) + '</p><p class="setting-hint" style="margin-top:10px">重置后可立即撤销。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-action="confirm-page-reset">确认重置</button></div>', true);
}
function performPageReset() {
  const before = snapshotEditor(pageResetDetails().label);
  board = resetPageData(board, tab, role()?.uid); paramSkill = 0;
  if (tab === 'factions') { allocationCamp = 1; membersOpen = {}; }
  if (!board.roles.some(r => r.uid === selected)) selected = board.roles[0]?.uid || '';
  if (!E.faction(board, ruleCamp)) ruleCamp = 1;
  if (tab === 'review') { drawResult = null; drawError = ''; scenario = null; simulationRun = false; } else mark();
  lastPageReset = before; closeModal(); render(); $('#content').scrollTop = 0;
  toast(before.label + '已重置');
}
function undoPageReset(){const previous=lastPageReset;if(!previous)return;simOpen=previous.simOpen??false;membersOpen=clone(previous.membersOpen||{});rosterCollapsed=clone(previous.rosterCollapsed||{});rosterSearchCollapsed={};board=clone(previous.board);tab=previous.tab;allocationCamp=previous.allocationCamp??1;selected=previous.selected;ruleCamp=previous.ruleCamp;rosterSearch=previous.rosterSearch??'';skillSearch=previous.skillSearch??'';skillModule=previous.skillModule??'all';roomMoreOpen=previous.roomMoreOpen??false;navigationContext=previous.navigationContext||null;paramSkill=0;if(previous.tab!=='review'||previous.kind==='global'||previous.kind==='remove-role')mark();drawResult=previous.drawResult;drawError=previous.drawError;scenario=previous.scenario;simulationRun=previous.simulationRun;simGroup=previous.simGroup;simRole=previous.simRole||'';lastPageReset=null;render();$('#content').scrollTop=0;revealAllocationCamp();toast(resetWords(previous.kind)[2]);}

/* ---------- 存档、导入导出 ---------- */
function fileMenu() {
  const items = [['load', 'folder', '我的板子', '打开已保存的板子'], ['save', 'save', '保存一份', '留下一个命名存档'], ['export', 'download', '导出板子', HOSTED ? '复制或下载，分享给朋友' : '下载文件，分享给朋友'], ['import', 'upload', '导入板子', HOSTED ? '选择文件，或粘贴板子数据' : '打开已有的板子文件'], ['how-to', 'help', '怎么使用？', '一分钟了解编辑流程'], ['reset-all', 'undo', '重置全部', '恢复当前板子的全部初始设置']];
  modal(modalHead('管理我的板子') + `<div class="file-menu-grid">${items.map(([a, ic, t, s]) => `<button class="${a==='reset-all'?'reset-all-entry':''}" data-action="${a}"><span class="menu-ic">${icon(ic)}</span><strong>${t}</strong><span>${s}</span></button>`).join('')}</div>`, true);
}
function howTo() {
  const steps = [['设置房间', '选好人数，会议设置可直接用默认。'], ['分配阵营', '定好每队几人，再挑可随机出现的角色。'], ['搭配技能', '给已有或自创角色添加主动或被动技能。'], ['设置胜利', '保留原规则，或给阵营添加额外胜利条件。'], ['预览板子', '试抽一局，修正提示后导出分享。']];
  modal(modalHead('跟着这 5 步，做一套新玩法') + `<ol class="quick-guide">${steps.map(([t, p], i) => `<li><span class="guide-badge">${stepArt(STEP_INFO[STEPS[i]].icon)}<b>${i + 1}</b></span><strong>${t}</strong><p>${p}</p></li>`).join('')}</ol><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">开始动手</button></div>`, true);
}
function readSaves() { try { const a = JSON.parse(localStorage.getItem(STORE) || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } }
function save() {
  try { const saves = readSaves(), item = {id: Date.now().toString(), name: board.boardName, time: new Date().toISOString(), board: E.exportDraft(board)}; saves.unshift(item); localStorage.setItem(STORE, JSON.stringify(saves.slice(0, 8))); dirty = false; $('#save-state').textContent = '已保存命名存档'; if ($('#modal').open && $('#modal').dataset.kind === 'saves') loadModal(); toast('已保存到本机存档（保留最近8份）'); }
  catch (e) { toast('本地存储不可用，请导出 JSON 保存。'); }
}
function loadModal() {
  const saves = readSaves();
  modal(modalHead('我的本机存档') + `<small class="modal-small">加载会先备份当前板子；最多保留最近 8 份命名存档。</small>${saves.map((s, i) => `<div class="save-row"><div><strong>${esc(s.name)}</strong><p>${esc(new Date(s.time).toLocaleString('zh-CN'))}</p></div><div class="inline-actions"><button class="btn btn-gold btn-sm" data-load-save="${i}">加载</button><button class="btn btn-ghost btn-sm danger" data-delete-save="${i}">删除</button></div></div>`).join('') || '<div class="empty" style="margin-top:15px">暂无命名存档，在“更多”中点击“保存一份”留下一个版本。</div>'}<div class="modal-actions"><button class="btn btn-ghost btn-sm" data-action="recover">恢复上次自动暂存</button><button class="btn btn-ghost btn-sm" data-action="recover-previous">恢复替换前草稿</button><span class="spacer"></span><button class="btn btn-violet btn-sm" data-action="save">${icon('save')}保存一份</button><button class="btn btn-gold btn-sm" data-action="close-modal">关闭</button></div>`, false, 'saves');
}
function replaceBoard(b,keepModal=false){const incoming=E.validateShape(b);try{localStorage.setItem(STORE+'-recovery',JSON.stringify(E.exportDraft(board)));}catch{}rosterCollapsed={};rosterSearchCollapsed={};membersOpen={};simOpen=false;justDrew=false;allocationCamp=1;board=incoming;const fixNote=normalizeNote(normalizeBoard(board));selected=board.roles[0]?.uid||'';tab='room';ruleCamp=1;rosterSearch='';skillSearch='';skillModule='all';roomMoreOpen=false;navigationContext=null;simRole='';simGroup='';scenario=null;paramSkill=0;simulationRun=false;mark();if(!keepModal)closeModal();render();$('#content').scrollTop=0;toast('已载入板子，原草稿已备份'+(fixNote?'；'+fixNote:''));}
function exportModal() {
  header(); const errors = checkReport.filter(x => x.level === 'error').length;
  if (HOSTED) {
    askHostDownloads();
    modal(modalHead('导出我的板子') + `<div class="modal-notice">${errors ? `有 ${errors} 项错误。可以导出问题草稿，其中会保留检查报告，便于继续修改。` : '当前基础检查通过。导出的板子保留全部自定义设置。'}</div><p class="muted">复制板子数据发给朋友，对方在“导入板子”里粘贴即可；能下载时也可以存成文件。</p><label class="export-text" id="export-text-wrap" hidden><span class="field-label">没能自动复制，请手动全选并复制：</span><textarea id="export-text" readonly spellcheck="false" aria-label="板子数据"></textarea></label><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">继续编辑</button><button class="btn btn-ghost" id="export-download" data-action="download" ${hostDownloads ? '' : 'hidden'}>${icon('download')}下载文件</button><button class="btn btn-gold" data-action="copy-export">${icon('copy')}${errors ? '复制问题草稿' : '复制板子数据'}</button></div>`, true, 'export');
    return;
  }
  modal(modalHead('导出我的板子') + `<div class="modal-notice">${errors ? `有 ${errors} 项错误。可以导出问题草稿，文件会保留检查报告，便于继续修改。` : '当前基础检查通过。导出为离线板子草稿，保留全部自定义设置。'}</div><p class="muted">保存全部设置，之后可重新导入编辑。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">继续编辑</button><button class="btn btn-gold" data-action="download">${icon('download')}${errors ? '导出问题草稿' : '下载板子文件'}</button></div>`);
}
function exportPayload() { const out = E.exportDraft(board); out.checkReport = clone(checkReport); if (drawResult) out.drawPreview = clone(drawResult); return JSON.stringify(out, null, 2); }
function exportFileName() { return (board.boardName.replace(/[\\/:*?"<>|]/g, '_') || '板子') + '.json'; }
function download() {
  try {
    const text = exportPayload();
    if (HOSTED) { hostedSave(text); return; }
    const blob = new Blob([text], {type: 'application/json;charset=utf-8'});
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = exportFileName(); a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000); toast('板子已导出');
  } catch (e) { toast('导出失败：' + e.message); }
}
// 托管版的下载能力由平台提供，可能没有；拿到之后才显示“下载文件”，每次保存都要查看者确认。
function askHostDownloads() {
  if (!HOSTED || hostDownloads || hostDownloadsAsked || !(window.claude && typeof window.claude.use === 'function')) return;
  hostDownloadsAsked = Promise.resolve().then(() => window.claude.use('downloads')).then(ns => {
    hostDownloadsAsked = null; hostDownloads = ns || null;
    if (hostDownloads) $('#export-download')?.removeAttribute('hidden');
  }).catch(() => { hostDownloadsAsked = null; });
}
async function hostedSave(text) {
  const useCopy = () => { hostDownloads = null; $('#export-download')?.setAttribute('hidden', ''); toast('这里暂时不能下载，请用“复制板子数据”'); };
  if (!hostDownloads) { useCopy(); return; }
  try { await hostDownloads.save({filename: exportFileName(), data: text}); toast('板子已导出'); }
  catch (e) {
    const code = e && e.code;
    if (code === 'declined') toast('已取消下载');
    else if (code === 'rate_limited') toast('已有一个保存提示在等待确认，请先处理它');
    else useCopy();
  }
}
function copyExport() {
  let text; try { text = exportPayload(); } catch (e) { toast('导出失败：' + e.message); return; }
  const manual = () => { const wrap = $('#export-text-wrap'), area = $('#export-text'); if (!area) return; area.value = text; wrap.hidden = false; area.focus(); area.select(); toast('没能自动复制，请手动复制下面的内容'); };
  try { navigator.clipboard.writeText(text).then(() => toast('已复制板子数据，可以粘贴发给朋友'), manual); } catch { manual(); }
}
function importModal() {
  modal(modalHead('导入板子') + `<p class="muted">选择板子文件，或把收到的板子数据粘贴到下面。</p><div class="import-file"><button class="btn btn-ghost" data-action="import-file">${icon('upload')}选择板子文件</button></div><label class="field import-paste" for="import-text"><span class="field-label">粘贴板子数据</span><textarea id="import-text" spellcheck="false" autocomplete="off" placeholder="以 { 开头的板子数据"></textarea></label><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" data-action="import-text">导入</button></div>`, true, 'import');
}
function confirmImport(data) {
  const incoming = E.validateShape(data), issues = E.validate(incoming);
  modal(modalHead('导入为新草稿') + `<p style="font:18px var(--font-display)">板子：${esc(incoming.boardName)}</p><p style="margin-top:8px;color:var(--text-2)">${incoming.room.total} 人 · ${incoming.roles.length} 种候选 · ${issues.filter(x => x.level === 'error').length} 项待修正</p><div class="note" style="margin-top:14px">只导入到本编辑器。当前草稿会先保存恢复备份，不修改游戏房间。</div><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" id="confirm-import">导入草稿</button></div>`);
  $('#confirm-import').addEventListener('click', () => replaceBoard(incoming), {once: true});
}
async function importFile(file) {
  if (!file) return;
  try {
    if (file.size > 2 * 1024 * 1024) throw Error('文件超过 2MB');
    confirmImport(JSON.parse(await file.text()));
  } catch (e) { toast('导入失败：' + e.message); } finally { $('#file-import').value = ''; }
}
function importPasted() {
  const text = ($('#import-text')?.value || '').trim();
  try {
    if (!text) throw Error('请先粘贴板子数据');
    if (text.length > 2 * 1024 * 1024) throw Error('内容超过 2MB');
    let data; try { data = JSON.parse(text); } catch { throw Error('内容不是完整的板子数据，请重新复制后粘贴'); }
    confirmImport(data);
  } catch (e) { toast('导入失败：' + e.message); $('#import-text')?.focus(); }
}

/* ---------- 实时刷新（输入中不整页重绘） ---------- */
function refreshInline() {
  $$('[data-total-delta]').forEach(b => b.disabled = Number(b.dataset.totalDelta) > 0 ? board.room.total >= E.ROOM_LIMITS.max : board.room.total <= E.ROOM_LIMITS.min);
  $$('[data-count-step]').forEach(b => b.disabled = Number(b.dataset.delta) > 0 ? board.room.counts[b.dataset.countStep] >= E.ROOM_LIMITS.max : board.room.counts[b.dataset.countStep] === 0);
  $$('[data-total-preset]').forEach(b => { const on = Number(b.dataset.totalPreset) === board.room.total; b.classList.toggle('selected', on); b.setAttribute('aria-pressed', on); });
  const ring = $('.room-hero .seat-ring');
  if (ring) { const before = captureSeats(); ring.outerHTML = seatRing(planTokens()); playSeats(before); }
  const alloc = $('.js-alloc'); if (alloc) alloc.innerHTML = allocationSummary();
  const strip = $('.js-seat-strip'); if (strip) strip.innerHTML = seatStrip();
  const status = $('[data-alloc-status]'); if (status) status.outerHTML = allocationStatus();
  for (const f of board.factions) { const node = $(`[data-pool-count="${f.id}"]`); if (node) { const p = E.poolStats(board, f.id); node.textContent = p.candidates + ' 个候选 · 随机抽 ' + p.seats + ' 人'; } }
  refreshAllocationRows();
  $$('[data-room-range]').forEach(rg => { const k = rg.dataset.roomRange; if (document.activeElement !== rg) rg.value = board.room[k]; setPct(rg); });
  $$('input[type=number][data-room]').forEach(n => { if (document.activeElement !== n && !n.hidden && Number(n.value) !== board.room[n.dataset.room]) n.value = board.room[n.dataset.room]; });
  const drawNode = $('#draw-panel'); if (drawNode && !drawResult) drawNode.outerHTML = drawPanel();
  refreshGoalWarnings();
  $$('[data-select-role]').forEach(button => { const r = board.roles.find(x => x.uid === button.dataset.selectRole); if (!r) return; button.querySelector('.name>span').innerHTML = nameHtml(r.name); const c = button.querySelector('.copies'); c.textContent = '≤' + r.count; c.title = '单局最多出现' + r.count + '次'; button.querySelector('.name small').textContent = E.campName(board, r.camp); });
}

/* ---------- 事件 ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('button'); if (!el) return;
  const d = el.dataset;
  try {
    if (d.stepFor) {
      const input = document.getElementById(d.stepFor); if (!input) return;
      const min = Number(input.min || 0), max = Number(input.max || 100000), cur = Number.isFinite(input.valueAsNumber) ? input.valueAsNumber : min, next = Math.max(min, Math.min(max, cur + Number(d.delta)));
      if (next === cur) return;
      input.value = next; input.dispatchEvent(new Event('input', {bubbles: true})); input.dispatchEvent(new Event('change', {bubbles: true}));
      return;
    }
    if (d.tab) { go(d.tab); return; }
    if (d.allocationCamp) { switchAllocationCamp(Number(d.allocationCamp)); return; }
    if (d.allocationToggle) { toggleAllocationPool(Number(d.allocationToggle), el); return; }
    if (d.issueIndex!==undefined) { const issue=checkReport[Number(d.issueIndex)];if(issue)navigateTo(issueDestination(issue,board),issue);return; }
    if (d.issueRoom!==undefined) { const issue=checkReport[Number(d.issueRoom)];if(issue){const reports=E.campRule(board,issue.camp).events.some(e=>e.type==='reports');navigateTo({tab:'room',field:reports&&!board.room.allow_report_dead?'allow_report_dead':'meeting_amount'},issue);}return; }
    if (d.confirmRemoveRole) {closeModal();removeCandidate(d.confirmRemoveRole);return;}
    if (d.totalPreset || d.totalDelta) { board.room.total = Math.max(E.ROOM_LIMITS.min, Math.min(E.ROOM_LIMITS.max, d.totalPreset ? Number(d.totalPreset) : board.room.total + Number(d.totalDelta))); mark(); renderInPlace(); return; }
    if (d.ruleCamp) { selectCamp(d.ruleCamp, true); return; }
    if (d.applyCond) { addCondOpen(d.applyCond, ruleCamp); return; }
    if (d.acPick) { addCondPick(d.acPick); return; }
    if (d.acBulk) { addCondBulk(d.acBulk); return; }
    if (d.copyRole) { copyRole(d.copyRole); return; }
    if (d.pasteRoleCamp) { pasteRole(Number(d.pasteRoleCamp)); return; }
    if (d.acCat) { if (!addCond) return; addCond.category = d.acCat; $$('#ac-cats [data-ac-cat]').forEach(b => { const on = b.dataset.acCat === d.acCat; b.classList.toggle('selected', on); b.setAttribute('aria-pressed', on); }); addCondRefreshList(); $('#ac-list').scrollTop = 0; return; }
    if (d.openCamp) { openCamp(d.openCamp); return; }
    if (d.issueFaction) { navigateTo({tab:'factions',camp:Number(d.issueFaction),kind:'candidates'});return; }
    if (d.removeEvent) { removeGoal(d.removeEvent); return; }
    if (d.toggleRosterCamp !== undefined) { toggleRosterCamp(Number(d.toggleRosterCamp)); return; }
    if (d.toggleRosterAll !== undefined) { toggleRosterGroups(); return; }
    if (d.selectRole) { selected = d.selectRole; revealRosterRole(role()); paramSkill = 0; renderInPlace(); $('.role-hero')?.scrollIntoView({block: 'nearest'}); return; }
    if (d.countStep) {
      const c = d.countStep;
      board.room.counts[c] = Math.max(0, Math.min(E.ROOM_LIMITS.max, board.room.counts[c] + Number(d.delta)));
      const input = $(`[data-count="${c}"]`); if (input) input.value = board.room.counts[c];
      mark(); refreshInline(); if (el.disabled) input?.focus({preventScroll:true}); return;
    }
    if (d.addCareer) {
      const c = E.careers.get(Number(d.addCareer));
      if (!c || !E.classicCareerIds.has(c.id) || (careerLockedCamp !== null && c.camp !== careerLockedCamp)) throw Error('请选择当前阵营的已有职业');
      if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('候选池最多300个角色条目');
      const r = E.addCareer(board,c.id); selected = r.uid; rosterSearch=''; revealRosterRole(r); paramSkill = 0; mark(); renderInPlace(); refreshPickerList('#career-list', careerItems(), 'data-add-career'); toast('已添加「' + c.name + '」'); return;
    }
    if (d.careerCamp) { careerCamp = d.careerCamp; $$('[data-career-camp]').forEach(b => { b.classList.toggle('selected', b.dataset.careerCamp === careerCamp); b.setAttribute('aria-pressed', b.dataset.careerCamp === careerCamp); }); $('#career-list').innerHTML = careerItems(); return; }
    if (d.skillModule) { selectSkillModule(d.skillModule); return; }
    if (d.skillType) { skillType = d.skillType; syncSkillPickerFilters(); return; }
    if (d.resetNeutralCount) { const r=board.roles.find(r=>r.uid===d.resetNeutralCount); if(r){E.setRoleCount(r,1);mark();renderInPlace();roleOptions();toast('已改为每局最多1人');}return; }
    if (d.removeCandidate) { removeCandidate(d.removeCandidate); return; }
    if (d.addSkill) {
      const r = role(), id = +d.addSkill, before = new Set(E.allIds(r)); E.addSkill(r, id, slotChoice);
      const added = E.allIds(r).filter(x => !before.has(x)); paramSkill = 0; mark(); renderInPlace(); updateSkillPicker();
      toast('已添加 '+E.playerSkill(id).name); return;
    }
    if (d.removeSkill) { E.removeSkill(role(), +d.removeSkill, d.slot); mark(); renderInPlace(); return; }
    if (d.param) { skillParameters(d.param); return; }
    if (d.locate) {navigateTo({tab:'roles',uid:d.locate,kind:'skills'});return;}
    if (d.loadSave !== undefined) { replaceBoard(readSaves()[+d.loadSave].board, true); return; }
    if (d.deleteSave !== undefined) { const saves = readSaves(); saves.splice(+d.deleteSave, 1); localStorage.setItem(STORE, JSON.stringify(saves)); loadModal(); return; }
    if (d.editRole) {navigateTo({tab:'roles',uid:d.editRole});return;}
    if (d.newRoleCamp) { customRoleModal(Number(d.newRoleCamp)); return; }
    if (d.addOriginalCamp) { addRoleModal(Number(d.addOriginalCamp)); return; }
    if (d.deleteFaction) { const id = Number(d.deleteFaction); E.removeFaction(board, id); if (ruleCamp === id) ruleCamp = 1; mark(); renderInPlace(); revealAllocationCamp(); toast('已删除空阵营'); return; }
    const action = d.action;
    if (!action) return;
    if (action === 'reset-page') pageResetModal();
    else if (action === 'reset-all') resetAllModal();
    else if (action === 'confirm-global-reset') performGlobalReset();
    else if (action === 'back-review') go('review');
    else if (action === 'confirm-page-reset') performPageReset();
    else if (action === 'undo-page-reset') undoPageReset();
    else if (action === 'next') { if (tab === 'review') exportModal(); else go(STEPS[STEPS.indexOf(tab) + 1]); }
    else if (action === 'prev') go(STEPS[Math.max(0, STEPS.indexOf(tab) - 1)]);
    else if (action === 'choose-skills') skillPicker();
    else if (action === 'role-options') roleOptions();
    else if (action === 'file-menu') fileMenu();
    else if (action === 'how-to') howTo();
    else if (action === 'to-wins') openCamp(1);
    else if (action === 'to-roles') go('roles');
    else if (action === 'to-factions') go('factions');
    else if (action === 'to-draw') go('review');
    else if (action === 'view-original-neutrals') originalNeutralModal();
    else if (action === 'add-role') addRoleModal();
    else if (action === 'new-custom-role' || action === 'new-custom-neutral') customRoleModal();
    else if (action === 'add-faction') {
      // 新阵营只在“分配阵营”创建；其他页面即使触发也不处理。
      if (tab !== 'factions') return;
      const f = E.addFaction(board); allocationCamp = f.id; mark(); renderInPlace(); revealAllocationCamp();
      const detail = $('.allocation-detail-scroll'); if (detail) detail.scrollTop = 0;
      const input = $(`[data-faction-name="${f.id}"]`); if (input) { input.focus({preventScroll:true}); input.select(); }
      toast('已创建' + f.name + '，请分配人数与角色');
    }
    else if (action === 'clear-custom-skills') pageResetModal();
    else if (action === 'role-art') roleArtModal();
    else if (action === 'close-modal') closeModal();
    else if (action === 'add-cond') addCondOpen(null, ruleCamp);
    else if (action === 'paste-role') pasteRole();
    else if (action === 'ac-confirm') addCondConfirm();
    else if (action === 'ac-back') { $('.ac').dataset.step = 'pick'; ($('#ac-list .ac-item.selected') || $('#ac-search'))?.focus({preventScroll: true}); }
    else if (action === 'save') save();
    else if (action === 'load') loadModal();
    else if (action === 'recover') { const b = JSON.parse(localStorage.getItem(AUTOSAVE) || 'null'); if (!b) throw Error('暂无自动暂存'); replaceBoard(b, true); }
    else if (action === 'recover-previous') { const b = JSON.parse(localStorage.getItem(STORE + '-recovery') || 'null'); if (!b) throw Error('暂无替换备份'); replaceBoard(b, true); }
    else if (action === 'export') exportModal();
    else if (action === 'download') download();
    else if (action === 'import') { if (HOSTED) importModal(); else { closeModal(); $('#file-import').click(); } }
    else if (action === 'import-file') { closeModal(); $('#file-import').click(); }
    else if (action === 'import-text') importPasted();
    else if (action === 'copy-export') copyExport();
    else if (action === 'draw-pool') { try { drawResult = E.drawPool(board); drawError = ''; scenario = null; simulationRun = false; justDrew = true; } catch (error) { drawResult = null; drawError = error.message; } renderInPlace(); }
    else if (action === 'pool-example') modal(modalHead('载入随机角色池示例') + '<p style="color:var(--text-2)">载入鹅30种、鸭20种、中立8种候选，本局仍为6／2／2共10人。当前草稿将自动备份。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" data-action="confirm-pool-example">载入示例</button></div>', true);
    else if (action === 'confirm-pool-example') replaceBoard(E.poolExample());
    else if (action === 'remove-role') deleteRoleModal();
    else if (action === 'restore-role') pageResetModal();
    else if (action === 'close-params') { paramSkill = 0; closeModal(); renderInPlace(); }
    else if (action === 'reset-params') { E.resetSkillParameters(role(),paramSkill); mark(); renderInPlace(); skillParameters(paramSkill); }
    else if (action === 'simulate') { simulationRun = true; showResult(); }
    else if (action === 'recheck') { renderInPlace(); toast('已重新检查'); }
  } catch (err) { toast(err.message); }
});
// Ctrl/⌘ + C 复制自创角色，Ctrl/⌘ + V 粘贴。只在“分配阵营”和“搭配技能”两页接管，
// 而且焦点不在输入框里、没有弹窗、没有选中文字时才生效，其余情况保持浏览器原有的复制粘贴。
document.addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.isComposing) return;
  const key = e.key.toLowerCase(); if (key !== 'c' && key !== 'v') return;
  if (tab !== 'factions' && tab !== 'roles') return;
  if (document.querySelector('dialog[open]')) return;
  const t = e.target instanceof Element ? e.target : document.body;
  if (t.closest('input,textarea,select,[contenteditable="true"]')) return;
  try {
    if (key === 'c') {
      if (String(getSelection() || '').trim()) return;
      const uid = t.closest('.role-chip')?.querySelector('[data-edit-role]')?.dataset.editRole || t.closest('[data-select-role]')?.dataset.selectRole || (tab === 'roles' ? role()?.uid : '');
      if (!uid) return;
      e.preventDefault(); copyRole(uid);
    } else {
      if (!roleClip) return;
      e.preventDefault(); pasteRole(tab === 'factions' ? allocationCamp : null);
    }
  } catch (error) { toast(error.message); }
});
// 另一个标签页里复制了角色：这边的剪贴板跟着更新（按钮在下次重绘时出现）。
window.addEventListener('storage', e => { if (e.key === ROLE_CLIP) roleClip = readRoleClip(); });
document.addEventListener('toggle', e => {
  const t = e.target; if (!t.isConnected || !t.classList) return;
  if (t.classList.contains('room-more')) roomMoreOpen = t.open;
  else if (t.classList.contains('simple-sim')) simOpen = t.open;
  else if (t.classList.contains('native-effects')) passiveExpanded[t.dataset.passiveRole] = t.open;
}, true);
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'roster-search') { rosterSearch = t.value; rosterSearchCollapsed={}; refreshRoster(); return; }
  if (t.id === 'ac-search') { if (addCond) { addCond.search = t.value; addCondRefreshList(); $('#ac-list').scrollTop = 0; } return; }
  if (t.dataset.acValue || t.dataset.acWeight) { addCondInput(t); return; }
  if (t.id === 'skill-search') { skillSearch = t.value; updateSkillPicker(true); return; }
  if (t.id === 'career-search') { careerSearch = t.value; $('#career-list').innerHTML = careerItems(); return; }
  if (t.id === 'new-role-name') { $('#custom-role-error').hidden = true; return; }
  if (t.dataset.roomRange) { const k = t.dataset.roomRange; board.room[k] = Number(t.value); setPct(t); const num = $(`input[type=number][data-room="${k}"]`); if (num) num.value = t.value; scheduleMark(); return; }
  // 合法数值边输入边保存，不替换正在编辑的输入框。
  try {
    if (t.dataset.room && t.type !== 'number') return;
    if (t.dataset.simProgress) { if (Number.isInteger(t.valueAsNumber) && t.valueAsNumber >= 0 && t.valueAsNumber <= 999) { scenario.progress[t.dataset.simProgress] = t.valueAsNumber; simulationRun = false; $('#sim-result').innerHTML = ''; } return; }
    if (t.type === 'number' && (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < Number(t.min || 0) || t.valueAsNumber > Number(t.max || 100000))) return;
    if (t.dataset.count) board.room.counts[t.dataset.count] = t.valueAsNumber;
    else if (t.dataset.room) board.room[t.dataset.room] = t.valueAsNumber;
    else if (t.dataset.roleField === 'name' && t.value.trim()) role().name = t.value.trim();
    else if (t.dataset.roleField === 'count') E.setRoleCount(role(),t.valueAsNumber);
    else if (t.dataset.factionName && t.value.trim()) E.renameFaction(board, Number(t.dataset.factionName), t.value);
    else if (t.dataset.eventValue) findEvent(t.dataset.eventValue).event.value = t.valueAsNumber;
    else if (t.dataset.eventWeight) findEvent(t.dataset.eventWeight).event.weight = t.valueAsNumber;
    else if (t.dataset.skillParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillParam] = t.valueAsNumber; }
    else if (t.dataset.stageParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill].stages ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage] ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam] = t.valueAsNumber; }
    else return;
    mark(); refreshInline();
  } catch { /* 失焦时的 change 事件会给出最终校验提示。 */ }
});
document.addEventListener('change', e => {
  const t = e.target;
  try {
    if (t.id === 'file-import') { importFile(t.files[0]); return; }
    if (t.id === 'ac-search') return;
    if (t.dataset.acToggle) { addCondToggle(t); return; }
    if (t.dataset.acValue || t.dataset.acWeight) { addCondInput(t, true); return; }
    if (t.id === 'slot-choice') { slotChoice = t.value; return; }
    if (t.hasAttribute('data-skill-module-select')) { selectSkillModule(t.value); return; }
    if (t.id === 'show-unopened-skills') { skillShowUnavailable = t.checked; syncSkillPickerFilters(); return; }
    if (t.dataset.roomRange) { scheduleMark(); return; }
    if (t.id === 'sim-group') { simGroup = t.value; scenario = newScenario(); simulationRun = false; renderSimulation(); return; }
    if (t.dataset.simProgress) { if (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < 0 || t.valueAsNumber > 999) throw Error('请输入0–999的整数'); scenario.progress[t.dataset.simProgress] = t.valueAsNumber; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.hasAttribute('data-sim-original')) { scenario.originalWinner = t.value; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.hasAttribute('data-sim-alive')) { scenario.eligibleAlive = t.checked; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.dataset.roomToggle) { const k = t.dataset.roomToggle; board.room[k] = t.checked; const st = t.closest('.toggle-field')?.querySelector('.switch-state'); if (st) st.textContent = t.checked ? t.dataset.on : t.dataset.off; mark(); return; }
    if (t.dataset.factionName) { E.renameFaction(board, Number(t.dataset.factionName), t.value); syncAllocationName(t); mark(); refreshInline(); return; }
    if (t.id === 'new-role-camp') { $('#custom-role-error').hidden = true; refreshCustomRoleForm(); return; }
    if (t.dataset.assignFaction) { if (!t.value) return; const r = board.roles.find(r => r.uid === t.value); E.setRoleCamp(board, r, Number(t.dataset.assignFaction)); mark(); renderInPlace(); return; }
    if (t.type === 'number' && (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < Number(t.min || 0) || t.valueAsNumber > Number(t.max || 100000))) {
      if (t.dataset.count) t.value = board.room.counts[t.dataset.count];
      else if ($('#modal').open && $('#modal').dataset.kind === 'parameters') skillParameters(paramSkill);
      else if ($('#modal').open && $('#modal').dataset.kind === 'role-options') roleOptions();
      else renderInPlace();
      toast('请输入' + (t.min || 0) + '–' + (t.max || 100000) + '的整数'); return;
    }
    if (t.dataset.eventWeight) { const active = document.activeElement, id = active?.id, step = active?.dataset?.stepFor ? `[data-step-for="${CSS.escape(active.dataset.stepFor)}"][data-delta="${active.dataset.delta}"]` : ''; findEvent(t.dataset.eventWeight).event.weight = t.valueAsNumber; mark(); renderInPlace(); (step ? $(step) : id ? document.getElementById(id) : null)?.focus({preventScroll: true}); return; }
    if (t.dataset.eventValue) { findEvent(t.dataset.eventValue).event.value = t.valueAsNumber; mark(); refreshInline(); return; }
    if (t.id === 'board-name') { if (!t.value.trim()) { toast('板子名称不能为空'); t.value = board.boardName; header(); return; } board.boardName = t.value.trim(); }
    else if (t.hasAttribute('data-description')) board.description = t.value;
    else if (t.dataset.room) {
      const key = t.dataset.room, d = E.ROOM_FIELDS[key];
      if (t.value === 'custom') { const input = t.closest('.room-option')?.querySelector('input[type=number]'); if (input) { input.hidden = false; input.focus(); input.select(); } return; }
      board.room[key] = d?.type === 'boolean' ? t.value === 'true' : Number(t.value);
    }
    else if (t.dataset.skillLimit) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillLimit] = Number(t.value); }
    else if (t.dataset.count) board.room.counts[t.dataset.count] = t.valueAsNumber;
    else if (t.dataset.roleField) {
      const k = t.dataset.roleField;
      if (k === 'name' && !t.value.trim()) throw Error('角色名不能为空');
      if (k === 'camp') { E.setRoleCamp(board, role(), Number(t.value)); toast('已采用' + E.campName(board, role().camp) + '目标'); }
      else if(k==='count') E.setRoleCount(role(),Number(t.value));
      else role()[k] = t.type === 'number' ? Number(t.value) : t.value.trim();
    }
    else if (t.dataset.skillParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillParam] = t.valueAsNumber; }
    else if (t.dataset.stageParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill].stages ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage] ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam] = t.valueAsNumber; }
    else return;
    mark();
    if (t.dataset.room === 'total' || (t.dataset.room && t.tagName === 'SELECT')) renderInPlace();
    else if (t.type === 'number' || t.type === 'text' || t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && !t.type)) refreshInline();
    else renderInPlace();
  } catch (err) { toast(err.message); if (t.dataset.factionName) syncAllocationName(t); if (t.dataset.assignFaction) renderInPlace(); if (t.dataset.roleField === 'camp') t.value = String(role().camp); }
});
$('#modal').addEventListener('close', () => {
  // 添加条件弹窗关掉后清空内容，暂存的选择一并丢弃，页面上不留隐藏的重复控件。
  if ($('#modal').dataset.kind === 'add-cond') { addCond = null; $('#modal-content').innerHTML = ''; }
  if ($('#modal').dataset.kind === 'parameters' && tab === 'roles') renderInPlace();
});

/* ---------- 启动 ---------- */
let hadDraft = false;
try {
  const saved = localStorage.getItem(AUTOSAVE);
  if (saved) {
    hadDraft = true;
    const raw = JSON.parse(saved); board = E.validateShape(raw);
    const fixNote = normalizeNote(normalizeBoard(board));
    if (fixNote) { try { localStorage.setItem(AUTOSAVE, JSON.stringify(E.exportDraft(board))); } catch {} setTimeout(() => toast('草稿已按新规则更新：' + fixNote), 600); }
    if (raw.schema !== E.SCHEMA) { localStorage.setItem(STORE + '-pre-v027', saved); setTimeout(() => toast('旧草稿已恢复'), 500); }
    selected = board.roles[0]?.uid || ''; $('#save-state').textContent = '已恢复草稿';
  }
} catch {}
if (location.hash === '#factions') tab = 'factions';
render();
if (window.GgdBoot) window.GgdBoot.ready();
try { if (tab !== 'factions' && !hadDraft && !localStorage.getItem(GUIDE_SEEN)) { localStorage.setItem(GUIDE_SEEN, '1'); setTimeout(howTo, 350); } } catch {}


