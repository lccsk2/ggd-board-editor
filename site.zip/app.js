'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 界面层（预览版 0.5.0.6）
 * 规则、草稿格式、随机抽取与判胜全部沿用 engine.js → faction-rules.js → camp-events.js → factions.js；已合入 0.4.0.4 的完整技能与交互修复。
 * 本文件只负责界面：五步流程、会议桌座位、阵营卡、胜利目标、角色卡、弹窗与本机存档。
 */
const E = window.EditorEngine, D = E.D;
const $ = s => document.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const clone = E.clone;
// 元黑的数字“1”是一条竖线，容易看成字母 I；标题里的数字改用典黑加粗。
const nums = html => String(html).replace(/&#?\w+;|<[^>]*>|\d+/g, m => /^\d+$/.test(m) ? `<span class="num">${m}</span>` : m);
const nameHtml = s => nums(esc(s));
const STORE = 'ggd-board-workshop-v1', AUTOSAVE = STORE + '-autosave', GUIDE_SEEN = STORE + '-guide-seen';
const STEPS = ['room', 'factions', 'roles', 'wins', 'review'];
const STEP_INFO = {
  room: {icon: 's-room', next: '下一步：分配阵营 →', hint: '默认设置已经备好，随时可以下一步。'},
  factions: {icon: 's-factions', next: '下一步：搭配技能 →', hint: '候选角色可以多选，按人数随机抽取。'},
  roles: {icon: 's-roles', next: '下一步：设置胜利 →', hint: '不想改技能？保留角色原本的技能即可。'},
  wins: {icon: 's-wins', next: '下一步：预览板子 →', hint: '无需改动原规则，也可以直接下一步。'},
  review: {icon: 's-review', next: '导出我的板子', hint: '导出文件后，可以分享或再次导入编辑。'}
};
// 检查徽章与报错按钮共用同一条定位规则。
const CATEGORY_ICON = {'对抗与推理': 'swords', '行动与技能': 'bolt', '会议与生存': 'bell'};
const ROOM_ICON = {meeting_amount: 'bell', discuss_cd: 'users', vote_cd: 'ballot', first_bell_cd: 'clock', meeting_cd: 'refresh', meeting_hit_cd: 'swords', meeting_destroy_cd: 'bolt'};

let board = E.defaultBoard(), tab = 'room', selected = board.roles[1].uid, paramSkill = 0, dirty = false, toastTimer;
let rosterCollapsed = {}, rosterSearchCollapsed = {};
let rosterSearch = '', skillSearch = '', skillModule = 'all', slotChoice = 'auto', careerSearch = '', careerCamp = 'all', careerLockedCamp = null, customRoleCamp = null;
let scenario = null, simRole = '', simulationRun = false, checkReport = [];
let drawResult = null, drawError = '', ruleCamp = 1, simGroup = '', roomMoreOpen = false, lastPageReset = null;
let navigationContext = null;
let simOpen = false, justDrew = false, flashFaction = null, membersOpen = {}, markQueued = false, lastRenderTab = null, rendering = false, renderAgain = false;

/* ---------- 美术与图标 ---------- */
const ART = window.EDITOR_ART || {roles: {}, skills: {}, stages: {}, camps: {}};
const CUSTOM_ICON = {src: 'assets/custom-role.png', width: 512, height: 512};
const icon = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;
const stepArt = name => `<svg class="step-art" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><use href="#${name}"></use></svg>`;
const TONES = {1: ['#49b6ff', '#1e78cf'], 2: ['#ff5d5d', '#c3303c'], 3: ['#b98bff', '#7a4fe0']};
const CUSTOM_TONES = [['#2fd5c6', '#15978e'], ['#ff9f45', '#d06f18'], ['#ff6fb4', '#c93f86'], ['#9be15d', '#5c9f2c'], ['#f5d449', '#be9a12'], ['#5da9ff', '#2c6fd0'], ['#ff8a79', '#c9574a'], ['#c9a3ff', '#8a5fe0']];
function tone(id) {
  id = Number(id);
  if (!id) return ['#9c93d6', '#6c62b0'];
  return TONES[id] || CUSTOM_TONES[((id - 4) % CUSTOM_TONES.length + CUSTOM_TONES.length) % CUSTOM_TONES.length];
}
function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${n >> 8 & 255},${n & 255},${a})`; }
function toneStyle(id) { const [c, d] = tone(id); return `--fc:${c};--fc-deep:${d};--fc-soft:${rgba(c, .18)};--fc-line:${rgba(c, .55)}`; }
function artImage(a, cls = '', alt = '', lazy = true) { return a ? `<img class="${cls}" src="${esc(a.src)}" data-art-source="${esc(a.src)}" width="${a.width}" height="${a.height}" alt="${esc(alt)}" ${lazy ? 'loading="lazy"' : ''} decoding="async" data-art-image>` : ''; }
function emblem(f, cls = '') {
  const art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
  return `<span class="emblem ${cls}" style="${toneStyle(f?.id)}" aria-hidden="true">${art ? `<img src="${esc(art.src)}" alt="" width="${art.width}" height="${art.height}" decoding="async">` : `<b>${esc([...(f?.name || '新')][0])}</b>`}</span>`;
}
function roleAvatar(id, camp = 0, cls = '') {
  const a = id === null ? {icon: CUSTOM_ICON} : ART.roles[id];
  return `<span class="avatar ${a?.icon ? 'has-art' : ''} ${cls}" style="${toneStyle(camp)}">${a?.icon ? artImage(a.icon, 'role-icon', '', true) : `<b>${esc(E.camps[camp]?.slice(0, 1) || '?')}</b>`}</span>`;
}
function skillIcon(id, cls = '') { const s = E.skills.get(Number(id)), a = ART.skills[id]?.icon; return a ? artImage(a, 'skill-icon ' + cls, '', true) : `<span class="skill-icon skill-text ${cls}" aria-label="${s?.type === 1 ? '被动技能' : '暂无图标'}">${s?.type === 1 ? '被' : '技'}</span>`; }
function rolePortrait(r) {
  if (E.isCustom(r)) return `<div class="portrait-frame icon-portrait" style="${toneStyle(r.camp)}">${artImage(CUSTOM_ICON, 'portrait-role-icon', r.name + '自创角色图标', false)}</div>`;
  const c = E.careers.get(r.templateCareerId), a = ART.roles[c.id];
  return `<div class="portrait-frame ${a?.portrait ? '' : 'icon-portrait'}" style="${toneStyle(r.camp)}">${a?.portrait ? artImage(a.portrait, 'role-portrait', c.name + '职业立绘', false) : artImage(a?.icon, 'portrait-role-icon', c.name + '职业图标', false)}</div>`;
}
function stageImages(id) { const a = ART.stages[id]; return a?.images?.length ? `<div class="stage-art">${a.images.map(x => `<figure>${artImage(x.image, 'stage-icon', a.name + ' · ' + (x.context === 'meeting' ? '会议图标' : '局内图标'), true)}<figcaption>${x.context === 'meeting' ? '会议图标' : '局内图标'}</figcaption></figure>`).join('')}</div>` : ''; }
function roleArtModal(){const r=role();if(!r)return;const c=E.isCustom(r)?{name:r.name}:E.careers.get(r.templateCareerId),a=E.isCustom(r)?{icon:CUSTOM_ICON}:ART.roles[c.id];modal(modalHead(esc(c.name)+' · 角色与技能素材')+`<div class="art-modal-hero"><div>${artImage(a?.icon,'modal-role-icon',c.name+'职业图标',false)}<p>职业图标</p></div>${a?.portrait?`<div>${artImage(a.portrait,'modal-portrait',c.name+'职业立绘',false)}<p>职业立绘</p></div>`:''}</div><h3 class="section-label">当前装备的技能</h3><div class="art-skill-grid">${E.equippedSkills(r,{type:'active'}).map(s=>`<article><div class="art-skill-heading">${skillIcon(s.id)}<strong>${esc(s.name)}</strong></div><p>${esc(s.des)}</p></article>`).join('')||'<p class="muted">还未装备技能</p>'}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">继续编辑</button></div>`);}
document.addEventListener('error', event => {
  const img = event.target;
  if (!(img instanceof HTMLImageElement) || !img.hasAttribute('data-art-image') || !img.isConnected) return;
  const retries = Number(img.dataset.artRetries || 0);
  if (retries < 2) {
    img.dataset.artRetries = String(retries + 1);
    setTimeout(() => { if (!img.isConnected) return; const source = new URL(img.dataset.artSource, document.baseURI); if (source.protocol === 'http:' || source.protocol === 'https:') source.searchParams.set('artRetry', String(retries + 1)); img.src = source.href; }, 400 * (retries + 1));
    return;
  }
  const hint = document.createElement('span'); hint.className = 'art-unavailable'; hint.textContent = '图像暂不可用'; hint.title = img.alt; img.replaceWith(hint);
}, true);

function snapshotEditor(label,kind='page'){return {kind,tab,label,simOpen,membersOpen:clone(membersOpen),rosterCollapsed:clone(rosterCollapsed),board:clone(board),selected,ruleCamp,drawResult:drawResult?clone(drawResult):null,drawError,scenario:scenario?clone(scenario):null,simulationRun,simGroup,simRole,rosterSearch,skillSearch,skillModule,roomMoreOpen,navigationContext:navigationContext?clone(navigationContext):null};}

function issueDestination(issue,b){const code=String(issue.code||''),text=String(issue.text||''),r=b.roles.find(r=>r.uid===(issue.uid||issue.roleUid));let camp=r?.camp??issue.camp;const uid=r?.uid;const roomLabels={total:'房间总人数',hit_cd:'击倒冷却',task:'房间总任务数',...Object.fromEntries(Object.entries(E.ROOM_FIELDS).map(([k,d])=>[k,d.label]))};const field=issue.field||Object.keys(roomLabels).find(k=>text.includes(k)||text.includes(roomLabels[k]));
 if(code==='NEUTRAL_ROLE_COUNT')return {tab:'roles',uid,camp:3,kind:'role-options'};
 if(code==='NEUTRAL_ROLE_DUPLICATE'||code==='NEUTRAL_PAIR_UNSUPPORTED')return {tab:'factions',camp:3,uid,kind:'candidates'};
 if(code==='ORIGINAL_OPENING')return {tab:'factions',camp:2,kind:'count'};
 if(code==='ORIGINAL_DUCK_OPENING')return {tab:'factions',camp:1,kind:'count'};
 if(code==='ORIGINAL_CAMP_OPENING')return {tab:'factions',camp:camp===1?2:1,kind:'count'};
 if(['CAMP_SUM','CAMP_COUNT','POOL_CAPACITY','POOL_INACTIVE','POOL_NO_COMBINATION','POOL_SEARCH_LIMIT','POOL_CONSTRAINTS','SKILL_FAMILY_POOL','EMPTY','CAREER_OUT_OF_SCOPE','CAREER_POOL'].includes(code))return {tab:'factions',camp,uid,kind:code.startsWith('CAMP_')?'count':'candidates'};
 if(code==='TOTAL_RANGE'||code.startsWith('ROOM_'))return {tab:'room',field:code==='TOTAL_RANGE'?'total':field};
 if(['COPY_CAP','CUSTOM_NEUTRAL_FORBIDDEN','CAMP_OVERRIDE','WIN_CAMP'].includes(code))return {tab:'roles',uid,camp,kind:'role-options'};
 if(code.startsWith('SKILL_')||['SNIPER_PAIR','ABILITY_COMPAT','CD_PARAM','SLOT_LAYOUT'].includes(code))return {tab:'roles',uid,camp,kind:'skills'};
 if(code==='BASE_DEPENDENCY'){const actor=r||b.roles.find(r=>r.camp===camp);return actor?{tab:'roles',uid:actor.uid,camp,kind:'skills'}:{tab:'factions',camp,kind:'candidates'};}
 if(/^(BASE_|EXTRA_|EVENT_|WIN_|FIXED_|LOSS_|OPENING_|EMPTY_WIN|EMPTY_LOSS|ZERO_THRESHOLD|CUSTOM_FACTION_NO_WIN|CUSTOM_NEUTRAL_NO_WIN|MEETING_GOAL_)/.test(code))return {tab:'wins',camp:camp??1,kind:code.startsWith('BASE_')?'base':'goals'};
 if(code==='SCHEMA'){if(field)return {tab:'room',field};if(/技能|槽位/.test(text))return {tab:'roles',uid,kind:'skills'};if(/胜利|目标|权重/.test(text))return {tab:'wins',camp:camp??1,kind:'goals'};if(/阵营|候选|角色/.test(text))return {tab:'factions',camp,kind:'candidates'};}
 return uid?{tab:'roles',uid,camp,kind:'skills'}:camp?{tab:'factions',camp,kind:'count'}:{tab:'room',field};
}

function reviewIssueLink(issue){const target=issueDestination(issue,board),index=checkReport.indexOf(issue),label={room:'设置房间',factions:'分配阵营',wins:'设置胜利',roles:'搭配技能'}[target.tab];return `<div class="issue-actions"><button class="btn btn-ghost btn-sm" data-issue-index="${index}" data-issue-code="${esc(issue.code)}" aria-label="查看${label}" title="前往${label}">查看</button>${issue.code==='MEETING_GOAL_UNREACHABLE'?`<button class="btn btn-ghost btn-sm" data-issue-room="${index}">会议设置</button>`:''}</div>`;}

function navigateTo(target,issue=null){if(!['room','factions','wins','roles','review'].includes(target.tab))return;closeModal();tab=target.tab;paramSkill=0;navigationContext=issue?{from:'review'}:null;
 if(target.uid&&board.roles.some(r=>r.uid===target.uid)){selected=target.uid;if(!target.keepSearch)rosterSearch='';}
 if(target.camp&&E.faction(board,target.camp))ruleCamp=Number(target.camp);
 if(target.tab==='roles'&&target.uid)revealRosterRole(role());
 if(target.tab==='factions'&&target.camp&&target.kind==='candidates')membersOpen[target.camp]=true;render();$('#content').scrollTop=0;
 if(!issue&&!target.kind&&!target.uid&&!target.camp&&!target.field)return;
 let highlight=null,focus=null;
 if(tab==='factions'){highlight=target.camp?document.querySelector(`[data-faction-card="${Number(target.camp)}"]`):$('.faction-total');if(highlight&&target.kind==='candidates'){const details=highlight.querySelector('details');if(details)details.open=true;focus=highlight.querySelector('[data-add-original-camp],[data-new-role-camp]');}else focus=highlight?.querySelector('[data-count]')||$('#content [data-count]');}
 else if(tab==='wins'){highlight=$('.wins-editor');focus=target.kind==='base'?highlight?.querySelector('[data-base-victory]'):highlight?.querySelector('[data-event-value],[data-action="choose-event"]');}
 else if(tab==='roles'){highlight=$('.role-workspace')||$('.empty-stage');focus=target.kind==='skills'?highlight?.querySelector('.skill-out-of-scope button[data-remove-skill],[data-action="choose-skills"]'):highlight?.querySelector('[data-role-field="name"]');}
 else if(tab==='room'){focus=target.field?document.querySelector(`[data-room="${CSS.escape(target.field)}"],[data-room-toggle="${CSS.escape(target.field)}"]`):null;highlight=focus?.closest('.panel')||$('.room-hero');}
 if(focus){for(let p=focus.parentElement;p&&p!==$('#content');p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;focus.scrollIntoView({block:'center'});focus.focus({preventScroll:true});}else highlight?.scrollIntoView({block:'start'});
 if(issue&&highlight){highlight.classList.add('navigation-target');setTimeout(()=>highlight.classList.remove('navigation-target'),6000);}
 if(tab==='roles'&&target.kind==='role-options'&&role())roleOptions();
}

function resetAllModal(){modal(modalHead('重置全部设置？')+'<p class="reset-scope-copy">将当前板子的名称、房间、阵营、候选角色、胜利目标和技能恢复为初始设置。</p><p class="setting-hint">已保存的板子会保留。重置后可撤销，也可在“我的板子”中恢复替换前草稿。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-action="confirm-global-reset">确认重置全部</button></div>',true,'global-reset');}

function performGlobalReset(){const before=snapshotEditor('全部设置','global');let backedUp=false;try{localStorage.setItem(STORE+'-recovery',JSON.stringify(E.exportDraft(board)));backedUp=true;}catch{}
 rosterCollapsed={};rosterSearchCollapsed={};membersOpen={};simOpen=false;justDrew=false;flashFaction=null;board=E.defaultBoard();tab='room';selected=board.roles[0]?.uid||'';ruleCamp=1;paramSkill=0;rosterSearch='';skillSearch='';skillModule='all';slotChoice='auto';careerSearch='';careerCamp='all';careerLockedCamp=null;customRoleCamp=null;roomMoreOpen=false;navigationContext=null;simRole='';simGroup='';scenario=null;simulationRun=false;drawResult=null;drawError='';mark();lastPageReset=before;closeModal();render();$('#content').scrollTop=0;toast(backedUp?'全部设置已重置，原草稿已备份':'全部设置已重置，可立即撤销');
}

function deleteRoleModal(uid=role()?.uid){const r=board.roles.find(r=>r.uid===uid);if(!r)return;modal(modalHead('删除「'+esc(r.name)+'」？')+'<p class="reset-scope-copy">从当前板子的候选池移除该角色及其技能设置。</p><p class="setting-hint">删除后可撤销。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-confirm-remove-role="'+esc(r.uid)+'">确认删除角色</button></div>',true,'delete-role');}

/* ---------- 状态 ---------- */
function role() { return board.roles.find(x => x.uid === selected) || board.roles[0]; }
function activeCampRule() { return E.campRule(board, ruleCamp); }
function allocation() { const assigned = board.factions.reduce((n, f) => n + board.room.counts[f.id], 0); return {assigned, delta: board.room.total - assigned}; }
function factionLabel(id) { return E.campName(board, id); }
function toast(s) {
  if ($('#modal').open && $('#dialog-status')) $('#dialog-status').textContent = s;
  $('#toast').textContent = s; $('#toast').classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').classList.remove('show'), 3300);
}
function mark() {
  lastPageReset = null; $('.page-reset-feedback')?.remove();
  E.ensureCampRules(board); scenario = null; simulationRun = false; drawResult = null; drawError = ''; dirty = true; board.updatedAt = new Date().toISOString();
  try { localStorage.setItem(AUTOSAVE, JSON.stringify(E.exportDraft(board))); $('#save-state').textContent = '已自动保存'; } catch { $('#save-state').textContent = '未保存 · 请导出备份'; }
  header();
}
function scheduleMark() { if (markQueued) return; markQueued = true; requestAnimationFrame(() => { markQueued = false; mark(); refreshInline(); }); }
function issueStep(x) { return issueDestination(x, board).tab; }
function header() {
  checkReport = E.validate(board).filter(x => x.level === 'error' || !['ABILITY_COMPAT', 'SLOT_LAYOUT', 'SKILL_SLOT', 'CD_PARAM'].includes(x.code));
  const errors = checkReport.filter(x => x.level === 'error').length, warnings = checkReport.filter(x => x.level === 'warn').length;
  const nameInput = $('#board-name'); if (document.activeElement !== nameInput) nameInput.value = board.boardName;
  $('#board-summary').innerHTML = `<span class="sum-total">${nums(board.room.total)}人</span><span class="sum-sep"> · </span>` + board.factions.map((f, i) => `${i ? '<span class="sum-sep"> / </span>' : ''}<span class="sum-camp" style="${toneStyle(f.id)}"><i aria-hidden="true"></i>${esc(f.name.replace(/阵营$/, ''))} ${board.room.counts[f.id]}</span>`).join('');
  $('#issue-badge').textContent = errors || '';
  const perStep = {room: 0, factions: 0, wins: 0, roles: 0};
  for (const x of checkReport) if (x.level === 'error') { const s = issueStep(x); if (s in perStep) perStep[s]++; }
  for (const [s, n] of Object.entries(perStep)) { const b = $(`[data-step-badge="${s}"]`); if (b) { b.textContent = n || ''; b.title = n ? n + ' 项待修正' : ''; } }
  const status = $('#footer-status');
  status.innerHTML = nums(errors ? errors + ' 项待修正' : '人数与已知规则通过' + (warnings ? ' · ' + warnings + ' 项提醒' : ''));
  status.classList.toggle('has-errors', !!errors);
  $('#next-step').textContent = STEP_INFO[tab].next;
  $('#prev-step').hidden = tab === 'room';
  $('#footer-hint').textContent = STEP_INFO[tab].hint;
  document.body.dataset.step = tab;
  const idx = STEPS.indexOf(tab);
  $$('.steps [data-tab]').forEach(n => { const i = STEPS.indexOf(n.dataset.tab); n.classList.toggle('active', i === idx); n.classList.toggle('passed', i < idx); n.setAttribute('aria-current', i === idx ? 'step' : 'false'); });
}

/* ---------- 渲染 ---------- */
function captureSeats() { const m = new Map(); $$('.seat-ring .seat').forEach(s => m.set(s.dataset.seat, s.getBoundingClientRect())); return m; }
function playSeats(before) {
  if (!before || !Element.prototype.animate || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  $$('.seat-ring .seat').forEach(s => {
    const r0 = before.get(s.dataset.seat), r1 = s.getBoundingClientRect();
    if (!r0) { s.animate([{transform: 'translate(-50%,-50%) scale(.2)', opacity: 0}, {transform: 'translate(-50%,-50%) scale(1)', opacity: 1}], {duration: 280, easing: 'cubic-bezier(.2,1.3,.4,1)'}); return; }
    const dx = r0.left - r1.left, dy = r0.top - r1.top;
    if (Math.abs(dx) + Math.abs(dy) < 1) return;
    s.animate([{transform: `translate(calc(-50% + ${dx}px),calc(-50% + ${dy}px))`}, {transform: 'translate(-50%,-50%)'}], {duration: 300, easing: 'cubic-bezier(.3,.8,.3,1)'});
  });
}
function render() {
  // 替换内容时被移除的输入框可能再触发一次 change；重入时延后到本次绘制结束再画。
  if (rendering) { renderAgain = true; return; }
  rendering = true;
  try { paint(); } finally { rendering = false; }
  if (renderAgain) { renderAgain = false; render(); }
}
function paint() {
  const before = lastRenderTab === tab && !justDrew ? captureSeats() : null;
  header();
  const view = {room: roomView, factions: factionsView, wins: winsView, roles: rolesView, review: reviewView}[tab]();
  $('#content').innerHTML = `<div class="page page-${tab}">${view}</div>`;
  const page = $('#content .page');
  if(navigationContext && tab!=='review') $('#content .title-row').insertAdjacentHTML('afterend', '<div class="issue-navigation"><span>已定位到需要调整的设置</span><button class="btn btn-ghost btn-sm" data-action="back-review">返回预览</button></div>');
  if (tab === 'review') renderSimulation();
  if (lastPageReset && (lastPageReset.kind === 'global' || lastPageReset.tab === tab)) $('#content .title-row').insertAdjacentHTML('afterend', `<div class="page-reset-feedback" role="status">${icon('undo')}<span>${esc(lastPageReset.label)}${lastPageReset.kind==='remove-role'?'已删除':'已重置'}</span><button class="btn btn-ghost btn-sm" data-action="undo-page-reset">${lastPageReset.kind==='remove-role'?'撤销删除':'撤销重置'}</button></div>`);
  if (board.room.total < E.ROOM_LIMITS.min || board.room.total > E.ROOM_LIMITS.max) page.insertAdjacentHTML('afterbegin', `<div class="note warning" role="alert">此草稿为 ${board.room.total} 人，房间支持 ${E.ROOM_LIMITS.min}–${E.ROOM_LIMITS.max} 人，请调整人数及阵营分配。</div>`);
  if (board.roles.some(r => r.camp === 3 && E.isCustom(r))) page.insertAdjacentHTML('afterbegin', '<div class="note warning" role="alert">旧草稿中的空白中立角色已保留，请到“搭配技能”为其选择鹅、鸭或新阵营。</div>');
  $$('[data-room-range]').forEach(setPct);
  if (before) playSeats(before);
  lastRenderTab = tab; justDrew = false;
  if (flashFaction != null) {
    const card = $(`[data-faction-card="${flashFaction}"]`);
    if (card) { card.scrollIntoView({block: 'center'}); setTimeout(() => card.classList.remove('flash'), 1800); }
    flashFaction = null;
  }
}
function renderInPlace() {
  const selectors = ['#content', '.roster-list', '.role-workspace', '.faction-list', '.wins-editor', '.faction-rail', '.room-col:first-child', '.room-col:last-child'];
  const positions = selectors.map(selector => [selector, $(selector)?.scrollTop || 0]);
  render();
  for (const [selector, top] of positions) { const node = $(selector); if (node) node.scrollTop = top; }
}
function go(next) { navigateTo({tab:next}); }
function openCamp(camp){navigateTo({tab:'wins',camp:Number(camp),kind:'goals'});}
function setPct(range) { const min = Number(range.min), max = Number(range.max), v = Math.min(max, Math.max(min, Number(range.value))); range.style.setProperty('--pct', ((v - min) / (max - min || 1) * 100).toFixed(1) + '%'); }

function number(label,value,data,min=0,max=100000){return numberField(label,value,data,'param-'+data.replace(/[^a-zA-Z0-9_-]+/g,'-'),min,max);}

/* ---------- 通用部件 ---------- */
function title(n, p) {
  return `<div class="title-row"><span class="title-badge" aria-hidden="true">${stepArt(STEP_INFO[tab].icon)}</span><div class="title-copy"><h2 class="page-title">${n}</h2><p>${p}</p></div><button class="btn btn-ghost btn-sm page-reset-button" data-action="reset-page" ${tab === 'roles' && !role() ? 'disabled' : ''}>${icon('undo')}<span>${tab === 'roles' ? '重置当前技能' : tab === 'review' ? '清空预览' : '重置本页'}</span></button></div>`;
}
const options = (obj, val) => Object.entries(obj).map(([k, v]) => `<option value="${esc(k)}" ${String(val) === String(k) ? 'selected' : ''}>${esc(v)}</option>`).join('');
function stepperHtml(inputHtml, id, step = 1, label = '', unit = '') {
  return `<span class="stepper"><button type="button" class="step-btn" data-step-for="${esc(id)}" data-delta="-${step}" aria-label="减少${esc(label)}">${icon('minus')}</button>${inputHtml}${unit ? `<span class="stepper-unit">${esc(unit)}</span>` : ''}<button type="button" class="step-btn" data-step-for="${esc(id)}" data-delta="${step}" aria-label="增加${esc(label)}">${icon('plus')}</button></span>`;
}
function numberField(label, value, data, id, min = 0, max = 100000, step = 1) {
  return `<div class="param-field"><span>${label}</span>${stepperHtml(`<input id="${esc(id)}" type="number" min="${min}" max="${max}" value="${value}" ${data} aria-label="${esc(label)}" inputmode="numeric">`, id, step, label)}</div>`;
}
function toggleField(key, label, value, on = '允许', off = '禁止') {
  return `<label class="toggle-field room-option"><span class="field-label">${label}</span><span class="switch"><input type="checkbox" role="switch" data-room-toggle="${key}" data-on="${on}" data-off="${off}" aria-label="${label}" ${value ? 'checked' : ''}><i aria-hidden="true"></i></span><em class="switch-state">${value ? on : off}</em></label>`;
}

/* ---------- 会议桌 ---------- */
function planTokens() {
  const list = [];
  for (const f of board.factions) for (let i = 0; i < (board.room.counts[f.id] || 0); i++) list.push({camp: f.id});
  while (list.length < board.room.total) list.push({camp: null});
  return list.map((t, i) => ({...t, over: i >= board.room.total}));
}
function ringPoint(i, n) { const a = -Math.PI / 2 + i * 2 * Math.PI / n; return [50 + 45.5 * Math.cos(a), 50 + 41.5 * Math.sin(a)]; }
function ringSize(n) { return n <= 10 ? 'ring-lg' : n <= 16 ? 'ring-md' : 'ring-sm'; }
function seatRing(tokens) {
  const n = Math.max(1, tokens.length);
  return `<div class="seat-ring ${ringSize(n)}" aria-hidden="true">${tokens.map((t, i) => {
    const [x, y] = ringPoint(i, n), f = t.camp != null ? E.faction(board, t.camp) : null, art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
    return `<span class="seat ${f ? '' : 'seat-open'} ${t.over ? 'seat-over' : ''}" data-seat="${i}" style="left:${x.toFixed(2)}%;top:${y.toFixed(2)}%;${f ? toneStyle(f.id) : ''}" title="${f ? esc(f.name) : '待分配'}">${art ? `<img src="${esc(art.src)}" alt="" width="${art.width}" height="${art.height}" decoding="async">` : `<b>${f ? esc([...f.name][0]) : '?'}</b>`}</span>`;
  }).join('')}</div>`;
}
function seatStrip() { return `<div class="seat-strip" aria-hidden="true">${planTokens().map(t => `<i class="${t.camp == null ? 'open' : ''} ${t.over ? 'over' : ''}" style="${t.camp != null ? toneStyle(t.camp) : ''}"></i>`).join('')}</div>`; }
function allocationSummary() {
  const {delta} = allocation();
  if (delta !== 0) return `<p class="alloc-note ${delta < 0 ? 'danger' : ''}" role="status">${icon('alert')}<span>${nums(delta > 0 ? '还需分配 ' + delta + ' 人' : '多分配了 ' + (-delta) + ' 人')}</span><button class="btn btn-ghost btn-sm" data-tab="factions">分配阵营 →</button></p>`;
  return `<div class="seat-legend">${board.factions.filter(f => board.room.counts[f.id] > 0).map(f => `<span style="${toneStyle(f.id)}"><i></i>${esc(f.name)} ${board.room.counts[f.id]}</span>`).join('')}</div>`;
}

/* ---------- 第 1 步：设置房间 ---------- */
function roomOption(key) {
  const d = E.ROOM_FIELDS[key], value = board.room[key];
  if (d.type === 'boolean') return toggleField(key, d.label, value);
  const range = D.custom[0][key], values = [...new Set([...d.choices, value])].sort((a, b) => a - b), custom = key !== 'meeting_amount';
  return `<label class="field room-option"><span class="field-label">${ROOM_ICON[key] ? icon(ROOM_ICON[key]) : ''}${d.label}</span><select data-room="${key}" aria-label="${d.label}">${options(Object.fromEntries(values.map(v => [v, v === 0 ? '关闭' : v + ' ' + d.unit])), value)}${custom ? '<option value="custom">自定义…</option>' : ''}</select>${custom ? `<input hidden type="number" data-room="${key}" aria-label="自定义${d.label}" min="${range[0]}" max="${range[1]}" value="${value}" inputmode="numeric">` : ''}</label>`;
}
function rangeField(key, label, ic) {
  const [min, max] = D.custom[0][key], v = board.room[key], id = 'room-' + key;
  return `<div class="range-field"><div class="range-top"><label class="field-label" for="${id}">${icon(ic)}${label}</label>${stepperHtml(`<input id="${id}" type="number" min="${min}" max="${max}" value="${v}" data-room="${key}" inputmode="numeric">`, id, 1, label)}</div><input type="range" min="${min}" max="${max}" value="${Math.min(max, Math.max(min, v))}" data-room-range="${key}" aria-label="${label}"><div class="range-scale"><span>${min}</span><span>${max}</span></div></div>`;
}
function roomView() {
  const r = board.room;
  return title('这局，想怎么玩？', '先选人数，其他设置可以先用默认。') + `
<div class="room-grid">
 <div class="room-col room-col-people">
 <section class="panel room-hero" aria-labelledby="room-people-title">
  <div class="panel-head"><div><h3 class="panel-title" id="room-people-title">房间人数</h3><p class="panel-sub">一起开一局</p></div><span class="tag">${icon('seat')}${E.ROOM_LIMITS.min}–${E.ROOM_LIMITS.max} 人</span></div>
  <div class="room-people-layout">
  <div class="seat-table">
   <div class="table-top" aria-hidden="true"></div>
   ${seatRing(planTokens())}
   <div class="table-center">
    <button class="round-btn" data-total-delta="-1" aria-label="减少房间人数" ${r.total <= E.ROOM_LIMITS.min ? 'disabled' : ''}>${icon('minus')}</button>
    <label class="people-number"><span class="sr-only">房间人数</span><input type="number" aria-label="房间人数" min="${E.ROOM_LIMITS.min}" max="${E.ROOM_LIMITS.max}" value="${r.total}" data-room="total" inputmode="numeric"><span>人</span></label>
    <button class="round-btn" data-total-delta="1" aria-label="增加房间人数" ${r.total >= E.ROOM_LIMITS.max ? 'disabled' : ''}>${icon('plus')}</button>
   </div>
  </div>
  <div class="room-people-controls">
  <div class="people-presets" role="group" aria-label="常用人数">${[E.ROOM_LIMITS.min, 6, 8, 10, 12, E.ROOM_LIMITS.max].map(n => `<button class="chip ${r.total === n ? 'selected' : ''}" data-total-preset="${n}" aria-pressed="${r.total === n}">${nums(n)} 人</button>`).join('')}</div>
  <div class="js-alloc">${allocationSummary()}</div>
  </div>
  </div>
 </section>

 </div>
 <div class="room-col room-col-settings">
  <section class="panel room-pace">
   <div class="panel-head"><h3 class="panel-title">对局节奏</h3></div>
   <div class="pace-fields">${rangeField('hit_cd', '击倒冷却（秒）', 'swords')}${rangeField('task', '房间总任务数', 'check')}</div>
  </section>
  <section class="panel meeting-settings">
   <div class="panel-head"><div><h3 class="panel-title">开会怎么聊？</h3><p class="panel-sub">决定讨论、投票和拍铃的节奏。</p></div><span class="tag">${icon('bell')}会议设置</span></div>
   <div class="meeting-grid meeting-main">${['meeting_amount', 'discuss_cd', 'vote_cd', 'first_bell_cd', 'meeting_cd'].map(roomOption).join('')}</div>
   <p class="setting-hint" style="margin-top:12px">拍铃次数全局共用，每人最多一次；报告鸡腿不占次数。</p>
   <details class="room-more" ${roomMoreOpen ? 'open' : ''}><summary class="disclosure">更多会议设置</summary>
    <div class="meeting-grid">${['meeting_hit_cd', 'meeting_destroy_cd'].map(roomOption).join('')}</div>
    <div class="toggle-list">${['allow_speak', 'discuss_chat', 'discuss_emojis', 'allow_report_dead'].map(roomOption).join('')}${toggleField('hide', '放逐后身份', board.room.hide, '隐藏', '公开')}</div>
   </details>
  </section>
  <section class="panel room-intro">
  <details class="board-description"><summary class="disclosure">写点玩法介绍 <span>选填</span></summary><label class="board-intro"><span class="sr-only">板子介绍</span><textarea maxlength="300" data-description placeholder="例如：侦探与炸弹的欢乐对决">${esc(board.description)}</textarea></label></details>
  </section>
 </div>
</div>`;
}

/* ---------- 第 2 步：分配阵营 ---------- */
function allocationStatus() {
  const {delta} = allocation();
  return `<span class="alloc-status ${delta === 0 ? 'ok' : 'danger'}" data-alloc-status>${icon(delta === 0 ? 'check' : 'alert')}<span>${nums(delta === 0 ? '人数已分配好' : delta > 0 ? '还需分配 ' + delta + ' 人' : '多分配了 ' + (-delta) + ' 人')}</span></span>`;
}
function factionsView() {
  return title('谁和谁是一队？', '先分配人数，再挑选候选角色。角色选得多，开局会随机抽。') + `
<section class="panel alloc-panel">
 <div class="alloc-row">
  <div class="faction-total"><strong>这局 ${nums(board.room.total)} 人</strong>${allocationStatus()}<button class="btn-link" data-tab="room">修改总人数</button></div>
  <button class="btn btn-violet add-faction" data-action="add-faction" aria-label="新增阵营" ${board.factions.length >= E.MAX_FACTIONS ? 'disabled' : ''}>${icon('plus')}<span><strong>新增阵营</strong><small>创建自己的队伍，安排人数与角色</small></span></button>
 </div>
 <div class="js-seat-strip">${seatStrip()}</div>
</section>
<div class="faction-list">${board.factions.map(factionCard).join('')}</div>`;
}
function factionCard(f) {
  const p = E.poolStats(board, f.id), members = board.roles.filter(r => r.camp === f.id), custom = f.kind === 'custom';
  const movable = f.id === 3 ? [] : board.roles.filter(r => E.isCustom(r) && r.camp !== f.id);
  return `<article class="faction-card ${flashFaction === f.id ? 'flash' : ''}" data-faction-card="${f.id}" style="${toneStyle(f.id)}">
 <div class="faction-side">
  <div class="faction-head">${emblem(f)}<div>${custom ? `<input aria-label="${esc(f.name)}名称" maxlength="20" value="${esc(f.name)}" data-faction-name="${f.id}">` : `<h3>${esc(f.name)}</h3>`}<small>${f.id === 3 ? '各自获胜' : '共同获胜'}</small></div></div>
  <div class="faction-seats"><span>出场人数</span><span class="stepper"><button class="step-btn" data-count-step="${f.id}" data-delta="-1" aria-label="减少${esc(f.name)}人数" ${p.seats === 0 ? 'disabled' : ''}>${icon('minus')}</button><input aria-label="${esc(f.name)}人数" type="number" min="0" max="${E.ROOM_LIMITS.max}" value="${p.seats}" data-count="${f.id}" inputmode="numeric"><button class="step-btn" data-count-step="${f.id}" data-delta="1" aria-label="增加${esc(f.name)}人数" ${p.seats >= E.ROOM_LIMITS.max ? 'disabled' : ''}>${icon('plus')}</button></span></div>
  <p class="faction-pool-count" data-pool-count="${f.id}">${p.candidates} 个候选 · 随机选 ${p.seats} 人</p>
  ${custom ? `<button class="btn-link danger" data-delete-faction="${f.id}">${icon('trash')}删除空阵营</button>` : ''}
 </div>
 <div class="faction-candidates">
  <details class="faction-members" data-members="${f.id}" ${membersOpen[f.id] === false ? '' : 'open'}><summary class="disclosure">候选角色 <span class="count">${members.length}</span></summary>
   <div class="role-chips faction-role-chips">${members.map(r => `<div class="role-chip faction-role-chip"><button class="role-chip-main faction-role-edit" data-edit-role="${esc(r.uid)}" aria-label="编辑${esc(r.name)}" title="编辑${esc(r.name)}">${roleAvatar(r.templateCareerId, r.camp)}<span>${esc(r.name)}</span>${r.count > 1 ? `<small class="copies">≤${r.count}</small>` : ''}</button><button class="role-chip-x faction-role-remove" data-remove-candidate="${esc(r.uid)}" aria-label="移除${esc(r.name)}" title="移出候选池">${icon('x')}</button></div>`).join('') || '<p class="empty-pool">还没有角色，从下方添加一个吧。</p>'}</div>
  </details>
  <div class="faction-member-actions">
   ${custom ? '' : `<button class="btn btn-gold btn-sm" data-add-original-camp="${f.id}">${icon('plus')}添加已有职业</button>`}
   ${f.id === 3 ? '' : `<button class="btn btn-ghost btn-sm" data-new-role-camp="${f.id}">${artImage(CUSTOM_ICON, 'custom-entry-icon', '', false)}创建空白角色</button>`}
   ${movable.length ? `<label class="assign-role"><span class="sr-only">加入自创角色</span><select aria-label="为${esc(f.name)}加入自创角色" data-assign-faction="${f.id}"><option value="">移入自创角色…</option>${movable.map(r => `<option value="${esc(r.uid)}">${esc(r.name)}（${esc(factionLabel(r.camp))}）</option>`).join('')}</select></label>` : ''}
   <span class="spacer"></span>
   <button class="btn-link faction-win-link" data-open-camp="${f.id}">设置胜利 →</button>
  </div>
 </div>
</article>`;
}
function removeCandidate(uid){const index=board.roles.findIndex(r=>r.uid===uid);if(index<0)return;const before=snapshotEditor(board.roles[index].name,'remove-role'),camp=board.roles[index].camp,focusWasRemove=document.activeElement?.dataset.removeCandidate===uid;E.removeRole(board,uid);if(selected===uid){const visible=board.roles.filter(r=>!rosterSearch||(r.name+E.campName(board,r.camp)).includes(rosterSearch));if(!visible.length)rosterSearch='';selected=(visible.find(r=>board.roles.indexOf(r)>=index)||visible.at(-1)||board.roles[Math.min(index,board.roles.length-1)])?.uid||'';paramSkill=0;}mark();lastPageReset=before;renderInPlace();if(focusWasRemove){const card=document.querySelector(`[data-faction-card="${camp}"]`);card?.querySelector('[data-remove-candidate],[data-add-original-camp],[data-new-role-camp]')?.focus({preventScroll:true});}toast('已删除角色，可撤销');}

/* ---------- 第 4 步：设置胜利 ---------- */
function eventText(e) { const d = E.eventCatalog[e.type]; return `${d.name} · ${e.value}${d.unit}（权重 ${e.weight}）`; }
function campEventCopy(text) { if (ruleCamp !== 3) return text; return text.replace('队友投中同一人只计一次。', '本人对同一目标只计一次。').replace('每个行动回合本阵营最多计一次。', '本人每个行动回合最多计一次。').replace('同一场会议本阵营最多计一次。', '本人每场会议最多计一次。').replaceAll('一名成员', '本人').replace('本人连续参加', '本人连续参加').replace('中立只看本人，', '').replace('仍存活成员的个人记录，不相加', '本人存活时的个人记录，不与其他中立相加').replace('存活成员个人连续记录', '本人存活时的连续记录'); }
function baseBlock(f, preset) {
  if (f.kind === 'custom') return `<div class="custom-base-win"><label class="field"><span class="field-label">${icon('trophy')}基础胜利条件</span><select aria-label="${esc(f.name)}原有胜利条件" data-base-victory="${f.id}">${options({'': '仅使用额外目标', ...Object.fromEntries(E.baseVictoryOptions.map(p => [p.id, p.name]))}, f.baseVictory || '')}</select></label>${preset ? `<p>${esc(preset.description)}</p>` : ''}</div>`;
  if (f.id === 3) { const neutrals = E.D.eligibleCareerIds.map(id => E.careers.get(id)).filter(c => c.camp === 3); return `<div class="base-rule"><span class="lock">${icon('lock')}</span><div><h4>原胜利条件 <span class="tag">固定</span></h4><p>每个原角色保留自己的胜利条件。</p><button class="btn-link" data-action="view-original-neutrals">查看 ${neutrals.length} 种原条件</button></div></div>`; }
  const c = E.careers.get(f.id === 1 ? 1 : 101);
  return `<div class="base-rule"><span class="lock">${icon('lock')}</span><div><h4>原胜利条件 <span class="tag">固定</span></h4><p data-original-condition="${f.id}">${esc(c.win_condition_des)}</p></div></div>`;
}
function winsView() {
  if (!E.faction(board, ruleCamp)) ruleCamp = 1;
  const g = activeCampRule(), f = E.faction(board, ruleCamp), neutral = ruleCamp === 3, custom = f.kind === 'custom', preset = E.baseVictory(f.baseVictory);
  return title('怎样才算赢？', '原有规则始终生效；也可以给阵营添加优先达成的额外目标。') + `
<div class="wins-layout">
 <nav class="faction-rail faction-tabs" aria-label="选择阵营">
  <p class="rail-title">选择阵营</p>
  ${board.factions.map(x => `<button class="rail-item ${x.id === ruleCamp ? 'selected' : ''}" data-rule-camp="${x.id}" aria-pressed="${x.id === ruleCamp}" style="${toneStyle(x.id)}">${emblem(x, 'sm')}<span class="rail-text">${nameHtml(x.name)}<small>${x.id === 3 ? '各自获胜' : '共同获胜'}</small></span><b class="rail-count" title="额外胜利目标">${E.campRule(board, x.id)?.events.length || 0}</b></button>`).join('')}
 </nav>
 <section class="panel wins-editor" style="${toneStyle(f.id)}">
  <header class="wins-head">${emblem(f, 'lg')}<div><h3>${nameHtml(f.name)}</h3><p>${neutral ? '所有中立职业适用，各自完成、各自获胜。' : '达成目标，阵营全员获胜。'}</p></div></header>
  ${baseBlock(f, preset)}
  <div class="goals-header"><h3>额外胜利目标 <small>选填</small></h3><span class="goal-meter" style="--fill:${(g.events.length / E.MAX_CAMP_EVENTS * 100).toFixed(0)}%"><i></i>${g.events.length} / ${E.MAX_CAMP_EVENTS}</span></div>
  ${g.events.length > 1 ? `<div class="goal-join"><span>获胜方式</span><div class="segmented"><button data-goal-join="any" class="${g.join === 'any' ? 'selected' : ''}" aria-pressed="${g.join === 'any'}">完成任意一个</button><button data-goal-join="all" class="${g.join === 'all' ? 'selected' : ''}" aria-pressed="${g.join === 'all'}">全部完成</button></div></div>` : ''}
  <p class="goal-priority-hint">${icon('crown')}<span>权重越大越优先；同时达成时，同权重可并列。${g.join === 'all' && g.events.length > 1 ? ' 全部完成后，整组按最低权重结算。' : ''}</span></p>
  ${g.events.length ? `<div class="goal-list">${[...g.events].sort((a, b) => b.weight - a.weight).map((e, i) => goalCard(e, i, neutral)).join('')}</div><button class="btn btn-ghost add-goal-button" data-action="choose-event" ${g.events.length >= E.MAX_CAMP_EVENTS ? 'disabled' : ''}>${icon('plus')}添加胜利目标</button>` : `<div class="goal-empty">${icon('trophy')}<p>${custom && !preset ? '为新阵营选一个获胜目标。' : '沿用原有规则，直接下一步也可以。'}</p><button class="btn btn-gold" data-action="choose-event">${icon('plus')}添加胜利目标</button></div>`}
  <p class="goal-footnote">${neutral ? '达成额外目标时，本人须存活。' : '达成额外目标时，阵营须有人存活。'} 额外目标优先于原有规则；未达成的高权重目标不会阻挡其他目标。</p>
 </section>
</div>`;
}
function goalCard(e, i, neutral) {
  const d = E.eventCatalog[e.type], vid = 'goal-v-' + e.id, wid = 'goal-w-' + e.id;
  return `<article class="goal-card"><span class="goal-rank goal-number">${i + 1}</span>
 <div class="goal-copy"><h4><span class="cat" title="${esc(d.category)}">${icon(CATEGORY_ICON[d.category] || 'target')}</span>${esc(d.name)}</h4><p>${esc(campEventCopy(d.description))}</p>${d.hint ? `<small class="ability-hint">${icon('info')}${esc(d.hint)}</small>` : ''}<details class="goal-detail"><summary>计数说明</summary><p>${esc(campEventCopy(d.detail || d.description))}</p></details></div>
 <div class="goal-side"><div class="goal-controls"><div class="goal-target"><span>目标</span>${stepperHtml(`<input id="${esc(vid)}" aria-label="${esc(d.name)}目标" type="number" min="1" max="999" value="${e.value}" data-event-value="${esc(e.id)}" inputmode="numeric">`, vid, 1, d.name + '目标', d.unit)}</div><div class="goal-weight"><span>权重 · 优先级</span>${stepperHtml(`<input id="${esc(wid)}" aria-label="${esc(d.name)}权重" type="number" min="1" max="${E.MAX_EVENT_WEIGHT}" value="${e.weight}" data-event-weight="${esc(e.id)}" inputmode="numeric">`, wid, 10, d.name + '权重')}</div></div><button class="btn btn-ghost btn-sm danger goal-remove" data-remove-event="${esc(e.id)}" aria-label="删除${esc(d.name)}">${icon('trash')}移除</button></div>
</article>`;
}
function eventPickerItems() {
  const g = activeCampRule(), categories = [...new Set(Object.values(E.eventCatalog).map(d => d.category))];
  const full = g.events.length >= E.MAX_CAMP_EVENTS;
  return categories.map(category => `<section class="event-category"><h3><span class="cat">${icon(CATEGORY_ICON[category] || 'target')}</span>${category}</h3><div class="event-catalog">${Object.entries(E.eventCatalog).filter(([, d]) => d.category === category).map(([type, d]) => { const added = g.events.some(e => e.type === type); return `<button class="event-choice" data-add-event="${type}" ${added || full ? 'disabled' : ''}><span class="event-choice-title">${esc(d.name)}</span><span>${esc(campEventCopy(d.description))}</span><small>${added ? '已添加' : full ? '已达上限' : d.defaultValue + d.unit}</small></button>`; }).join('')}</div></section>`).join('');
}
function eventPicker() {
  modal(modalHead('选择胜利目标') + `<div class="picker-summary"><span>额外胜利目标</span><span id="event-picker-status" role="status">已选 ${activeCampRule().events.length} / ${E.MAX_CAMP_EVENTS} 项</span></div><div class="event-catalog-scroll" id="event-picker-list">${eventPickerItems()}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成选择</button></div>`, false, 'events');
}
function updateEventPicker() {
  if ($('#modal').dataset.kind !== 'events' || !$('#modal').open) return;
  refreshPickerList('#event-picker-list', eventPickerItems(), 'data-add-event');
  $('#event-picker-status').textContent = '已选 ' + activeCampRule().events.length + ' / ' + E.MAX_CAMP_EVENTS + ' 项';
}
function originalNeutralModal() {
  modal(modalHead('中立原胜利条件 · 全部只读') + `<div class="original-condition-list">${E.D.eligibleCareerIds.map(id => E.careers.get(id)).filter(c => c.camp === 3).map(c => `<div class="original-rule-row">${roleAvatar(c.id, 3)}<div><strong>${esc(c.name)}</strong><p>${esc(c.win_condition_des)}</p></div></div>`).join('')}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">知道了</button></div>`);
}

/* ---------- 第 3 步：搭配技能 ---------- */
function rosterGroups() {
  const query=rosterSearch.trim();
  const list=board.roles.filter(r=>!query||(r.name+E.campName(board,r.camp)).includes(query));
  return board.factions.map(f=>({f,rs:list.filter(r=>r.camp===f.id)})).filter(x=>x.rs.length);
}
function rosterCollapseState() { return rosterSearch.trim() ? rosterSearchCollapsed : rosterCollapsed; }
function revealRosterRole(r) { if(r){rosterCollapsed[r.camp]=false;rosterSearchCollapsed[r.camp]=false;} }
function rosterAllLabel() {
  const state=rosterCollapseState(),groups=rosterGroups();
  return groups.length&&groups.every(x=>state[x.f.id])?'全部展开':'全部收起';
}
function refreshRoster() {
  const list=$('.roster-list'); if(!list)return;const top=list.scrollTop;list.innerHTML=rosterItems();list.scrollTop=top;
  const all=$('[data-toggle-roster-all]');if(all){all.textContent=rosterAllLabel();all.disabled=!rosterGroups().length;}
}
function toggleRosterCamp(camp) {
  const state=rosterCollapseState();state[camp]=!state[camp];refreshRoster();
  $(`[data-toggle-roster-camp="${camp}"]`)?.focus({preventScroll:true});
}
function toggleRosterGroups() {
  const groups=rosterGroups(),state=rosterCollapseState(),collapse=!groups.every(x=>state[x.f.id]);
  for(const x of groups)state[x.f.id]=collapse;refreshRoster();
}
function rosterItems() {
  const groups=rosterGroups(),state=rosterCollapseState();
  const current = role()?.uid;
  const item = r => `<button class="roster-item camp-${r.camp} ${current === r.uid ? 'selected' : ''}" data-select-role="${r.uid}" aria-pressed="${current === r.uid}" style="${toneStyle(r.camp)}">${roleAvatar(r.templateCareerId, r.camp, 'sm')}<span class="name"><span>${nameHtml(r.name)}</span><small>${esc(E.campName(board, r.camp))}</small></span><span class="copies" title="单局最多出现${r.count}次">≤${r.count}</span></button>`;
  const grouped=groups.map(({f,rs})=>{
    const collapsed=!!state[f.id],editing=rs.some(r=>r.uid===current);
    return `<div class="roster-group" style="${toneStyle(f.id)}"><h4><button class="roster-group-toggle" data-toggle-roster-camp="${f.id}" aria-expanded="${!collapsed}" aria-controls="roster-camp-${f.id}" aria-label="${collapsed?'展开':'收起'}${esc(f.name)}角色"><i aria-hidden="true"></i><span class="roster-camp-name">${nameHtml(f.name)}</span>${collapsed&&editing?'<span class="roster-editing">编辑中</span>':''}<small>${rs.length}</small>${icon('chevron','roster-chevron')}</button></h4><div class="roster-group-body" id="roster-camp-${f.id}" ${collapsed?'hidden':''}>${rs.map(item).join('')}</div></div>`;
  }).join('');
  const other=board.roles.filter(r=>!E.faction(board,r.camp)&&(!rosterSearch.trim()||(r.name+E.campName(board,r.camp)).includes(rosterSearch.trim()))).map(item).join('');
  return grouped+other||'<p class="empty">没有找到角色</p>';
}
function rosterView() {
  return `<aside class="panel roster" aria-label="候选角色"><div class="roster-heading"><h3>选一个角色</h3><span>${board.roles.length}</span></div><div class="search-box">${icon('search')}<input id="roster-search" type="search" aria-label="搜索候选角色" placeholder="搜索角色或阵营" value="${esc(rosterSearch)}" autocomplete="off"></div><div class="roster-fold-tools"><span>按阵营查看</span><button class="btn-link" data-toggle-roster-all ${!rosterGroups().length?'disabled':''}>${rosterAllLabel()}</button></div><div class="roster-list">${rosterItems()}</div><div class="roster-bottom"><button class="btn btn-gold btn-sm roster-add" data-action="add-role" aria-label="添加已有职业" data-compact-label="加职业">${icon('plus')}添加已有职业</button><button class="btn btn-ghost btn-sm roster-add custom-role-add" data-action="new-custom-role" aria-label="创建空白角色" data-compact-label="建角色">${artImage(CUSTOM_ICON, 'custom-entry-icon', '', false)}<span>创建空白角色</span></button></div></aside>`;
}
function roleTop(r) {
  const custom = E.isCustom(r), f = E.faction(board, r.camp);
  return `<div class="role-hero" style="${toneStyle(r.camp)}">${rolePortrait(r)}<div class="role-hero-main"><div class="role-name-row"><span class="role-name-input"><input aria-label="角色名称" maxlength="20" value="${esc(r.name)}" data-role-field="name" autocomplete="off">${icon('pencil')}</span><span class="faction-tag"><i aria-hidden="true"></i>${nameHtml(f?.name || '')}${custom ? ' · 自创角色' : ''}</span></div><p class="role-desc">${custom ? '给你的新角色搭配技能。' : esc(E.careers.get(r.templateCareerId).des)}</p><div class="role-hero-actions"><button class="btn btn-violet btn-sm" data-action="role-options">${icon('gear')}角色设置</button><button class="btn btn-ghost btn-sm danger" data-action="remove-role" aria-label="删除${esc(r.name)}角色">${icon('trash')}删除角色</button><button class="btn btn-ghost btn-sm" data-action="role-art">${icon('image')}查看角色与技能素材</button><button class="btn-link" data-open-camp="${r.camp}">查看胜利条件 →</button></div></div></div>`;
}
function rolesView() {
  const r = role();
  if (!r) return title('给角色搭配技能', '先选角色，再选择想给他的能力。') + `<section class="panel empty-stage">${artImage(CUSTOM_ICON, 'workshop-mascot', '', false)}<h3>先添加一位角色</h3><p>已有职业可以直接使用，自创角色从空白开始。</p><div class="inline-actions"><button class="btn btn-gold" data-action="add-role">${icon('plus')}添加已有职业</button><button class="btn btn-ghost" data-action="new-custom-role">创建空白角色</button></div></section>`;
  const active = E.equippedSkills(r,{type:'active'}), passive = E.equippedSkills(r,{type:'passive'});
  return title('给角色搭配技能', '选中角色，点击“添加技能”。已有职业也可以换一种玩法。') + `
<div class="roles-layout">${rosterView()}
 <section class="role-workspace">
  ${roleTop(r)}
  ${E.phaseOneIssues(r).length ? '<div class="note warning" role="alert">这个角色有暂不可用的技能，请移除标记项。</div>' : ''}
  <div class="equipped-heading"><div><h3>我的技能 <span>${active.length}</span></h3><p>点击“调整”可设置冷却和使用次数。</p></div><button class="btn btn-gold" data-action="choose-skills">${icon('plus')}添加技能</button></div>
  <div class="equipped-grid skill-scroll">${active.map(x => skillCard(r, x.id, x.slot, x.name)).join('') || '<div class="empty">还没有技能，先为角色挑一个吧。</div>'}<button class="add-skill-tile" data-action="choose-skills"><span aria-hidden="true">＋</span>添加技能</button></div>
  ${passive.length ? `<details class="native-effects"><summary class="disclosure">角色自带效果 <span>${passive.length} 项</span></summary><div class="equipped-grid">${passive.map(x => skillCard(r, x.id, x.slot, x.name)).join('')}</div></details>` : ''}
 </section>
</div>`;
}
function skillCard(r, id, slot, name) {
  const identity=E.playerSkill(id), entry=E.equippedSkills(r).find(x=>x.id===identity.id), s=entry||identity, info=E.skillScope(s.sourceId), outside=!info?.inScope, duplicate=E.equivalentSkillIssues(r).length&&s.equivalentIds.filter(key=>E.allIds(r).includes(key)).length>1, incomplete=!entry?.complete||entry?.hasRuntimeAction||duplicate, tuned=[...s.memberIds,...s.equivalentIds].some(key=>r.skillOverrides[key]&&Object.keys(r.skillOverrides[key]).length); id=s.id;
  return `<article class="skill-card ${paramSkill === id ? 'active' : ''}${outside||incomplete ? ' skill-out-of-scope' : ''}"><div class="skill-title">${skillIcon(id)}<button class="skill-name" data-param="${id}" ${incomplete?'disabled':''}>${esc(s.name)}</button><button class="btn btn-ghost btn-sm danger" data-remove-skill="${id}" data-slot="${slot}" aria-label="移除${esc(s.name)}技能">${icon('x')}移除</button></div><p>${esc(s.des)}</p>${outside ? '<p class="skill-boundary" role="alert">当前不可用，请移除。</p>' : incomplete?'<p class="skill-boundary" role="alert">技能配置不完整，请移除后重新添加。</p>':''}<div class="skill-meta"><span class="tag">${s.type === 1 ? '被动技能' : '主动技能'}${s.skill_kind === 0 ? ' · 会议中使用' : ''}</span>${tuned ? '<span class="tag tag-gold">已调整</span>' : ''}<button class="btn-link" data-param="${id}" ${incomplete?'disabled':''}>${icon('gear')}调整</button></div></article>`;
}
function roleCountControl(r){
 if(!E.isUniqueNeutral(r))return numberField('本局最多出现几人',r.count,'data-role-field="count"','role-count',1,E.ROOM_LIMITS.max);
 return '<div class="neutral-copy-limit">'+icon('lock')+'同一中立职业，每局最多1人</div>'+(r.count!==1?'<button class="btn btn-gold btn-sm" data-reset-neutral-count="'+esc(r.uid)+'">将出场上限改为1人</button>':'');
}
function roleOptions() {
  const r = role(), custom = E.isCustom(r);
  modal(modalHead('角色设置') + `<div class="role-options-form"><p class="role-desc">${custom ? '给你的新角色搭配技能。' : esc(E.careers.get(r.templateCareerId).des)}</p>${custom ? `<label class="field"><span class="field-label">所属阵营</span><select data-role-field="camp" aria-label="归属阵营">${r.camp === 3 ? '<option value="3" disabled selected>请选择其他阵营</option>' : ''}${options(Object.fromEntries(board.factions.filter(f => f.id !== 3).map(f => [f.id, f.name])), r.camp)}</select></label>` : `<p class="locked-role-camp">${icon('lock')}${esc(E.campName(board, r.camp))} · 原阵营固定</p>`}${roleCountControl(r)}<p class="setting-hint">这是此角色的出场上限，不会增加阵营人数。</p></div><div class="role-maintenance"><button class="btn btn-ghost btn-sm" data-action="role-art">${icon('image')}查看角色与技能素材</button>${custom ? `<button class="btn btn-ghost btn-sm" data-action="clear-custom-skills">${icon('trash')}清空技能</button>` : `<button class="btn btn-ghost btn-sm" data-action="restore-role">${icon('undo')}恢复原技能</button>`}<button class="btn btn-ghost btn-sm danger" data-action="remove-role">${icon('trash')}删除角色</button></div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成</button></div>`, true, 'role-options');
}
function skillPicker() {
  const r = role(), list = E.librarySkills({type: 'active'}), modules = [...new Set(list.map(s => E.skillScope(s.id).module))];
  modal(modalHead('为「' + nameHtml(r.name) + '」添加技能') + `<div class="modal-toolbar"><div class="search-box">${icon('search')}<input id="skill-search" type="search" aria-label="搜索技能" placeholder="搜索想要的能力" value="${esc(skillSearch)}" autocomplete="off"></div><select class="compact-module-picker" aria-label="技能类型" data-skill-module-select>${options(Object.fromEntries([['all', '全部类型'], ...modules.map(m => [m, m])]), skillModule)}</select></div><div class="filter-chips" id="skill-module" role="group" aria-label="技能模块" style="margin-top:12px">${[['all', '全部类型'], ...modules.map(m => [m, m])].map(([k, v]) => `<button class="chip ${skillModule === k ? 'selected' : ''}" data-skill-module="${esc(k)}" aria-pressed="${skillModule === k}">${esc(v)}</button>`).join('')}</div><div class="picker-summary"><span>技能库 · ${list.length} 项主动技能</span><span id="skill-picker-status" role="status">点击添加，可连续选择多个</span></div><div class="library-list skill-picker-list" id="library-list">${libraryItems(r)}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成搭配</button></div>`, false, 'skills');
  $('#skill-search').focus();
}
function selectSkillModule(value) {
  skillModule = value;
  $$('[data-skill-module]').forEach(b => { b.classList.toggle('selected', b.dataset.skillModule === value); b.setAttribute('aria-pressed', b.dataset.skillModule === value); });
  const select = $('[data-skill-module-select]'); if (select) select.value = value;
  updateSkillPicker();
}
function updateSkillPicker() {
  if ($('#modal').dataset.kind !== 'skills' || !$('#modal').open) return;
  refreshPickerList('#library-list', libraryItems(role()), 'data-add-skill');
  $('#skill-picker-status').textContent = '已装备 ' + E.equippedSkills(role(),{type:'active'}).length + ' 项主动技能';
}
function libraryItems(r) {
  const equipped = E.equippedSkills(r).map(s=>s.id), list = E.librarySkills({search: skillSearch, type: 'active', module: skillModule});
  return list.map(s => {
    const info = E.skillScope(s.id), compat = E.skillCompatibility(s.id, r), isEquipped = equipped.includes(s.id), blocked = compat.level === 'error';
    return `<article class="library-item${blocked ? ' skill-blocked' : ''}${isEquipped ? ' is-equipped' : ''}" data-library-skill="${s.id}"><div class="item-title">${skillIcon(s.id)}<strong>${esc(s.name)}</strong></div><p>${esc(s.des || '暂无技能说明')}</p><div class="item-foot">${blocked ? `<small class="skill-boundary">${esc(['SKILL_STATE_DEADLOCK', 'SKILL_FAMILY_CONFLICT'].includes(compat.code) ? '与已装备技能冲突' : compat.code === 'SKILL_CONTEXT_ONLY' ? '需在对局中触发' : '仅限原职业使用')}</small>` : `<span class="tag module-tag">${esc(info.module)}</span>`}<button class="btn ${isEquipped || blocked ? 'btn-ghost' : 'btn-gold'} btn-sm" data-add-skill="${s.id}" ${isEquipped || blocked ? 'disabled' : ''}>${isEquipped ? icon('check') + '已装备' : blocked ? '不可添加' : '＋ 添加'}</button></div></article>`;
  }).join('') || '<div class="empty">没有找到技能</div>';
}
function skillParameters(id){const r=role(),identity=E.playerSkill(id);paramSkill=E.equippedSkills(r).find(x=>x.id===identity?.id)?.sourceId||0;if(!E.allIds(r).includes(paramSkill)){toast('请移除不完整的技能后重新添加');return;}const s=E.playerSkill(paramSkill);modal(modalHead('调整「'+esc(s.name)+'」')+parameterView(r)+'<div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成</button></div>',false,'parameters');}
function parameterView(r){if(!paramSkill||!E.allIds(r).includes(paramSkill))return '';const s=E.effective(r,paramSkill),st=s.stages[0],uses=(label,key)=>`<label class="param-field">${label}<select data-skill-limit="${key}">${options(Object.fromEntries([...new Set([-1,0,1,2,3,5,10,s[key]])].sort((a,b)=>a-b).map(v=>[v,v===-1?'不限':v===0?'禁止使用':v+' 次'])),s[key])}</select></label>`;return `<div class="parameter-panel"><div class="inline-actions"><p class="muted">调整会自动保存。</p><button class="btn btn-ghost btn-sm" data-action="reset-params">恢复默认</button></div><div class="field-grid">${number('首次可用等待（秒）',s.get_cd,'data-skill-param="get_cd"',0)}${uses('整局使用次数','use_time')}${s.skill_kind===0?uses('每次会议使用次数','meeting_use_time'):''}${st?number('会议后等待（秒）',st.meeting_cd,`data-stage="${st.id}" data-stage-param="meeting_cd"`):''}${st?.cd_type<=1?number(st.cd_type===0?'使用冷却（秒）':'击倒冷却倍率（%）',st.cd_type_param_1,`data-stage="${st.id}" data-stage-param="cd_type_param_1"`):''}</div></div>`;}

/* ---------- 第 5 步：预览板子 ---------- */
function drawRing() {
  const seats = drawResult.seats, n = seats.length;
  return `<div class="seat-ring ${ringSize(n)}" aria-hidden="true">${seats.map((s, i) => {
    const [x, y] = ringPoint(i, n), a = s.templateCareerId === null ? {icon: CUSTOM_ICON} : ART.roles[s.templateCareerId];
    return `<span class="seat seat-role ${justDrew ? 'reveal' : ''}" data-seat="${i}" style="left:${x.toFixed(2)}%;top:${y.toFixed(2)}%;${toneStyle(s.camp)};--d:${i * 70}ms" title="席位 ${i + 1} · ${esc(s.name)}">${a?.icon ? `<img src="${esc(a.icon.src)}" alt="" decoding="async">` : `<b>${esc(s.name.slice(0, 1))}</b>`}<span class="seat-no">${i + 1}</span></span>`;
  }).join('')}</div>`;
}
function drawPanel() {
  const blocked = checkReport.some(x => x.level === 'error');
  const stats = E.campIds(board).map(c => { const p = E.poolStats(board, c); return `<span class="pool-stat" style="${toneStyle(c)}"><i aria-hidden="true"></i>${esc(E.campName(board, c))}：${p.candidates}种候选 → 抽${p.seats}人</span>`; }).join('');
  let body;
  if (drawError) body = `<div class="note warning" role="alert" style="margin-top:16px">${esc(drawError)}</div>`;
  else if (drawResult) body = `<div class="draw-stage"><div class="seat-table"><div class="table-top" aria-hidden="true"></div>${drawRing()}<div class="draw-table-label"><strong>${drawResult.seats.length}</strong><span>人</span></div></div><div><div class="draw-camps">${E.campIds(board).map(c => `<article class="draw-camp camp-${c}" style="${toneStyle(c)}"><h4>${nameHtml(E.campName(board, c))} <span>${drawResult.seats.filter(s => s.camp === c).length} / ${board.room.counts[c]} 人</span></h4><ol>${drawResult.seats.filter(s => s.camp === c).map(s => `<li>${roleAvatar(s.templateCareerId, c, 'sm')}<div><strong>${nameHtml(s.name)}</strong><small>席位 ${drawResult.seats.indexOf(s) + 1}${s.copy > 1 ? ' · 同角色第' + s.copy + '份' : ''}</small></div></li>`).join('') || '<li class="muted">本局不分配席位</li>'}</ol></article>`).join('')}</div><p class="draw-meta">本次抽中 ${drawResult.seats.length} 席，${drawResult.omitted.length} 种候选未出场。</p></div></div>`;
  else body = `<div class="draw-stage"><div class="seat-table"><div class="table-top" aria-hidden="true"></div>${seatRing(planTokens())}<div class="draw-table-label"><strong>${board.room.total}</strong><span>人</span></div></div><div class="draw-empty">${blocked ? '请先修正下方配置问题，再随机抽取。' : '角色池已就绪。点击“随机抽取一桌”，按各阵营人数产生本局名单。'}</div></div>`;
  return `<section id="draw-panel" class="panel draw-panel"><div class="draw-heading"><div><h3>这一局，谁会出场？</h3><div class="pool-stats">${stats}</div></div><button class="btn btn-gold btn-lg" data-action="draw-pool" ${blocked ? 'disabled' : ''}>${icon('dice')}${drawResult ? '重新随机抽取' : '随机抽取一桌'}</button></div>${body}<small class="draw-foot">修改设置后，需要重新抽取。</small></section>`;
}
function issueButton(x) { return reviewIssueLink(x); }
function customBaseSummary() { return board.factions.filter(f => f.kind === 'custom').map(f => `<div class="goal-review-row">${emblem(f, 'sm')}<div><strong>${nameHtml(f.name)} · 原有条件</strong><p>${esc(E.baseVictory(f.baseVictory)?.name || '未选择原有条件，使用新增目标')}</p></div></div>`).join(''); }
function reviewView() {
  const errors = checkReport.filter(x => x.level === 'error').length, warnings = checkReport.filter(x => x.level === 'warn').length;
  return title('看看这局会是什么样', '先试抽一局，确认无误后就能导出分享。') + drawPanel() + `
<div class="review-grid">
 <section class="panel check-panel">
  <div class="check-top"><span class="check-mark ${errors ? 'bad' : 'ok'}">${icon(errors ? 'alert' : 'check')}</span><div><strong class="${errors ? '' : 'ok'}">${nums(errors ? errors + ' 项需要调整' : '可以继续保存')}</strong><p>${warnings} 项提醒 · ${board.roles.length} 种候选</p></div><button class="btn btn-ghost btn-sm" data-action="recheck">${icon('refresh')}重新检查</button></div>
  <div class="check-list">${checkReport.filter(x => x.level !== 'info').map(x => `<div class="issue ${x.level}"><b>${x.level === 'error' ? '调整' : '提醒'}</b><span>${esc(x.text)}</span>${issueButton(x)}</div>`).join('') || '<div class="note">人数、候选容量与已知规则检查通过。</div>'}</div>
 </section>
 <div class="review-side">
  <section class="panel export-card export-summary"><span class="ic-wrap">${icon('download')}</span><p>保存这套板子，分享给朋友。</p><button class="btn btn-gold" data-action="export">导出板子</button></section>
  <section class="panel review-goals"><h3>本局胜利条件</h3>${customBaseSummary()}${board.campEvents.filter(g => g.events.length).map(g => `<div class="goal-review-row">${emblem(E.faction(board, g.camp), 'sm')}<div><strong>${nameHtml(E.campName(board, g.camp) + (g.camp === 3 ? ' · 所有中立角色适用' : ''))}</strong><p>${g.join === 'all' ? '全部完成：' : '完成任意一个：'}<br>${[...g.events].sort((a, b) => b.weight - a.weight).map(eventText).map(esc).join('<br>')}</p></div></div>`).join('') || '<p class="muted">没有新增目标，沿用原条件。</p>'}</section>
 </div>
</div>
<details class="panel simple-sim" ${simOpen ? 'open' : ''}><summary>试一试胜利判定${drawResult ? '' : `<span class="tag">${icon('dice')}先随机抽取一桌</span>`}</summary><div class="sim-body"><p class="muted">填入假设进度，检查新增目标与原条件的先后关系。</p><div id="sim-inputs"></div><div id="sim-result" aria-live="polite"></div></div></details>`;
}
function newScenario() { return {progress: {}, eligibleAlive: true, originalWinner: ''}; }
function simGroups() {
  if (!drawResult) return [];
  return E.campIds(board).filter(c => c !== 3 && drawResult.seats.some(s => s.camp === c)).map(c => ({key: 'camp-' + c, camp: c, label: factionLabel(c)})).concat(drawResult.seats.filter(s => s.camp === 3).map(s => ({key: s.uid, camp: 3, roleUid: s.roleUid, seatId: s.uid, label: s.name + ' · 席位' + (drawResult.seats.indexOf(s) + 1)})));
}
function renderSimulation() {
  const el = $('#sim-inputs'); if (!el) return;
  const groups = simGroups();
  if (!groups.length) { el.innerHTML = '<div class="note" style="margin-top:12px">先在上方随机抽取一桌，再试算实际出场的阵营。</div>'; return; }
  if (!groups.some(g => g.key === simGroup)) simGroup = groups[0].key;
  if (!scenario) scenario = newScenario();
  const g = groups.find(g => g.key === simGroup), rule = E.campRule(board, g.camp, g.roleUid);
  el.innerHTML = `<div class="simple-sim-grid"><label class="param-field"><span>要试算的阵营／玩家</span><select id="sim-group">${groups.map(x => `<option value="${x.key}" ${x.key === simGroup ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select></label><label class="param-field"><span>假设原条件也已达成</span><select data-sim-original>${options({'': '暂未达成原条件', ...Object.fromEntries(groups.filter(x => x.camp > 3 ? !!E.faction(board, x.camp).baseVictory : x.camp !== 3 || !E.isCustom(board.roles.find(r => r.uid === x.roleUid))).map(x => [x.key, x.label]))}, scenario.originalWinner)}</select></label>${rule.events.map(e => { const d = E.eventCatalog[e.type], key = d.counter || e.type; return numberField(d.name + (g.camp !== 3 && d.aggregation === 'personalMax' ? '个人最高记录' : '已完成') + '（' + d.unit + '）', scenario.progress[key] || 0, `data-sim-progress="${key}"`, 'sim-' + key, 0, 999); }).join('')}</div><label class="sim-alive"><input type="checkbox" data-sim-alive ${scenario.eligibleAlive ? 'checked' : ''}>${g.camp === 3 ? '本人仍然存活' : '本阵营仍有成员存活'}</label><small class="scope-note">${g.camp === 3 ? '所有中立采用相同目标；这里仅填写该席位本人的进度，不与其他中立合并。' : '按每项目标的说明填写；个人目标填写一名存活成员的最高记录，其余填写阵营累计。'}</small><div class="sim-actions"><button class="btn btn-gold" data-action="simulate">${icon('trophy')}看看谁获胜</button></div>`;
  if (simulationRun) showResult(); else $('#sim-result').innerHTML = '';
}
function showResult() {
  const groups = simGroups(), g = groups.find(g => g.key === simGroup); if (!g) return;
  const seats = drawResult.seats, original = groups.find(x => x.key === scenario.originalWinner);
  const ids = x => x.camp === 3 ? [x.seatId] : seats.filter(s => s.camp === x.camp).map(s => s.uid), actorIds = ids(g);
  const state = {finalized: true, seats, campProgress: g.camp === 3 ? {} : {[g.camp]: scenario.progress}, playerProgress: g.camp === 3 ? {[g.seatId]: scenario.progress} : {}, aliveSeatIds: seats.map(s => s.uid).filter(id => scenario.eligibleAlive || !actorIds.includes(id)), originalWinners: original && original.camp <= 3 ? ids(original) : [], baseConditionMatches: original?.camp > 3 ? [{camp: original.camp, presetId: E.faction(board, original.camp).baseVictory, actorSeatId: ids(original)[0]}] : []};
  if (g.camp !== 3 && actorIds.length) { const p = {}; for (const [type, d] of Object.entries(E.eventCatalog)) if (d.aggregation === 'personalMax') p[type] = scenario.progress[type] || 0; state.playerProgress[actorIds[0]] = p; }
  const result = E.resolveVictory(board, state);
  $('#sim-result').innerHTML = `<div class="simulation-result"><h3>${result.source === 'extra' ? '新增目标优先获胜' : result.source === 'original' ? '按原条件获胜' : result.source === 'pending' ? '等待事件处理完成' : '暂时无人获胜'}</h3><p>${esc(result.invalid ? result.reason : result.source === 'extra' ? result.reason : result.source === 'original' ? '额外目标尚未达成，按原有条件获胜。' : result.source === 'none' ? '继续游戏。' : '等待结算。')}</p>${result.winners.length ? `<p class="sim-winners">${result.winners.map(id => esc(seats.find(s => s.uid === id)?.name || id)).join('、')}</p>` : ''}</div>`;
}

/* ---------- 弹窗 ---------- */
function modal(html, compact = false, kind = '') {
  const d = $('#modal');
  d.classList.toggle('compact-dialog', compact); d.dataset.kind = kind; d.setAttribute('aria-labelledby', 'modal-title');
  const box = $('#modal-content');
  box.innerHTML = html;
  const status = document.createElement('p'); status.id = 'dialog-status'; status.className = 'dialog-status'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
  const actions = [...box.children].reverse().find(n => n.classList.contains('modal-actions'));
  const body = document.createElement('div'); body.className = 'modal-body';
  const picker = ['skills', 'careers', 'events'].includes(kind);
  for (const node of [...box.children]) {
    if (node.classList.contains('modal-head') || node === actions || (picker && node.matches('.modal-toolbar,.filter-chips,.picker-summary'))) continue;
    body.appendChild(node);
  }
  box.insertBefore(body, actions || null);
  if (actions) box.insertBefore(status, actions); else box.appendChild(status);
  if (!d.open) d.showModal();
  if (!d.contains(document.activeElement)) d.querySelector('[autofocus],button,input,select,textarea,[tabindex="0"]')?.focus();
  box.scrollTop = 0;
}
function closeModal() { $('#modal').close(); }
function refreshPickerList(selector, html, attribute) {
  const list = $(selector); if (!list) return;
  const scroller = $('#modal .modal-body') || $('#modal-content'), top = list.scrollTop, outer = scroller.scrollTop;
  const active = document.activeElement, current = active?.closest('[' + attribute + ']');
  const hadFocus = list.contains(active), key = current?.getAttribute(attribute);
  const index = current ? [...list.querySelectorAll('[' + attribute + ']')].indexOf(current) : -1;
  list.innerHTML = html;
  if (hadFocus) {
    const buttons = [...list.querySelectorAll('[' + attribute + ']')];
    const same = buttons.find(b => b.getAttribute(attribute) === key && !b.disabled);
    const next = buttons.slice(Math.max(0, index)).find(b => !b.disabled) || buttons.find(b => !b.disabled);
    (same || next || $('#modal .modal-close'))?.focus({preventScroll: true});
  }
  list.scrollTop = top; scroller.scrollTop = outer;
}
const modalHead = t => `<div class="modal-head"><h2 id="modal-title">${t}</h2><button type="button" class="modal-close" data-action="close-modal" aria-label="关闭弹窗">${icon('x')}</button></div>`;
function addRoleModal(camp = null) {
  careerLockedCamp = camp === null ? null : Number(camp); careerSearch = ''; careerCamp = careerLockedCamp === null ? 'all' : String(careerLockedCamp);
  modal(modalHead(careerLockedCamp === null ? '添加已有职业' : nameHtml(E.campName(board, careerLockedCamp)) + ' · 添加职业') + `<div class="modal-toolbar ${careerLockedCamp === null ? '' : 'locked-camp-toolbar'}"><div class="search-box">${icon('search')}<input id="career-search" type="search" aria-label="搜索职业" placeholder="搜索职业" autocomplete="off"></div>${careerLockedCamp === null ? `<div class="filter-chips" id="career-camp" role="group" aria-label="筛选阵营">${[['all', '全部阵营'], ['1', '鹅阵营'], ['2', '鸭阵营'], ['3', '中立阵营']].map(([k, v]) => `<button class="chip ${careerCamp === k ? 'selected' : ''}" data-career-camp="${k}" aria-pressed="${careerCamp === k}">${v}</button>`).join('')}</div>` : ''}</div><div class="modal-grid" id="career-list">${careerItems()}</div><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">完成选择</button></div>`, false, 'careers');
  $('#career-search').focus();
}
function careerItems() {
  const pooled = new Map(); board.roles.forEach(r => pooled.set(r.templateCareerId, (pooled.get(r.templateCareerId) || 0) + 1));
  return D.career.filter(c => E.classicCareerIds.has(c.id) && (careerLockedCamp === null || c.camp === careerLockedCamp) && (careerCamp === 'all' || c.camp === +careerCamp) && (!careerSearch || (c.name + String(c.id)).includes(careerSearch))).map(c => {
    const state=E.careerAddStatus(board,c.id), label=state.allowed?(pooled.has(c.id)?'已添加 '+pooled.get(c.id)+' 个 · 可继续添加':'添加角色'):state.reason;
    return '<button class="career-option camp-'+c.camp+'" data-add-career="'+c.id+'" style="'+toneStyle(c.camp)+'" '+(state.allowed?'':'disabled')+' title="'+esc(label)+'">'+roleAvatar(c.id,c.camp)+'<h3>'+esc(c.name)+'</h3><p>'+esc(c.des)+'</p><span class="chip-camp"><i aria-hidden="true"></i>'+esc(label)+'</span><span class="add-mark" aria-hidden="true">'+icon(state.allowed?'plus':pooled.has(c.id)?'check':'lock')+'</span></button>';
  }).join('') || '<div class="empty">没有匹配角色</div>';
}
function nextCustomRoleName() {
  let name = '自创角色', n = 2; const names = new Set(board.roles.map(r => r.name));
  while (names.has(name)) name = '自创角色' + n++;
  return name;
}
function customRoleModal(camp = null) {
  if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('候选池最多300个角色条目');
  if (camp !== null && (!E.faction(board, camp) || camp === 3)) throw Error('空白角色请选择鹅、鸭或新阵营');
  customRoleCamp = camp; const name = nextCustomRoleName();
  const choices = board.factions.filter(f => f.id !== 3), chosen = camp ?? choices[0].id;
  modal(modalHead('创建空白角色') + `<form id="custom-role-form"><div class="custom-role-preview">${roleAvatar(null, chosen)}<span>为新角色起个名字</span></div><div class="custom-role-fields"><label for="new-role-name">角色名称</label><input id="new-role-name" name="name" maxlength="20" required value="${esc(name)}" autocomplete="off"><label for="new-role-camp">所属阵营</label>${camp === null ? `<select id="new-role-camp" name="camp">${options(Object.fromEntries(choices.map(f => [f.id, f.name])), chosen)}</select>` : `<input id="new-role-camp" value="${esc(E.campName(board, camp))}" readonly>`}</div><p class="setting-hint" style="margin-top:12px">创建后，到“搭配技能”选择能力。</p><p class="form-error" id="custom-role-error" role="alert" hidden></p><div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="close-modal">关闭</button><button type="submit" class="btn btn-gold">创建角色</button></div></form>`, true, 'custom-role');
  $('#new-role-name').focus(); $('#new-role-name').select();
}
document.addEventListener('submit', e => {
  if (e.target.id !== 'custom-role-form') return; e.preventDefault();
  try {
    const name = $('#new-role-name').value.trim(); if (!name) throw Error('请输入角色名称'); if (name.length > 20) throw Error('角色名称最多20个字');
    if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('候选池最多300个角色条目');
    const camp = customRoleCamp ?? Number($('#new-role-camp').value), r = E.makeCustomRole(board, camp); r.name = name;
    board.roles.push(r); selected = r.uid; rosterSearch=''; revealRosterRole(r); paramSkill = 0; mark(); renderInPlace();
    $('#new-role-name').value = nextCustomRoleName(); $('#custom-role-error').hidden = true;
    $('#new-role-name').focus({preventScroll: true}); $('#new-role-name').select();
    toast('已创建「' + r.name + '」，可继续创建');
  } catch (error) { const n = $('#custom-role-error'); n.textContent = error.message; n.hidden = false; }
});

/* ---------- 按页重置 ---------- */
function resetPageData(source, page, roleUid) {
  const b = clone(source), defaults = E.defaultBoard();
  if (page === 'room') { b.room = {...defaults.room, counts: clone(b.room.counts)}; b.description = defaults.description; }
  else if (page === 'factions') {
    const previous = b.roles;
    b.factions = clone(defaults.factions);
    const total = Math.min(E.ROOM_LIMITS.max, Math.max(E.ROOM_LIMITS.min, b.room.total)), ducks = Math.max(1, Math.floor(total / 5)), neutral = Math.min(2, Math.floor(total / 5));
    b.room.counts = {1: total - ducks - neutral, 2: ducks, 3: neutral};
    b.roles = defaults.roles.map(r => clone(previous.find(p => !E.isCustom(p) && p.templateCareerId === r.templateCareerId) || r));
    for (const [camp, careerId] of [[1, 1], [2, 101]]) { const missing = b.room.counts[camp] - E.poolStats(b, camp).capacity; if (missing > 0) b.roles.find(r => r.templateCareerId === careerId).count += missing; }
    E.ensureCampRules(b);
  } else if (page === 'wins') {
    for (const f of b.factions) if (f.kind === 'custom') f.baseVictory = null;
    b.campEvents = b.factions.map(f => ({key: 'camp-' + f.id, camp: f.id, join: 'any', events: []}));
  } else if (page === 'roles') {
    const r = b.roles.find(r => r.uid === roleUid); if (!r) throw Error('请先选择角色。');
    const fresh = E.isCustom(r) ? E.makeCustomRole(b, 1) : E.makeRole(r.templateCareerId);
    r.slots = clone(fresh.slots); r.skillOverrides = {};
  } else if (page !== 'review') throw Error('当前页面不能重置。');
  return b;
}
function pageResetDetails() {
  const r = role();
  return {
    room: {label: '房间设置', copy: '恢复默认人数、会议参数、对局参数和玩法介绍。阵营分配、角色与胜利目标会保留。'},
    factions: {label: '阵营分配', copy: '按当前房间人数恢复鹅、鸭、中立及经典候选角色。自建阵营及被移除角色的设置会一并移除。保留角色的技能、原三阵营胜利目标和房间参数不变。'},
    wins: {label: '胜利设置', copy: '清空所有额外胜利目标，取消新阵营选用的基础条件。原有胜利条件仍固定，阵营与技能保持原样。'},
    roles: {label: r ? r.name + '的技能' : '当前角色技能', copy: r ? (E.isCustom(r) ? '清空「' + r.name + '」的技能和技能参数调整。' : '恢复「' + r.name + '」的原技能，清除技能参数调整。') : '请先选择角色。'},
    review: {label: '预览结果', copy: '清空本次抽取名单和胜利试算结果，已配置的板子保持原样。'}
  }[tab];
}
function pageResetModal() {
  const d = pageResetDetails(); if (tab === 'roles' && !role()) return;
  modal(modalHead('重置' + nameHtml(d.label) + '？') + '<p class="reset-scope-copy">' + esc(d.copy) + '</p><p class="setting-hint" style="margin-top:10px">重置后可立即撤销。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-danger" data-action="confirm-page-reset">确认重置</button></div>', true);
}
function performPageReset() {
  const before = snapshotEditor(pageResetDetails().label);
  board = resetPageData(board, tab, role()?.uid); paramSkill = 0;
  if (!board.roles.some(r => r.uid === selected)) selected = board.roles[0]?.uid || '';
  if (!E.faction(board, ruleCamp)) ruleCamp = 1;
  if (tab === 'review') { drawResult = null; drawError = ''; scenario = null; simulationRun = false; } else mark();
  lastPageReset = before; closeModal(); render(); $('#content').scrollTop = 0;
  toast(before.label + '已重置');
}
function undoPageReset(){const previous=lastPageReset;if(!previous)return;simOpen=previous.simOpen??false;membersOpen=clone(previous.membersOpen||{});rosterCollapsed=clone(previous.rosterCollapsed||{});rosterSearchCollapsed={};board=clone(previous.board);tab=previous.tab;selected=previous.selected;ruleCamp=previous.ruleCamp;rosterSearch=previous.rosterSearch??'';skillSearch=previous.skillSearch??'';skillModule=previous.skillModule??'all';roomMoreOpen=previous.roomMoreOpen??false;navigationContext=previous.navigationContext||null;paramSkill=0;if(previous.tab!=='review'||previous.kind==='global'||previous.kind==='remove-role')mark();drawResult=previous.drawResult;drawError=previous.drawError;scenario=previous.scenario;simulationRun=previous.simulationRun;simGroup=previous.simGroup;simRole=previous.simRole||'';lastPageReset=null;render();$('#content').scrollTop=0;toast(previous.kind==='remove-role'?'已撤销删除':'已撤销重置');}

/* ---------- 存档、导入导出 ---------- */
function fileMenu() {
  const items = [['load', 'folder', '我的板子', '打开已保存的板子'], ['save', 'save', '保存一份', '留下一个命名存档'], ['export', 'download', '导出板子', '下载文件，分享给朋友'], ['import', 'upload', '导入板子', '打开已有的板子文件'], ['how-to', 'help', '怎么使用？', '一分钟了解编辑流程'], ['reset-all', 'undo', '重置全部', '恢复当前板子的全部初始设置']];
  modal(modalHead('管理我的板子') + `<div class="file-menu-grid">${items.map(([a, ic, t, s]) => `<button class="${a==='reset-all'?'reset-all-entry':''}" data-action="${a}"><span class="menu-ic">${icon(ic)}</span><strong>${t}</strong><span>${s}</span></button>`).join('')}</div>`, true);
}
function howTo() {
  const steps = [['设置房间', '选好人数，会议设置可直接用默认。'], ['分配阵营', '定好每队几人，再挑可随机出现的角色。'], ['搭配技能', '给已有或自创角色添加主动技能。'], ['设置胜利', '保留原规则，或给阵营增加新的获胜目标。'], ['预览板子', '试抽一局，修正提示后导出分享。']];
  modal(modalHead('跟着这 5 步，做一套新玩法') + `<ol class="quick-guide">${steps.map(([t, p], i) => `<li><span class="guide-badge">${stepArt(STEP_INFO[STEPS[i]].icon)}<b>${i + 1}</b></span><strong>${t}</strong><p>${p}</p></li>`).join('')}</ol><div class="modal-actions"><button class="btn btn-gold" data-action="close-modal">开始动手</button></div>`, true);
}
function readSaves() { try { const a = JSON.parse(localStorage.getItem(STORE) || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } }
function save() {
  try { const saves = readSaves(), item = {id: Date.now().toString(), name: board.boardName, time: new Date().toISOString(), board: E.exportDraft(board)}; saves.unshift(item); localStorage.setItem(STORE, JSON.stringify(saves.slice(0, 8))); dirty = false; $('#save-state').textContent = '已保存命名存档'; if ($('#modal').open && $('#modal').dataset.kind === 'saves') loadModal(); toast('已保存到本机存档（保留最近8份）'); }
  catch (e) { toast('本地存储不可用，请导出 JSON 保存。'); }
}
function loadModal() {
  const saves = readSaves();
  modal(modalHead('我的本机存档') + `<small class="modal-small">加载会先备份当前板子；最多保留最近 8 份命名存档。</small>${saves.map((s, i) => `<div class="save-row"><div><strong>${esc(s.name)}</strong><p>${esc(new Date(s.time).toLocaleString('zh-CN'))}</p></div><div class="inline-actions"><button class="btn btn-gold btn-sm" data-load-save="${i}">加载</button><button class="btn btn-ghost btn-sm danger" data-delete-save="${i}">删除</button></div></div>`).join('') || '<div class="empty" style="margin-top:15px">暂无命名存档，在“更多”中点击“保存一份”留下一个版本。</div>'}<div class="modal-actions"><button class="btn btn-ghost btn-sm" data-action="recover">恢复上次自动暂存</button><button class="btn btn-ghost btn-sm" data-action="recover-previous">恢复替换前草稿</button><span class="spacer"></span><button class="btn btn-violet btn-sm" data-action="save">${icon('save')}保存一份</button><button class="btn btn-gold btn-sm" data-action="close-modal">关闭</button></div>`, false, 'saves');
}
function replaceBoard(b,keepModal=false){const incoming=E.validateShape(b);try{localStorage.setItem(STORE+'-recovery',JSON.stringify(E.exportDraft(board)));}catch{}rosterCollapsed={};rosterSearchCollapsed={};membersOpen={};simOpen=false;justDrew=false;flashFaction=null;board=incoming;selected=board.roles[0]?.uid||'';tab='room';ruleCamp=1;rosterSearch='';skillSearch='';skillModule='all';roomMoreOpen=false;navigationContext=null;simRole='';simGroup='';scenario=null;paramSkill=0;simulationRun=false;mark();if(!keepModal)closeModal();render();$('#content').scrollTop=0;toast('已载入板子，原草稿已备份');}
function exportModal() {
  header(); const errors = checkReport.filter(x => x.level === 'error').length;
  modal(modalHead('导出我的板子') + `<div class="modal-notice">${errors ? `有 ${errors} 项错误。可以导出问题草稿，文件会保留检查报告，便于继续修改。` : '当前基础检查通过。导出为离线板子草稿，保留全部自定义设置。'}</div><p class="muted">保存全部设置，之后可重新导入编辑。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">继续编辑</button><button class="btn btn-gold" data-action="download">${icon('download')}${errors ? '导出问题草稿' : '下载板子文件'}</button></div>`);
}
function download() {
  try {
    const out = E.exportDraft(board); out.checkReport = clone(checkReport); if (drawResult) out.drawPreview = clone(drawResult);
    const blob = new Blob([JSON.stringify(out, null, 2)], {type: 'application/json;charset=utf-8'});
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = (board.boardName.replace(/[\\/:*?"<>|]/g, '_') || '板子') + '.json'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000); toast('板子已导出');
  } catch (e) { toast('导出失败：' + e.message); }
}
async function importFile(file) {
  if (!file) return;
  try {
    if (file.size > 2 * 1024 * 1024) throw Error('文件超过 2MB');
    const incoming = E.validateShape(JSON.parse(await file.text())), issues = E.validate(incoming);
    modal(modalHead('导入为新草稿') + `<p style="font:18px var(--font-display)">板子：${esc(incoming.boardName)}</p><p style="margin-top:8px;color:var(--text-2)">${incoming.room.total} 人 · ${incoming.roles.length} 种候选 · ${issues.filter(x => x.level === 'error').length} 项待修正</p><div class="note" style="margin-top:14px">只导入到本编辑器。当前草稿会先保存恢复备份，不修改游戏房间。</div><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" id="confirm-import">导入草稿</button></div>`);
    $('#confirm-import').addEventListener('click', () => replaceBoard(incoming), {once: true});
  } catch (e) { toast('导入失败：' + e.message); } finally { $('#file-import').value = ''; }
}

/* ---------- 实时刷新（输入中不整页重绘） ---------- */
function refreshInline() {
  $$('[data-total-delta]').forEach(b => b.disabled = Number(b.dataset.totalDelta) > 0 ? board.room.total >= E.ROOM_LIMITS.max : board.room.total <= E.ROOM_LIMITS.min);
  $$('[data-count-step]').forEach(b => b.disabled = Number(b.dataset.delta) > 0 ? board.room.counts[b.dataset.countStep] >= E.ROOM_LIMITS.max : board.room.counts[b.dataset.countStep] === 0);
  $$('[data-total-preset]').forEach(b => { const on = Number(b.dataset.totalPreset) === board.room.total; b.classList.toggle('selected', on); b.setAttribute('aria-pressed', on); });
  const ring = $('.room-hero .seat-ring');
  if (ring) { const before = captureSeats(); ring.outerHTML = seatRing(planTokens()); playSeats(before); }
  const alloc = $('.js-alloc'); if (alloc) alloc.innerHTML = allocationSummary();
  const strip = $('.js-seat-strip'); if (strip) strip.innerHTML = seatStrip();
  const status = $('[data-alloc-status]'); if (status) status.outerHTML = allocationStatus();
  for (const f of board.factions) { const node = $(`[data-pool-count="${f.id}"]`); if (node) { const p = E.poolStats(board, f.id); node.textContent = p.candidates + ' 个候选 · 随机选 ' + p.seats + ' 人'; } }
  $$('[data-room-range]').forEach(rg => { const k = rg.dataset.roomRange; if (document.activeElement !== rg) rg.value = board.room[k]; setPct(rg); });
  $$('input[type=number][data-room]').forEach(n => { if (document.activeElement !== n && !n.hidden && Number(n.value) !== board.room[n.dataset.room]) n.value = board.room[n.dataset.room]; });
  const drawNode = $('#draw-panel'); if (drawNode && !drawResult) drawNode.outerHTML = drawPanel();
  $$('[data-select-role]').forEach(button => { const r = board.roles.find(x => x.uid === button.dataset.selectRole); if (!r) return; button.querySelector('.name>span').innerHTML = nameHtml(r.name); const c = button.querySelector('.copies'); c.textContent = '≤' + r.count; c.title = '单局最多出现' + r.count + '次'; button.querySelector('.name small').textContent = E.campName(board, r.camp); });
}

/* ---------- 事件 ---------- */
document.addEventListener('click', e => {
  const el = e.target.closest('button'); if (!el) return;
  const d = el.dataset;
  try {
    if (d.stepFor) {
      const input = document.getElementById(d.stepFor); if (!input) return;
      const min = Number(input.min || 0), max = Number(input.max || 100000), cur = Number.isFinite(input.valueAsNumber) ? input.valueAsNumber : min, next = Math.max(min, Math.min(max, cur + Number(d.delta)));
      if (next === cur) return;
      input.value = next; input.dispatchEvent(new Event('input', {bubbles: true})); input.dispatchEvent(new Event('change', {bubbles: true}));
      return;
    }
    if (d.tab) { go(d.tab); return; }
    if (d.issueIndex!==undefined) { const issue=checkReport[Number(d.issueIndex)];if(issue)navigateTo(issueDestination(issue,board),issue);return; }
    if (d.issueRoom!==undefined) { const issue=checkReport[Number(d.issueRoom)];if(issue){const reports=E.campRule(board,issue.camp).events.some(e=>e.type==='reports');navigateTo({tab:'room',field:reports&&!board.room.allow_report_dead?'allow_report_dead':'meeting_amount'},issue);}return; }
    if (d.confirmRemoveRole) {closeModal();removeCandidate(d.confirmRemoveRole);return;}
    if (d.totalPreset || d.totalDelta) { board.room.total = Math.max(E.ROOM_LIMITS.min, Math.min(E.ROOM_LIMITS.max, d.totalPreset ? Number(d.totalPreset) : board.room.total + Number(d.totalDelta))); mark(); renderInPlace(); return; }
    if (d.ruleCamp) { ruleCamp = Number(d.ruleCamp); render(); return; }
    if (d.openCamp) { openCamp(d.openCamp); return; }
    if (d.issueFaction) { navigateTo({tab:'factions',camp:Number(d.issueFaction),kind:'candidates'});return; }
    if (d.goalJoin) { activeCampRule().join = d.goalJoin; mark(); renderInPlace(); return; }
    if (d.addEvent) { E.addCampEvent(board, ruleCamp, d.addEvent); mark(); renderInPlace(); updateEventPicker(); toast('已添加「' + E.eventCatalog[d.addEvent].name + '」'); return; }
    if (d.removeEvent) { E.removeCampEvent(board, ruleCamp, d.removeEvent); mark(); renderInPlace(); return; }
    if (d.toggleRosterCamp !== undefined) { toggleRosterCamp(Number(d.toggleRosterCamp)); return; }
    if (d.toggleRosterAll !== undefined) { toggleRosterGroups(); return; }
    if (d.selectRole) { selected = d.selectRole; revealRosterRole(role()); paramSkill = 0; renderInPlace(); $('.role-hero')?.scrollIntoView({block: 'nearest'}); return; }
    if (d.countStep) { const c = d.countStep; board.room.counts[c] = Math.max(0, Math.min(E.ROOM_LIMITS.max, board.room.counts[c] + Number(d.delta))); mark(); renderInPlace(); return; }
    if (d.addCareer) {
      const c = E.careers.get(Number(d.addCareer));
      if (!c || !E.classicCareerIds.has(c.id) || (careerLockedCamp !== null && c.camp !== careerLockedCamp)) throw Error('请选择当前阵营的已有职业');
      if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('候选池最多300个角色条目');
      const r = E.addCareer(board,c.id); selected = r.uid; rosterSearch=''; revealRosterRole(r); paramSkill = 0; mark(); renderInPlace(); refreshPickerList('#career-list', careerItems(), 'data-add-career'); toast('已添加「' + c.name + '」'); return;
    }
    if (d.careerCamp) { careerCamp = d.careerCamp; $$('[data-career-camp]').forEach(b => { b.classList.toggle('selected', b.dataset.careerCamp === careerCamp); b.setAttribute('aria-pressed', b.dataset.careerCamp === careerCamp); }); $('#career-list').innerHTML = careerItems(); return; }
    if (d.skillModule) { selectSkillModule(d.skillModule); return; }
    if (d.resetNeutralCount) { const r=board.roles.find(r=>r.uid===d.resetNeutralCount); if(r){E.setRoleCount(r,1);mark();renderInPlace();roleOptions();toast('已改为每局最多1人');}return; }
    if (d.removeCandidate) { removeCandidate(d.removeCandidate); return; }
    if (d.addSkill) {
      const r = role(), id = +d.addSkill, before = new Set(E.allIds(r)); E.addSkill(r, id, slotChoice);
      const added = E.allIds(r).filter(x => !before.has(x)); paramSkill = 0; mark(); renderInPlace(); updateSkillPicker();
      toast('已添加 '+E.playerSkill(id).name); return;
    }
    if (d.removeSkill) { E.removeSkill(role(), +d.removeSkill, d.slot); mark(); renderInPlace(); return; }
    if (d.param) { skillParameters(d.param); return; }
    if (d.locate) {navigateTo({tab:'roles',uid:d.locate,kind:'skills'});return;}
    if (d.loadSave !== undefined) { replaceBoard(readSaves()[+d.loadSave].board, true); return; }
    if (d.deleteSave !== undefined) { const saves = readSaves(); saves.splice(+d.deleteSave, 1); localStorage.setItem(STORE, JSON.stringify(saves)); loadModal(); return; }
    if (d.editRole) {navigateTo({tab:'roles',uid:d.editRole});return;}
    if (d.newRoleCamp) { customRoleModal(Number(d.newRoleCamp)); return; }
    if (d.addOriginalCamp) { addRoleModal(Number(d.addOriginalCamp)); return; }
    if (d.deleteFaction) { const id = Number(d.deleteFaction); E.removeFaction(board, id); if (ruleCamp === id) ruleCamp = 1; mark(); renderInPlace(); toast('已删除空阵营'); return; }
    const action = d.action;
    if (!action) return;
    if (action === 'reset-page') pageResetModal();
    else if (action === 'reset-all') resetAllModal();
    else if (action === 'confirm-global-reset') performGlobalReset();
    else if (action === 'back-review') go('review');
    else if (action === 'confirm-page-reset') performPageReset();
    else if (action === 'undo-page-reset') undoPageReset();
    else if (action === 'next') { if (tab === 'review') exportModal(); else go(STEPS[STEPS.indexOf(tab) + 1]); }
    else if (action === 'prev') go(STEPS[Math.max(0, STEPS.indexOf(tab) - 1)]);
    else if (action === 'choose-skills') skillPicker();
    else if (action === 'role-options') roleOptions();
    else if (action === 'file-menu') fileMenu();
    else if (action === 'how-to') howTo();
    else if (action === 'to-wins') openCamp(1);
    else if (action === 'to-roles') go('roles');
    else if (action === 'to-factions') go('factions');
    else if (action === 'to-draw') go('review');
    else if (action === 'choose-event') eventPicker();
    else if (action === 'view-original-neutrals') originalNeutralModal();
    else if (action === 'add-role') addRoleModal();
    else if (action === 'new-custom-role' || action === 'new-custom-neutral') customRoleModal();
    else if (action === 'add-faction') { const f = E.addFaction(board); mark(); render(); const input = $(`[data-faction-name="${f.id}"]`); if (input) { input.closest('.faction-card')?.scrollIntoView({block: 'center'}); input.focus(); input.select(); } toast('已创建' + f.name + '，请分配人数与角色'); }
    else if (action === 'clear-custom-skills') pageResetModal();
    else if (action === 'role-art') roleArtModal();
    else if (action === 'close-modal') closeModal();
    else if (action === 'save') save();
    else if (action === 'load') loadModal();
    else if (action === 'recover') { const b = JSON.parse(localStorage.getItem(AUTOSAVE) || 'null'); if (!b) throw Error('暂无自动暂存'); replaceBoard(b, true); }
    else if (action === 'recover-previous') { const b = JSON.parse(localStorage.getItem(STORE + '-recovery') || 'null'); if (!b) throw Error('暂无替换备份'); replaceBoard(b, true); }
    else if (action === 'export') exportModal();
    else if (action === 'download') download();
    else if (action === 'import') { closeModal(); $('#file-import').click(); }
    else if (action === 'draw-pool') { try { drawResult = E.drawPool(board); drawError = ''; scenario = null; simulationRun = false; justDrew = true; } catch (error) { drawResult = null; drawError = error.message; } renderInPlace(); }
    else if (action === 'pool-example') modal(modalHead('载入随机角色池示例') + '<p style="color:var(--text-2)">载入鹅30种、鸭20种、中立8种候选，本局仍为6／2／2共10人。当前草稿将自动备份。</p><div class="modal-actions"><button class="btn btn-ghost" data-action="close-modal">取消</button><button class="btn btn-gold" data-action="confirm-pool-example">载入示例</button></div>', true);
    else if (action === 'confirm-pool-example') replaceBoard(E.poolExample());
    else if (action === 'remove-role') deleteRoleModal();
    else if (action === 'restore-role') pageResetModal();
    else if (action === 'close-params') { paramSkill = 0; closeModal(); renderInPlace(); }
    else if (action === 'reset-params') { E.resetSkillParameters(role(),paramSkill); mark(); renderInPlace(); skillParameters(paramSkill); }
    else if (action === 'simulate') { simulationRun = true; showResult(); }
    else if (action === 'recheck') { renderInPlace(); toast('已重新检查'); }
  } catch (err) { toast(err.message); }
});
document.addEventListener('toggle', e => {
  const t = e.target; if (!t.isConnected || !t.classList) return;
  if (t.classList.contains('room-more')) roomMoreOpen = t.open;
  else if (t.classList.contains('simple-sim')) simOpen = t.open;
  else if (t.classList.contains('faction-members')) membersOpen[t.dataset.members] = t.open;
}, true);
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'roster-search') { rosterSearch = t.value; rosterSearchCollapsed={}; refreshRoster(); return; }
  if (t.id === 'skill-search') { skillSearch = t.value; $('#library-list').innerHTML = libraryItems(role()); return; }
  if (t.id === 'career-search') { careerSearch = t.value; $('#career-list').innerHTML = careerItems(); return; }
  if (t.id === 'new-role-name') { $('#custom-role-error').hidden = true; return; }
  if (t.dataset.roomRange) { const k = t.dataset.roomRange; board.room[k] = Number(t.value); setPct(t); const num = $(`input[type=number][data-room="${k}"]`); if (num) num.value = t.value; scheduleMark(); return; }
  // 合法数值边输入边保存，不替换正在编辑的输入框。
  try {
    if (t.dataset.room && t.type !== 'number') return;
    if (t.dataset.simProgress) { if (Number.isInteger(t.valueAsNumber) && t.valueAsNumber >= 0 && t.valueAsNumber <= 999) { scenario.progress[t.dataset.simProgress] = t.valueAsNumber; simulationRun = false; $('#sim-result').innerHTML = ''; } return; }
    if (t.type === 'number' && (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < Number(t.min || 0) || t.valueAsNumber > Number(t.max || 100000))) return;
    if (t.dataset.count) board.room.counts[t.dataset.count] = t.valueAsNumber;
    else if (t.dataset.room) board.room[t.dataset.room] = t.valueAsNumber;
    else if (t.dataset.roleField === 'name' && t.value.trim()) role().name = t.value.trim();
    else if (t.dataset.roleField === 'count') E.setRoleCount(role(),t.valueAsNumber);
    else if (t.dataset.factionName && t.value.trim()) E.renameFaction(board, Number(t.dataset.factionName), t.value);
    else if (t.dataset.eventValue) activeCampRule().events.find(x => x.id === t.dataset.eventValue).value = t.valueAsNumber;
    else if (t.dataset.eventWeight) activeCampRule().events.find(x => x.id === t.dataset.eventWeight).weight = t.valueAsNumber;
    else if (t.dataset.skillParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillParam] = t.valueAsNumber; }
    else if (t.dataset.stageParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill].stages ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage] ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam] = t.valueAsNumber; }
    else return;
    mark(); refreshInline();
  } catch { /* 失焦时的 change 事件会给出最终校验提示。 */ }
});
document.addEventListener('change', e => {
  const t = e.target;
  try {
    if (t.id === 'file-import') { importFile(t.files[0]); return; }
    if (t.id === 'slot-choice') { slotChoice = t.value; return; }
    if (t.hasAttribute('data-skill-module-select')) { selectSkillModule(t.value); return; }
    if (t.dataset.roomRange) { scheduleMark(); return; }
    if (t.id === 'sim-group') { simGroup = t.value; scenario = newScenario(); simulationRun = false; renderSimulation(); return; }
    if (t.dataset.simProgress) { if (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < 0 || t.valueAsNumber > 999) throw Error('请输入0–999的整数'); scenario.progress[t.dataset.simProgress] = t.valueAsNumber; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.hasAttribute('data-sim-original')) { scenario.originalWinner = t.value; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.hasAttribute('data-sim-alive')) { scenario.eligibleAlive = t.checked; simulationRun = false; $('#sim-result').innerHTML = ''; return; }
    if (t.dataset.roomToggle) { const k = t.dataset.roomToggle; board.room[k] = t.checked; const st = t.closest('.toggle-field')?.querySelector('.switch-state'); if (st) st.textContent = t.checked ? t.dataset.on : t.dataset.off; mark(); return; }
    if (t.dataset.factionName) { E.renameFaction(board, Number(t.dataset.factionName), t.value); mark(); renderInPlace(); return; }
    if (t.dataset.assignFaction) { if (!t.value) return; const r = board.roles.find(r => r.uid === t.value); E.setRoleCamp(board, r, Number(t.dataset.assignFaction)); mark(); renderInPlace(); return; }
    if (t.dataset.baseVictory) { E.setBaseVictory(board, Number(t.dataset.baseVictory), t.value || null); mark(); renderInPlace(); return; }
    if (t.type === 'number' && (!Number.isInteger(t.valueAsNumber) || t.valueAsNumber < Number(t.min || 0) || t.valueAsNumber > Number(t.max || 100000))) {
      if ($('#modal').open && $('#modal').dataset.kind === 'parameters') skillParameters(paramSkill);
      else if ($('#modal').open && $('#modal').dataset.kind === 'role-options') roleOptions();
      else renderInPlace();
      toast('请输入' + (t.min || 0) + '–' + (t.max || 100000) + '的整数'); return;
    }
    if (t.dataset.eventWeight) { activeCampRule().events.find(x => x.id === t.dataset.eventWeight).weight = t.valueAsNumber; mark(); renderInPlace(); return; }
    if (t.dataset.eventValue) { activeCampRule().events.find(x => x.id === t.dataset.eventValue).value = t.valueAsNumber; mark(); return; }
    if (t.id === 'board-name') { if (!t.value.trim()) { toast('板子名称不能为空'); t.value = board.boardName; header(); return; } board.boardName = t.value.trim(); }
    else if (t.hasAttribute('data-description')) board.description = t.value;
    else if (t.dataset.room) {
      const key = t.dataset.room, d = E.ROOM_FIELDS[key];
      if (t.value === 'custom') { const input = t.closest('.room-option')?.querySelector('input[type=number]'); if (input) { input.hidden = false; input.focus(); input.select(); } return; }
      board.room[key] = d?.type === 'boolean' ? t.value === 'true' : Number(t.value);
    }
    else if (t.dataset.skillLimit) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillLimit] = Number(t.value); }
    else if (t.dataset.count) board.room.counts[t.dataset.count] = t.valueAsNumber;
    else if (t.dataset.roleField) {
      const k = t.dataset.roleField;
      if (k === 'name' && !t.value.trim()) throw Error('角色名不能为空');
      if (k === 'camp') { E.setRoleCamp(board, role(), Number(t.value)); toast('已采用' + E.campName(board, role().camp) + '目标'); }
      else if(k==='count') E.setRoleCount(role(),Number(t.value));
      else role()[k] = t.type === 'number' ? Number(t.value) : t.value.trim();
    }
    else if (t.dataset.skillParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill][t.dataset.skillParam] = t.valueAsNumber; }
    else if (t.dataset.stageParam) { const r = role(); r.skillOverrides[paramSkill] ||= {}; r.skillOverrides[paramSkill].stages ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage] ||= {}; r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam] = t.valueAsNumber; }
    else return;
    mark();
    if (t.dataset.count || t.dataset.room === 'total' || (t.dataset.room && t.tagName === 'SELECT')) renderInPlace();
    else if (t.type === 'number' || t.type === 'text' || t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && !t.type)) refreshInline();
    else renderInPlace();
  } catch (err) { toast(err.message); if (t.dataset.factionName || t.dataset.assignFaction || t.dataset.baseVictory) renderInPlace(); }
});
$('#modal').addEventListener('close', () => { if ($('#modal').dataset.kind === 'parameters' && tab === 'roles') renderInPlace(); });

/* ---------- 启动 ---------- */
let hadDraft = false;
try {
  const saved = localStorage.getItem(AUTOSAVE);
  if (saved) {
    hadDraft = true;
    const raw = JSON.parse(saved); board = E.validateShape(raw);
    if (raw.schema !== E.SCHEMA) { localStorage.setItem(STORE + '-pre-v027', saved); setTimeout(() => toast('旧草稿已恢复'), 500); }
    selected = board.roles[0]?.uid || ''; $('#save-state').textContent = '已恢复草稿';
  }
} catch {}
render();
if (window.GgdBoot) window.GgdBoot.ready();
try { if (!hadDraft && !localStorage.getItem(GUIDE_SEEN)) { localStorage.setItem(GUIDE_SEEN, '1'); setTimeout(howTo, 350); } } catch {}
