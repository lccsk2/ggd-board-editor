'use strict';
const E=window.EditorEngine,D=E.D,$=s=>document.querySelector(s),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const STORE='ggd-board-workshop-v1',AUTOSAVE=STORE+'-autosave';
let board=E.defaultBoard(),tab='room',selected=board.roles[1].uid,paramSkill=0,dirty=false,toastTimer;
let rosterSearch='',skillSearch='',skillModule='all',slotChoice='auto',careerSearch='',careerCamp='all',careerLockedCamp=null,customRoleCamp=null;
let scenario=null,simRole='',simulationRun=false,checkReport=[];
let drawResult=null,drawError='',ruleCamp=1,simGroup='',roomMoreOpen=false,lastPageReset=null;
function activeCampRule(){return E.campRule(board,ruleCamp);}
function openCamp(camp){ruleCamp=Number(camp);tab='wins';render();$('#content').scrollTop=0;}
function renderInPlace(){
 const x=window.scrollX,y=window.scrollY,top=$('#content').scrollTop;
 const cards=[...document.querySelectorAll('[data-faction-card]')].map(n=>({id:n.dataset.factionCard,open:n.querySelector('.faction-members').open,top:n.querySelector('.faction-role-chips').scrollTop}));
 render();
 for(const c of cards){const n=document.querySelector(`[data-faction-card="${c.id}"]`);if(n){n.querySelector('.faction-members').open=c.open;n.querySelector('.faction-role-chips').scrollTop=c.top;}}
 $('#content').scrollTop=top;window.scrollTo(x,y);
}
function removeCandidate(uid){
 const index=board.roles.findIndex(r=>r.uid===uid);if(index<0)return;
 const camp=board.roles[index].camp,focusWasRemove=document.activeElement?.dataset.removeCandidate===uid;
 E.removeRole(board,uid);if(selected===uid){selected=board.roles[Math.min(index,board.roles.length-1)]?.uid||'';paramSkill=0;}
 mark();renderInPlace();
 if(focusWasRemove){const card=document.querySelector(`[data-faction-card="${camp}"]`);card?.querySelector('[data-remove-candidate], [data-add-original-camp], [data-new-role-camp]')?.focus({preventScroll:true});}
 toast('已移出候选池');
}
const clone=E.clone;
const ART=window.EDITOR_ART||{roles:{},skills:{},stages:{},camps:{}};
function artImage(a,cls='',alt='',lazy=true){return a?`<img class="${cls}" src="${esc(a.src)}" data-art-source="${esc(a.src)}" width="${a.width}" height="${a.height}" alt="${esc(alt)}" ${lazy?'loading="lazy"':''} decoding="async" data-art-image>`:'';}
const CUSTOM_ICON={src:'assets/custom-role.png',width:512,height:512};
function roleAvatar(id,camp=0){const a=id===null?{icon:CUSTOM_ICON}:ART.roles[id];return `<span class="avatar ${a?.icon?'has-art':''}">${a?.icon?artImage(a.icon,'role-icon','',true):esc(E.camps[camp]?.slice(0,1)||'?')}</span>`;}
function skillIcon(id,cls=''){const s=E.skills.get(Number(id)),a=ART.skills[id]?.icon;return a?artImage(a,'skill-icon '+cls,'',true):`<span class="skill-icon skill-text ${cls}" aria-label="${s?.type===1?'被动技能':'暂无图标'}">${s?.type===1?'被':'技'}</span>`;}
function roleVisual(r){if(E.isCustom(r))return `<aside class="role-visual custom-role-visual"><div class="portrait-frame icon-portrait">${artImage(CUSTOM_ICON,'portrait-role-icon',r.name+'自创角色图标',false)}</div><div class="portrait-caption"><strong data-custom-name>${esc(r.name)}</strong></div></aside>`;const c=E.careers.get(r.templateCareerId),a=ART.roles[c.id];return `<aside class="role-visual"><div class="portrait-frame ${a?.portrait?'':'icon-portrait'}">${a?.portrait?artImage(a.portrait,'role-portrait',c.name+'职业立绘',false):artImage(a?.icon,'portrait-role-icon',c.name+'职业图标',false)}</div><div class="portrait-caption"><strong>${esc(c.name)}</strong><p>${esc(c.des)}</p></div></aside>`;}
function roleArtModal(){const r=role();if(!r)return;const c=E.isCustom(r)?{name:r.name}:E.careers.get(r.templateCareerId),a=E.isCustom(r)?{icon:CUSTOM_ICON}:ART.roles[c.id];modal(modalHead(c.name+' · 角色与技能素材')+`<div class="art-modal-hero"><div>${artImage(a?.icon,'modal-role-icon',c.name+'职业图标',false)}<p>职业图标</p></div>${a?.portrait?`<div>${artImage(a.portrait,'modal-portrait',c.name+'职业立绘',false)}<p>职业立绘</p></div>`:''}</div><h3 class="section-label">当前装备的技能</h3><div class="art-skill-grid">${E.equippedSkills(r,{type:'active'}).map(s=>`<article><div class="art-skill-heading">${skillIcon(s.id)}<strong>${esc(s.name)}</strong></div><p>${esc(s.des)}</p></article>`).join('')||'<p class="muted">还未装备技能</p>'}</div><div class="modal-actions"><button class="primary" data-action="close-modal">继续编辑</button></div>`);}
document.addEventListener('error',event=>{const img=event.target;if(!(img instanceof HTMLImageElement)||!img.hasAttribute('data-art-image')||!img.isConnected)return;const retries=Number(img.dataset.artRetries||0);if(retries<2){img.dataset.artRetries=String(retries+1);setTimeout(()=>{if(!img.isConnected)return;const source=new URL(img.dataset.artSource,document.baseURI);if(source.protocol==='http:'||source.protocol==='https:')source.searchParams.set('artRetry',String(retries+1));img.src=source.href;},400*(retries+1));return;}const hint=document.createElement('span');hint.className='art-unavailable';hint.textContent='图像暂不可用';hint.title=img.alt;img.replaceWith(hint);},true);

function role(){return board.roles.find(x=>x.uid===selected)||board.roles[0];}
function toast(s){if($('#modal').open&&$('#dialog-status'))$('#dialog-status').textContent=s;$('#toast').textContent=s;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3300);}
function mark(){lastPageReset=null;$('.page-reset-feedback')?.remove();E.ensureCampRules(board);scenario=null;simulationRun=false;drawResult=null;drawError='';dirty=true;board.updatedAt=new Date().toISOString();try{localStorage.setItem(AUTOSAVE,JSON.stringify(E.exportDraft(board)));$('#save-state').textContent='已自动保存';}catch{$('#save-state').textContent='未保存 · 请导出备份';}header();}
function header(){
 checkReport=E.validate(board).filter(x=>x.level==='error'||!['ABILITY_COMPAT','SLOT_LAYOUT','SKILL_SLOT','CD_PARAM'].includes(x.code));const errors=checkReport.filter(x=>x.level==='error').length,warnings=checkReport.filter(x=>x.level==='warn').length;
 $('#board-name').value=board.boardName;$('#board-summary').textContent=board.room.total+'人 · '+board.factions.map(f=>f.name.replace(/阵营$/,'')+' '+board.room.counts[f.id]).join(' / ');
 $('#issue-badge').textContent=errors||'';$('#footer-status').textContent=errors?errors+' 项待修正':'人数与已知规则通过'+(warnings?' · '+warnings+' 项提醒':'');
 $('#next-step').textContent=tab==='review'?'导出我的板子':{room:'下一步：分配阵营 →',factions:'下一步：设置胜利 →',wins:'下一步：搭配技能 →',roles:'下一步：预览板子 →'}[tab];
 $('#prev-step').hidden=tab==='room';
 $('#footer-hint').textContent={room:'默认设置已经备好，随时可以下一步。',factions:'候选角色可以多选，按人数随机抽取。',wins:'无需改动原规则，也可以直接下一步。',roles:'不想改技能？保留角色原本的技能即可。',review:'导出文件后，可以分享或再次导入编辑。'}[tab];
 document.body.dataset.step=tab;
 document.querySelectorAll('[data-tab]').forEach(n=>{n.classList.toggle('active',n.dataset.tab===tab);n.setAttribute('aria-current',n.dataset.tab===tab?'step':'false');});
}
function render(){
 header();$('#content').innerHTML=tab==='room'?roomView():tab==='factions'?factionsView():tab==='wins'?winsView():tab==='roles'?rolesView():reviewView();
 if(tab==='review')renderSimulation();
 if(lastPageReset?.tab===tab)$('#content .title-row').insertAdjacentHTML('afterend','<div class="page-reset-feedback" role="status"><span>'+esc(lastPageReset.label)+'已重置</span><button class="quiet small" data-action="undo-page-reset">撤销重置</button></div>');
 if(board.room.total>E.ROOM_LIMITS.max)$('#content').insertAdjacentHTML('afterbegin',`<div class="note warning" role="alert">此草稿为 ${board.room.total} 人，房间最多支持 ${E.ROOM_LIMITS.max} 人，请调整人数及阵营分配。</div>`);
 if(board.roles.some(r=>r.camp===3&&E.isCustom(r)))$('#content').insertAdjacentHTML('afterbegin','<div class="note warning" role="alert">旧草稿中的空白中立角色已保留，请到“搭配技能”为其选择鹅、鸭或新阵营。</div>');
}
const title=(n,p,right='')=>`<div class="title-row"><div><h2>${n}</h2><p>${p}</p></div>${right}<button class="page-reset-button" data-action="reset-page" ${tab==='roles'&&!role()?'disabled':''}><span aria-hidden="true">↺</span> ${tab==='roles'?'重置当前技能':tab==='review'?'清空预览':'重置本页'}</button></div>`;
const options=(obj,val)=>Object.entries(obj).map(([k,v])=>`<option value="${esc(k)}" ${String(val)===String(k)?'selected':''}>${esc(v)}</option>`).join('');
const campOptions=v=>options(E.camps,v);
const number=(label,value,data,min=0,max=100000)=>`<label>${label}<input type="number" min="${min}" max="${max}" value="${value}" ${data}></label>`;
function roomOption(key){
 const d=E.ROOM_FIELDS[key],value=board.room[key];
 if(d.type==='boolean')return `<label class="room-option">${d.label}<select data-room="${key}" aria-label="${d.label}">${options({'true':'允许','false':'禁止'},value)}</select></label>`;
 const range=D.custom[0][key],values=[...new Set([...d.choices,value])].sort((a,b)=>a-b),custom=key!=='meeting_amount';
 return `<label class="room-option">${d.label}<select data-room="${key}" aria-label="${d.label}">${options(Object.fromEntries(values.map(v=>[v,v===0?'关闭':v+' '+d.unit])),value)}${custom?'<option value="custom">自定义…</option>':''}</select>${custom?`<input hidden type="number" data-room="${key}" aria-label="自定义${d.label}" min="${range[0]}" max="${range[1]}" value="${value}">`:''}</label>`;
}
function roomView(){return title('这局，想怎么玩？','先选人数，其他设置可以先用默认。')+`<div class="room-layout player-room"><section class="room-settings room-people"><div class="people-heading"><div><span class="eyebrow-dark">一起开一局</span><h3>房间人数</h3></div>${artImage(CUSTOM_ICON,'workshop-mascot','',false)}</div><div class="people-counter"><button data-total-delta="-1" aria-label="减少房间人数" ${board.room.total<=E.ROOM_LIMITS.min?'disabled':''}>−</button><label><span class="sr-only">房间人数</span><input type="number" aria-label="房间人数" min="2" max="${E.ROOM_LIMITS.max}" value="${board.room.total}" data-room="total"><span>人</span></label><button data-total-delta="1" aria-label="增加房间人数" ${board.room.total>=E.ROOM_LIMITS.max?'disabled':''}>＋</button></div><div class="people-presets" aria-label="常用人数">${[6,8,10,12,E.ROOM_LIMITS.max].map(n=>`<button data-total-preset="${n}" class="${board.room.total===n?'selected':''}" aria-pressed="${board.room.total===n}">${n} 人</button>`).join('')}</div><div class="room-basics"><h3>对局节奏</h3><div class="form-grid">${number('击倒冷却（秒）',board.room.hit_cd,'data-room="hit_cd"',...D.custom[0].hit_cd)}${number('房间总任务数',board.room.task,'data-room="task"',...D.custom[0].task)}</div></div><details class="board-description"><summary>写点玩法介绍 <span>选填</span></summary><label class="board-intro"><span class="sr-only">板子介绍</span><textarea maxlength="300" data-description placeholder="例如：侦探与炸弹的欢乐对决">${esc(board.description)}</textarea></label></details></section><section class="room-settings meeting-settings"><div class="panel-heading"><div><h3>开会怎么聊？</h3><p>决定讨论、投票和拍铃的节奏。</p></div><span class="soft-tag">会议设置</span></div><div class="meeting-fields">${['meeting_amount','discuss_cd','vote_cd','first_bell_cd','meeting_cd'].map(roomOption).join('')}</div><p class="setting-hint">拍铃次数全局共用，每人最多一次；报告鸡腿不占次数。</p><details class="room-more" ${roomMoreOpen?'open':''}><summary>更多会议设置</summary><div class="form-grid">${['meeting_hit_cd','meeting_destroy_cd','allow_speak','discuss_chat','discuss_emojis','allow_report_dead'].map(roomOption).join('')}<label class="room-option">放逐后身份<select data-room="hide" aria-label="放逐后身份">${options({'true':'隐藏','false':'公开'},board.room.hide)}</select></label></div></details></section></div>`;}
function rosterItems(){const list=board.roles.filter(r=>!rosterSearch||(r.name+E.campName(board,r.camp)).includes(rosterSearch));return list.map(r=>`<button class="camp-${r.camp} ${role()?.uid===r.uid?'selected':''}" data-select-role="${r.uid}" aria-pressed="${role()?.uid===r.uid}">${roleAvatar(r.templateCareerId,r.camp)}<span class="name"><span>${esc(r.name)}</span><small>${esc(E.campName(board,r.camp))}</small></span><span class="copies" title="单局最多出现${r.count}次">≤${r.count}</span></button>`).join('')||'<p class="empty">没有找到角色</p>';}
function rosterView(){return `<aside class="roster"><div class="roster-heading"><h3>选一个角色</h3><span>${board.roles.length}</span></div><input id="roster-search" aria-label="搜索候选角色" placeholder="搜索角色或阵营" value="${esc(rosterSearch)}"><div class="roster-list">${rosterItems()}</div><div class="roster-bottom"><button class="roster-add" data-action="add-role">＋ 添加已有职业</button><button class="roster-add custom-role-add" data-action="new-custom-role">${artImage(CUSTOM_ICON,'custom-entry-icon','',false)}<span>创建空白角色</span></button></div></aside>`;}
function roleTop(r){const custom=E.isCustom(r),f=E.faction(board,r.camp);return `<div class="role-top"><div class="role-identity camp-${r.camp<=3?r.camp:'custom'}">${roleAvatar(r.templateCareerId,r.camp)}<div><input aria-label="角色名称" maxlength="20" value="${esc(r.name)}" data-role-field="name"><p>${esc(f.name)}${custom?' · 自创角色':''}</p></div></div><button class="small" data-action="role-options">角色设置</button></div><div class="role-rule-link"><span>${custom?'给你的新角色搭配技能。':esc(E.careers.get(r.templateCareerId).des)}</span><button class="quiet small" data-open-camp="${r.camp}">查看胜利条件 →</button></div>`;}
function roleOptions(){const r=role(),custom=E.isCustom(r);modal(modalHead('角色设置')+`<div class="role-options-form">${custom?`<label>所属阵营<select data-role-field="camp" aria-label="归属阵营">${r.camp===3?'<option value="3" disabled selected>请选择其他阵营</option>':''}${options(Object.fromEntries(board.factions.filter(f=>f.id!==3).map(f=>[f.id,f.name])),r.camp)}</select></label>`:`<p class="locked-role-camp">${esc(E.campName(board,r.camp))} · 原阵营固定</p>`}${number('本局最多出现几人',r.count,'data-role-field="count"',1,E.ROOM_LIMITS.max)}<p class="setting-hint">这是此角色的出场上限，不会增加阵营人数。</p></div><div class="role-maintenance">${custom?'<button data-action="clear-custom-skills">清空技能</button>':'<button data-action="restore-role">恢复原技能</button>'}<button class="danger" data-action="remove-role">移除角色</button></div><div class="modal-actions"><button class="primary" data-action="close-modal">完成</button></div>`,true,'role-options');}
function rolesView(){const r=role();if(!r)return title('给角色搭配技能','先选角色，再选择想给他的能力。')+`<div class="empty-stage">${artImage(CUSTOM_ICON,'workshop-mascot','',false)}<h3>先添加一位角色</h3><p>已有职业可以直接使用，自创角色从空白开始。</p><div class="inline-actions"><button class="primary" data-action="add-role">添加已有职业</button><button data-action="new-custom-role">创建空白角色</button></div></div>`;const active=E.equippedSkills(r,{type:'active'}),passive=E.equippedSkills(r,{type:'passive'});return title('给角色搭配技能','选中角色，点击“添加技能”。已有职业也可以换一种玩法。')+`<div class="roles-layout">${rosterView()}<section class="role-workspace">${roleTop(r)}${E.phaseOneIssues(r).length?'<div class="note warning" role="alert">这个角色有暂不可用的技能，请移除标记项。</div>':''}<div class="equipped-heading"><div><h3>我的技能 <span>${active.length}</span></h3><p>点击“调整”可设置冷却和使用次数。</p></div><button class="primary" data-action="choose-skills">＋ 添加技能</button></div><div class="skill-scroll equipped-grid">${active.map(x=>skillCard(r,x.id,x.slot,x.name)).join('')||'<div class="empty">还没有技能，先为角色挑一个吧。</div>'}<button class="add-skill-tile" data-action="choose-skills"><span>＋</span>添加技能</button></div>${passive.length?`<details class="native-effects"><summary>角色自带效果 <span>${passive.length} 项</span></summary><div class="equipped-grid">${passive.map(x=>skillCard(r,x.id,x.slot,x.name)).join('')}</div></details>`:''}</section></div>`;}
function skillPicker(){const r=role(),list=E.librarySkills({type:'active'});modal(modalHead('为「'+esc(r.name)+'」添加技能')+`<div class="skill-picker-toolbar"><input aria-label="搜索技能" placeholder="搜索想要的能力" value="${esc(skillSearch)}" id="skill-search"><select aria-label="技能模块" id="skill-module">${options({all:'全部类型',...Object.fromEntries([...new Set(list.map(s=>E.skillScope(s.id).module))].map(m=>[m,m]))},skillModule)}</select></div><div class="picker-summary"><span>技能库 · ${list.length} 项主动技能</span><span id="skill-picker-status" role="status">点击添加，可连续选择多个</span></div><div class="library-list skill-picker-list" id="library-list">${libraryItems(r)}</div><div class="modal-actions"><button class="primary" data-action="close-modal">完成搭配</button></div>`,false,'skills');$('#skill-search').focus();}
function updateSkillPicker(){if($('#modal').dataset.kind!=='skills'||!$('#modal').open)return;const list=$('#library-list'),top=list.scrollTop;list.innerHTML=libraryItems(role());list.scrollTop=top;$('#skill-picker-status').textContent='已装备 '+E.equippedSkills(role(),{type:'active'}).length+' 项主动技能';}
function skillParameters(id){paramSkill=E.playerSkill(id)?.id||0;const r=role();if(!E.allIds(r).includes(paramSkill)){toast('请移除不完整的技能后重新添加');return;}const s=E.playerSkill(paramSkill);modal(modalHead('调整「'+esc(s.name)+'」')+parameterView(r)+'<div class="modal-actions"><button class="primary" data-action="close-modal">完成</button></div>',false,'parameters');}
function skillCard(r,id,slot,name){const s=E.playerSkill(id),info=E.skillScope(s.id),outside=!info?.inScope,entry=E.equippedSkills(r).find(x=>x.id===s.id),incomplete=!entry?.complete||entry?.hasRuntimeAction;return `<article class="skill-card ${paramSkill===s.id?'active':''}${outside||incomplete?' skill-out-of-scope':''}"><div class="skill-title">${skillIcon(s.id)}<button class="skill-name" data-param="${s.id}" ${incomplete?'disabled':''}>${esc(s.name)}</button><button data-remove-skill="${s.id}" data-slot="${slot}" aria-label="移除${esc(s.name)}技能">移除</button></div><p>${esc(s.des)}</p>${outside?'<p class="skill-boundary" role="alert">当前不可用，请移除。</p>':incomplete?'<p class="skill-boundary" role="alert">技能配置不完整，请移除后重新添加。</p>':''}<div class="skill-meta">${s.type===1?'被动技能':'主动技能'}${s.skill_kind===0?' · 会议中使用':''}<button class="quiet small" data-param="${s.id}" ${incomplete?'disabled':''}>调整</button></div></article>`;}
function libraryItems(r){const equipped=E.equippedSkills(r).map(s=>s.id),list=E.librarySkills({search:skillSearch,type:'active',module:skillModule});return list.map(s=>{const compat=E.skillCompatibility(s.id,r),isEquipped=equipped.includes(s.id),blocked=compat.level==='error';return `<article class="library-item${blocked?' skill-blocked':''}" data-library-skill="${s.id}"><div class="item-title">${skillIcon(s.id)}<strong>${esc(s.name)}</strong><button data-add-skill="${s.id}" ${isEquipped||blocked?'disabled':''}>${isEquipped?'已装备':blocked?'不可添加':'＋ 添加'}</button></div><p>${esc(s.des||'暂无技能说明')}</p>${blocked?`<small class="skill-boundary">${esc(['SKILL_STATE_DEADLOCK','SKILL_FAMILY_CONFLICT'].includes(compat.code)?'与已装备技能冲突':compat.code==='SKILL_CONTEXT_ONLY'?'需在对局中触发':'仅限原职业使用')}</small>`:''}</article>`;}).join('')||'<div class="empty">没有找到技能</div>';}
function parameterView(r){if(!paramSkill||!E.allIds(r).includes(paramSkill))return '';const s=E.effective(r,paramSkill),st=s.stages[0],uses=(label,key)=>`<label>${label}<select data-skill-limit="${key}">${options(Object.fromEntries([...new Set([-1,0,1,2,3,5,10,s[key]])].sort((a,b)=>a-b).map(v=>[v,v===-1?'不限':v===0?'禁止使用':v+' 次'])),s[key])}</select></label>`;return `<div class="parameter-panel"><div class="inline-actions"><p class="muted">调整会自动保存。</p><button class="quiet small" data-action="reset-params">恢复默认</button></div><div class="form-grid">${number('首次可用等待（秒）',s.get_cd,'data-skill-param="get_cd"',0)}${uses('整局使用次数','use_time')}${s.skill_kind===0?uses('每次会议使用次数','meeting_use_time'):''}${st?number('会议后等待（秒）',st.meeting_cd,`data-stage="${st.id}" data-stage-param="meeting_cd"`):''}${st?.cd_type<=1?number(st.cd_type===0?'使用冷却（秒）':'击倒冷却倍率（%）',st.cd_type_param_1,`data-stage="${st.id}" data-stage-param="cd_type_param_1"`):''}</div></div>`;}
function originalConditions(){const neutrals=E.D.eligibleCareerIds.map(id=>E.careers.get(id)).filter(c=>c.camp===3);return `<section class="fixed-baselines" aria-label="原胜利条件，只读"><div class="baseline-title"><h3>原胜利条件</h3><span>固定</span></div><div class="baseline-grid"><article class="baseline-card camp-1"><span class="baseline-symbol">鹅</span><div><h4>鹅阵营</h4><p data-original-condition="1">${esc(E.careers.get(1).win_condition_des)}</p></div></article><article class="baseline-card camp-2"><span class="baseline-symbol">鸭</span><div><h4>鸭阵营</h4><p data-original-condition="2">${esc(E.careers.get(101).win_condition_des)}</p></div></article><article class="baseline-card camp-3"><span class="baseline-symbol">独</span><div><h4>中立阵营</h4><p>每个原角色保留自己的胜利条件。</p><button class="quiet small" data-action="view-original-neutrals">查看 ${neutrals.length} 种原条件</button></div></article></div></section>`;}
function originalNeutralModal(){modal(modalHead('中立原胜利条件 · 全部只读')+`<div class="original-condition-list">${E.D.eligibleCareerIds.map(id=>E.careers.get(id)).filter(c=>c.camp===3).map(c=>`<div class="original-rule-row">${roleAvatar(c.id,3)}<div><strong>${esc(c.name)}</strong><p>${esc(c.win_condition_des)}</p></div></div>`).join('')}</div><div class="modal-actions"><button class="primary" data-action="close-modal">知道了</button></div>`);}
function eventText(e){const d=E.eventCatalog[e.type];return `${d.name} · ${e.value}${d.unit}（权重 ${e.weight}）`;}
function campEventCopy(text){if(ruleCamp!==3)return text;return text.replace('队友投中同一人只计一次。','本人对同一目标只计一次。').replace('每个行动回合本阵营最多计一次。','本人每个行动回合最多计一次。').replace('同一场会议本阵营最多计一次。','本人每场会议最多计一次。').replaceAll('一名成员','本人').replace('本人连续参加','本人连续参加').replace('中立只看本人，','').replace('仍存活成员的个人记录，不相加','本人存活时的个人记录，不与其他中立相加').replace('存活成员个人连续记录','本人存活时的连续记录');}
function winsView(){
 if(!E.faction(board,ruleCamp))ruleCamp=1;const g=activeCampRule(),f=E.faction(board,ruleCamp),neutral=ruleCamp===3,custom=f.kind==='custom',preset=E.baseVictory(f.baseVictory);
 return title('怎样才算赢？','原有规则始终生效；也可以给阵营添加优先达成的额外目标。')+originalConditions()+`<section class="extra-goals"><div class="segmented faction-tabs">${board.factions.map(x=>`<button data-rule-camp="${x.id}" class="${x.id===ruleCamp?'selected':''}">${esc(x.name)}</button>`).join('')}</div><div class="goal-scope"><strong>${esc(f.name)}</strong><span>${neutral?'所有中立职业适用，各自完成、各自获胜。':'达成目标，阵营全员获胜。'}</span></div>${custom?`<div class="custom-base-win"><label>基础胜利条件<select aria-label="${esc(f.name)}原有胜利条件" data-base-victory="${f.id}">${options({'':'仅使用额外目标',...Object.fromEntries(E.baseVictoryOptions.map(p=>[p.id,p.name]))},f.baseVictory||'')}</select></label>${preset?`<p>${esc(preset.description)}</p>`:''}</div>`:''}<div class="goals-header"><h3>额外胜利目标 <small>选填</small></h3><span class="muted">${g.events.length} / ${E.MAX_CAMP_EVENTS}</span></div>${g.events.length>1?`<div class="goal-join"><span>获胜方式</span><div class="segmented"><button data-goal-join="any" class="${g.join==='any'?'selected':''}">完成任意一个</button><button data-goal-join="all" class="${g.join==='all'?'selected':''}">全部完成</button></div></div>`:''}<p class="goal-priority-hint">权重越大越优先；同时达成时，同权重可并列。${g.join==='all'&&g.events.length>1?' 全部完成后，整组按最低权重结算。':''}</p><div class="goal-list">${[...g.events].sort((a,b)=>b.weight-a.weight).map((e,i)=>goalCard(e,i,neutral)).join('')||`<div class="goal-empty"><p>${custom&&!preset?'为新阵营选一个获胜目标。':'沿用原有规则，直接下一步也可以。'}</p></div>`}</div><button class="add-goal-button" data-action="choose-event" ${g.events.length>=E.MAX_CAMP_EVENTS?'disabled':''}>＋ 添加胜利目标</button><p class="goal-footnote">${neutral?'达成额外目标时，本人须存活。':'达成额外目标时，阵营须有人存活。'} 额外目标优先于原有规则；未达成的高权重目标不会阻挡其他目标。</p></section>`;
}
function eventPicker(){const g=activeCampRule(),categories=[...new Set(Object.values(E.eventCatalog).map(d=>d.category))];modal(modalHead('选择胜利目标')+`<div class="event-catalog-scroll">${categories.map(category=>`<section class="event-category"><h3>${category}</h3><div class="event-catalog">${Object.entries(E.eventCatalog).filter(([,d])=>d.category===category).map(([type,d])=>`<button class="event-choice" data-add-event="${type}" ${g.events.some(e=>e.type===type)?'disabled':''}><span class="event-choice-title">${esc(d.name)}</span><span>${esc(campEventCopy(d.description))}</span><small>${g.events.some(e=>e.type===type)?'已添加':d.defaultValue+d.unit}</small></button>`).join('')}</div></section>`).join('')}</div><div class="modal-actions"><button data-action="close-modal">取消</button></div>`);}
function drawPanel(){const blocked=checkReport.some(x=>x.level==='error');return `<section id="draw-panel" class="draw-panel"><div class="draw-heading"><div><h3>这一局，谁会出场？</h3><p>${E.campIds(board).map(c=>{const p=E.poolStats(board,c);return esc(E.campName(board,c))+'：'+p.candidates+'种候选 → 抽'+p.seats+'人';}).join('　·　')}</p></div><button class="primary" data-action="draw-pool" ${blocked?'disabled':''}>${drawResult?'重新随机抽取':'随机抽取一桌'}</button></div>${drawError?`<div class="note warning" role="alert">${esc(drawError)}</div>`:drawResult?`<div class="draw-camps">${E.campIds(board).map(c=>`<article class="draw-camp camp-${c}"><h4>${esc(E.campName(board,c))} <span>${drawResult.seats.filter(s=>s.camp===c).length} / ${board.room.counts[c]} 人</span></h4><ol>${drawResult.seats.filter(s=>s.camp===c).map(s=>`<li>${roleAvatar(s.templateCareerId,c)}<div><strong>${esc(s.name)}</strong><small>席位 ${drawResult.seats.indexOf(s)+1}${s.copy>1?' · 同角色第'+s.copy+'份':''}</small></div></li>`).join('')||'<li class="muted">本局不分配席位</li>'}</ol></article>`).join('')}</div><p class="draw-meta">本次抽中 ${drawResult.seats.length} 席，${drawResult.omitted.length} 种候选未出场。</p>`:`<div class="draw-empty">${blocked?'请先修正下方配置问题，再随机抽取。':'角色池已就绪。点击“随机抽取一桌”，按各阵营人数产生本局名单。'}</div>`}<small>修改设置后，需要重新抽取。</small></section>`;}
function reviewView(){const errors=checkReport.filter(x=>x.level==='error').length,warnings=checkReport.filter(x=>x.level==='warn').length;return title('看看这局会是什么样','先试抽一局，确认无误后就能导出分享。')+drawPanel()+`<div class="review-grid"><section><div class="check-top"><div><strong class="${errors?'':'ok'}">${errors?errors+' 项需要调整':'可以继续保存'}</strong><p class="muted">${warnings} 项提醒 · ${board.roles.length} 种候选</p></div><button class="small" data-action="recheck">重新检查</button></div><div class="check-list">${checkReport.filter(x=>x.level!=='info').map(x=>`<div class="issue ${x.level}"><b>${x.level==='error'?'调整':'提醒'}</b><span>${esc(x.text)}</span>${x.camp?`<button data-open-camp="${x.camp}" data-neutral-role="${esc(x.roleUid||'')}">查看</button>`:x.uid?`<button data-locate="${x.uid}">查看</button>`:''}</div>`).join('')||'<div class="note">人数、候选容量与已知规则检查通过。</div>'}</div><div class="export-summary"><p>保存这套板子，分享给朋友。</p><button class="accent" data-action="export">导出板子</button></div></section><section class="review-goals"><h3>本局胜利条件</h3>${customBaseSummary()}${board.campEvents.filter(g=>g.events.length).map(g=>`<div class="goal-review-row"><strong>${esc(E.campName(board,g.camp)+(g.camp===3?' · 所有中立角色适用':''))}</strong><p>${g.join==='all'?'全部完成：':'完成任意一个：'}<br>${[...g.events].sort((a,b)=>b.weight-a.weight).map(eventText).map(esc).join('<br>')}</p></div>`).join('')||'<p class="muted">没有新增目标，沿用原条件。</p>'}</section></div><details class="simple-sim"><summary>试一试胜利判定</summary><p class="muted">填入假设进度，检查新增目标与原条件的先后关系。</p><div id="sim-inputs"></div><div id="sim-result" aria-live="polite"></div></details>`;}
function newScenario(){return {progress:{},eligibleAlive:true,originalWinner:''};}
function simGroups(){if(!drawResult)return [];return E.campIds(board).filter(c=>c!==3&&drawResult.seats.some(s=>s.camp===c)).map(c=>({key:'camp-'+c,camp:c,label:factionLabel(c)})).concat(drawResult.seats.filter(s=>s.camp===3).map(s=>({key:s.uid,camp:3,roleUid:s.roleUid,seatId:s.uid,label:s.name+' · 席位'+(drawResult.seats.indexOf(s)+1)})));}
function renderSimulation(){const el=$('#sim-inputs');if(!el)return;const groups=simGroups();if(!groups.length){el.innerHTML='<div class="note">先在上方随机抽取一桌，再试算实际出场的阵营。</div>';return;}if(!groups.some(g=>g.key===simGroup))simGroup=groups[0].key;if(!scenario)scenario=newScenario();const g=groups.find(g=>g.key===simGroup),rule=E.campRule(board,g.camp,g.roleUid);el.innerHTML=`<div class="simple-sim-grid"><label>要试算的阵营／玩家<select id="sim-group">${groups.map(x=>`<option value="${x.key}" ${x.key===simGroup?'selected':''}>${esc(x.label)}</option>`).join('')}</select></label><label>假设原条件也已达成<select data-sim-original>${options({'':'暂未达成原条件',...Object.fromEntries(groups.filter(x=>x.camp>3?!!E.faction(board,x.camp).baseVictory:x.camp!==3||!E.isCustom(board.roles.find(r=>r.uid===x.roleUid))).map(x=>[x.key,x.label]))},scenario.originalWinner)}</select></label>${rule.events.map(e=>{const d=E.eventCatalog[e.type];return number(d.name+(g.camp!==3&&d.aggregation==='personalMax'?'个人最高记录':'已完成')+'（'+d.unit+'）',scenario.progress[d.counter||e.type]||0,`data-sim-progress="${d.counter||e.type}"`,0,999)}).join('')}</div><label class="inline"><input type="checkbox" data-sim-alive ${scenario.eligibleAlive?'checked':''}>${g.camp===3?'本人仍然存活':'本阵营仍有成员存活'}</label><small class="scope-note">${g.camp===3?'所有中立采用相同目标；这里仅填写该席位本人的进度，不与其他中立合并。':'按每项目标的说明填写；个人目标填写一名存活成员的最高记录，其余填写阵营累计。'}</small><button class="accent" data-action="simulate">看看谁获胜</button>`;if(simulationRun)showResult();else $('#sim-result').innerHTML='';}
function showResult(){const groups=simGroups(),g=groups.find(g=>g.key===simGroup);if(!g)return;const seats=drawResult.seats,original=groups.find(x=>x.key===scenario.originalWinner);const ids=x=>x.camp===3?[x.seatId]:seats.filter(s=>s.camp===x.camp).map(s=>s.uid),actorIds=ids(g);const state={finalized:true,seats,campProgress:g.camp===3?{}:{[g.camp]:scenario.progress},playerProgress:g.camp===3?{[g.seatId]:scenario.progress}:{},aliveSeatIds:seats.map(s=>s.uid).filter(id=>scenario.eligibleAlive||!actorIds.includes(id)),originalWinners:original&&original.camp<=3?ids(original):[],baseConditionMatches:original?.camp>3?[{camp:original.camp,presetId:E.faction(board,original.camp).baseVictory,actorSeatId:ids(original)[0]}]:[]};if(g.camp!==3&&actorIds.length){const p={};for(const [type,d] of Object.entries(E.eventCatalog))if(d.aggregation==='personalMax')p[type]=scenario.progress[type]||0;state.playerProgress[actorIds[0]]=p;}const result=E.resolveVictory(board,state);$('#sim-result').innerHTML=`<div class="simulation-result"><h3>${result.source==='extra'?'新增目标优先获胜':result.source==='original'?'按原条件获胜':result.source==='pending'?'等待事件处理完成':'暂时无人获胜'}</h3><p>${esc(result.invalid?result.reason:result.source==='extra'?result.reason:result.source==='original'?'额外目标尚未达成，按原有条件获胜。':result.source==='none'?'继续游戏。':'等待结算。')}</p>${result.winners.length?`<p class="sim-winners">${result.winners.map(id=>esc(seats.find(s=>s.uid===id)?.name||id)).join('、')}</p>`:''}</div>`;}
function modal(html,compact=false,kind=''){const d=$('#modal');d.classList.toggle('compact-dialog',compact);d.dataset.kind=kind;d.setAttribute('aria-labelledby','modal-title');$('#modal-content').innerHTML=html+'<p id="dialog-status" class="dialog-status" role="status" aria-live="polite"></p>';d.showModal();}
function closeModal(){$('#modal').close();}
const modalHead=(title)=>`<div class="modal-head"><h2 id="modal-title">${title}</h2><button type="button" data-action="close-modal" aria-label="关闭弹窗">×</button></div>`;
function addRoleModal(camp=null){
 careerLockedCamp=camp===null?null:Number(camp);careerSearch='';careerCamp=careerLockedCamp===null?'all':String(careerLockedCamp);
 modal(modalHead(careerLockedCamp===null?'添加已有职业':esc(E.campName(board,careerLockedCamp))+' · 添加职业')+`<div class="modal-toolbar ${careerLockedCamp===null?'':'locked-camp-toolbar'}"><input id="career-search" aria-label="搜索职业" placeholder="搜索职业">${careerLockedCamp===null?`<select id="career-camp" aria-label="筛选阵营">${options({all:'全部阵营',1:'鹅阵营',2:'鸭阵营',3:'中立阵营'},'all')}</select>`:''}</div><div class="modal-grid" id="career-list" style="margin-top:13px">${careerItems()}</div>`);
}
function careerItems(){return D.career.filter(c=>E.classicCareerIds.has(c.id)&&(careerLockedCamp===null||c.camp===careerLockedCamp)&&(careerCamp==='all'||c.camp===+careerCamp)&&(!careerSearch||(c.name+String(c.id)).includes(careerSearch))).map(c=>`<button class="career-option camp-${c.camp}" data-add-career="${c.id}">${roleAvatar(c.id,c.camp)}<h3>${esc(c.name)}</h3><p>${esc(c.des)}</p><span class="chip">${E.camps[c.camp]}阵营</span></button>`).join('')||'<div class="empty">没有匹配角色</div>';}
function customRoleModal(camp=null){
 if(board.roles.length>=E.MAX_POOL_ROLES)throw Error('候选池最多300个角色条目');
 if(camp!==null&&(!E.faction(board,camp)||camp===3))throw Error('空白角色请选择鹅、鸭或新阵营');
 customRoleCamp=camp;let name='自创角色',n=2;const names=new Set(board.roles.map(r=>r.name));while(names.has(name))name='自创角色'+n++;
 const choices=board.factions.filter(f=>f.id!==3),chosen=camp??choices[0].id;
 modal(modalHead('创建空白角色')+`<form id="custom-role-form"><div class="custom-role-preview">${roleAvatar(null,chosen)}<span>为新角色起个名字</span></div><div class="custom-role-fields"><label for="new-role-name">角色名称</label><input id="new-role-name" name="name" maxlength="20" required value="${esc(name)}" autocomplete="off"><label for="new-role-camp">所属阵营</label>${camp===null?`<select id="new-role-camp" name="camp">${options(Object.fromEntries(choices.map(f=>[f.id,f.name])),chosen)}</select>`:`<input id="new-role-camp" value="${esc(E.campName(board,camp))}" readonly>`}</div><p class="setting-hint">创建后，到“搭配技能”选择能力。</p><p class="form-error" id="custom-role-error" role="alert" hidden></p><div class="modal-actions"><button type="button" data-action="close-modal">取消</button><button type="submit" class="primary">创建角色</button></div></form>`,true);
 $('#new-role-name').focus();$('#new-role-name').select();
}
document.addEventListener('submit',e=>{
 if(e.target.id!=='custom-role-form')return;e.preventDefault();
 try{
  const name=$('#new-role-name').value.trim();if(!name)throw Error('请输入角色名称');if(name.length>20)throw Error('角色名称最多20个字');
  if(board.roles.length>=E.MAX_POOL_ROLES)throw Error('候选池最多300个角色条目');
  const camp=customRoleCamp??Number($('#new-role-camp').value),r=E.makeCustomRole(board,camp);r.name=name;
  board.roles.push(r);selected=r.uid;paramSkill=0;closeModal();mark();renderInPlace();toast('已创建空白角色');
 }catch(error){const n=$('#custom-role-error');n.textContent=error.message;n.hidden=false;}
});

function resetPageData(source,page,roleUid){
 const b=clone(source),defaults=E.defaultBoard();
 if(page==='room'){b.room={...defaults.room,counts:clone(b.room.counts)};b.description=defaults.description;}
 else if(page==='factions'){
  const previous=b.roles;
  b.factions=clone(defaults.factions);
  const total=Math.min(E.ROOM_LIMITS.max,Math.max(E.ROOM_LIMITS.min,b.room.total)),ducks=Math.max(1,Math.floor(total/5)),neutral=Math.min(2,Math.floor(total/5));
  b.room.counts={1:total-ducks-neutral,2:ducks,3:neutral};
  b.roles=defaults.roles.map(r=>clone(previous.find(p=>!E.isCustom(p)&&p.templateCareerId===r.templateCareerId)||r));
  for(const [camp,careerId] of [[1,1],[2,101]]){const missing=b.room.counts[camp]-E.poolStats(b,camp).capacity;if(missing>0)b.roles.find(r=>r.templateCareerId===careerId).count+=missing;}
  E.ensureCampRules(b);
 }else if(page==='wins'){
  for(const f of b.factions)if(f.kind==='custom')f.baseVictory=null;
  b.campEvents=b.factions.map(f=>({key:'camp-'+f.id,camp:f.id,join:'any',events:[]}));
 }else if(page==='roles'){
  const r=b.roles.find(r=>r.uid===roleUid);if(!r)throw Error('请先选择角色。');
  const fresh=E.isCustom(r)?E.makeCustomRole(b,1):E.makeRole(r.templateCareerId);
  r.slots=clone(fresh.slots);r.skillOverrides={};
 }else if(page!=='review')throw Error('当前页面不能重置。');
 return b;
}
function pageResetDetails(){
 const r=role();return {
  room:{label:'房间设置',copy:'恢复默认人数、会议参数、对局参数和玩法介绍。阵营分配、角色与胜利目标会保留。'},
  factions:{label:'阵营分配',copy:'按当前房间人数恢复鹅、鸭、中立及经典候选角色。自建阵营及被移除角色的设置会一并移除。保留角色的技能、原三阵营胜利目标和房间参数不变。'},
  wins:{label:'胜利设置',copy:'清空所有额外胜利目标，取消新阵营选用的基础条件。原有胜利条件仍固定，阵营与技能保持原样。'},
  roles:{label:r?r.name+'的技能':'当前角色技能',copy:r?(E.isCustom(r)?'清空「'+r.name+'」的技能和技能参数调整。':'恢复「'+r.name+'」的原技能，清除技能参数调整。'):'请先选择角色。'},
  review:{label:'预览结果',copy:'清空本次抽取名单和胜利试算结果，已配置的板子保持原样。'}
 }[tab];
}
function pageResetModal(){
 const d=pageResetDetails();if(tab==='roles'&&!role())return;
 modal(modalHead('重置'+d.label+'？')+'<p class="reset-scope-copy">'+esc(d.copy)+'</p><p class="setting-hint">重置后可立即撤销。</p><div class="modal-actions"><button data-action="close-modal">取消</button><button class="danger" data-action="confirm-page-reset">确认重置</button></div>',true);
}
function performPageReset(){
 const before={tab,label:pageResetDetails().label,board:clone(board),selected,ruleCamp,drawResult:drawResult?clone(drawResult):null,drawError,scenario:scenario?clone(scenario):null,simulationRun,simGroup};
 board=resetPageData(board,tab,role()?.uid);paramSkill=0;
 if(!board.roles.some(r=>r.uid===selected))selected=board.roles[0]?.uid||'';
 if(!E.faction(board,ruleCamp))ruleCamp=1;
 if(tab==='review'){drawResult=null;drawError='';scenario=null;simulationRun=false;}else mark();
 lastPageReset=before;closeModal();render();$('#content').scrollTop=0;
 toast(before.label+'已重置');
}
function undoPageReset(){
 const previous=lastPageReset;if(!previous)return;
 board=clone(previous.board);selected=previous.selected;ruleCamp=previous.ruleCamp;
 if(previous.tab!=='review')mark();
 drawResult=previous.drawResult;drawError=previous.drawError;scenario=previous.scenario;simulationRun=previous.simulationRun;simGroup=previous.simGroup;
 lastPageReset=null;render();toast('已撤销重置');
}

function fileMenu(){modal(modalHead('管理我的板子')+`<div class="file-menu-grid"><button data-action="load"><strong>我的板子</strong><span>打开已保存的板子</span></button><button data-action="save"><strong>保存一份</strong><span>留下一个命名存档</span></button><button data-action="export"><strong>导出板子</strong><span>下载文件，分享给朋友</span></button><button data-action="import"><strong>导入板子</strong><span>打开已有的板子文件</span></button><button data-action="how-to"><strong>怎么使用？</strong><span>一分钟了解编辑流程</span></button></div>`,true);}
function howTo(){modal(modalHead('跟着这 5 步，做一套新玩法')+`<ol class="quick-guide"><li><strong>设置房间</strong><p>选好人数，会议设置可直接用默认。</p></li><li><strong>分配阵营</strong><p>定好每队几人，再挑可随机出现的角色。</p></li><li><strong>设置胜利</strong><p>保留原规则，或给阵营增加新的获胜目标。</p></li><li><strong>搭配技能</strong><p>给已有或自创角色添加主动技能。</p></li><li><strong>预览板子</strong><p>试抽一局，修正提示后导出分享。</p></li></ol><div class="modal-actions"><button class="primary" data-action="close-modal">开始动手</button></div>`,true);}
function readSaves(){try{const a=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(a)?a:[];}catch{return [];}}
function save(){try{const saves=readSaves(),item={id:Date.now().toString(),name:board.boardName,time:new Date().toISOString(),board:E.exportDraft(board)};saves.unshift(item);localStorage.setItem(STORE,JSON.stringify(saves.slice(0,8)));dirty=false;$('#save-state').textContent='已保存命名存档';toast('已保存到本机存档（保留最近8份）');}catch(e){toast('本地存储不可用，请导出 JSON 保存。');}}
function loadModal(){const saves=readSaves();modal(modalHead('我的本机存档')+`<small>加载会先备份当前板子；最多保留最近 8 份命名存档。</small>${saves.map((s,i)=>`<div class="save-row"><div><strong>${esc(s.name)}</strong><p>${esc(new Date(s.time).toLocaleString('zh-CN'))}</p></div><div class="inline-actions"><button data-load-save="${i}">加载</button><button class="quiet small danger" data-delete-save="${i}">删除</button></div></div>`).join('')||'<div class="empty" style="margin-top:15px">暂无命名存档，在“更多”中点击“保存一份”留下一个版本。</div>'}<div class="modal-actions"><button data-action="recover">恢复上次自动暂存</button><button data-action="recover-previous">恢复替换前草稿</button><button data-action="close-modal">关闭</button></div>`);}
function replaceBoard(b){try{localStorage.setItem(STORE+'-recovery',JSON.stringify(E.exportDraft(board)));}catch{}board=E.validateShape(b);selected=board.roles[0]?.uid||'';simRole='';scenario=null;paramSkill=0;simulationRun=false;mark();closeModal();render();toast('已载入板子，原草稿已备份');}
function exportModal(){header();const errors=checkReport.filter(x=>x.level==='error').length;modal(modalHead('导出我的板子')+`<div class="modal-notice">${errors?`有 ${errors} 项错误。可以导出问题草稿，文件会保留检查报告，便于继续修改。`:'当前基础检查通过。导出为离线板子草稿，保留全部自定义设置。'}</div><p class="muted">保存全部设置，之后可重新导入编辑。</p><div class="modal-actions"><button data-action="close-modal">继续编辑</button><button class="primary" data-action="download">${errors?'导出问题草稿':'下载板子文件'}</button></div>`);}
function download(){try{const out=E.exportDraft(board);out.checkReport=clone(checkReport);if(drawResult)out.drawPreview=clone(drawResult);const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=(board.boardName.replace(/[\\/:*?"<>|]/g,'_')||'板子')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);closeModal();toast('板子已导出');}catch(e){toast('导出失败：'+e.message);}}
async function importFile(file){if(!file)return;try{if(file.size>2*1024*1024)throw Error('文件超过 2MB');const incoming=E.validateShape(JSON.parse(await file.text()));const issues=E.validate(incoming);modal(modalHead('导入为新草稿')+`<p>板子：${esc(incoming.boardName)}</p><p style="margin-top:8px">${incoming.room.total} 人 · ${incoming.roles.length} 种候选 · ${issues.filter(x=>x.level==='error').length} 项待修正</p><div class="note">只导入到本编辑器。当前草稿会先保存恢复备份，不修改游戏房间。</div><div class="modal-actions"><button data-action="close-modal">取消</button><button class="primary" id="confirm-import">导入草稿</button></div>`);$('#confirm-import').addEventListener('click',()=>replaceBoard(incoming),{once:true});}catch(e){toast('导入失败：'+e.message);}finally{$('#file-import').value='';}}
document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el)return;try{
 if(el.dataset.tab){tab=el.dataset.tab;render();$('#content').scrollTop=0;return;}
 if(el.dataset.totalPreset||el.dataset.totalDelta){board.room.total=el.dataset.totalPreset?Number(el.dataset.totalPreset):Math.max(2,Math.min(E.ROOM_LIMITS.max,board.room.total+Number(el.dataset.totalDelta)));mark();renderInPlace();return;}
 if(el.dataset.ruleCamp){ruleCamp=Number(el.dataset.ruleCamp);render();return;}
 if(el.dataset.openCamp){openCamp(el.dataset.openCamp);return;}
 if(el.dataset.goalJoin){activeCampRule().join=el.dataset.goalJoin;mark();render();return;}
 if(el.dataset.addEvent){E.addCampEvent(board,ruleCamp,el.dataset.addEvent);closeModal();mark();render();return;}
 if(el.dataset.removeEvent){E.removeCampEvent(board,ruleCamp,el.dataset.removeEvent);mark();render();return;}
 if(el.dataset.selectRole){selected=el.dataset.selectRole;paramSkill=0;render();return;}
 if(el.dataset.countStep){const c=el.dataset.countStep;board.room.counts[c]=Math.max(0,Math.min(E.ROOM_LIMITS.max,board.room.counts[c]+Number(el.dataset.delta)));mark();render();return;}
 if(el.dataset.addCareer){const c=E.careers.get(Number(el.dataset.addCareer));if(!c||!E.classicCareerIds.has(c.id)||(careerLockedCamp!==null&&c.camp!==careerLockedCamp))throw Error('请选择当前阵营的已有职业');if(board.roles.length>=E.MAX_POOL_ROLES)throw Error('候选池最多300个角色条目');const r=E.makeRole(c.id);board.roles.push(r);selected=r.uid;paramSkill=0;closeModal();mark();renderInPlace();toast('已加入候选池');return;}
 if(el.dataset.removeCandidate){removeCandidate(el.dataset.removeCandidate);return;}
 if(el.dataset.addSkill){const r=role(),id=+el.dataset.addSkill;E.addSkill(r,id,slotChoice);paramSkill=0;mark();renderInPlace();updateSkillPicker();toast('已添加 '+E.playerSkill(id).name);return;}
 if(el.dataset.removeSkill){E.removeSkill(role(),+el.dataset.removeSkill,el.dataset.slot);mark();render();return;}
 if(el.dataset.param){skillParameters(el.dataset.param);return;}
 if(el.dataset.locate){selected=el.dataset.locate;tab='roles';render();return;}
 if(el.dataset.loadSave!==undefined){replaceBoard(readSaves()[+el.dataset.loadSave].board);return;}
 if(el.dataset.deleteSave!==undefined){const saves=readSaves();saves.splice(+el.dataset.deleteSave,1);localStorage.setItem(STORE,JSON.stringify(saves));closeModal();loadModal();return;}
 const action=el.dataset.action;
 if(action==='reset-page')pageResetModal();
 else if(action==='confirm-page-reset')performPageReset();
 else if(action==='undo-page-reset')undoPageReset();
 else if(action==='next'){if(tab==='review')exportModal();else{tab=['room','factions','wins','roles','review'][['room','factions','wins','roles','review'].indexOf(tab)+1];render();$('#content').scrollTop=0;}}
 else if(action==='prev'){const steps=['room','factions','wins','roles','review'];tab=steps[Math.max(0,steps.indexOf(tab)-1)];render();$('#content').scrollTop=0;}
 else if(action==='choose-skills')skillPicker();
 else if(action==='role-options')roleOptions();
 else if(action==='file-menu')fileMenu();
 else if(action==='how-to')howTo();
 else if(action==='to-wins')openCamp(1);
 else if(action==='to-roles'){tab='roles';render();}
 else if(action==='choose-event')eventPicker();
 else if(action==='view-original-neutrals')originalNeutralModal();
 else if(action==='add-role')addRoleModal();
 else if(action==='new-custom-role'||action==='new-custom-neutral')customRoleModal();
 else if(action==='clear-custom-skills'){closeModal();const r=role();if(!E.isCustom(r))return;r.slots=E.makeCustomRole(board).slots;r.skillOverrides={};paramSkill=0;mark();render();toast('已清空技能');}
 else if(action==='role-art')roleArtModal();
 else if(action==='close-modal')closeModal();
 else if(action==='save'){save();closeModal();}
 else if(action==='load')loadModal();
 else if(action==='recover'){const b=JSON.parse(localStorage.getItem(AUTOSAVE)||'null');if(!b)throw Error('暂无自动暂存');replaceBoard(b);}
 else if(action==='recover-previous'){const b=JSON.parse(localStorage.getItem(STORE+'-recovery')||'null');if(!b)throw Error('暂无替换备份');replaceBoard(b);}
 else if(action==='export')exportModal();
 else if(action==='download')download();
 else if(action==='import'){closeModal();$('#file-import').click();}
 else if(action==='to-draw'){tab='review';render();$('#content').scrollTop=0;}
 else if(action==='draw-pool'){try{drawResult=E.drawPool(board);drawError='';scenario=null;simulationRun=false;}catch(error){drawResult=null;drawError=error.message;}render();$('#content').scrollTop=0;}
 else if(action==='pool-example')modal(modalHead('载入随机角色池示例')+'<p>载入鹅30种、鸭20种、中立10种候选，本局仍为6／2／2共10人。当前草稿将自动备份。</p><div class="modal-actions"><button data-action="close-modal">取消</button><button class="primary" data-action="confirm-pool-example">载入示例</button></div>');
 else if(action==='confirm-pool-example')replaceBoard(E.poolExample());
 else if(action==='remove-role'){closeModal();removeCandidate(role()?.uid);}
 else if(action==='restore-role'){closeModal();const r=role();if(E.isCustom(r))return;const fresh=E.makeRole(r.templateCareerId);fresh.uid=r.uid;fresh.count=r.count;board.roles[board.roles.indexOf(r)]=fresh;paramSkill=0;mark();render();toast('已还原职业技能；阵营目标保持不变');}
 else if(action==='close-params'){paramSkill=0;closeModal();renderInPlace();}
 else if(action==='reset-params'){E.resetSkillParameters(role(),paramSkill);mark();skillParameters(paramSkill);}
 else if(action==='simulate'){simulationRun=true;showResult();}
 else if(action==='recheck'){render();toast('已重新检查');}
 }catch(err){toast(err.message);}});
document.addEventListener('toggle',e=>{if(e.target.isConnected&&e.target.classList?.contains('room-more'))roomMoreOpen=e.target.open;},true);
document.addEventListener('input',e=>{const t=e.target;if(t.id==='roster-search'){rosterSearch=t.value;$('.roster-list').innerHTML=rosterItems();}if(t.id==='skill-search'){skillSearch=t.value;$('#library-list').innerHTML=libraryItems(role());}if(t.id==='career-search'){careerSearch=t.value;$('#career-list').innerHTML=careerItems();}if(t.id==='new-role-name')$('#custom-role-error').hidden=true;});
document.addEventListener('change',e=>{const t=e.target;try{
 if(t.id==='file-import'){importFile(t.files[0]);return;}
 if(t.id==='skill-module'){skillModule=t.value;$('#library-list').innerHTML=libraryItems(role());return;}
 if(t.id==='slot-choice'){slotChoice=t.value;return;}
 if(t.id==='career-camp'){careerCamp=t.value;$('#career-list').innerHTML=careerItems();return;}
 if(t.id==='sim-group'){simGroup=t.value;scenario=newScenario();simulationRun=false;renderSimulation();return;}
 if(t.dataset.simProgress){if(!Number.isInteger(t.valueAsNumber)||t.valueAsNumber<0||t.valueAsNumber>999)throw Error('请输入0–999的整数');scenario.progress[t.dataset.simProgress]=t.valueAsNumber;simulationRun=false;$('#sim-result').innerHTML='';return;}
 if(t.hasAttribute('data-sim-original')){scenario.originalWinner=t.value;simulationRun=false;$('#sim-result').innerHTML='';return;}
 if(t.hasAttribute('data-sim-alive')){scenario.eligibleAlive=t.checked;simulationRun=false;$('#sim-result').innerHTML='';return;}
 if(t.type==='number'&&(!Number.isInteger(t.valueAsNumber)||t.valueAsNumber<Number(t.min||0)||t.valueAsNumber>Number(t.max||100000))){if($('#modal').open&&$('#modal').dataset.kind==='parameters')skillParameters(paramSkill);else if($('#modal').open&&$('#modal').dataset.kind==='role-options')roleOptions();else renderInPlace();toast('请输入'+(t.min||0)+'–'+(t.max||100000)+'的整数');return;}
 if(t.dataset.eventWeight){activeCampRule().events.find(x=>x.id===t.dataset.eventWeight).weight=t.valueAsNumber;mark();renderInPlace();return;}
 if(t.dataset.eventValue){activeCampRule().events.find(x=>x.id===t.dataset.eventValue).value=t.valueAsNumber;mark();return;}
 if(t.id==='board-name'){if(!t.value.trim()){toast('板子名称不能为空');header();return;}board.boardName=t.value.trim();}
 else if(t.hasAttribute('data-description'))board.description=t.value;
 else if(t.dataset.room){const key=t.dataset.room,d=E.ROOM_FIELDS[key];if(t.value==='custom'){const input=t.parentElement.querySelector('input');input.hidden=false;input.focus();return;}board.room[key]=d?.type==='boolean'?t.value==='true':Number(t.value);}
 else if(t.dataset.skillLimit){const r=role();r.skillOverrides[paramSkill]||={};r.skillOverrides[paramSkill][t.dataset.skillLimit]=Number(t.value);}
 else if(t.dataset.count)board.room.counts[t.dataset.count]=t.valueAsNumber;
 else if(t.dataset.roleField){const k=t.dataset.roleField;if(k==='name'&&!t.value.trim())throw Error('角色名不能为空');if(k==='camp'){E.setRoleCamp(board,role(),Number(t.value));toast('已采用'+E.campName(board,role().camp)+'目标');}else role()[k]=t.type==='number'?Number(t.value):t.value.trim();}
 else if(t.dataset.skillParam){const r=role();r.skillOverrides[paramSkill]||={};r.skillOverrides[paramSkill][t.dataset.skillParam]=t.valueAsNumber;}
 else if(t.dataset.stageParam){const r=role();r.skillOverrides[paramSkill]||={};r.skillOverrides[paramSkill].stages||={};r.skillOverrides[paramSkill].stages[t.dataset.stage]||={};r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam]=t.valueAsNumber;}
 else return;
 mark();if(t.dataset.count||t.dataset.room==='total'||t.dataset.room&&t.tagName==='SELECT')render();else if(t.type==='number'||t.type==='text'||t.tagName==='TEXTAREA')refreshInline();else render();
 }catch(err){toast(err.message);}});
function refreshInline(){
 document.querySelectorAll('[data-total-delta]').forEach(button=>button.disabled=Number(button.dataset.totalDelta)>0?board.room.total>=E.ROOM_LIMITS.max:board.room.total<=E.ROOM_LIMITS.min);
 document.querySelectorAll('[data-count-step]').forEach(button=>button.disabled=Number(button.dataset.delta)>0?board.room.counts[button.dataset.countStep]>=E.ROOM_LIMITS.max:board.room.counts[button.dataset.countStep]===0);
 const drawPanelNode=$('#draw-panel');if(drawPanelNode&&!drawResult){drawPanelNode.querySelectorAll('.draw-camps,.draw-meta,.draw-empty,[role="alert"]').forEach(n=>n.remove());const blocked=checkReport.some(x=>x.level==='error'),button=drawPanelNode.querySelector('[data-action="draw-pool"]');button.disabled=blocked;button.textContent='随机抽取一桌';drawPanelNode.querySelector(':scope > small').insertAdjacentHTML('beforebegin',`<div class="draw-empty">${blocked?'请先修正下方配置问题，再随机抽取。':'角色池已就绪。点击“随机抽取一桌”，按各阵营人数产生本局名单。'}</div>`);}
 document.querySelectorAll('[data-select-role]').forEach(button=>{const r=board.roles.find(x=>x.uid===button.dataset.selectRole);if(!r)return;button.querySelector('.name>span').textContent=r.name;button.querySelector('.copies').textContent='≤'+r.count;button.querySelector('.copies').title='单局最多出现'+r.count+'次';button.querySelector('.name small').textContent=E.campName(board,r.camp);});
 const r=role();if(r&&$('[data-custom-name]'))$('[data-custom-name]').textContent=r.name;
 for(const c of [1,2,3]){const small=$('.camp-card.camp-'+c+' small'),p=E.poolStats(board,c);if(small)small.innerHTML=`候选 <b>${p.candidates}</b> 种 · 可供 ${p.capacity} 席<br>本局随机抽取 ${p.seats} 人`;}
 if($('.seat-bar'))$('.seat-bar').innerHTML=[1,2,3].flatMap(c=>Array.from({length:board.room.counts[c]},()=>`<span class="camp-tone-${c}"></span>`)).join('');


}
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal')){const r=$('#modal').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeModal();}});
function factionLabel(id){return E.campName(board,id);}

function factionsView(){const assigned=board.factions.reduce((n,f)=>n+board.room.counts[f.id],0),delta=board.room.total-assigned;return title('谁和谁是一队？','先分配人数，再挑选候选角色。角色选得多，开局会随机抽。')+`<div class="faction-total"><strong>这局 ${board.room.total} 人</strong><span class="${delta===0?'ok':'danger'}">${delta===0?'人数已分配好':delta>0?'还需分配 '+delta+' 人':'多分配了 '+(-delta)+' 人'}</span><button class="quiet small" data-tab="room">修改总人数</button></div><button class="add-faction-card" data-action="add-faction" aria-label="新增阵营" ${board.factions.length>=E.MAX_FACTIONS?'disabled':''}><span class="add-faction-icon" aria-hidden="true">＋</span><span class="add-faction-copy"><strong>新增阵营</strong><span>创建自己的队伍，安排人数与角色</span></span><span class="add-faction-arrow" aria-hidden="true">→</span></button><div class="faction-cards">${board.factions.map(factionCard).join('')}</div>`;}
function factionCard(f){const p=E.poolStats(board,f.id),members=board.roles.filter(r=>r.camp===f.id),custom=f.kind==='custom',movable=f.id===3?[]:board.roles.filter(r=>E.isCustom(r)&&r.camp!==f.id);return `<article class="faction-card camp-${f.id<=3?f.id:'custom'}" data-faction-card="${f.id}"><div class="faction-side"><div class="faction-card-head"><span class="faction-emblem">${custom?'新':f.id===1?'鹅':f.id===2?'鸭':'独'}</span><div>${custom?`<input aria-label="${esc(f.name)}名称" maxlength="20" value="${esc(f.name)}" data-faction-name="${f.id}">`:`<h3>${esc(f.name)}</h3>`}<small>${f.id===3?'各自获胜':'共同获胜'}</small></div></div><div class="faction-seats"><span>出场人数</span><div class="stepper"><button data-count-step="${f.id}" data-delta="-1" aria-label="减少${esc(f.name)}人数" ${p.seats===0?'disabled':''}>−</button><input aria-label="${esc(f.name)}人数" type="number" min="0" max="${E.ROOM_LIMITS.max}" value="${p.seats}" data-count="${f.id}"><button data-count-step="${f.id}" data-delta="1" aria-label="增加${esc(f.name)}人数" ${p.seats>=E.ROOM_LIMITS.max?'disabled':''}>＋</button></div></div><p class="faction-pool-count">${p.candidates} 个候选 · 随机选 ${p.seats} 人</p>${custom?`<button class="quiet small danger" data-delete-faction="${f.id}">删除空阵营</button>`:''}</div><div class="faction-candidates"><details class="faction-members" open><summary>候选角色 <span>${members.length}</span></summary><div class="faction-role-chips">${members.map(r=>`<div class="faction-role-chip"><button class="faction-role-edit" data-edit-role="${esc(r.uid)}" aria-label="编辑${esc(r.name)}">${roleAvatar(r.templateCareerId,r.camp)}<span>${esc(r.name)}</span></button><button class="faction-role-remove" data-remove-candidate="${esc(r.uid)}" aria-label="移除${esc(r.name)}" title="移出候选池">×</button></div>`).join('')||'<p class="empty-pool">还没有角色，从下方添加一个吧。</p>'}</div></details><div class="faction-member-actions">${custom?'':`<button class="small" data-add-original-camp="${f.id}">＋ 添加已有职业</button>`}${f.id===3?'':`<button class="small secondary" data-new-role-camp="${f.id}">创建空白角色</button>`}${movable.length?`<label class="assign-role"><span class="sr-only">加入自创角色</span><select aria-label="为${esc(f.name)}加入自创角色" data-assign-faction="${f.id}"><option value="">移入自创角色…</option>${movable.map(r=>`<option value="${esc(r.uid)}">${esc(r.name)}（${esc(factionLabel(r.camp))}）</option>`).join('')}</select></label>`:''}<button class="quiet small faction-win-link" data-open-camp="${f.id}">设置胜利 →</button></div></div></article>`;}
function goalCard(e,i,neutral){const d=E.eventCatalog[e.type];return `<article class="goal-card"><span class="goal-number">${i+1}</span><div class="goal-copy"><h4>${esc(d.name)}</h4><p>${esc(campEventCopy(d.description))}</p>${d.hint?`<small class="ability-hint">${esc(d.hint)}</small>`:''}<details class="goal-detail"><summary>计数说明</summary><p>${esc(campEventCopy(d.detail||d.description))}</p></details></div><label class="goal-target"><span>目标</span><div><input aria-label="${esc(d.name)}目标" type="number" min="1" max="999" value="${e.value}" data-event-value="${esc(e.id)}"><span>${esc(d.unit)}</span></div></label><label class="goal-weight"><span>权重 · 优先级</span><input aria-label="${esc(d.name)}权重" type="number" min="1" max="${E.MAX_EVENT_WEIGHT}" value="${e.weight}" data-event-weight="${esc(e.id)}"></label><button class="quiet small danger" data-remove-event="${esc(e.id)}" aria-label="删除${esc(d.name)}">移除</button></article>`;}

document.addEventListener('click',e=>{const el=e.target.closest('button');if(!el)return;try{
 if(el.dataset.action==='to-factions'){tab='factions';render();}
 else if(el.dataset.action==='add-faction'){const f=E.addFaction(board);mark();render();document.querySelector(`[data-faction-name="${f.id}"]`)?.focus();toast('已创建'+f.name+'，请分配人数与角色');}
 else if(el.dataset.editRole){selected=el.dataset.editRole;tab='roles';paramSkill=0;render();}
 else if(el.dataset.newRoleCamp)customRoleModal(Number(el.dataset.newRoleCamp));
 else if(el.dataset.addOriginalCamp)addRoleModal(Number(el.dataset.addOriginalCamp));
 else if(el.dataset.deleteFaction){const id=Number(el.dataset.deleteFaction);E.removeFaction(board,id);if(ruleCamp===id)ruleCamp=1;mark();render();toast('已删除空阵营');}
 }catch(error){toast(error.message);}});
document.addEventListener('change',e=>{const t=e.target;try{
 if(t.dataset.factionName){E.renameFaction(board,Number(t.dataset.factionName),t.value);mark();render();}
 else if(t.dataset.assignFaction){if(!t.value)return;const r=board.roles.find(r=>r.uid===t.value);E.setRoleCamp(board,r,Number(t.dataset.assignFaction));mark();render();}
 else if(t.dataset.baseVictory){E.setBaseVictory(board,Number(t.dataset.baseVictory),t.value||null);mark();render();}
 }catch(error){toast(error.message);render();}});

// Save valid edits as they are typed, without replacing the focused input.
document.addEventListener('input',e=>{const t=e.target;try{
 if(t.dataset.room&&t.type!=='number')return;
 if(t.dataset.simProgress){if(Number.isInteger(t.valueAsNumber)&&t.valueAsNumber>=0&&t.valueAsNumber<=999){scenario.progress[t.dataset.simProgress]=t.valueAsNumber;simulationRun=false;$('#sim-result').innerHTML='';}return;}
 if(t.type==='number'&&(!Number.isInteger(t.valueAsNumber)||t.valueAsNumber<Number(t.min||0)||t.valueAsNumber>Number(t.max||100000)))return;
 if(t.dataset.count)board.room.counts[t.dataset.count]=t.valueAsNumber;
 else if(t.dataset.room)board.room[t.dataset.room]=t.valueAsNumber;
 else if(t.dataset.roleField==='name'&&t.value.trim())role().name=t.value.trim();
 else if(t.dataset.roleField==='count')role().count=t.valueAsNumber;
 else if(t.dataset.factionName&&t.value.trim())E.renameFaction(board,Number(t.dataset.factionName),t.value);
 else if(t.dataset.eventValue)activeCampRule().events.find(x=>x.id===t.dataset.eventValue).value=t.valueAsNumber;
 else if(t.dataset.eventWeight)activeCampRule().events.find(x=>x.id===t.dataset.eventWeight).weight=t.valueAsNumber;
 else if(t.dataset.skillParam){const r=role();r.skillOverrides[paramSkill]||={};r.skillOverrides[paramSkill][t.dataset.skillParam]=t.valueAsNumber;}
 else if(t.dataset.stageParam){const r=role();r.skillOverrides[paramSkill]||={};r.skillOverrides[paramSkill].stages||={};r.skillOverrides[paramSkill].stages[t.dataset.stage]||={};r.skillOverrides[paramSkill].stages[t.dataset.stage][t.dataset.stageParam]=t.valueAsNumber;}
 else return;
 mark();refreshInline();
 if(tab==='factions'){
  const assigned=board.factions.reduce((n,f)=>n+board.room.counts[f.id],0),status=$('.faction-total>span');
  status.className=assigned===board.room.total?'ok':'danger';status.textContent='已分配 '+assigned+' 人'+(assigned===board.room.total?' · 人数一致':assigned<board.room.total?' · 还需分配 '+(board.room.total-assigned)+' 人':' · 超出 '+(assigned-board.room.total)+' 人');
  for(const f of board.factions){const p=E.poolStats(board,f.id),node=document.querySelector(`[data-faction-card="${f.id}"] .faction-pool-count`);if(node)node.textContent=p.candidates+' 个候选 · 随机选出 '+p.seats+' 人';}
 }
 }catch{ /* The change handler gives a final validation message on blur. */ }});
try{const saved=localStorage.getItem(AUTOSAVE);if(saved){const raw=JSON.parse(saved);board=E.validateShape(raw);if(raw.schema!==E.SCHEMA){localStorage.setItem(STORE+'-pre-v027',saved);setTimeout(()=>toast('旧草稿已恢复'),500);}selected=board.roles[0]?.uid||'';$('#save-state').textContent='已恢复草稿';}}catch{}
render();
if(window.GgdBoot)window.GgdBoot.ready();

function customBaseSummary(){return board.factions.filter(f=>f.kind==='custom').map(f=>`<div class="goal-review-row"><strong>${esc(f.name)} · 原有条件</strong><p>${esc(E.baseVictory(f.baseVictory)?.name||'未选择原有条件，使用新增目标')}</p></div>`).join('');}
