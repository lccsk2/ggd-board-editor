'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 手机横屏版 · 操作与启动
 * 所有按钮通过 data-act 分发到这里；输入框、开关、滑杆在 change / input 里处理。
 */
const cleanError = err => String(err && err.message || err).replace(/^[A-Z][A-Z0-9_]+:\s*/, '');

/* ---------- 按页重置 ---------- */
function resetPageData(source, page, roleUid) {
  const b = clone(source), defaults = E.defaultBoard();
  if (page === 'room') b.room = {...defaults.room, counts: clone(b.room.counts)};
  else if (page === 'lineup') {
    const previous = b.roles;
    b.factions = clone(defaults.factions);
    b.room.counts = clone(defaults.room.counts);
    b.roles = defaults.roles.map(r => {
      const saved = previous.find(p => !E.isCustom(p) && p.templateCareerId === r.templateCareerId);
      return saved ? {...clone(saved), count: r.count} : r;
    });
    E.ensureCampRules(b);
  } else if (page === 'wins') {
    for (const f of b.factions) if (f.kind === 'custom') f.baseVictory = null;
    b.campEvents = b.factions.map(f => ({key: 'camp-' + f.id, camp: f.id, join: 'any', events: []}));
  } else if (page === 'role') {
    const r = b.roles.find(r => r.uid === roleUid); if (!r) throw Error('请先选择角色');
    const fresh = E.isCustom(r) ? E.makeCustomRole(b, 1) : E.makeRole(r.templateCareerId);
    r.slots = clone(fresh.slots); r.skillOverrides = {};
  }
  return b;
}
function resetScope() {
  const r = role(), page = ui.page === 'roles' && r ? 'role' : ui.page;
  return {
    page,
    ...({
      info: {label: '', text: '', note: ''},
      roles: {label: '', text: '', note: ''},
      room: {label: '房间设置', text: '把人数、节奏、会议和房规恢复成默认值。', note: '板子的名字和介绍、阵营、角色和胜利条件不变。'},
      lineup: {label: '阵容', text: '恢复初始阵容：鹅 6 人、鸭 2 人、中立 2 人，以及 10 个经典角色。房间总人数不变。', note: '自建阵营、自创角色和后来添加的职业会一起移除；经典角色改过的技能会保留。'},
      wins: {label: '胜利条件', text: '清空所有阵营的额外胜利条件。', note: '鹅、鸭、中立的原有条件不受影响。'},
      role: {label: r ? r.name + '的技能' : '技能', text: r ? (E.isCustom(r) ? '清空「' + esc(r.name) + '」的全部技能和参数调整。' : '把「' + esc(r.name) + '」恢复成工坊预设技能，参数调整也会清掉。') : '', note: ''},
      play: {label: '本局名单', text: '', note: ''}
    }[page])
  };
}
function askPageReset() {
  const scope = resetScope();
  if (!scope.label) return;
  if (scope.page === 'play') { draw = null; drawError = ''; scenario = null; simRun = false; render(); toast('名单已清空'); return; }
  confirmDialog({
    title: '重置' + nameHtml(scope.label) + '？', text: scope.text, note: [scope.note, '重置后可以马上撤销。'].filter(Boolean).join(''), ok: '重置', danger: true,
    onOk() {
      const s = snapshot('重置' + scope.label);
      board = resetPageData(board, scope.page, role()?.uid);
      if (ui.roleUid && !role()) ui.roleUid = '';
      commit({undo: s, say: scope.label + '已重置'});
    }
  });
}
function askResetAll() {
  confirmDialog({
    title: '重置全部设置？', text: '把这块板子的名字、房间、阵营、角色、技能和胜利条件都恢复成初始的经典 10 人局。', note: '本机存档不受影响。重置后可以撤销，也能在“板子”页恢复被替换前的草稿。', ok: '全部重置', danger: true,
    onOk() {
      const s = snapshot('重置全部');
      try { localStorage.setItem(RECOVERY, JSON.stringify(E.exportDraft(board))); } catch { /* 备份失败不拦着重置 */ }
      board = E.defaultBoard(); resetUi(); closeAllLayers(true);
      commit({undo: s, say: '已全部重置'});
    }
  });
}

/* ---------- 操作 ---------- */
const ACT = {
  go(el) { go(el.dataset.page); },
  'go-wins'(el) { go('wins', {flash: `[data-wcol="${Number(el.dataset.camp)}"]`}); },
  check() { if (topLayer()?.name !== 'check') openCheck(); },
  undo() { doUndo(); },
  close() { closeLayer(); },
  'dialog-ok'() { const L = topLayer(); if (!L) return; const fn = L.onOk; closeLayer(true); if (fn) fn(); renderLayers(); },
  seg(el) { const {seg, key} = el.dataset; if (seg === 'room') ui.roomTab = key; else if (seg === 'play') ui.playTab = key; render(); },
  guide() { openGuide(); },

  /* 房间与席位 */
  preset(el) { if (setTotal(Number(el.dataset.n))) finishBound('total'); },
  'reset-page'() { askPageReset(); },
  'reset-all'() { askResetAll(); },
  fix(el) {
    const issue = checkReport[Number(el.dataset.i)], fix = issue && issueFix(issue); if (!fix) return;
    const s = snapshot(fix.label); fix.run();
    commit({undo: s, say: '已处理：' + fix.label});
  },
  issue(el) { const issue = checkReport[Number(el.dataset.i)]; if (issue) goIssue(issue); },
  'issue-room'(el) {
    const issue = checkReport[Number(el.dataset.i)]; if (!issue) return;
    const reports = E.campRule(board, issue.camp)?.events.some(e => e.type === 'reports') && !board.room.allow_report_dead;
    ui.roomTab = reports ? 'rules' : 'meeting';
    go('room', {flash: `[data-field="${reports ? 'allow_report_dead' : 'meeting_amount'}"]`});
  },

  /* 阵营 */
  'add-faction'() {
    const f = E.addFaction(board);
    closeAllLayers(true); ui.page = 'lineup'; ui.roleUid = ''; ui.flash = `[data-lane="${f.id}"]`;
    commit(); openFaction(f.id);
  },
  faction(el) { openFaction(el.dataset.camp); },
  // 删除自建阵营只清掉它自己的席位、角色和胜利条件；可撤销。
  'del-faction'(el) {
    const id = Number(el.dataset.camp), f = E.faction(board, id); if (!f || f.kind !== 'custom') return;
    const members = rolesOf(id), seats = board.room.counts[id] || 0, conds = E.campRule(board, id).events.length;
    const run = () => {
      const s = snapshot('删除' + f.name);
      board.room.counts[id] = 0;
      for (const r of members) E.removeRole(board, r.uid);
      E.removeFaction(board, id);
      closeAllLayers(true); if (!role()) ui.roleUid = '';
      commit({undo: s, say: '已删除' + f.name});
    };
    if (!members.length && !seats && !conds) return run();
    const lose = [members.length ? `阵营里的 ${members.length} 个角色` : '', conds ? `${conds} 个胜利条件` : ''].filter(Boolean).join('和');
    confirmDialog({title: '删除「' + esc(f.name) + '」？', text: nums([lose ? lose + '会一起删除。' : '', seats ? `这个阵营的 ${seats} 个席位会一起移除，其他阵营人数不变。` : ''].filter(Boolean).join('')), note: '删除后可以马上撤销。', ok: '删除', danger: true, onOk: run});
  },

  /* 角色 */
  'add-role'(el) { const camp = Number(el.dataset.camp); closeAllLayers(true); if (ui.page !== 'lineup') { ui.page = 'lineup'; ui.roleUid = ''; render(); } openAddRole(camp); },
  // 点一个角色：到“角色”页编辑它。从阵容点进来的，编辑完回阵容。
  role(el) { go('roles', {uid: el.dataset.uid, from: ui.page}); },
  back() {
    const uid = ui.roleUid, to = ui.roleBack === 'lineup' ? 'lineup' : 'roles';
    go(to, {flash: to === 'lineup' ? `.tok[data-uid="${cssEsc(uid)}"]` : `[data-rc="${cssEsc(uid)}"]`});
  },
  'role-filter'(el) { ui.roleFilter = el.dataset.key; render(); const list = $('#stage .rc-scroll'); if (list) list.scrollTop = 0; },
  // 添加已有职业（角色页）：整屏清单，鹅、鸭、中立之间可以切换。
  'add-career'(el) { if (topLayer()?.name !== 'add-career') openCareerPick(el.dataset.camp); },
  'career-camp'(el) { const L = topLayer(); if (L?.name !== 'add-career') return; L.camp = Number(el.dataset.camp); renderLayers(); const list = $('#career-list'); if (list) list.parentElement.scrollTop = 0; },
  // 新建角色（角色页）：先在面板里起名字、选阵营。
  'create-role'(el) { if (topLayer()?.name !== 'new-role') openNewRole(el.dataset.camp); },
  'new-role-camp'(el) { const L = topLayer(); if (L?.name !== 'new-role') return; L.camp = Number(el.dataset.camp); renderLayers(); },
  'new-role-ok'() {
    const L = topLayer(); if (L?.name !== 'new-role') return;
    const name = String($('[data-field="new-role-name"]')?.value ?? L.roleName).trim().slice(0, 20);
    if (!name) throw Error('先给角色起个名字');
    if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('角色池最多 ' + E.MAX_POOL_ROLES + ' 个角色');
    const r = E.makeCustomRole(board, L.camp); r.name = name; board.roles.push(r);
    closeAllLayers(true); ui.page = 'roles'; ui.roleUid = r.uid; ui.roleBack = 'roles';
    commit({say: '已创建「' + name + '」，接着给它挑技能'});
  },
  'copy-role'() { copyRole(ui.roleUid); },
  'reset-role'() { askPageReset(); },
  'remove-role'(el) {
    const fromLineup = el.hasAttribute('data-uid');
    const r = role(fromLineup ? el.dataset.uid : ui.roleUid); if (!r) return;
    const run = () => {
      const s = snapshot('移出' + r.name);
      E.removeRole(board, r.uid);
      if (!fromLineup) {
        ui.roleUid = '';
        if (ui.roleBack === 'lineup') { ui.page = 'lineup'; ui.flash = `[data-lane="${r.camp}"]`; }
      }
      commit({undo: s, say: '已把「' + r.name + '」移出角色池'});
    };
    if (E.isCustom(r)) confirmDialog({title: '删除「' + esc(r.name) + '」？', text: '这个自创角色和它的技能设置会从板子里移除。', note: '删除后可以马上撤销。', ok: '删除', danger: true, onOk: run}); else run();
  },
  'move-role'() { openMoveRole(); },
  'set-camp'(el) {
    const r = role(), camp = Number(el.dataset.camp); if (!r) return;
    if (camp === r.camp) { closeLayer(); return; }
    E.setRoleCamp(board, r, camp); closeLayer(true);
    commit({say: '已移到' + campName(camp) + '，跟着它的胜利条件走'});
  },
  art() { openArt(); },
  'pick-career'(el) {
    const c = E.careers.get(Number(el.dataset.id)), L = topLayer();
    if (!c || !E.classicCareerIds.has(c.id) || (L && L.camp !== c.camp)) throw Error('请选择当前阵营的已有职业');
    if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('角色池最多 ' + E.MAX_POOL_ROLES + ' 个角色');
    E.addCareer(board, c.id);
    commit();
  },
  'new-role'(el) {
    const camp = Number(el.dataset.camp);
    if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('角色池最多 ' + E.MAX_POOL_ROLES + ' 个角色');
    const r = E.makeCustomRole(board, camp); r.name = nextCustomName(); board.roles.push(r);
    closeAllLayers(true); ui.page = 'roles'; ui.roleUid = r.uid; ui.roleBack = 'lineup';
    commit();
  },
  'paste-role'(el) {
    const from = topLayer()?.name === 'new-role' ? 'roles' : 'lineup', r = pasteRole(el.dataset.camp);
    closeAllLayers(true); ui.page = 'roles'; ui.roleUid = r.uid; ui.roleBack = from;
    commit({say: '已粘贴「' + r.name + '」到' + campName(r.camp) + (E.compatibilityIssues(r).length ? '；有技能在这里暂不可用，请处理' : '')});
  },
  'move-in'(el) {
    const r = role(el.dataset.uid), camp = Number(el.dataset.camp); if (!r) return;
    E.setRoleCamp(board, r, camp);
    commit({say: '已把「' + r.name + '」移到' + campName(camp)});
  },

  /* 技能 */
  'skill-lib'() { openLib(); },
  skill(el) { openSkill(Number(el.dataset.id)); },
  'lib-type'(el) { lib.type = el.dataset.key; lib.module = 'all'; renderLayers(); const list = $('#lib-list'); if (list) list.parentElement.scrollTop = 0; },
  'lib-mod'(el) { lib.module = el.dataset.key; renderLayers(); const list = $('#lib-list'); if (list) list.parentElement.scrollTop = 0; },
  'lib-add'(el) {
    const r = role(), id = Number(el.dataset.id); if (!r) return;
    E.addSkill(r, id, 'auto');
    commit();
  },
  'lib-remove'(el) {
    const r = role(), id = Number(el.dataset.id); if (!r) return;
    const s = snapshot('移除' + E.playerSkill(id).name);
    E.removeSkill(r, id);
    commit({undo: s, say: '已移除「' + E.playerSkill(id).name + '」'});
  },
  uses(el) {
    const r = role(); if (!E.canEditEquippedSkill(r, paramSkill)) return;
    (r.skillOverrides[paramSkill] ||= {})[el.dataset.key] = Number(el.dataset.v);
    commit();
  },
  'skill-reset'() { const r = role(); if (!E.canEditEquippedSkill(r, paramSkill)) return; E.resetSkillParameters(r, paramSkill); commit({say: '已恢复默认参数'}); },
  'skill-remove'(el) {
    const r = role(), id = Number(el.dataset.id); if (!r) return;
    const name = E.playerSkill(id)?.name || '技能', s = snapshot('移除' + name);
    E.removeSkill(r, id, el.dataset.slot); closeLayer(true);
    commit({undo: s, say: '已移除「' + name + '」'});
  },
  'strip-skills'() {
    const r = role(); if (!r) return;
    const s = snapshot('移除不可用的技能');
    for (const id of [...new Set(E.allIds(r))]) if (E.skillMountIssue(r, id)) E.removeSkill(r, id);
    for (const sk of E.equippedSkills(r)) if (skillState(r, sk).broken) E.removeSkill(r, sk.id);
    commit({undo: s, say: '已移除不可用的技能'});
  },

  /* 胜利条件 */
  'add-cond'(el) { openAddCond(el.dataset.camp); },
  'pick-cond'(el) {
    if (topLayer()?.name !== 'add-cond') return;
    closeLayer(true); openCondEditor(Number(el.dataset.camp), el.dataset.type);
  },
  'cond-select'(el) { const L=topLayer(); if (L?.name==='cond') changeConditionScope(L, el.dataset.mode); },
  'cond-save'() { const L=topLayer(); if (L?.name==='cond') saveConditionScope(L); },
  cond(el) { openCond(el.dataset.id); },
  'cond-remove'(el) {
    const hit = findEvent(el.dataset.id); if (!hit) return;
    const name = E.eventCatalog[hit.event.type].name, s = snapshot('移除' + name);
    E.removeCampEvent(board, hit.rule.camp, hit.event.id); closeLayer(true);
    commit({undo: s, say: '已从' + campName(hit.rule.camp) + '移除「' + name + '」'});
  },
  'cond-cap'(el) {
    const hit = findEvent(el.dataset.id); if (!hit) return;
    const limit = goalLimit(hit.rule.camp, hit.event.type); if (!Number.isFinite(limit) || limit < 1) return;
    hit.event.value = Math.min(hit.event.value, limit); commit({say: '目标已调到 ' + hit.event.value});
  },
  'cond-room'(el) {
    const hit = findEvent(el.dataset.id), reports = hit && hit.event.type === 'reports' && !board.room.allow_report_dead;
    ui.roomTab = reports ? 'rules' : 'meeting';
    go('room', {flash: `[data-field="${reports ? 'allow_report_dead' : 'meeting_amount'}"]`});
  },
  'neutral-base'() { openNeutralBase(); },
  'win-help'() { openWinHelp(); },

  /* 试玩 */
  draw(el) {
    try { draw = E.drawPool(board); drawError = ''; scenario = null; simRun = false; justDrew = true; }
    catch (error) { draw = null; drawError = cleanError(error); }
    closeAllLayers(true);
    if (ui.page !== 'play') { ui.page = 'play'; ui.roleUid = ''; }
    if (!(ui.playTab === 'sim' && draw && el.closest('.side-card'))) ui.playTab = 'cast';
    render();
  },
  'sim-group'(el) { simGroup = el.dataset.key; scenario = {progress: {}, eligibleAlive: true, originalWinner: ''}; simRun = false; render(); },
  'sim-orig'(el) { if (!scenario) return; scenario.originalWinner = el.dataset.key; simRun = false; render(); },
  'sim-run'() { simRun = true; render(); const res = $('.sim-res'); if (res) res.scrollIntoView({block: 'nearest'}); },

  /* 存档、导入导出 */
  export() { if (topLayer()?.name !== 'export') openExport(); },
  import() { if (topLayer()?.name !== 'import') openImport(); },
  'import-file'() { $('#file-import').click(); },
  'import-text'() { importPasted(); },
  'copy-export'() { copyExport(); },
  download() { download(); },
  'share-export'() { shareExport(); },
  save() { saveSlot(); },
  'load-save'(el) { const item = readSaves()[Number(el.dataset.i)]; if (item) replaceBoard(item.board, '已打开存档「' + item.name + '」，原来的草稿已备份'); },
  'del-save'(el) { const saves = readSaves(); saves.splice(Number(el.dataset.i), 1); try { localStorage.setItem(STORE, JSON.stringify(saves)); } catch { /* 忽略 */ } render(); toast('存档已删除'); },
  recover() { const b = JSON.parse(localStorage.getItem(AUTOSAVE) || 'null'); if (!b) throw Error('还没有自动保存的草稿'); replaceBoard(b, '已恢复上次自动保存的草稿'); },
  'recover-prev'() { const b = JSON.parse(localStorage.getItem(RECOVERY) || 'null'); if (!b) throw Error('还没有被替换过的草稿'); replaceBoard(b, '已恢复被替换前的草稿'); },
  example() {
    confirmDialog({title: '载入示例板子？', text: '一块 58 个角色的大角色池：鹅 30 选 6、鸭 20 选 2、中立 8 选 2，每局随机出场。', note: '现在的草稿会先备份，之后能在“板子”页恢复。', ok: '载入示例', onOk() { replaceBoard(E.poolExample(), '已载入示例板子，原来的草稿已备份'); }});
  }
};

/* ---------- 事件 ---------- */
document.addEventListener('click', e => {
  // 正在输入框里打字时点了别的地方：先把输入的内容提交。手机上点按钮不一定会让输入框失焦，不这样做，打的字可能丢。
  const typing = isTyping() ? document.activeElement : null;
  if (typing && e.target !== typing && !e.target.closest('label')?.contains(typing)) typing.blur();
  const stepBtn = e.target.closest('.stp-b');
  if (stepBtn) {
    if (stepBtn.disabled || Date.now() - holdSuppress < 450) return;
    try { stepOnce(stepBtn); } catch (err) { toast(cleanError(err)); render(); }
    return;
  }
  const el = e.target.closest('[data-act]'); if (!el || el.disabled) return;
  const fn = ACT[el.dataset.act]; if (!fn) return;
  // 页面还没来得及按最新的检查结果重画时，按序号指向检查结果的按钮先不执行，重画后再点。
  if (renderPending && ['fix', 'issue', 'issue-room'].includes(el.dataset.act)) { render(); return; }
  try { fn(el, e); } catch (err) { toast(cleanError(err)); }
});
document.addEventListener('pointerdown', e => {
  pointerDown = true; pointerDownAt = Date.now();
  const b = e.target.closest('.stp-b');
  if (b && !b.disabled && !(e.pointerType === 'mouse' && e.button !== 0)) holdArm(b);
}, true);
// 松手后等这一下 click 派发完，再把“手指按着”的标记放下（见 renderSoon）。
for (const type of ['pointerup', 'pointercancel']) window.addEventListener(type, () => { holdRelease(); setTimeout(() => { pointerDown = false; }, 0); }, true);
window.addEventListener('blur', () => { holdRelease(); pointerDown = false; });
document.addEventListener('contextmenu', e => { if (e.target.closest('.stp-b, .tok, .rail, .seat')) e.preventDefault(); });
// iOS 上要有一个 touchstart 监听，按钮的 :active 按压反馈才会生效。
document.addEventListener('touchstart', () => {}, {passive: true});

// 点进数字或名字输入框时全选，直接打字就能替换。只在它还聚焦、内容没动过时才选：
// 这一步排在下一帧，要是那时玩家已经打了字或者离开了输入框，再全选会把刚打的字盖掉，或者把键盘又叫出来。
let nameBefore = '';   // 进入名字输入框时的名字：清空后失焦，就退回它
document.addEventListener('focusin', e => {
  const t = e.target;
  if (t instanceof HTMLInputElement && ['role-name', 'mod-name'].includes(t.dataset.field)) nameBefore = t.dataset.field === 'role-name' ? (role()?.name ?? '') : board.boardName;
  if (!(t instanceof HTMLInputElement) || !(t.type === 'number' || ['role-name', 'new-role-name'].includes(t.dataset.field))) return;
  const before = t.value;
  requestAnimationFrame(() => { try { if (document.activeElement === t && t.value === before) t.select(); } catch { /* 忽略 */ } });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && layers.length) { e.preventDefault(); closeLayer(); return; }
  if (e.key === 'Enter' && e.target instanceof HTMLInputElement && e.target.dataset.field === 'new-role-name') { e.preventDefault(); e.target.blur(); try { ACT['new-role-ok'](); } catch (err) { toast(cleanError(err)); } return; }
  if (e.key === 'Enter' && e.target instanceof HTMLInputElement && e.target.type !== 'search') { e.target.blur(); return; }
  // Ctrl/⌘ + C 复制自创角色，Ctrl/⌘ + V 粘贴：只在角色页、焦点不在输入框、没有弹层、没有选中文字时接管。
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.isComposing || layers.length || !['lineup', 'roles'].includes(ui.page)) return;
  const key = e.key.toLowerCase(); if (key !== 'c' && key !== 'v') return;
  const t = e.target instanceof Element ? e.target : document.body;
  if (t.closest('input,textarea,select,[contenteditable="true"]')) return;
  try {
    if (key === 'c') { if (String(getSelection() || '').trim() || !role()) return; e.preventDefault(); copyRole(ui.roleUid); }
    else {
      if (!roleClip) return;
      const usable = id => Number.isInteger(id) && id !== 3 && !!E.faction(board, id);
      const camp = [role()?.camp, roleClip.camp, ...board.factions.map(f => f.id)].map(x => x == null ? NaN : Number(x)).find(usable);
      if (camp == null) return;
      e.preventDefault(); const from = ui.page === 'roles' ? ui.roleBack : 'lineup', r = pasteRole(camp);
      ui.page = 'roles'; ui.roleUid = r.uid; ui.roleBack = from === 'lineup' ? 'lineup' : 'roles';
      commit({say: '已粘贴「' + r.name + '」到' + campName(camp)});
    }
  } catch (error) { toast(cleanError(error)); }
});
document.addEventListener('input', e => {
  const t = e.target;
  try {
    if (t.dataset.search === 'career') { careerSearch = t.value; const L = topLayer(), list = $('#career-list'); if (L && list) { list.innerHTML = careerList(L.camp); list.parentElement.scrollTop = 0; } return; }
    if (t.dataset.search === 'skill') { lib.search = t.value; const list = $('#lib-list'), r = role(); if (list && r) { list.innerHTML = libList(r); list.parentElement.scrollTop = 0; } return; }
    if (t.type === 'range' && t.dataset.bind) { bindWrite(t.dataset.bind, Number(t.value)); setPct(t); syncBound(); return; }
    // 文字边输入边生效，不重画正在编辑的输入框；空名字等失焦时再提示。稍停一下就自动保存，免得没来得及失焦就丢了。
    const field = t.dataset.field;
    if (field === 'role-name') { const r = role(), v = t.value.trim(); if (r && v) { r.name = v.slice(0, 20); const h = $('#stage .ph h1'); if (h) h.innerHTML = nameHtml(r.name); saveTextSoon(); } }
    else if (field === 'mod-name') { const v = t.value.trim(); if (v) { board.boardName = v.slice(0, 40); saveTextSoon(); } }
    else if (field === 'mod-desc') { board.description = t.value.slice(0, 300); const n = $('[data-count="mod-desc"]'); if (n) n.textContent = [...board.description].length + '/300'; saveTextSoon(); }
    else if (field === 'new-role-name') { const L = topLayer(); if (L?.name === 'new-role') L.roleName = t.value; }
  } catch { /* 失焦时的 change 会给出最终提示 */ }
});
let textSaveTimer = 0;
function saveTextSoon() { clearTimeout(textSaveTimer); textSaveTimer = setTimeout(autosave, 500); }
document.addEventListener('change', e => {
  const t = e.target;
  // 输入框失焦带来的改动先保存、稍后重画（见 commit）；开关、滑杆是玩家直接点的那个控件，立刻重画。
  softRender = t instanceof HTMLTextAreaElement || (t instanceof HTMLInputElement && ['text', 'number', 'search'].includes(t.type));
  try {
    if (t.id === 'file-import') { importFile(t.files[0]); return; }
    if (t.dataset.search) return;
    if (t.type === 'range' && t.dataset.bind) { commit(); return; }
    const stp = t.closest('.stp');
    if (stp && t.type === 'number') {
      const bind = stp.dataset.bind, s = bindSpec(bind);
      try { bindWrite(bind, t.valueAsNumber); } catch (err) { t.value = s ? s.value : ''; throw err; }
      const after = bindSpec(bind);
      if (s && after && after.value !== s.value) { finishBound(bind); syncBound(); } else { t.value = after ? after.value : t.value; }
      return;
    }
    if (t.dataset.toggle) { board.room[t.dataset.toggle] = t.checked; commit(); return; }
    if (t.hasAttribute('data-scope-camp')) {
      const L=topLayer(); if (L?.name==='cond') changeConditionScope(L, null, Number(t.dataset.scopeCamp), t.checked);
      return;
    }
    if (t.hasAttribute('data-sim-alive')) { if (scenario) { scenario.eligibleAlive = t.checked; simRun = false; render(); } return; }
    if (t.hasAttribute('data-lib-all')) { lib.showAll = t.checked; renderLayers(); const list = $('#lib-list'); if (list) list.parentElement.scrollTop = 0; return; }
    const field = t.dataset.field;
    if (field === 'role-name') { const r = role(); if (!r) return; if (!t.value.trim()) { r.name = nameBefore || r.name; t.value = r.name; const h = $('#stage .ph h1'); if (h) h.innerHTML = nameHtml(r.name); saveText(); throw Error('角色名字不能为空'); } r.name = t.value.trim().slice(0, 20); t.value = r.name; saveText(); const h = $('#stage .ph h1'); if (h) h.innerHTML = nameHtml(r.name); return; }
    if (field === 'faction-name') {
      const camp = Number(t.dataset.camp);
      try { E.renameFaction(board, camp, t.value); } catch (err) { t.value = E.faction(board, camp)?.name ?? t.value; throw err; }
      const f = E.faction(board, camp); t.value = f.name; saveText();
      $$(`.lane[data-lane="${camp}"] .lane-name b`).forEach(n => { n.innerHTML = nameHtml(f.name); });
      renderSoon();   // 别处也写着阵营名（筛选、提示文字），稍后整页重画一次
      return;
    }
    if (field === 'mod-name') { if (!t.value.trim()) { board.boardName = nameBefore || board.boardName; t.value = board.boardName; saveText(); throw Error('板子名字不能为空'); } board.boardName = t.value.trim().slice(0, 40); t.value = board.boardName; saveText(); return; }
    if (field === 'mod-desc') { board.description = t.value.slice(0, 300); saveText(); return; }
  } catch (err) { toast(cleanError(err)); } finally { softRender = false; }
});

/* ---------- 启动 ---------- */
// 核对实际载入的规则版本，避免旧脚本在新版界面中继续运行。
if (document.querySelector('meta[name="ggd-editor-version"]').content !== 'mobile-' + E.WORKSHOP_RULES_VERSION) {
  window.GgdBoot?.failed('RULE_VERSION', '请重新打开「打开最新版工坊.html」或刷新此页。');
  throw Error('编辑器与技能规则版本不一致。');
}
let bootNote = '';
try {
  const saved = localStorage.getItem(AUTOSAVE);
  if (saved) {
    const raw = JSON.parse(saved); board = E.validateShape(raw);
    const note = normalizeNote(normalizeBoard(board));
    if (note) { try { localStorage.setItem(AUTOSAVE, JSON.stringify(E.exportDraft(board))); } catch { /* 忽略 */ } bootNote = '草稿已按新规则更新：' + note; }
    else if (raw.schema !== E.SCHEMA) { try { localStorage.setItem(STORE + '-pre-v027', saved); } catch { /* 忽略 */ } bootNote = '旧版草稿已恢复'; }
    saveNote = '已恢复上次的草稿';
  }
} catch { board = E.defaultBoard(); }
E.ensureCampRules(board); revalidate(); render();
if (window.GgdBoot) window.GgdBoot.ready();
if (parent !== window && window.name === 'ggd-iphone17-screen') {
  parent.postMessage({type:'ggd-mobile:ready', version:E.WORKSHOP_RULES_VERSION, activeLimit:E.MAX_ACTIVE_SKILLS}, location.protocol === 'file:' ? '*' : location.origin);
}
if (bootNote) setTimeout(() => toast(bootNote), 600);
try { if (!localStorage.getItem(GUIDE_SEEN)) { localStorage.setItem(GUIDE_SEEN, '1'); setTimeout(openGuide, 350); } } catch { /* 存不了就不弹引导 */ }
