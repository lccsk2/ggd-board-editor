'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 手机横屏版 · 弹层内容
 * 右侧面板：检查、阵营、新建角色、技能参数、胜利条件、导入导出等；整屏清单：添加角色、技能库、胜利条件库、上手引导。
 */

/* ---------- 本机存档（列表在“板子”页） ---------- */
function readSaves() { try { const a = JSON.parse(localStorage.getItem(STORE) || '[]'); return Array.isArray(a) ? a : []; } catch { return []; } }
function saveSlot() {
  try {
    const saves = readSaves(), item = {id: Date.now().toString(), name: board.boardName, time: new Date().toISOString(), board: E.exportDraft(board)};
    saves.unshift(item); localStorage.setItem(STORE, JSON.stringify(saves.slice(0, 8)));
    render(); toast('已存到本机存档');
  } catch { toast('这台设备存不了，请改用“导出板子”'); }
}
function openGuide() {
  const steps = [
    ['board', '板子', '给这套玩法起个名字，写两句介绍。'],
    ['room', '房间', '定几个人玩，再看节奏、会议和房规。'],
    ['factions', '阵容', '给每个阵营分席位、放角色，也能新建阵营。'],
    ['char', '角色', '从零创造新角色，或者给已有角色换技能。'],
    ['wins', '胜利', '每个阵营怎么赢，还能加优先结算的额外条件。'],
    ['play', '试玩', '随机抽一桌看看效果，没问题就导出分享。']
  ];
  openLayer('overlay', () => overlayHead('六步做一套新玩法') + `<div class="ov-b guide"><ol class="guide-l">${steps.map(([art, t, p], i) => `<li><span class="guide-n num">${i + 1}</span>${sticker(art)}<span class="guide-m"><b>${t}</b><p>${p}</p></span></li>`).join('')}</ol><div class="guide-go"><span>左边的导航就是这六步，顺序随意，改动会自动保存。</span><button class="btn btn-primary" data-act="close" data-focus>开始动手</button></div></div>`, {name: 'guide'});
}

/* ---------- 检查：问题清单 + 一键修复 ---------- */
function checkView() {
  const errs = checkReport.filter(x => x.level === 'error'), warns = checkReport.filter(x => x.level === 'warn');
  const row = x => {
    const i = checkReport.indexOf(x), fix = issueFix(x);
    return `<div class="iss is-${x.level}"><span class="iss-ic">${icon(x.level === 'error' ? 'alert' : 'info')}</span><p>${nums(esc(issueText(x)))}</p><div class="iss-acts">${fix ? `<button class="btn btn-primary btn-sm" data-act="fix" data-i="${i}">${nums(esc(fix.label))}</button>` : ''}${x.code === 'MEETING_GOAL_UNREACHABLE' ? `<button class="btn btn-soft btn-sm" data-act="issue-room" data-i="${i}">会议设置</button>` : ''}<button class="btn btn-soft btn-sm" data-act="issue" data-i="${i}">去看看</button></div></div>`;
  };
  return sheetHead(errs.length ? nums(`还有 ${errs.length} 项要处理`) : '检查通过', errs.length ? '处理完这些，才能抽名单、正常开局。' : nums(`${board.room.total} 人 · ${board.factions.length} 个阵营 · ${board.roles.length} 个角色`)) + `
<div class="sh-b" data-keep="check">
  ${errs.length ? errs.map(row).join('') : `<div class="ok-card">${icon('check')}<div><b>人数、角色池和已知规则都没问题</b><p>去试玩抽一桌看看，或者直接导出。</p></div></div>`}
  ${warns.length ? `<h3 class="sh-sub">提醒<b class="num">${warns.length}</b></h3>${warns.map(row).join('')}` : ''}
</div>
<footer class="sh-f"><button class="btn btn-soft" data-act="go" data-page="play">${icon('dice')}去试玩</button><span class="grow"></span><button class="btn btn-primary" data-act="export">${icon('download')}导出板子</button></footer>`;
}
function openCheck() { openLayer('sheet', checkView, {name: 'check'}); }
function goIssue(issue) {
  const d = issueDest(issue);
  if (d.page === 'room') {
    ui.roomTab = Object.keys(ROOM_TABS).find(k => ROOM_TABS[k].includes(d.field)) || ui.roomTab;
    go('room', {flash: d.field ? `[data-field="${cssEsc(d.field)}"]` : '.tcard'});
  } else if (d.page === 'wins') go('wins', {flash: `[data-wcol="${Number(d.camp) || 1}"]`});
  else if (d.uid && role(d.uid)) go('roles', {uid: d.uid, flash: '.skills'});
  else go('lineup', {flash: d.camp ? `[data-lane="${Number(d.camp)}"]` : '.ph-seats'});
}

/* ---------- 阵营面板：改名、席位、待办、删除 ---------- */
function factionView(camp) {
  const f = E.faction(board, camp); if (!f) return null;
  const custom = f.kind === 'custom', p = E.poolStats(board, camp), rule = E.campRule(board, camp);
  const members = rolesOf(camp);
  const steps = custom ? [
    [p.seats > 0, '分席位', p.seats ? `每局出场 ${p.seats} 人` : '用上面的加号分几个席位'],
    [members.length > 0 && p.capacity >= p.seats, '放角色', members.length ? (p.capacity >= p.seats ? `${members.length} 个角色` : `角色不够，最多只能出场 ${p.capacity} 人`) : '还没有角色'],
    [rule.events.length > 0, '定胜利条件', rule.events.length ? `${rule.events.length} 个额外条件` : '还没有，这个阵营赢不了']
  ] : null;
  return sheetHead(custom ? '自建阵营' : nameHtml(f.name), f.id === 3 ? '中立玩家各自为战，各自获胜。' : custom ? '你自己的队伍，成员共同获胜。' : '成员共同获胜。') + `
<div class="sh-b" data-keep="faction" style="${fc(camp)}">
  ${custom ? `<label class="fld"><span>阵营名称</span><input type="text" data-field="faction-name" data-camp="${camp}" maxlength="20" value="${esc(f.name)}" autocomplete="off" enterkeyhint="done"></label>` : `<div class="fac-id">${emblem(f)}<div><b>${nameHtml(f.name)}</b><small>原有阵营，名字固定，不能删除</small></div></div>`}
  <div class="row-f"><span class="lab">出场人数</span>${seatGapTag()}${stepper('seat:' + camp, {unit: '人', label: f.name + '出场人数'})}</div>
  ${steps ? `<ul class="todo">${steps.map(([ok, t, s], i) => `<li class="${ok ? 'is-ok' : ''}">${icon(ok ? 'check' : 'alert')}<span><b>${t}</b><small>${nums(s)}</small></span>${i === 1 ? `<button class="btn btn-soft btn-sm" data-act="add-role" data-camp="${camp}">添加角色</button>` : i === 2 ? `<button class="btn btn-soft btn-sm" data-act="go-wins" data-camp="${camp}">去设置</button>` : ''}</li>`).join('')}</ul>`
    : `<div class="fac-row">${icon('trophy')}<div><em>怎么赢</em><p>${f.id === 3 ? '每个中立角色按自己的原条件各自获胜。' : esc(originalText(f))}${rule.events.length ? nums(` 另有 ${rule.events.length} 个额外条件。`) : ''}</p></div><button class="btn btn-soft btn-sm" data-act="go-wins" data-camp="${camp}">胜利条件</button></div>
       <div class="fac-row">${icon('users')}<div><em>角色池</em><p>${nums(esc(laneIssue(camp)?.text || poolNote(f, p).text))}</p></div><button class="btn btn-soft btn-sm" data-act="add-role" data-camp="${camp}">添加角色</button></div>`}
  ${custom ? `<div class="danger-zone"><button class="btn btn-ghost is-danger" data-act="del-faction" data-camp="${camp}">${icon('trash')}删除这个阵营</button></div>` : ''}
</div>`;
}
function openFaction(camp) { openLayer('sheet', L => factionView(L.camp), {name: 'faction', camp: Number(camp)}); }

/* ---------- 添加角色：已有职业 / 新建空白角色 / 粘贴 / 从别的阵营移入 ---------- */
let careerSearch = '';
function careerList(camp) {
  const pooled = new Map(); board.roles.forEach(r => pooled.set(r.templateCareerId, (pooled.get(r.templateCareerId) || 0) + 1));
  const q = careerSearch.trim();
  return D.career.filter(c => E.classicCareerIds.has(c.id) && c.camp === camp && (!q || c.name.includes(q) || c.des.includes(q))).map(c => {
    const st = E.careerAddStatus(board, c.id), n = pooled.get(c.id) || 0;
    const state = st.allowed ? `${icon('plus')}${n ? '再加一个' : '添加'}` : st.reason.includes('已添加') ? '已在角色池' : st.reason.includes('暂不可用') ? '暂不可用' : esc(st.reason);
    return `<button class="car ${n ? 'is-in' : ''}" data-act="pick-career" data-id="${c.id}" style="${fc(c.camp)}" ${st.allowed ? '' : 'disabled'} aria-label="${esc(c.name)}${n ? '，角色池里已有 ' + n + ' 个' : ''}"><span class="car-av">${avatar(c.id, c.camp)}${n ? `<i class="car-ck">${n > 1 ? '×' + n : icon('check')}</i>` : ''}</span><span class="car-m"><span class="car-top"><b>${esc(c.name)}</b><i class="car-s">${state}</i></span><small>${esc(c.des.trim())}</small></span></button>`;
  }).join('') || '<p class="muted">没有找到这个职业，换个词试试。</p>';
}
function addRoleView(camp) {
  const f = E.faction(board, camp); if (!f) return null;
  const builtin = camp <= 3, canCustom = camp !== 3;
  const movable = canCustom ? board.roles.filter(r => E.isCustom(r) && r.camp !== camp) : [];
  return overlayHead(`给${nameHtml(f.name)}添加角色`, `<span class="ov-note">${nums('角色池里有 ' + rolesOf(camp).length + ' 个')}</span><button class="btn btn-primary btn-sm" data-act="close">完成</button>`) + `
<div class="ov-b addrole ${builtin ? '' : 'is-custom'}" style="${fc(camp)}">
  <aside class="addrole-side scroll">
    ${canCustom ? `<button class="make" data-act="new-role" data-camp="${camp}">${artImg(CUSTOM_ICON, 'make-art', '', false)}<span><b>新建空白角色</b><small>从零开始，自己起名字、配技能</small></span></button>` : `<p class="note">${icon('info')}<span>中立阵营只能放已有职业，每个职业每局最多 1 个。</span></p>`}
    ${canCustom && roleClip ? `<button class="make is-paste" data-act="paste-role" data-camp="${camp}"><span class="make-ic">${icon('paste')}</span><span><b>粘贴「${esc(roleClip.name)}」</b><small>刚才复制的自创角色</small></span></button>` : ''}
    ${movable.length ? `<h3 class="sh-sub">从别的阵营移过来</h3>${movable.map(r => `<button class="mv" data-act="move-in" data-uid="${esc(r.uid)}" data-camp="${camp}">${avatar(null, r.camp, 'sm')}<span><b>${nameHtml(r.name)}</b><small>现在在${nameHtml(campName(r.camp))}</small></span>${icon('arrow')}</button>`).join('')}` : ''}
  </aside>
  ${builtin ? `<section class="addrole-main"><div class="lib-bar"><h3>已有职业</h3><span class="grow"></span><label class="search">${icon('search')}<input type="search" data-search="career" placeholder="搜职业" value="${esc(careerSearch)}" autocomplete="off" enterkeyhint="search"></label></div><div class="scroll lib-scroll" data-keep="careers"><div class="car-grid" id="career-list">${careerList(camp)}</div></div></section>`
    : `<section class="addrole-main is-empty">${emptyState('新阵营里放自创角色', '已有职业的阵营是固定的，放不进新阵营。新建一个空白角色，或者把别的阵营的自创角色移过来。')}</section>`}
</div>`;
}
function openAddRole(camp) { careerSearch = ''; openLayer('overlay', L => addRoleView(L.camp), {name: 'add-role', camp: Number(camp)}); }

/* ---------- 添加已有职业（在“角色”页）：三个原有阵营之间可以切换 ---------- */
function careerPickView(L) {
  const camps = board.factions.filter(f => f.id <= 3);
  if (!camps.some(f => f.id === L.camp)) L.camp = 1;
  return overlayHead('添加已有职业', `<span class="ov-note">${nums('角色池里有 ' + board.roles.length + ' 个角色')}</span><button class="btn btn-primary btn-sm" data-act="close">完成</button>`) + `
<div class="ov-b lib" style="${fc(L.camp)}">
  <div class="lib-bar">
    <div class="seg seg-sm" role="tablist">${camps.map(f => `<button class="seg-i ${f.id === L.camp ? 'is-on' : ''}" role="tab" aria-selected="${f.id === L.camp}" data-act="career-camp" data-camp="${f.id}">${esc(shortCamp(f))}<b>${rolesOf(f.id).length}</b></button>`).join('')}</div>
    <span class="lib-tip">${L.camp === 3 ? '中立职业每局最多 1 人，同一个只能加一次。' : '职业会加入它原本的阵营，加进来以后可以换技能。'}</span>
    <label class="search">${icon('search')}<input type="search" data-search="career" placeholder="搜职业" value="${esc(careerSearch)}" autocomplete="off" enterkeyhint="search"></label>
  </div>
  <div class="scroll lib-scroll" data-keep="careers"><div class="car-grid" id="career-list">${careerList(L.camp)}</div></div>
</div>`;
}
function openCareerPick(camp) {
  const id = Number(camp);
  careerSearch = ''; openLayer('overlay', L => careerPickView(L), {name: 'add-career', camp: id >= 1 && id <= 3 ? id : 1});
}

/* ---------- 新建角色：起名字、选阵营（在“角色”页） ---------- */
function newRoleView(L) {
  const camps = board.factions.filter(f => f.id !== 3);
  if (!camps.some(f => f.id === L.camp)) L.camp = camps[0]?.id ?? 1;
  return sheetHead('新建角色', '从零开始：先起名字、选阵营，再给它挑技能。') + `
<div class="sh-b" data-keep="new-role">
  <label class="fld"><span>角色名字</span><input type="text" data-field="new-role-name" maxlength="20" value="${esc(L.roleName)}" autocomplete="off" enterkeyhint="done"></label>
  <h3 class="sh-sub">放进哪个阵营<small>它怎么赢，跟着阵营走</small></h3>
  ${camps.map(f => `<button class="pick ${f.id === L.camp ? 'is-on' : ''}" data-act="new-role-camp" data-camp="${f.id}" style="${fc(f.id)}" aria-pressed="${f.id === L.camp}">${emblem(f)}<span><b>${nameHtml(f.name)}</b><small>${nums((board.room.counts[f.id] || 0) + ' 人出场 · ' + rolesOf(f.id).length + ' 个角色')}</small></span>${f.id === L.camp ? icon('check') : ''}</button>`).join('')}
  <p class="note">${icon('info')}<span>中立阵营只能放已有职业。想放进全新的阵营，先到「阵容」新增一个。</span></p>
</div>
<footer class="sh-f">${roleClip ? `<button class="btn btn-soft" data-act="paste-role" data-camp="${L.camp}">${icon('paste')}粘贴「${esc(roleClip.name)}」</button>` : ''}<span class="grow"></span><button class="btn btn-primary" data-act="new-role-ok">${icon('plus')}创建角色</button></footer>`;
}
function openNewRole(camp) {
  const id = Number(camp), ok = id && id !== 3 && E.faction(board, id);
  openLayer('sheet', L => newRoleView(L), {name: 'new-role', camp: ok ? id : 1, roleName: nextCustomName()});
}

/* ---------- 角色图像与技能一览 ---------- */
function openArt() {
  openLayer('overlay', () => {
    const r = role(); if (!r) return null;
    const custom = E.isCustom(r), c = custom ? null : E.careers.get(r.templateCareerId), a = roleArt(r), f = E.faction(board, r.camp);
    const skills = E.equippedSkills(r);
    return overlayHead(nameHtml(r.name), `<span class="tag is-fc" style="${fc(r.camp)}">${nameHtml(f?.name || '')}</span>`) + `
<div class="ov-b artv" style="${fc(r.camp)}">
  <div class="artv-pic ${a?.portrait ? '' : 'is-icon'}">${a?.portrait ? artImg(a.portrait, '', r.name + '立绘', false) : artImg(a?.icon, '', r.name + '图标', false)}</div>
  <div class="artv-info scroll">
    <div class="artv-top">${a?.portrait && a?.icon ? `<span class="ava lg" style="${fc(r.camp)}">${artImg(a.icon, '', '', false)}</span>` : ''}<p>${custom ? '自创角色：怎么赢跟着所属阵营走。' : esc(c.des.trim())}</p></div>
    <h3 class="sh-sub">现在带着的技能<b class="num">${skills.length}</b></h3>
    ${skills.map(s => `<div class="artv-sk">${skillIcon(s.id)}<span><b>${esc(s.name)}${s.type === 1 ? '<i class="tag">被动</i>' : ''}</b><small>${esc(s.des || '暂无说明')}</small></span></div>`).join('') || '<p class="muted">还没有技能。</p>'}
  </div>
</div>`;
  }, {name: 'art'});
}
function openMoveRole() {
  openLayer('sheet', () => {
    const r = role(); if (!r || !E.isCustom(r)) return null;
    return sheetHead('放到哪个阵营', '自创角色怎么赢，跟着所属阵营走。') + `<div class="sh-b">${board.factions.filter(f => f.id !== 3).map(f => `<button class="pick ${f.id === r.camp ? 'is-on' : ''}" data-act="set-camp" data-camp="${f.id}" style="${fc(f.id)}">${emblem(f)}<span><b>${nameHtml(f.name)}</b><small>${nums((board.room.counts[f.id] || 0) + ' 人出场 · ' + rolesOf(f.id).length + ' 个角色')}</small></span>${f.id === r.camp ? icon('check') : ''}</button>`).join('')}<p class="note">${icon('info')}<span>中立阵营只能放已有职业。</span></p></div>`;
  }, {name: 'move'});
}

/* ---------- 技能库：挑技能、连着加 ---------- */
const lib = {type: 'active', module: 'all', showAll: false, search: ''};
// 被动仅供查看，无须勾选「含未开放」；开关只筛选尚未开放的主动技能。
const visibleSkill = s => s.type === 1 || lib.showAll || s.mountStatus === 'open';
function libBase(type = lib.type) { return E.librarySkills({type}).filter(visibleSkill); }
function libModules() { return [...new Set(libBase().map(s => s.module || E.skillScope(s.id)?.module).filter(Boolean))]; }
function libRows() { return E.librarySkills({search: lib.search, type: lib.type, module: lib.module}).filter(visibleSkill); }
function libList(r) {
  const equipped = new Set(E.equippedSkills(r).map(s => s.id));
  return libRows().map(s => {
    const on = equipped.has(s.id), passive = s.type === 1;
    const compat = E.skillCompatibility(s.id, r), blocked = compat.level === 'error' && !on;
    const reason = compat.code === 'SKILL_SLOT_LIMIT' ? '主动槽已满' : ['SKILL_STATE_DEADLOCK','SKILL_FAMILY_CONFLICT'].includes(compat.code) ? '和已有技能冲突' : compat.code === 'SKILL_CONTEXT_ONLY' ? '要在对局中触发' : s.mountStatus === 'native-only' ? '只有原职业能用' : '以后再开放';
    const native = passive && on && E.isNativeSkill(r, s.sourceId);
    const badge = passive ? (on ? native ? `<i class="tag is-ok">${icon('check')}职业自带</i>` : '<i class="tag is-bad">需从角色移除</i>' : '') : on ? `<i class="tag is-ok">${icon('check')}已装备</i>` : blocked ? `<i class="tag is-off">${icon('lock')}${reason}</i>` : '';
    const button = passive ? `<button type="button" class="btn btn-soft btn-sm" data-id="${s.id}" disabled aria-label="${esc(s.name)}：被动技能不可分配">${icon('lock')}不可分配</button>` : on ? `<button class="btn btn-soft btn-sm" data-act="lib-remove" data-id="${s.id}">移除</button>` : `<button class="btn btn-primary btn-sm" data-act="lib-add" data-id="${s.id}" ${blocked ? 'disabled' : ''}>${icon('plus')}添加</button>`;
    return `<article class="ls ${on && (!passive || native) ? 'is-on' : ''} ${blocked && !passive ? 'is-off' : ''}">${skillIcon(s.id)}
  <div class="ls-m"><b>${esc(s.name)}</b><small>${esc(s.des || '暂无说明')}</small><span class="ls-f">${lib.type === 'all' ? `<i class="tag">${passive ? '被动' : '主动'}</i>` : ''}<i class="tag">${esc(s.module || '')}</i>${badge}</span></div>
  ${button}</article>`;
  }).join('') || '<p class="muted">没有找到技能，换个分类或关键词试试。</p>';
}
function libView() {
  const r = role(); if (!r) return null;
  const mods = libModules(); if (lib.module !== 'all' && !mods.includes(lib.module)) lib.module = 'all';
  return overlayHead(`给「${nameHtml(r.name)}」挑技能`, `<span class="ov-note">${nums('主动技能 ' + E.equippedSkills(r, {type:'active'}).length + ' / ' + E.MAX_ACTIVE_SKILLS)}</span><button class="btn btn-primary btn-sm" data-act="close">完成</button>`) + `
<div class="ov-b lib">
  <div class="lib-bar">
    <div class="seg seg-sm" role="tablist">${[['active', '主动'], ['passive', '被动'], ['all', '全部']].map(([k, l]) => `<button class="seg-i ${lib.type === k ? 'is-on' : ''}" role="tab" aria-selected="${lib.type === k}" data-act="lib-type" data-key="${k}">${l}<b>${libBase(k).length}</b></button>`).join('')}</div>
    <div class="chips-x" data-keep="lib-mods"><button class="chip ${lib.module === 'all' ? 'is-on' : ''}" data-act="lib-mod" data-key="all">全部类型</button>${mods.map(m => `<button class="chip ${lib.module === m ? 'is-on' : ''}" data-act="lib-mod" data-key="${esc(m)}">${esc(m)}</button>`).join('')}</div>
    <label class="check"><input type="checkbox" data-lib-all aria-label="显示尚未开放的主动技能" ${lib.type === 'passive' ? 'disabled' : ''} ${lib.showAll ? 'checked' : ''}><i aria-hidden="true"></i>含未开放</label>
    <label class="search">${icon('search')}<input type="search" data-search="skill" placeholder="搜技能" value="${esc(lib.search)}" autocomplete="off" enterkeyhint="search"></label>
  </div>
  <div class="scroll lib-scroll" data-keep="lib"><div class="ls-grid" id="lib-list">${libList(r)}</div></div>
</div>`;
}
function openLib() { if (!role()) return; lib.search = ''; openLayer('overlay', libView, {name: 'lib'}); }

/* ---------- 技能面板：说明、参数、移除 ---------- */
function skillView(id) {
  const r = role(); if (!r) return null;
  const entry = E.equippedSkills(r).find(x => x.id === id); if (!entry) return null;
  paramSkill = entry.sourceId;
  const st = skillState(r, entry), passive = entry.type === 1;
  const usable = E.allIds(r).includes(paramSkill) && !E.skillMountIssue(r, paramSkill) && !st.broken;
  let body;
  if (!passive && usable && !E.canEditEquippedSkill(r, paramSkill)) {
    body = `<p class="note bad">${icon('alert')}<span>主动技能超过 ${E.MAX_ACTIVE_SKILLS} 个。可以先移除任意一个，回到上限内就能调整参数。</span></p>`;
  } else if (!usable) {
    const reason = passive && !E.isNativeSkill(r, paramSkill) ? '这个角色不能携带其他职业的被动，请移除后再开局。' : st.incomplete && !st.outside && !st.restricted ? '这个技能的配置不完整，请移除后重新添加。' : '这个技能暂时不能用，请移除。';
    body = `<p class="note bad">${icon('alert')}<span>${reason}</span></p>`;
  }
  else {
    const s = E.effective(r, paramSkill), stage = s.stages[0], over = r.skillOverrides[paramSkill] || {}, stageOver = over.stages?.[stage?.id] || {};
    const uses = (key, label) => { const cur = s[key], vals = [...new Set([-1, 0, 1, 2, 3, 5, 10, cur])].sort((a, b) => a - b); return `<div class="pf"><span class="lab">${label}</span><div class="chips">${vals.map(v => `<button class="chip ${v === cur ? 'is-on' : ''}" data-act="uses" data-key="${key}" data-v="${v}" aria-pressed="${v === cur}">${v === -1 ? '不限' : v === 0 ? '禁用' : nums(v + ' 次')}</button>`).join('')}</div></div>`; };
    const num = (bind, label, unit) => `<div class="row-f"><span class="lab">${label}</span>${stepper(bind, {unit, label})}</div>`;
    const fields = [
      !passive || s.get_cd > 0 || over.get_cd !== undefined ? num('sp:get_cd', passive ? '生效前等待' : '开局后多久能用', '秒') : '',
      !passive || s.use_time > 0 || over.use_time !== undefined ? uses('use_time', passive ? '整局触发次数' : '整局能用几次') : '',
      !passive && s.skill_kind === 0 ? uses('meeting_use_time', '每次会议能用几次') : '',
      stage && (!passive || stage.meeting_cd > 0 || stageOver.meeting_cd !== undefined) ? num('st:' + stage.id + ':meeting_cd', '会议后等待', '秒') : '',
      stage && stage.cd_type <= 1 && (!passive || stage.cd_type_param_1 > 0 || stageOver.cd_type_param_1 !== undefined) ? num('st:' + stage.id + ':cd_type_param_1', stage.cd_type === 0 ? (passive ? '触发冷却' : '使用冷却') : '击倒冷却倍率', stage.cd_type === 0 ? '秒' : '%') : ''
    ].join('');
    body = fields ? `<div class="sec-h"><h2>参数</h2><span class="grow"></span>${st.tuned ? `<button class="link-btn" data-act="skill-reset">${icon('undo')}恢复默认</button>` : '<span class="sec-note">改动会自动保存</span>'}</div>${fields}` : `<p class="note">${icon('info')}<span>这个被动效果没有可调的次数或冷却。</span></p>`;
  }
  return sheetHead(esc(entry.name), passive ? (E.isNativeSkill(r, paramSkill) ? '职业自带的被动，不占主动技能名额' : '旧板子的被动效果') : entry.skill_kind === 0 ? '主动技能：在会议中使用' : '主动技能') + `
<div class="sh-b" data-keep="skill">
  <div class="skv">${skillIcon(entry.id, 'lg')}<p>${esc(entry.des || '暂无说明')}</p></div>
  ${body}
</div>
<footer class="sh-f"><button class="btn btn-ghost is-danger" data-act="skill-remove" data-id="${entry.id}" data-slot="${esc(entry.slot)}">${icon('trash')}移除技能</button><span class="grow"></span><button class="btn btn-primary" data-act="close">完成</button></footer>`;
}
function openSkill(id) {
  const r = role(), identity = E.playerSkill(id), entry = r && E.equippedSkills(r).find(x => x.id === identity?.id);
  if (!entry) return;
  openLayer('sheet', L => skillView(L.skillId), {name: 'skill', skillId: entry.id, onClose() { paramSkill = 0; }});
}

/* ---------- 胜利条件库：按类别分三栏，点一下就加 ---------- */
function addCondView(camp) {
  const f = E.faction(board, camp); if (!f) return null;
  const rule = E.campRule(board, camp), cats = [...new Set(Object.values(E.eventCatalog).map(d => d.category))], full = rule.events.length >= E.MAX_CAMP_EVENTS;
  return overlayHead(`给${nameHtml(f.name)}加一个胜利条件`, `<span class="ov-note">${nums(`已有 ${rule.events.length}/${E.MAX_CAMP_EVENTS} 个，完成任意一个就赢`)}</span>`) + `
<div class="ov-b addcond scroll" data-keep="addcond" style="${fc(camp)}">
  <div class="cc-cols">${cats.map(cat => `<section class="cc-col"><h3>${icon(CATEGORY_ICON[cat] || 'target')}${esc(cat)}</h3>${Object.keys(E.eventCatalog).filter(t => E.eventCatalog[t].category === cat).map(t => {
    const d = E.eventCatalog[t], mine = rule.events.find(e => e.type === t), others = condHolders(t).filter(x => x.id !== camp);
    return `<button class="cc ${mine ? 'is-in' : ''}" data-act="pick-cond" data-type="${t}" data-camp="${camp}" ${!mine && full ? 'disabled' : ''}><span class="cond-ic">${icon(condIcon(t))}</span><span class="cc-m"><b>${esc(d.name)}</b><small>${esc(campEventCopy(d.description, camp))}</small>${d.hint ? `<em>${icon('info')}${esc(d.hint)}</em>` : ''}</span><span class="cc-s">${mine ? `<i class="tag is-ok">${icon('check')}已添加</i>` : `<i class="tag">${nums(d.defaultValue + ' ' + esc(d.unit))}</i>`}${others.length ? `<span class="cc-o" title="别的阵营也在用">${others.slice(0, 4).map(x => emblem(x, 'xs')).join('')}</span>` : ''}</span></button>`;
  }).join('')}</section>`).join('')}</div>
</div>`;
}
function openAddCond(camp) { openLayer('overlay', L => addCondView(L.camp), {name: 'add-cond', camp: Number(camp)}); }

/* ---------- 条件详情沿用原右侧面板；在原阵营开关上批量选择 ---------- */
function campChoices(type) {
  return board.factions.map(f => {
    const rule = E.campRule(board, f.id), event = rule.events.find(e => e.type === type);
    return {f, event, available: !!event || rule.events.length < E.MAX_CAMP_EVENTS};
  });
}
function condSelection(L) {
  const rows = campChoices(L.type), available = rows.filter(x => x.available);
  const add = available.filter(x => !x.event && L.selected.has(x.f.id));
  const remove = rows.filter(x => x.event && !L.selected.has(x.f.id));
  return {rows, available, add, remove};
}
function openCondEditor(camp, type) {
  const d=E.eventCatalog[type], rows=campChoices(type), home=rows.find(x=>x.f.id===Number(camp));
  if (!d || !home) return;
  const selected = new Set(rows.filter(x=>x.event || (x === home && x.available)).map(x=>x.f.id));
  openLayer('sheet', condView, {name:'cond', camp:home.f.id, type, selected, value:home.event?.value ?? d.defaultValue, weight:home.event?.weight ?? E.DEFAULT_EVENT_WEIGHT, applied:false});
}
function openCond(id) { const hit=findEvent(id); if (hit) openCondEditor(hit.rule.camp, hit.event.type); }
function changeConditionScope(L, mode, camp, checked) {
  const {rows,available,add}=condSelection(L), home=rows.find(x=>x.f.id===L.camp)?.event;
  // 开始给别的阵营添加时，沿用当前阵营刚调好的数值；已有阵营不被批量覆写。
  if (!add.length && home) { L.value=home.value; L.weight=home.weight; }
  if (mode === 'all') L.selected=new Set(available.map(x=>x.f.id));
  else if (mode === 'none') L.selected.clear();
  else if (available.some(x=>x.f.id===camp)) { if (checked) L.selected.add(camp); else L.selected.delete(camp); }
  renderLayers();
  if (!mode) $(`.sheet [data-scope-camp="${camp}"]`)?.focus({preventScroll:true});
}
function saveConditionScope(L) {
  const {add,remove}=condSelection(L); if (!add.length && !remove.length) return;
  const next=clone(board), name=E.eventCatalog[L.type].name, undoState=snapshot('调整「'+name+'」的生效阵营');
  for (const {f,event} of remove) E.removeCampEvent(next,f.id,event.id);
  for (const {f} of add) { const e=E.addCampEvent(next,f.id,L.type); e.value=L.value; e.weight=L.weight; }
  board=next; L.applied=true;
  commit({undo:undoState, say:L.selected.size ? `「${name}」已对 ${L.selected.size} 个阵营生效` : `已从所有阵营移除「${name}」`});
}
function condView(L) {
  const camp=L.camp, f=E.faction(board,camp), d=E.eventCatalog[L.type]; if (!f || !d) return null;
  const {rows,available,add,remove}=condSelection(L), e=rows.find(x=>x.f.id===camp)?.event;
  const had=rows.some(x=>x.event), changed=!!(add.length || remove.length);
  const editingHome=!!e && L.selected.has(camp) && !add.length;
  const blocked=e && blockedIssue(camp,L.type), limit=e ? goalLimit(camp,L.type) : null, reachable=Number.isFinite(limit) && limit >= 1;
  const scope = camp === 3 ? (d.aggregation === 'personalMax' ? '只看本人的记录，各自获胜' : '每名中立各自累计，各自获胜') : d.aggregation === 'personalMax' ? '取一名成员的最高记录，队友不相加' : '全队共享进度，达成后全员获胜';
  const clearAll=!L.selected.size && remove.length>0, saveLabel=clearAll ? '确认移除' : had ? '保存修改' : '添加条件';
  const canFinish=!changed && (had || L.applied);
  return sheetHead(esc(d.name), nameHtml(f.name) + '的额外胜利条件') + `
<div class="sh-b" data-keep="cond" style="${fc(camp)}">
  <div class="cv"><span class="cond-ic lg">${icon(condIcon(L.type))}</span><div><p>${esc(campEventCopy(d.description, camp))}</p><small>${esc(campEventCopy(d.detail || '', camp))}</small>${d.hint ? `<em class="tag is-gold">${icon('info')}${esc(d.hint)}</em>` : ''}</div></div>
  ${blocked && editingHome ? `<div class="banner is-warn">${icon('alert')}<span>${reachable ? nums(`按现在的人数和会议设置，最多只能完成 ${limit} ${esc(d.unit)}。`) : e.type === 'reports' && !board.room.allow_report_dead ? '房间关闭了「报告鸡腿」，这个条件完成不了。' : '按现在的房间设置，这个条件完成不了。'}</span>${reachable ? `<button class="btn btn-primary btn-sm" data-act="cond-cap" data-id="${esc(e.id)}">${nums('调到 ' + limit)}</button>` : `<button class="btn btn-primary btn-sm" data-act="cond-room" data-id="${esc(e.id)}">去改房间设置</button>`}</div>` : ''}
  ${editingHome || add.length ? `<div class="row-f"><span class="lab">目标<small>${add.length && had ? '用于新选阵营，保留已有阵营的目标' : scope}</small></span>${stepper(editingHome ? 'evv:' + e.id : 'scope:value', {unit: d.unit, label: d.name + '目标'})}</div>
  <div class="row-f"><span class="lab">权重<small>数字越大越优先结算，相同就并列获胜</small></span>${stepper(editingHome ? 'evw:' + e.id : 'scope:weight', {label: d.name + '权重'})}</div>` : ''}
  <div class="sec-h"><h3 class="sh-sub" id="cond-scope-title">生效阵营 <b class="num" role="status">${L.selected.size}/${rows.length}</b></h3><span class="grow"></span><button type="button" class="btn btn-soft btn-sm" data-act="cond-select" data-mode="all" ${available.every(x=>L.selected.has(x.f.id))?'disabled':''}>全选</button><button type="button" class="btn btn-soft btn-sm" data-act="cond-select" data-mode="none" ${L.selected.size?'':'disabled'}>全不选</button></div>
  <div class="apply" role="group" aria-labelledby="cond-scope-title">${rows.map(({f:x,available:ok})=>{
    const on=L.selected.has(x.id);
    return `<label class="apply-i ${on?'is-on':''}" style="${fc(x.id)}">${emblem(x,'xs')}<span>${nameHtml(x.name)}${!ok ? '<small>已经加满了</small>' : x.id===camp ? '<small>当前阵营</small>' : ''}</span><span class="sw"><input type="checkbox" role="switch" data-scope-camp="${x.id}" aria-label="对${esc(x.name)}生效" ${on?'checked':''} ${ok?'':'disabled'}><i aria-hidden="true"></i></span></label>`;
  }).join('')}</div>
  <p class="hint">${clearAll ? '确认后，将从所有阵营移除这个额外条件。' : changed ? '确认后生效，已有阵营保留各自的目标和权重。' : !L.selected.size ? '选择要应用这个条件的阵营。' : '可以逐个调整阵营。'}</p>
</div>
<footer class="sh-f">${e && !changed ? `<button class="btn btn-ghost is-danger" data-act="cond-remove" data-id="${esc(e.id)}">${icon('trash')}移除条件</button>` : !canFinish ? '<button class="btn btn-soft" data-act="close">取消</button>' : ''}<span class="grow"></span>${canFinish ? '<button class="btn btn-primary" data-act="close">完成</button>' : `<button class="btn ${clearAll?'btn-danger':'btn-primary'}" data-act="cond-save" ${changed?'':'disabled'}>${saveLabel}</button>`}</footer>`;
}
function openNeutralBase() {
  openLayer('sheet', () => sheetHead('中立的原有条件', '每个中立职业有自己的赢法，这些不能改。') + `<div class="sh-b">${E.D.eligibleCareerIds.map(id => E.careers.get(id)).filter(c => c.camp === 3).map(c => `<div class="artv-sk">${avatar(c.id, 3, 'sm')}<span><b>${esc(c.name)}</b><small>${esc(c.win_condition_des)}</small></span></div>`).join('')}</div>`, {name: 'neutral'});
}
function openWinHelp() {
  const rules = [
    ['crown', '额外条件先结算', '只要有阵营达成了额外条件，这一刻就按额外条件判胜，原有条件不再看。'],
    ['check', '完成任意一个就赢', '一个阵营加了多个额外条件时，达成其中一个即可。'],
    ['swords', '同时达成看权重', '几个阵营同一刻都达成时，权重大的赢；权重一样就并列获胜。没达成的高权重条件不会挡住别人。'],
    ['shield', '要有人活着', '达成额外条件时，阵营里得有人存活；中立只看本人。'],
    ['lock', '原有条件一直在', '鹅、鸭和中立职业的原有赢法不能改。新阵营没有原有条件，至少要加一个额外条件。']
  ];
  openLayer('sheet', () => sheetHead('胜负怎么判', '读一遍就够，之后凭直觉用。') + `<div class="sh-b">${rules.map(([ic, t, p]) => `<div class="rule">${icon(ic)}<div><b>${t}</b><p>${p}</p></div></div>`).join('')}</div>`, {name: 'win-help'});
}

/* ---------- 导出与导入 ---------- */
let hostDownloads = null, hostDownloadsAsked = null;
function exportPayload() { const out = E.exportDraft(board); out.checkReport = clone(checkReport); if (draw) out.drawPreview = clone(draw); return JSON.stringify(out, null, 2); }
function exportFileName() { return (board.boardName.replace(/[\\/:*?"<>|]/g, '_') || '板子') + '.json'; }
function exportView() {
  const errs = errorCount(), canShare = typeof navigator.share === 'function';
  return sheetHead('导出板子', nameHtml(board.boardName)) + `
<div class="sh-b">
  <div class="banner ${errs ? 'is-warn' : 'is-ok'}">${icon(errs ? 'alert' : 'check')}<span>${errs ? nums(`还有 ${errs} 项没处理。现在导出的是草稿，里面带着检查结果，方便以后接着改。`) : '检查通过。导出的板子保留全部设置，之后还能导入接着改。'}</span></div>
  <button class="big-act" data-act="copy-export">${icon('copy')}<span><b>${errs ? '复制草稿数据' : '复制板子数据'}</b><small>发给朋友，对方在“导入板子”里粘贴就行</small></span></button>
  <button class="big-act" id="export-download" data-act="download" ${HOSTED && !hostDownloads ? 'hidden' : ''}>${icon('download')}<span><b>存成文件</b><small>${esc(exportFileName())}</small></span></button>
  ${canShare ? `<button class="big-act" data-act="share-export">${icon('arrow')}<span><b>用系统分享发出去</b><small>微信、隔空投送等</small></span></button>` : ''}
  <label class="fld" id="export-text-wrap" hidden><span>没能自动复制，请长按全选后复制</span><textarea id="export-text" readonly spellcheck="false"></textarea></label>
</div>`;
}
function openExport() { askHostDownloads(); openLayer('sheet', exportView, {name: 'export'}); }
function download() {
  try {
    const text = exportPayload();
    if (HOSTED) { hostedSave(text); return; }
    const blob = new Blob([text], {type: 'application/json;charset=utf-8'});
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = exportFileName(); document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000); toast('板子已存成文件');
  } catch (e) { toast('导出失败：' + e.message); }
}
// 托管版的下载能力由平台提供，可能没有；拿到之后才显示“存成文件”，每次保存都要查看者确认。
function askHostDownloads() {
  if (!HOSTED || hostDownloads || hostDownloadsAsked || !(window.claude && typeof window.claude.use === 'function')) return;
  hostDownloadsAsked = Promise.resolve().then(() => window.claude.use('downloads')).then(ns => {
    hostDownloadsAsked = null; hostDownloads = ns || null;
    if (hostDownloads) $('#export-download')?.removeAttribute('hidden');
  }).catch(() => { hostDownloadsAsked = null; });
}
async function hostedSave(text) {
  const useCopy = () => { hostDownloads = null; $('#export-download')?.setAttribute('hidden', ''); toast('这里暂时不能下载，请用“复制板子数据”'); };
  if (!hostDownloads) { useCopy(); return; }
  try { await hostDownloads.save({filename: exportFileName(), data: text}); toast('板子已存成文件'); }
  catch (e) {
    const code = e && e.code;
    if (code === 'declined') toast('已取消下载');
    else if (code === 'rate_limited') toast('已有一个保存提示在等待确认，请先处理它');
    else useCopy();
  }
}
// 复制文字：先用系统剪贴板；被页面策略拦住（例如嵌在手机外框里从本地打开）时，退回到选中文本再复制。
function legacyCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;font-size:16px';
  document.body.appendChild(ta); ta.focus({preventScroll: true}); ta.select(); ta.setSelectionRange(0, text.length);
  let ok = false; try { ok = document.execCommand('copy'); } catch { ok = false; }
  ta.remove(); return ok;
}
function copyText(text) {
  const policy = document.featurePolicy || document.permissionsPolicy;
  const allowed = !policy || typeof policy.allowsFeature !== 'function' || policy.allowsFeature('clipboard-write');
  if (allowed && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') return navigator.clipboard.writeText(text).then(() => true, () => legacyCopy(text));
  return Promise.resolve(legacyCopy(text));
}
function copyExport() {
  let text; try { text = exportPayload(); } catch (e) { toast('导出失败：' + e.message); return; }
  const manual = () => { const wrap = $('#export-text-wrap'), area = $('#export-text'); if (!area) return; area.value = text; wrap.hidden = false; area.focus(); area.select(); toast('没能自动复制，请手动复制下面的内容'); };
  copyText(text).then(ok => ok ? toast('已复制板子数据，粘贴发给朋友吧') : manual(), manual);
}
async function shareExport() {
  let text; try { text = exportPayload(); } catch (e) { toast('导出失败：' + e.message); return; }
  try {
    const file = typeof File === 'function' ? new File([text], exportFileName(), {type: 'application/json'}) : null;
    if (file && navigator.canShare && navigator.canShare({files: [file]})) await navigator.share({files: [file], title: board.boardName});
    else await navigator.share({title: board.boardName, text});
  } catch (e) { if (e && e.name !== 'AbortError') toast('分享没成功，试试“复制板子数据”'); }
}
function importView() {
  return sheetHead('导入板子', '只导入到这个编辑器，不会改动游戏房间。') + `
<div class="sh-b">
  <label class="fld"><span>粘贴板子数据</span><textarea id="import-text" spellcheck="false" autocomplete="off" placeholder="把收到的板子数据粘贴到这里（以 { 开头）"></textarea></label>
  <button class="big-act" data-act="import-file">${icon('folder')}<span><b>或者选一个板子文件</b><small>之前导出的 .json 文件</small></span></button>
</div>
<footer class="sh-f"><button class="btn btn-soft" data-act="close">取消</button><span class="grow"></span><button class="btn btn-primary" data-act="import-text">${icon('upload')}导入</button></footer>`;
}
function openImport() { openLayer('sheet', importView, {name: 'import'}); }
function confirmImport(data) {
  const incoming = E.validateShape(data), issues = E.validate(incoming), errs = issues.filter(x => x.level === 'error').length;
  confirmDialog({
    title: '导入「' + esc(incoming.boardName) + '」？',
    text: nums(`${incoming.room.total} 人 · ${incoming.roles.length} 个角色${errs ? ' · ' + errs + ' 项待处理' : ''}`),
    note: '现在的草稿会先备份，之后能在“板子”页恢复。', ok: '导入',
    onOk() { replaceBoard(incoming); }
  });
}
async function importFile(file) {
  if (!file) return;
  try {
    if (file.size > 2 * 1024 * 1024) throw Error('文件超过 2MB');
    let data; try { data = JSON.parse(await file.text()); } catch { throw Error('这个文件不是板子数据'); }
    confirmImport(data);
  } catch (e) { toast('导入失败：' + e.message); } finally { const input = $('#file-import'); if (input) input.value = ''; }
}
function importPasted() {
  const text = ($('#import-text')?.value || '').trim();
  try {
    if (!text) throw Error('请先粘贴板子数据');
    if (text.length > 2 * 1024 * 1024) throw Error('内容超过 2MB');
    let data; try { data = JSON.parse(text); } catch { throw Error('内容不是完整的板子数据，请重新复制后粘贴'); }
    confirmImport(data);
  } catch (e) { toast('导入失败：' + e.message); }
}
