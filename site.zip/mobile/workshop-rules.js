'use strict';
// 手机版工坊：只有主动技能占用可分配名额；原始职业配置和已存草稿保持原样。
(function (root) {
  const base = root.EditorEngine, MAX_ACTIVE_SKILLS = 4;
  const WORKSHOP_RULES_VERSION = '1.4.2';
  const passiveText = '被动技能不能分配，只能保留原职业自带的被动。';
  const capText = `每个角色最多 ${MAX_ACTIVE_SKILLS} 个主动技能，请先移除一个主动技能。`;
  const passive = id => base.playerSkill(id)?.type === 1;
  const activeSkills = r => base.equippedSkills(r, {type:'active'});

  // 五格旧草稿保留玩家的选择；超限时主动技能只能移除，不能继续调整参数。
  function canEditEquippedSkill(r, id) {
    return !!r && base.allIds(r).includes(Number(id)) && (passive(id) || activeSkills(r).length <= MAX_ACTIVE_SKILLS);
  }

  // 只调整新取出的职业预设；旧草稿和导入的技能保留给玩家选择。
  function applyFreshRolePreset(r) {
    // 刺客、食鸟鸭默认留核心动作和专属技能；通用的「遁入」仍可换回。
    if ((r.templateCareerId === 106 || r.templateCareerId === 107) && activeSkills(r).length > MAX_ACTIVE_SKILLS) {
      base.removeSkill(r, 2);
    }
    return r;
  }
  function applyFreshBoardPresets(b) {
    b.roles.forEach(applyFreshRolePreset);
    return b;
  }

  function skillMountIssue(r, id) {
    if (passive(id) && !base.isNativeSkill(r, id)) return {code:'SKILL_PASSIVE_ASSIGN', skillId:Number(id), text:passiveText};
    return base.skillMountIssue(r, id);
  }
  function workshopSkillIssues(r) {
    const skills = base.equippedSkills(r), n = skills.filter(s => s.type === 0).length, issues = [];
    if (n > MAX_ACTIVE_SKILLS) issues.push({code:'SKILL_SLOT_LIMIT', text:`有 ${n} 个主动技能，最多保留 ${MAX_ACTIVE_SKILLS} 个，请移除 ${n - MAX_ACTIVE_SKILLS} 个主动技能。`});
    for (const s of skills) if (s.type === 1 && !base.isNativeSkill(r, s.sourceId)) {
      issues.push({code:'SKILL_PASSIVE_ASSIGN', skillId:s.id, text:`「${s.name}」不是这个职业自带的被动，请移除。`});
    }
    return issues;
  }
  function skillCompatibility(id, r, opts = {}) {
    const raw = opts.raw ? Number(id) : base.resolveSkillRawId(id, r);
    const locked = key => ({level:'error', code:'SKILL_PASSIVE_ASSIGN', short:'不可分配', text:passiveText, skillId:key});
    if (passive(raw)) return locked(raw);
    const status = base.skillCompatibility(id, r, opts);
    if (status.level !== 'available') return status;
    // 按玩家看到的完整技能计数，多段或等价的技能不会重复占格。
    const ids = new Set(activeSkills(r).map(s => s.id));
    for (const key of [raw, ...(status.missing || [])]) {
      const s = base.playerSkill(key);
      if (s?.type === 1) return locked(key);
      if (s) ids.add(s.id);
    }
    return ids.size > MAX_ACTIVE_SKILLS ? {level:'error', code:'SKILL_SLOT_LIMIT', short:'主动槽已满', text:capText, skillId:raw} : status;
  }
  function addSkill(r, id, slot = 'auto', opts = {}) {
    const status = skillCompatibility(id, r, opts);
    if (status.level === 'error') throw Error(status.text);
    return base.addSkill(r, id, slot, opts);
  }
  function librarySkills(opts) {
    return base.librarySkills(opts).map(s => s.type === 1 ? {...s, mountStatus:'native-only', mountReason:passiveText} : s);
  }
  const limitsFor = b => b.roles.flatMap(r => workshopSkillIssues(r).map(i => ({...i, level:'error', uid:r.uid, text:r.name+'：'+i.text})));
  function validate(b, opts) {
    const issues = base.validate(b, opts);
    return issues.some(i => i.code === 'SCHEMA') ? issues : [...issues, ...limitsFor(b)];
  }
  root.EditorEngine = {...base, WORKSHOP_RULES_VERSION, MAX_ACTIVE_SKILLS, canEditEquippedSkill, workshopSkillIssues, skillMountIssue, skillCompatibility, addSkill, librarySkills, validate,
    makeRole(id) {return applyFreshRolePreset(base.makeRole(id));},
    addCareer(b, id) {return applyFreshRolePreset(base.addCareer(b, id));},
    defaultBoard() {return applyFreshBoardPresets(base.defaultBoard());},
    poolExample() {return applyFreshBoardPresets(base.poolExample());},
    drawPool(b, seed) {const [i]=limitsFor(b); if(i) throw Error(i.text); return base.drawPool(b,seed);},
    resolveVictory(b, state) {const [i]=limitsFor(b); return i ? {source:'pending',reason:i.text,invalid:true,winners:[],matchedGroups:[],checks:[]} : base.resolveVictory(b,state);}
  };
})(window);
