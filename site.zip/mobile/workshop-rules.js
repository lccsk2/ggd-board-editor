'use strict';
// 手机版工坊：只有主动技能占用可分配名额；原始职业配置和已存草稿保持原样。
(function (root) {
  const base = root.EditorEngine, MAX_ACTIVE_SKILLS = 4;
  const WORKSHOP_RULES_VERSION = '1.4.4';
  const passiveText = '被动技能不能分配，只能保留原职业自带的被动。';
  const capText = `每个角色最多 ${MAX_ACTIVE_SKILLS} 个主动技能，请先移除一个主动技能。`;
  const passive = id => base.playerSkill(id)?.type === 1;
  const activeSkills = r => base.equippedSkills(r, {type:'active'});

  // 五格旧草稿保留玩家的选择；超限时主动技能只能移除，不能继续调整参数。
  const locked=(r,id)=>!!r&&!base.isCustom(r)&&[...base.nativeSkillIds(r)].some(raw=>raw===Number(id)||(base.playerSkill(raw)?.id!=null&&base.playerSkill(raw).id===base.playerSkill(id)?.id));
  const limit=r=>Math.max(MAX_ACTIVE_SKILLS,base.isCustom(r)?0:activeSkills(base.makeRole(r.templateCareerId)).length);
  function canEditEquippedSkill(r,id){return !!r&&!locked(r,id)&&base.allIds(r).includes(Number(id))&&(passive(id)||activeSkills(r).length<=limit(r));}
  const applyFreshRolePreset=r=>r,applyFreshBoardPresets=b=>b;
  function normalized(raw){const b=base.validateShape(raw), seen=new Map(), list=[];
    for(const r of b.roles){if(r.appearance!==undefined&&!['random','fixed'].includes(r.appearance))throw Error('角色出场状态无效');if(base.isCustom(r)){list.push(r);continue;}
      const id=r.templateCareerId, dst=seen.get(id)||r, fresh=base.makeRole(id);if(dst!==r&&dst.count+r.count>15)throw Error('旧草稿同职业合计超过 15 份，请先在旧版调整数量');
      if(dst!==r){if((dst.appearance||'random')!==(r.appearance||'random'))throw Error('同职业有多种出场状态');dst.count+=r.count;}
      const oldSlots=base.clone(r.slots),over={...r.skillOverrides};if(!seen.has(id)){dst.slots=base.clone(fresh.slots);dst.skillOverrides={};seen.set(id,dst);list.push(dst);}
      for(const [key,v] of Object.entries(oldSlots)){for(const n of (Array.isArray(v)?v:[v])){if(!n||locked(dst,n)||base.allIds(dst).includes(n))continue;if(Array.isArray(dst.slots[key]))dst.slots[key].push(n);else if(!dst.slots[key])dst.slots[key]=n;else{const empty=Object.keys(dst.slots).find(k=>k.startsWith('assistant_key')&&!dst.slots[k]);if(empty)dst.slots[empty]=n;else dst.slots.main_key.push(n);}}}
      for(const [key,val] of Object.entries(over))if(!locked(dst,+key)&&!dst.skillOverrides[key]&&base.allIds(dst).includes(+key))dst.skillOverrides[key]=val;
    }b.roles=list;return b;}
  function skillMountIssue(r, id) {
    if (passive(id) && !base.isNativeSkill(r, id)) return {code:'SKILL_PASSIVE_ASSIGN', skillId:Number(id), text:passiveText};
    return base.skillMountIssue(r, id);
  }
  function workshopSkillIssues(r) {
    const skills = base.equippedSkills(r), n = skills.filter(s => s.type === 0).length, issues = [];
    if (n > limit(r)) issues.push({code:'SKILL_SLOT_LIMIT', text:`有 ${n} 个主动技能，最多保留 ${limit(r)} 个，请移除 ${n - limit(r)} 个追加主动技能。`});
    for (const s of skills) if (s.type === 1 && !base.isNativeSkill(r, s.sourceId)) {
      issues.push({code:'SKILL_PASSIVE_ASSIGN', skillId:s.id, text:`「${s.name}」不是这个职业自带的被动，请移除。`});
    }
    return issues;
  }
  function skillCompatibility(id, r, opts = {}) {
    const raw = opts.raw ? Number(id) : base.resolveSkillRawId(id, r);
    const locked = key => ({level:'error', code:'SKILL_PASSIVE_ASSIGN', short:'不可分配', text:passiveText, skillId:key});
    if (passive(raw)) return locked(raw);
    const status = base.skillCompatibility(id, r, opts);
    if (status.level !== 'available') return status;
    // 按玩家看到的完整技能计数，多段或等价的技能不会重复占格。
    const ids = new Set(activeSkills(r).map(s => s.id));
    for (const key of [raw, ...(status.missing || [])]) {
      const s = base.playerSkill(key);
      if (s?.type === 1) return locked(key);
      if (s) ids.add(s.id);
    }
    return ids.size > limit(r) ? {level:'error', code:'SKILL_SLOT_LIMIT', short:'主动槽已满', text:capText, skillId:raw} : status;
  }
  function addSkill(r, id, slot = 'auto', opts = {}) {
    const status = skillCompatibility(id, r, opts);
    if (status.level === 'error') throw Error(status.text);
    return base.addSkill(r, id, slot, opts);
  }
  function librarySkills(opts) {
    return base.librarySkills(opts).map(s => s.type === 1 ? {...s, mountStatus:'native-only', mountReason:passiveText} : s);
  }
  const limitsFor = b => b.roles.flatMap(r => workshopSkillIssues(r).map(i => ({...i, level:'error', uid:r.uid, text:r.name+'：'+i.text})));
  function validate(b, opts) {
    const issues = base.validate(b, opts);
    return issues.some(i => i.code === 'SCHEMA') ? issues : [...issues, ...limitsFor(b)];
  }
  root.EditorEngine = {...base, locked, activeLimit:limit, legacyRemove:base.removeSkill, legacyValidate:base.validateShape, legacyExport:base.exportDraft,
    validateShape:normalized,exportDraft:b=>base.exportDraft(normalized(b)),
    removeSkill(r,id,slot){if(locked(r,id))throw Error('职业原生技能不可移除');return base.removeSkill(r,id,slot);},
    resetSkillParameters(r,id){if(locked(r,id))throw Error('职业原生参数不可修改');return base.resetSkillParameters(r,id);}, WORKSHOP_RULES_VERSION, MAX_ACTIVE_SKILLS, canEditEquippedSkill, workshopSkillIssues, skillMountIssue, skillCompatibility, addSkill, librarySkills, validate,
    makeRole(id) {return applyFreshRolePreset(base.makeRole(id));},
    addCareer(b, id) {return applyFreshRolePreset(base.addCareer(b, id));},
    defaultBoard() {return applyFreshBoardPresets(base.defaultBoard());},
    poolExample() {return applyFreshBoardPresets(base.poolExample());},
    drawPool(b, seed) {const [i]=limitsFor(b); if(i) throw Error(i.text); return base.drawPool(b,seed);},
    resolveVictory(b, state) {const [i]=limitsFor(b); return i ? {source:'pending',reason:i.text,invalid:true,winners:[],matchedGroups:[],checks:[]} : base.resolveVictory(b,state);}
  };
})(window);
