'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 手机横屏版 · 界面层（核心）
 *
 * 规则、草稿格式、随机抽取与判胜全部沿用 engine.js → faction-rules.js → camp-events.js → factions.js，
 * 这里不改动它们，草稿也与旧版界面互通（同一份本机存档）。
 *
 * 界面按横屏手机重新组织：
 *   左侧导航：板子 / 房间 / 阵容 / 角色 / 胜利 / 试玩，一页只做一件事；
 *   需要细调的内容从右侧滑出面板（sheet），需要挑选的内容（角色、技能、胜利条件）用整屏清单（overlay）；
 *   所有数字都能用加减按钮完成，不依赖键盘；能一键修好的问题直接给出修复按钮。
 *
 * 本文件：工具函数、图像、状态与存档、检查与一键修复、席位规则、通用控件、弹层与提示。
 */
const E = window.EditorEngine, D = E.D;
const ART = window.EDITOR_ART || {roles: {}, skills: {}, stages: {}, camps: {}};
const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const clone = E.clone;
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const cssEsc = v => window.CSS && CSS.escape ? CSS.escape(String(v)) : String(v).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
// 标题字体里的数字“1”是一条竖线，容易看成字母 I：数字一律换成正文字体加粗。
const nums = html => String(html).replace(/&#?\w+;|<[^>]*>|\d+/g, m => /^\d+$/.test(m) ? `<span class="num">${m}</span>` : m);
const nameHtml = s => nums(esc(s));

const STYLE_REVIEW = new URLSearchParams(location.search).get('example') === 'layout';
const STORE = 'ggd-board-workshop-offline-mobile-v1' + (STYLE_REVIEW ? '-layout-example' : ''), AUTOSAVE = STORE + '-autosave', RECOVERY = STORE + '-recovery';
const GUIDE_SEEN = STORE + '-mobile-guide-seen', ROLE_CLIP = STORE + '-role-clip';

/* ---------- 图像与图标 ---------- */
const CUSTOM_ICON = ART.customRole || {src: 'assets/custom-role.png', width: 512, height: 512};
const icon = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true" focusable="false"><use href="#i-${name}"></use></svg>`;
const sticker = (name, cls = '') => `<svg class="stk ${cls}" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><use href="#s-${name}"></use></svg>`;
// 阵营色：鹅＝天蓝，鸭＝赤红，中立＝兰紫，新阵营按编号轮换。
const TONES = {1: ['#49b6ff', '#1e78cf'], 2: ['#ff5d5d', '#c3303c'], 3: ['#b98bff', '#7a4fe0']};
const CUSTOM_TONES = [['#2fd5c6', '#15978e'], ['#ff9f45', '#d06f18'], ['#ff6fb4', '#c93f86'], ['#9be15d', '#5c9f2c'], ['#f5d449', '#be9a12'], ['#5da9ff', '#2c6fd0'], ['#ff8a79', '#c9574a'], ['#c9a3ff', '#8a5fe0']];
function tone(id) {
  id = Number(id);
  if (!id) return ['#9c93d6', '#6c62b0'];
  return TONES[id] || CUSTOM_TONES[((id - 4) % CUSTOM_TONES.length + CUSTOM_TONES.length) % CUSTOM_TONES.length];
}
function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${n >> 8 & 255},${n & 255},${a})`; }
function fc(id) { const [c, d] = tone(id); return `--fc:${c};--fc-deep:${d};--fc-soft:${rgba(c, .16)};--fc-line:${rgba(c, .5)}`; }
function artImg(a, cls = '', alt = '', lazy = true) {
  if (!a) return '';
  const source = a.optimizedSrc || a.src;
  return `<img class="${cls}" src="${esc(source)}" data-art-source="${esc(a.src)}" ${a.optimizedSrc ? `data-art-optimized="${esc(source)}"` : ''} width="${a.width}" height="${a.height}" alt="${esc(alt)}" loading="${lazy ? 'lazy' : 'eager'}" decoding="async" draggable="false" data-art-image>`;
}
function emblem(f, cls = '') {
  const art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
  return `<span class="emb ${cls}" style="${fc(f?.id)}" aria-hidden="true">${art ? artImg(art, '', '', false) : `<b>${esc([...(f?.name || '新')][0])}</b>`}</span>`;
}
function roleArt(r) { return E.isCustom(r) ? {icon: CUSTOM_ICON} : ART.roles[r.templateCareerId]; }
function avatar(careerId, camp = 0, cls = '') {
  const a = careerId === null ? {icon: CUSTOM_ICON} : ART.roles[careerId];
  return `<span class="ava ${cls}" style="${fc(camp)}">${a?.icon ? artImg(a.icon, '', '', true) : `<b>${esc(E.camps[camp]?.slice(0, 1) || '?')}</b>`}</span>`;
}
function skillIcon(id, cls = '') {
  const s = E.skills.get(Number(id)), a = ART.skills[id]?.icon;
  return a ? artImg(a, 'ski ' + cls, '', true) : `<span class="ski ski-text ${cls}" aria-hidden="true">${s?.type === 1 ? '被' : '技'}</span>`;
}
// 图片缺失时：先退回原图，再重试两次，最后给一个占位，不让破图留在界面上。
document.addEventListener('error', event => {
  const img = event.target;
  if (!(img instanceof HTMLImageElement) || !img.hasAttribute('data-art-image') || !img.isConnected) return;
  if (img.dataset.artOptimized && !img.dataset.artFallback) { img.dataset.artFallback = 'true'; img.src = img.dataset.artSource; return; }
  const retries = Number(img.dataset.artRetries || 0);
  if (retries < 2) {
    img.dataset.artRetries = String(retries + 1);
    setTimeout(() => {
      if (!img.isConnected) return;
      const source = new URL(img.dataset.artSource, document.baseURI);
      if (source.protocol === 'http:' || source.protocol === 'https:') source.searchParams.set('artRetry', String(retries + 1));
      img.src = source.href;
    }, 400 * (retries + 1));
    return;
  }
  const hint = document.createElement('span'); hint.className = 'art-missing'; hint.textContent = '?'; hint.title = img.alt; img.replaceWith(hint);
}, true);

/* ---------- 状态 ---------- */
let board = STYLE_REVIEW ? E.validateShape(STYLE_EXAMPLE_BOARD) : E.defaultBoard();
// page：room / lineup / wins / play；roleUid 有值时，阵容页显示这个角色的详情。
// page：板子 info / 房间 room / 阵容 lineup / 角色 roles / 胜利 wins / 试玩 play。
// roleUid：正在编辑的角色（角色页）；roleBack：编辑完回到哪一页；roleFilter：角色页的筛选。
const ui = {page: STYLE_REVIEW ? 'lineup' : 'info', roomTab: 'pace', playTab: 'cast', roleUid: '', roleBack: 'roles', roleFilter: 'all', flash: '', seatPop: -1};
let checkReport = [];
let draw = null, drawError = '', justDrew = false;
let scenario = null, simGroup = '', simRun = false;
let undo = null;            // 可撤销的上一步：{label, board, ui, …}
let saveNote = '自动保存到本机';
let roleClip = readRoleClip();
if(STYLE_REVIEW && !roleClip){const sample=board.roles.find(r=>E.isCustom(r));if(sample)roleClip={v:1,name:'巡游员',count:1,appearance:'random',camp:sample.camp,slots:clone(sample.slots),skillOverrides:{}};}

function role(uid = ui.roleUid) { return board.roles.find(r => r.uid === uid) || null; }
function rolesOf(camp) { return board.roles.filter(r => r.camp === camp); }
function campName(id) { return E.campName(board, id); }
function shortCamp(f) { return f.name.replace(/阵营$/, '') || f.name; }
function seatSum(b = board) { return b.factions.reduce((n, f) => n + (b.room.counts[f.id] || 0), 0); }
function seatGapText() {
  const delta = board.room.total - seatSum();
  return delta > 0 ? `少 ${delta} 人` : delta < 0 ? `多 ${-delta} 人` : '';
}
// 房间、阵容和阵营面板共用同一条差额提示。长按时只更新提示，不替换玩家正按着的按钮。
function seatGapTag() {
  const text = seatGapText();
  return `<span class="seat-gap" role="status" data-seat-gap ${text ? '' : 'hidden'}>${icon('alert')}<b>${text}</b></span>`;
}
function errorCount() { return checkReport.filter(x => x.level === 'error').length; }
function warnCount() { return checkReport.filter(x => x.level === 'warn').length; }

/* ---------- 存档与检查 ---------- */
function autosave() {
  try { localStorage.setItem(AUTOSAVE, JSON.stringify(E.exportDraft(board))); saveNote = '已自动保存到本机'; }
  catch { saveNote = '没能自动保存，请点“保存”并复制唯一码留底'; }
}
function revalidate() {
  checkReport = E.validate(board).filter(x => x.level === 'error' || !['ABILITY_COMPAT', 'SLOT_LAYOUT', 'SKILL_SLOT', 'CD_PARAM'].includes(x.code));
}
// 板子有改动：重新检查、自动保存；之前抽出的名单和试算结果随之作废。
function touch() {
  E.ensureCampRules(board);
  draw = null; drawError = ''; scenario = null; simRun = false; justDrew = false;
  board.updatedAt = new Date().toISOString();
  autosave(); revalidate();
}
// softRender：这次改动来自输入框失焦。失焦多半是因为玩家点了别的按钮，这时立刻重画会把那个按钮换掉、这一下就点空了，
// 所以先保存，等这一下点完再重画（renderSoon）。
let softRender = false, renderPending = false, renderTimer = 0, pointerDown = false, pointerDownAt = 0;
function isTyping() {
  const a = document.activeElement;
  return a instanceof HTMLTextAreaElement || (a instanceof HTMLInputElement && ['text', 'number', 'search'].includes(a.type));
}
function renderSoon() {
  renderPending = true; clearTimeout(renderTimer);
  const run = () => {
    if (!renderPending) return;
    // 手指还按着（最多等 4 秒），或者玩家接着在别的输入框里打字：再等等。
    if (holding || (pointerDown && Date.now() - pointerDownAt < 4000) || isTyping()) { renderTimer = setTimeout(run, 80); return; }
    render();
  };
  renderTimer = setTimeout(run, 30);
}
function commit(opts = {}) {
  undo = opts.undo || null;
  touch();
  if (softRender) renderSoon(); else render();
  // 页面顶部会留一个“撤销”按钮；有弹层挡着页面时，提示里再带一个。
  if (opts.say) toast(opts.say, undo && layers.length ? {label: '撤销', act: 'undo'} : null);
}
// 名字、介绍这类文字改完：只保存，不重画（页面上别处不跟着变，也不打断玩家接下来点的按钮或输入框）。
function saveText() {
  undo = null; $$('.undo-pill').forEach(n => n.remove());
  touch();
}
function snapshot(label) {
  return {label, board: clone(board), ui: {...ui}, draw: draw ? clone(draw) : null, drawError, scenario: scenario ? clone(scenario) : null, simGroup, simRun};
}
function doUndo() {
  const s = undo; if (!s) return;
  board = clone(s.board); Object.assign(ui, s.ui); undo = null;
  closeAllLayers(true); touch();
  draw = s.draw; drawError = s.drawError; scenario = s.scenario; simGroup = s.simGroup; simRun = s.simRun;
  render(); toast('已撤销：' + s.label);
}
// 规则引擎的提示沿用“新增目标”一词；界面统一称“额外条件”。
const uiCopy = text => String(text ?? '').replace('请选择一种原有条件或添加新增目标', '请添加一个额外胜利条件').replace('添加新增目标', '添加额外条件').replaceAll('新增目标', '额外条件').replaceAll('候选池', '角色池');
// 两条规则在载入板子时统一执行，旧草稿随之改写：额外条件一律“完成任意一个即可”；新阵营只用额外胜利条件。
function normalizeBoard(b) {
  let joins = 0, bases = 0;
  for (const rule of b.campEvents || []) if (rule.join !== 'any') { if (rule.events.length > 1) joins++; rule.join = 'any'; }
  for (const f of b.factions || []) if (f.kind === 'custom' && f.baseVictory) { f.baseVictory = null; bases++; }
  return {joins, bases};
}
function normalizeNote(fix) {
  return [fix.joins ? '原先设为“全部完成”的阵营已改为完成任意一个即可' : '', fix.bases ? '新阵营现在只用额外胜利条件，原先选的基础胜利条件已取消' : ''].filter(Boolean).join('；');
}
function resetUi() {
  Object.assign(ui, {page: 'info', roomTab: 'pace', playTab: 'cast', roleUid: '', roleBack: 'roles', roleFilter: 'all', flash: '', seatPop: -1});
  scenario = null; simGroup = ''; simRun = false;
}
function replaceBoard(next, say = '已载入板子，原来的草稿已备份') {
  const incoming = E.validateShape(next);
  try { localStorage.setItem(RECOVERY, JSON.stringify(E.exportDraft(board))); } catch { /* 备份失败不拦着载入 */ }
  board = incoming;
  const note = normalizeNote(normalizeBoard(board));
  resetUi(); closeAllLayers(true);
  commit({say: say + (note ? '；' + note : '')});
}

/* ---------- 检查结果：定位与一键修复 ---------- */
// 把一条检查结果对应到界面位置：哪一页、哪个阵营、哪个角色或哪个设置。
function issueDest(issue, b = board) {
  const d = issueSpot(issue, b);
  return d.page === 'lineup' && d.uid ? {...d, page: 'roles'} : d;   // 落在某个角色身上的问题，去角色页处理
}
function issueSpot(issue, b = board) {
  const code = String(issue.code || ''), text = String(issue.text || ''), r = b.roles.find(r => r.uid === (issue.uid || issue.roleUid));
  const camp = r?.camp ?? issue.camp, uid = r?.uid;
  const labels = {total: '房间总人数', hit_cd: '击倒冷却', task: '房间总任务数', ...Object.fromEntries(Object.entries(E.ROOM_FIELDS).map(([k, d]) => [k, d.label]))};
  const field = issue.field || Object.keys(labels).find(k => text.includes(k) || text.includes(labels[k]));
  if (code === 'NEUTRAL_ROLE_COUNT') return {page: 'lineup', uid, camp: 3};
  if (code === 'NEUTRAL_ROLE_DUPLICATE' || code === 'NEUTRAL_PAIR_UNSUPPORTED') return {page: 'lineup', camp: 3};
  if (code === 'ORIGINAL_OPENING') return {page: 'lineup', camp: 2};
  if (code === 'ORIGINAL_DUCK_OPENING') return {page: 'lineup', camp: 1};
  if (code === 'ORIGINAL_CAMP_OPENING') return {page: 'lineup', camp: camp === 1 ? 2 : 1};
  if (['FIXED_SEATS','CAMP_SUM', 'CAMP_COUNT', 'POOL_CAPACITY', 'POOL_INACTIVE', 'POOL_NO_COMBINATION', 'POOL_SEARCH_LIMIT', 'POOL_CONSTRAINTS', 'SKILL_FAMILY_POOL', 'EMPTY', 'CAREER_OUT_OF_SCOPE', 'CAREER_POOL'].includes(code)) return {page: 'lineup', camp};
  if (code === 'TOTAL_RANGE' || code.startsWith('ROOM_')) return {page: 'room', field: code === 'TOTAL_RANGE' ? 'total' : field};
  if (['COPY_CAP', 'CUSTOM_NEUTRAL_FORBIDDEN', 'CAMP_OVERRIDE', 'WIN_CAMP'].includes(code)) return {page: 'lineup', uid, camp};
  if (code.startsWith('SKILL_') || ['SNIPER_PAIR', 'ABILITY_COMPAT', 'CD_PARAM', 'SLOT_LAYOUT'].includes(code)) return {page: 'lineup', uid, camp};
  if (code === 'BASE_DEPENDENCY') { const actor = r || b.roles.find(r => r.camp === camp); return actor ? {page: 'lineup', uid: actor.uid, camp} : {page: 'lineup', camp}; }
  if (/^(BASE_|EXTRA_|EVENT_|WIN_|FIXED_|LOSS_|OPENING_|EMPTY_WIN|EMPTY_LOSS|ZERO_THRESHOLD|CUSTOM_FACTION_NO_WIN|CUSTOM_NEUTRAL_NO_WIN|MEETING_GOAL_)/.test(code)) return {page: 'wins', camp: camp ?? 1};
  if (code === 'SCHEMA') {
    if (field) return {page: 'room', field};
    if (/技能|槽位/.test(text)) return {page: 'lineup', uid, camp};
    if (/胜利|目标|权重/.test(text)) return {page: 'wins', camp: camp ?? 1};
    if (/阵营|候选|角色/.test(text)) return {page: 'lineup', camp};
  }
  return uid ? {page: 'lineup', uid, camp} : camp ? {page: 'lineup', camp} : {page: 'room', field};
}
function issuesAt(page) { return checkReport.filter(x => x.level === 'error' && issueDest(x).page === page); }
// 落在某个阵营（而不是某个角色）上的问题：在阵容页对应的那一行就地提示。
const LANE_COPY = {ORIGINAL_OPENING: '鸭阵营没人出场，鹅一开局就赢了', ORIGINAL_DUCK_OPENING: '鹅阵营没人出场，鸭一开局就赢了'};
function laneIssue(camp) {
  const hit = checkReport.find(x => { if (x.level !== 'error' || x.code === 'CAMP_SUM') return false; const d = issueDest(x); return d.page === 'lineup' && !d.uid && d.camp === camp; });
  if (!hit) return null;
  const p = E.poolStats(board, camp);
  const text = hit.code === 'POOL_CAPACITY' ? `要出场 ${p.seats} 人，角色池最多只够 ${p.capacity} 人` : hit.code === 'ORIGINAL_CAMP_OPENING' ? `${shortCamp(E.faction(board, camp))}没人出场，对面一开局就赢了` : LANE_COPY[hit.code] || uiCopy(hit.text);
  return {issue: hit, text, fix: issueFix(hit)};
}
// 检查清单里的说明：常见问题换成大白话，其余沿用规则引擎的原文。
function issueText(x) {
  const p = x.camp ? E.poolStats(board, x.camp) : null;
  if (x.code === 'CAMP_SUM') return `房间 ${board.room.total} 人，阵营已分配 ${seatSum()} 人，${seatGapText()}。请到阵容调整。`;
  if (x.code === 'ORIGINAL_OPENING') return '鸭阵营没人出场，鹅一开局就赢了。给鸭阵营分个席位，或者把鹅的已有职业都移出角色池。';
  if (x.code === 'ORIGINAL_DUCK_OPENING') return '鹅阵营没人出场，鸭一开局就赢了。给鹅阵营留个席位，或者把鸭的已有职业都移出角色池。';
  if (x.code === 'POOL_CAPACITY' && p) return `${campName(x.camp)}要出场 ${p.seats} 人，角色池最多只够 ${p.capacity} 人。减少出场人数，或者再添加角色。`;
  return uiCopy(x.text);
}
function roleHasIssue(uid) { return checkReport.some(x => x.level === 'error' && (x.uid || x.roleUid) === uid); }
// 检查报告按阵营给出无法完成的条件名；据此在对应的条件上就地提示。
function issueNames(issue) { const m = /「([^」]*)」无法/.exec(String(issue?.text || '')); return m ? m[1].split('、') : []; }
function blockedIssue(camp, type) {
  const name = E.eventCatalog[type].name;
  return checkReport.find(x => x.camp === camp && ['EXTRA_UNREACHABLE', 'MEETING_GOAL_UNREACHABLE'].includes(x.code) && issueNames(x).includes(name)) || null;
}
// 一个额外条件在当前人数和会议设置下最多能完成到几；Infinity 表示不受限。
function goalLimit(camp, type) {
  const t = board.room.total, n = board.room.counts[camp] || 0;
  if (type === 'kills' || type === 'voteOuts') return t - (camp === 3 ? 1 : n);
  if (type === 'reports') return board.room.allow_report_dead ? t - 1 : 0;
  if (type === 'investigations') return t - (camp === 3 || n < 2 ? 1 : 0);
  if (type === 'emergencyCalls') return Math.min(board.room.meeting_amount, camp === 3 ? 1 : n);
  return Infinity;
}
// 能一键修好的问题返回 {label, run}；run 只改数据，由调用方负责保存与重绘。
function issueFix(issue) {
  const code = issue.code, r = board.roles.find(x => x.uid === (issue.uid || issue.roleUid));
  // 人数和角色池的差额只提示，不替玩家选择阵营或调整角色上限。
  if (code === 'NEUTRAL_ROLE_COUNT' && r) return {label: '改为每局最多 1 人', run() { E.setRoleCount(r, 1); }};
  if ((code === 'NEUTRAL_ROLE_DUPLICATE' || code === 'NEUTRAL_PAIR_UNSUPPORTED') && r) return {label: `把「${r.name}」移出角色池`, run() { E.removeRole(board, r.uid); if (ui.roleUid === r.uid) ui.roleUid = ''; }};
  if (['EXTRA_UNREACHABLE', 'MEETING_GOAL_UNREACHABLE'].includes(code) && issue.camp) {
    const names = issueNames(issue), rule = E.campRule(board, issue.camp);
    const hit = rule.events.filter(e => names.includes(E.eventCatalog[e.type].name));
    if (hit.some(e => e.type === 'reports') && !board.room.allow_report_dead) return {label: '开启「报告鸡腿」', run() { board.room.allow_report_dead = true; }};
    if (hit.length && hit.every(e => goalLimit(issue.camp, e.type) >= 1)) return {label: '把目标调到能完成的数量', run() { for (const e of hit) e.value = Math.min(e.value, goalLimit(issue.camp, e.type)); }};
    return null;
  }
  if (r && code.startsWith('SKILL_') && code !== 'SKILL_FAMILY_POOL') {
    const bad = [...new Set(E.allIds(r))].filter(id => E.skillMountIssue(r, id));
    if (bad.length) return {label: '移除不可用的技能', run() { for (const id of bad) if(!E.locked(r,id))E.removeSkill(r, id); }};
  }
  return null;
}

/* ---------- 席位：房间人数、各阵营名额、候选角色上限独立编辑 ---------- */
function setTotal(n) {
  const {min, max} = E.ROOM_LIMITS;
  if (!Number.isInteger(n) || n < min || n > max || n === board.room.total) return false;
  ui.seatPop = n > board.room.total ? board.room.total : -1;
  board.room.total = n;
  return true;
}
function setSeats(camp, n) {
  if (!E.faction(board, camp) || !Number.isInteger(n) || n < 0 || n > E.ROOM_LIMITS.max || n === board.room.counts[camp]) return false;
  board.room.counts[camp] = n;
  return true;
}

/* ---------- 自创角色的复制与粘贴（留在本机浏览器里，换一块板子也能粘贴） ---------- */
function readRoleClip() {
  try {
    const c = JSON.parse(localStorage.getItem(ROLE_CLIP) || 'null');
    return c && c.v === 1 && typeof c.name === 'string' && c.name.trim() && c.slots && typeof c.slots === 'object' ? c : null;
  } catch { return null; }
}
function copyRole(uid) {
  const r = role(uid); if (!r) return;
  if (!E.isCustom(r)) { toast('已有职业不能复制，只有自创角色可以'); return; }
  roleClip = {v: 1, name: r.name, count: r.count, appearance:r.appearance||'random', camp: r.camp, slots: clone(r.slots), skillOverrides: clone(r.skillOverrides || {})};
  try { localStorage.setItem(ROLE_CLIP, JSON.stringify(roleClip)); } catch { /* 存不进本机不影响这一次粘贴 */ }
  render(); toast('已复制「' + r.name + '」。点“新建角色”，就能粘贴出一个新的');
}
function uniqueRoleName(name) {
  const names = new Set(board.roles.map(r => r.name)), base = (String(name || '').trim() || '自创角色').replace(/ 副本\d*$/, '').slice(0, 20);
  if (!names.has(base)) return base;
  for (let n = 1; n < 1000; n++) { const suffix = ' 副本' + (n > 1 ? n : ''), candidate = base.slice(0, 20 - suffix.length) + suffix; if (!names.has(candidate)) return candidate; }
  return base;
}
function nextCustomName() { let name = '自创角色', n = 2; const names = new Set(board.roles.map(r => r.name)); while (names.has(name)) name = '自创角色' + n++; return name; }
function pasteRole(camp) {
  if (!roleClip) throw Error('还没有复制角色：先打开一个自创角色，点“复制”');
  camp = Number(camp);
  if (camp === 3) throw Error('中立阵营只能添加已有职业，请粘贴到鹅、鸭或新阵营');
  if (!E.faction(board, camp)) throw Error('请先选择一个阵营');
  if (board.roles.length >= E.MAX_POOL_ROLES) throw Error('角色池最多 ' + E.MAX_POOL_ROLES + ' 个角色');
  const r = E.makeCustomRole(board, camp);
  r.name = uniqueRoleName(roleClip.name);
  try { E.setRoleCount(r, roleClip.count); } catch { /* 上限不合规时保持默认 1 */ }
  r.appearance=roleClip.appearance==='fixed'?'fixed':'random';r.slots = {...r.slots, ...clone(roleClip.slots)}; r.skillOverrides = clone(roleClip.skillOverrides || {});
  // 剪贴板可能来自另一块板子或更早的版本：先在副本上按草稿规则检查，不合格就不粘贴。
  const trial = clone(board); trial.roles.push(clone(r));
  try { E.validateShape(clone(E.exportDraft(trial))); } catch (error) { throw Error('这个角色粘贴不了：' + error.message); }
  const [issue] = E.workshopSkillIssues(r); if (issue) throw Error('暂不能粘贴：' + issue.text);
  board.roles.push(r);
  return r;
}
window.addEventListener('storage', e => { if (e.key === ROLE_CLIP) roleClip = readRoleClip(); });

/* ---------- 通用控件 ---------- */
// 加减器：按钮一下一格，按住连续变化；点数字可以直接输入。bind 说明它改的是哪个值（见 bindSpec）。
function stepper(bind, o = {}) {
  const s = bindSpec(bind); if (!s) return '';
  const label = o.label || '', cls = o.cls || '';
  return `<span class="stp ${cls}" data-bind="${esc(bind)}">` +
    `<button type="button" class="stp-b" data-step="-1" aria-label="减少${esc(label)}" ${stepEnd(s, -1) ? 'disabled' : ''}>${icon('minus')}</button>` +
    `<label class="stp-v">${o.pre ? `<span class="stp-u">${esc(o.pre)}</span>` : ''}<input type="number" inputmode="numeric" enterkeyhint="done" value="${s.value}" min="${s.min}" max="${s.max}" aria-label="${esc(label)}">${o.unit ? `<span class="stp-u">${esc(o.unit)}</span>` : ''}</label>` +
    `<button type="button" class="stp-b" data-step="1" aria-label="增加${esc(label)}" ${stepEnd(s, 1) ? 'disabled' : ''}>${icon('plus')}</button></span>`;
}
function stepNext(s, dir) {
  if (s.choices) {
    const list = [...new Set([...s.choices, s.value])].sort((a, b) => a - b), i = list.indexOf(s.value);
    return list[clamp(i + dir, 0, list.length - 1)];
  }
  return clamp(s.value + dir * (s.step || 1), s.min, s.max);
}
function stepEnd(s, dir) { return stepNext(s, dir) === s.value; }
function switchRow(key, label, value, on = '允许', off = '禁止', ic = '') {
  return `<label class="tog"><span class="tog-l"><b>${esc(label)}</b><em class="tog-s ${value ? 'is-on' : ''}">${value ? on : off}</em></span><span class="sw"><input type="checkbox" role="switch" data-toggle="${esc(key)}" data-on="${esc(on)}" data-off="${esc(off)}" aria-label="${esc(label)}" ${value ? 'checked' : ''}><i aria-hidden="true"></i></span></label>`;
}
function segmented(name, items, current) {
  return `<div class="seg" role="tablist">${items.map(([key, label, badge]) => `<button type="button" role="tab" aria-selected="${key === current}" class="seg-i ${key === current ? 'is-on' : ''}" data-act="seg" data-seg="${esc(name)}" data-key="${esc(key)}">${esc(label)}${badge ? `<b>${badge}</b>` : ''}</button>`).join('')}</div>`;
}
function undoPill() {
  if(!undo)return '';
  const compact=['lineup','roles','play'].includes(ui.page),label='撤销「'+esc(undo.label)+'」';
  return `<button class="undo-pill ${compact?'is-compact':''}" data-act="undo" aria-label="${label}" title="${label}">${icon('undo')}<span>${compact?'撤销':label}</span></button>`;
}
function emptyState(title, text, actions = '') {
  return `<div class="empty">${artImg(CUSTOM_ICON, 'empty-art', '', false)}<div><h3>${title}</h3><p>${text}</p>${actions ? `<div class="empty-acts">${actions}</div>` : ''}</div></div>`;
}

/* ---------- 数值绑定：加减器、滑杆和输入框都通过这里读写数据 ---------- */
function findEvent(id) { for (const rule of board.campEvents) { const event = rule.events.find(e => e.id === id); if (event) return {rule, event}; } return null; }
let paramSkill = 0;         // 正在调整参数的技能（原始技能 id）
function bindSpec(bind) {
  const [kind, a, b] = String(bind).split(':'), {min, max} = E.ROOM_LIMITS;
  if (kind === 'total') return {value: board.room.total, min, max, set: v => { setTotal(v); }};
  if (kind === 'seat') return {value: board.room.counts[a] || 0, min: 0, max, set: v => { setSeats(a, v); }};
  if (kind === 'room') { const [lo, hi] = D.custom[0][a]; return {value: board.room[a], min: lo, max: hi, set: v => { board.room[a] = v; }}; }
  if (kind === 'opt') { const d = E.ROOM_FIELDS[a], [lo, hi] = D.custom[0][a]; return {value: board.room[a], min: lo, max: hi, choices: d.choices, set: v => { board.room[a] = v; }}; }
  if (kind === 'cap') { const r = role(a); return r ? {value: r.count, min: 1, max:Math.min(max,E.careerLimit(r)), set: v => { E.setRoleCount(r, v); }} : null; }
  if (kind === 'scope' && ['value','weight'].includes(a)) { const L=topLayer(); if (L?.name!=='cond')return null; return {value:L[a],min:1,max:a==='weight'?E.MAX_EVENT_WEIGHT:999,step:a==='weight'||E.eventCatalog[L.type].unit==='秒'?10:1,local:true,set:v=>{L[a]=v;}}; }
  if (kind === 'evv') { const hit = findEvent(a); if (!hit) return null; const big = E.eventCatalog[hit.event.type].unit === '秒'; return {value: hit.event.value, min: 1, max: 999, step: big ? 10 : 1, set: v => { hit.event.value = v; }}; }
  if (kind === 'evw') { const hit = findEvent(a); return hit ? {value: hit.event.weight, min: 1, max: E.MAX_EVENT_WEIGHT, step: 10, set: v => { hit.event.weight = v; }} : null; }
  if (kind === 'sp' || kind === 'st') {
    const r = role(); if (!E.canEditEquippedSkill(r, paramSkill)) return null;
    const s = E.effective(r, paramSkill);
    if (kind === 'sp') return {value: s[a], min: 0, max: 100000, set: v => { (r.skillOverrides[paramSkill] ||= {})[a] = v; }};
    const stage = s.stages.find(x => String(x.id) === a); if (!stage) return null;
    return {value: stage[b], min: 0, max: 100000, step: b === 'cd_type_param_1' && stage.cd_type === 1 ? 10 : 1, set: v => { const o = r.skillOverrides[paramSkill] ||= {}; o.stages ||= {}; (o.stages[a] ||= {})[b] = v; }};
  }
  if (kind === 'sim') return scenario ? {value: scenario.progress[a] || 0, min: 0, max: 999, local: true, set: v => { scenario.progress[a] = v; simRun = false; }} : null;
  return null;
}
// 把一个值写进数据。local 的值（试算进度）不属于板子，不触发保存。
function bindWrite(bind, value) {
  const s = bindSpec(bind); if (!s) return null;
  if (!Number.isInteger(value) || value < s.min || value > s.max) throw Error('请输入 ' + s.min + '–' + s.max + ' 的整数');
  if (value !== s.value) s.set(value);
  return s;
}
// 按住加减时不整页重画（被按住的按钮不能被替换）：只把页面上所有绑定的数字同步一遍。
function syncBound() {
  for (const node of $$('.stp[data-bind]')) {
    const s = bindSpec(node.dataset.bind); if (!s) continue;
    const input = $('input', node); if (input && document.activeElement !== input) input.value = s.value;
    const [minus, plus] = $$('.stp-b', node);
    if (minus && minus !== holding?.el) minus.disabled = stepEnd(s, -1);
    if (plus && plus !== holding?.el) plus.disabled = stepEnd(s, 1);
  }
  for (const rng of $$('input[type=range][data-bind]')) { const s = bindSpec(rng.dataset.bind); if (!s) continue; if (document.activeElement !== rng) rng.value = s.value; setPct(rng); }
  const gap = seatGapText();
  for (const node of $$('[data-seat-gap]')) { const label = $('b', node); if (label.textContent !== gap) label.textContent = gap; node.hidden = !gap; }
}
function setPct(range) { const lo = Number(range.min), hi = Number(range.max), v = clamp(Number(range.value), lo, hi); range.style.setProperty('--pct', ((v - lo) / (hi - lo || 1) * 100).toFixed(1) + '%'); }
// 一次加减操作结束：保存、重画。
function finishBound(bind) {
  const s = bindSpec(bind);
  if (s && s.local) { if (softRender) renderSoon(); else render(); } else { commit(); ui.seatPop = -1; }
}
// 点一下加减按钮：走一格，立即保存并重画。
function stepOnce(el) {
  const box = el.closest('.stp'); if (!box) return;
  const bind = box.dataset.bind, s = bindSpec(bind); if (!s) return;
  const next = stepNext(s, Number(el.dataset.step)); if (next === s.value) return;
  s.set(next);
  const after = bindSpec(bind);
  if (after && after.value !== s.value) finishBound(bind);
}
// 按住加减按钮：稍等后连续变化，按得久了改成大步走。按住期间不整页重画，松手时再保存。
let holding = null, holdSuppress = 0;   // holding：{el, bind, dir, timer, repeating, changed, ticks}
function holdArm(el) {
  holdRelease();
  const box = el.closest('.stp'); if (!box || el.disabled) return;
  holding = {el, bind: box.dataset.bind, dir: Number(el.dataset.step), repeating: false, changed: false, ticks: 0, timer: 0};
  holding.timer = setTimeout(() => { if (holding) { holding.repeating = true; holdLoop(); } }, 430);
}
function holdLoop() {
  const h = holding; if (!h) return;
  if (holdTick(h)) h.timer = setTimeout(holdLoop, h.ticks > 10 ? 60 : 90);
}
function holdTick(h) {
  const s = bindSpec(h.bind); if (!s) return false;
  let next = stepNext(s, h.dir);
  if (h.ticks > 10 && !s.choices && s.max - s.min > 60) {
    const big = (s.step || 1) * 5;
    next = clamp(h.dir > 0 ? Math.floor(s.value / big) * big + big : Math.ceil(s.value / big) * big - big, s.min, s.max);
  }
  if (next === s.value || ++h.ticks > 500) return false;
  try { s.set(next); } catch (err) { toast(err.message); return false; }
  const after = bindSpec(h.bind);
  if (!after || after.value === s.value) return false;
  h.changed = true; syncBound();
  return true;
}
function holdRelease() {
  const h = holding; if (!h) return;
  clearTimeout(h.timer); holding = null;
  if (!h.repeating) return;
  holdSuppress = Date.now();          // 长按松手后浏览器还会补一个 click，忽略它
  if (h.changed) finishBound(h.bind);
}

/* ---------- 弹层：右侧面板（sheet）、整屏清单（overlay）、确认框（dialog） ---------- */
const layers = [];
let layerSeq = 0;
function openLayer(kind, view, opts = {}) {
  const L = {id: ++layerSeq, kind, view, ...opts};
  layers.push(L); renderLayers(L.id);
  return L;
}
function topLayer() { return layers[layers.length - 1] || null; }
function closeLayer(silent = false) {
  const L = layers.pop(); if (!L) return;
  if (L.onClose) L.onClose();
  if (!silent) renderLayers();
}
function closeAllLayers(silent = false) { while (layers.length) { const L = layers.pop(); if (L.onClose) L.onClose(); } if (!silent) renderLayers(); }
function layerShell(L, inner, entering) {
  const enter = entering ? ' enter' : '';
  if (L.kind === 'sheet') return `<div class="layer is-sheet${enter}" data-layer="${L.id}"><div class="scrim" data-act="close"></div><aside class="sheet ${L.cls || ''}" role="dialog" aria-modal="true">${inner}</aside></div>`;
  if (L.kind === 'overlay') return `<div class="layer is-ov${enter}" data-layer="${L.id}"><section class="ov ${L.cls || ''}" role="dialog" aria-modal="true">${inner}</section></div>`;
  return `<div class="layer is-dlg${enter}" data-layer="${L.id}"><div class="scrim" data-act="close"></div><div class="dlg ${L.cls || ''}" role="alertdialog" aria-modal="true">${inner}</div></div>`;
}
function renderLayers(enteringId = 0) {
  const root = $('#layers'), keep = keepScroll(root), html = [];
  for (let i = 0; i < layers.length; i++) {
    const L = layers[i]; let inner;
    try { inner = L.view(L); }
    catch (err) { inner = `<header class="sh-h"><div><h2>出了点问题</h2></div><button class="icon-btn" data-act="close" aria-label="关闭">${icon('x')}</button></header><div class="sh-b"><p class="note bad">${esc(err.message)}</p></div>`; }
    // 视图返回 null 表示它依赖的对象已经不在了（比如角色被删掉）：这一层直接关掉。
    if (inner == null) { layers.splice(i, 1); i--; continue; }
    html.push(layerShell(L, inner, L.id === enteringId));
  }
  root.innerHTML = html.join('');
  restoreScroll(root, keep);
  const app = $('#app'); if (app) app.inert = layers.length > 0;
  $$('input[type=range]', root).forEach(setPct);
  if (enteringId) { const node = $(`[data-layer="${enteringId}"]`); (node && ($('[data-focus]', node) || $('.icon-btn', node) || $('button', node)))?.focus({preventScroll: true}); }
}
function keepScroll(root) { const m = new Map(); $$('[data-keep]', root).forEach(n => m.set(n.dataset.keep, [n.scrollTop, n.scrollLeft])); return m; }
function restoreScroll(root, m) { $$('[data-keep]', root).forEach(n => { const v = m.get(n.dataset.keep); if (v) { n.scrollTop = v[0]; n.scrollLeft = v[1]; } }); }
const sheetHead = (title, sub = '') => `<header class="sh-h"><div><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ''}</div><button class="icon-btn" data-act="close" aria-label="关闭">${icon('x')}</button></header>`;
const overlayHead = (title, right = '', back = 'x') => `<header class="ov-h"><button class="icon-btn" data-act="close" aria-label="关闭">${icon(back)}</button><h2>${title}</h2><span class="grow"></span>${right}</header>`;
function confirmDialog({title, text, note = '', ok = '确定', danger = false, onOk}) {
  openLayer('dialog', () => `<h2>${title}</h2><p>${text}</p>${note ? `<p class="dlg-note">${note}</p>` : ''}<div class="dlg-acts"><button class="btn btn-soft" data-act="close">取消</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-act="dialog-ok" data-focus>${ok}</button></div>`, {onOk});
}

/* ---------- 轻提示 ---------- */
let toastTimer = 0;
function toast(text, action = null) {
  const n = $('#toast'); if (!n) return;
  n.innerHTML = `<span>${nums(esc(uiCopy(text)))}</span>${action ? `<button type="button" data-act="${esc(action.act)}">${esc(action.label)}</button>` : ''}`;
  n.classList.toggle('beside-sheet', topLayer()?.kind === 'sheet');
  n.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => n.classList.remove('show'), action ? 6500 : 3200);
}
