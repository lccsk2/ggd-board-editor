'use strict';
/*
 * 鹅鸭杀 · 板子工坊 · 手机横屏版 · 页面
 * 左侧导航 + 六个页面：
 * 板子（名字、介绍、概览、存档与分享）、房间（人数与房规）、阵容（阵营、席位、角色池）、
 * 角色（创造新角色、给角色换技能）、胜利（每个阵营怎么赢）、试玩（抽一桌、试算、导出）。
 */
const PAGES = [
  {key: 'info', label: '板子', art: 'board'},
  {key: 'room', label: '房间', art: 'room'},
  {key: 'lineup', label: '阵容', art: 'factions'},
  {key: 'roles', label: '角色', art: 'char'},
  {key: 'wins', label: '胜利', art: 'wins'},
  {key: 'play', label: '试玩', art: 'play'}
];
const ROOM_ICON = {meeting_amount: 'bell', discuss_cd: 'users', vote_cd: 'ballot', first_bell_cd: 'clock', meeting_cd: 'refresh', meeting_hit_cd: 'swords', meeting_destroy_cd: 'bolt', allow_speak: 'megaphone', discuss_chat: 'book', discuss_emojis: 'sparkle', allow_report_dead: 'bell', hide: 'lock'};
const ROOM_TABS = {
  pace: ['hit_cd', 'task'],
  meeting: ['meeting_amount', 'discuss_cd', 'vote_cd', 'first_bell_cd', 'meeting_cd', 'meeting_hit_cd', 'meeting_destroy_cd'],
  rules: ['allow_speak', 'discuss_chat', 'discuss_emojis', 'allow_report_dead', 'hide']
};
const CATEGORY_ICON = {'对抗与推理': 'swords', '行动与技能': 'bolt', '会议与生存': 'bell'};
const COND_ICON = {kills: 'swords', voteOuts: 'ballot', investigations: 'search', ballotsCast: 'check', reports: 'megaphone', skillUses: 'bolt', ventTrips: 'swap', crisisRepairs: 'gear', exploredRooms: 'map', distinctSkillUses: 'sparkle', surviveMeetings: 'shield', zeroVoteMeetings: 'ban', votedSurvivalMeetings: 'alert', emergencyCalls: 'bell', meetingsAttended: 'users', survivalTime: 'clock'};
const condIcon = type => COND_ICON[type] || CATEGORY_ICON[E.eventCatalog[type]?.category] || 'target';

/* ---------- 外框 ---------- */
function renderRail() {
  const errs = errorCount();
  $('#rail').innerHTML = `
<div class="rail-nav">${PAGES.map(p => {
    const n = issuesAt(p.key).length, on = ui.page === p.key;
    return `<button class="rail-i ${on ? 'is-on' : ''}" data-act="go" data-page="${p.key}" aria-current="${on ? 'page' : 'false'}">${sticker(p.art)}<span>${p.label}</span>${n ? `<i class="rail-dot" aria-label="${n} 项待处理">${n}</i>` : ''}</button>`;
  }).join('')}</div>
<button class="rail-check ${errs ? 'is-bad' : 'is-ok'}" data-act="check" aria-label="${errs ? errs + ' 项待处理，点开查看' : '检查通过，点开查看'}">${icon(errs ? 'alert' : 'check')}<span>${errs ? errs + ' 项' : '可开局'}</span></button>`;
}
function pageHtml() {
  if (ui.roleUid && (!role() || ui.page !== 'roles')) ui.roleUid = '';
  if (ui.page === 'info') return infoPage();
  if (ui.page === 'room') return roomPage();
  if (ui.page === 'lineup') return lineupPage();
  if (ui.page === 'roles') return ui.roleUid ? rolePage() : rolesPage();
  if (ui.page === 'wins') return winsPage();
  return playPage();
}
function render() {
  renderPending = false; clearTimeout(renderTimer);
  renderRail();
  const stage = $('#stage'), view = ui.page + (ui.page === 'roles' && ui.roleUid ? ':' + ui.roleUid : '');
  const keep = stage.dataset.view === view ? keepScroll(stage) : null;
  stage.innerHTML = pageHtml(); stage.dataset.view = view;
  if (keep) restoreScroll(stage, keep);
  $$('input[type=range]', stage).forEach(setPct);
  renderLayers();
  if (ui.flash) {
    const node = $(ui.flash); ui.flash = '';
    if (node) { node.scrollIntoView({block: 'nearest'}); node.classList.add('flash'); setTimeout(() => node.classList.remove('flash'), 2200); }
  }
  justDrew = false;
}
// 换页。uid：直接打开某个角色（只在角色页有效）；from：编辑完这个角色回到哪一页。
function go(page, opts = {}) {
  if (!PAGES.some(p => p.key === page)) return;
  closeAllLayers(true);
  ui.page = page; ui.roleUid = page === 'roles' && opts.uid && role(opts.uid) ? opts.uid : '';
  if (ui.roleUid) ui.roleBack = opts.from === 'lineup' ? 'lineup' : 'roles';
  if (opts.flash) ui.flash = opts.flash;
  render();
  const body = $('#stage .scroll'); if (body && !opts.keepScroll && !opts.flash) body.scrollTop = 0;
}

/* ---------- 会议桌：一圈席位 ---------- */
const ringCache = new Map();
// 椭圆上按弧长等距取 n 个点（百分比坐标），席位不会在两端挤成一团。
function ringPoints(n, aspect = 1.7, rx = 44, ry = 39) {
  const key = [n, aspect, rx, ry].join(':'); if (ringCache.has(key)) return ringCache.get(key);
  const N = 720, pts = [], len = [0];
  for (let i = 0; i <= N; i++) {
    const a = -Math.PI / 2 + i / N * 2 * Math.PI; pts.push([rx * Math.cos(a), ry * Math.sin(a)]);
    if (i) len.push(len[i - 1] + Math.hypot((pts[i][0] - pts[i - 1][0]) * aspect, pts[i][1] - pts[i - 1][1]));
  }
  const out = []; let j = 0;
  for (let k = 0; k < n; k++) { const target = len[N] * k / n; while (j < N && len[j] < target) j++; out.push([50 + pts[j][0], 50 + pts[j][1]]); }
  ringCache.set(key, out); return out;
}
// 还没抽角色时，按各阵营人数摆出席位；没分出去的席位留空。
function planTokens() {
  const list = [];
  for (const f of board.factions) for (let i = 0; i < (board.room.counts[f.id] || 0) && list.length < E.ROOM_LIMITS.max; i++) list.push({camp: f.id});
  while (list.length < board.room.total) list.push({camp: null});
  return list.map((t, i) => ({...t, over: i >= board.room.total}));
}
function tableViz(tokens, mid, drawn = false) {
  const n = Math.max(1, tokens.length), pts = ringPoints(n), size = n <= 10 ? 'lg' : n <= 13 ? 'md' : 'sm';
  const seats = tokens.map((t, i) => {
    const [x, y] = pts[i], pos = `left:${x.toFixed(2)}%;top:${y.toFixed(2)}%;`;
    if (drawn) {
      const a = t.templateCareerId === null ? {icon: CUSTOM_ICON} : ART.roles[t.templateCareerId];
      return `<span class="seat is-role ${justDrew ? 'reveal' : ''}" style="${pos}${fc(t.camp)};--d:${i * 55}ms" title="席位 ${i + 1} · ${esc(t.name)}">${a?.icon ? artImg(a.icon, '', '', false) : `<b>${esc(t.name.slice(0, 1))}</b>`}<i>${i + 1}</i></span>`;
    }
    const f = t.camp != null ? E.faction(board, t.camp) : null, art = f && f.id <= 3 ? ART.camps?.[f.id] : null;
    return `<span class="seat ${f ? '' : 'is-open'} ${t.over ? 'is-over' : ''} ${ui.seatPop >= 0 && i >= ui.seatPop ? 'pop' : ''}" style="${pos}${f ? fc(f.id) : ''}" title="${f ? esc(f.name) : '还没分配'}">${art ? artImg(art, '', '', false) : `<b>${f ? esc([...f.name][0]) : '?'}</b>`}</span>`;
  }).join('');
  return `<div class="tbl tbl-${size}"><div class="tbl-top" aria-hidden="true"></div><div class="tbl-ring" aria-hidden="true">${seats}</div><div class="tbl-mid">${mid}</div></div>`;
}
function seatBar() {
  return `<div class="seatbar" aria-hidden="true">${planTokens().map(t => `<i class="${t.camp == null ? 'is-open' : ''} ${t.over ? 'is-over' : ''}" style="${t.camp != null ? fc(t.camp) : ''}"></i>`).join('')}</div>`;
}

/* ---------- 板子：名字、介绍、概览、存档与分享 ---------- */
function fmtTime(iso) {
  const d = new Date(iso); if (Number.isNaN(d.getTime())) return '';
  const p = n => String(n).padStart(2, '0');
  return `${d.getMonth() + 1}月${d.getDate()}日 ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function infoTiles() {
  const r = board.room, mine = board.roles.filter(x => E.isCustom(x)).length, own = board.factions.filter(f => f.kind === 'custom').length;
  const extra = board.campEvents.reduce((n, rule) => n + rule.events.length, 0);
  // 席位怎么分：原有阵营各写各的，自建阵营合在一起算（名字可能很长，也可能带数字）。
  const seat = (label, n) => n > 0 ? `<i>${esc(label)} <b class="num">${n}</b></i>` : '';
  const ownSeats = board.factions.filter(f => f.kind === 'custom').reduce((n, f) => n + (r.counts[f.id] || 0), 0);
  const split = board.factions.filter(f => f.kind !== 'custom').map(f => seat(shortCamp(f), r.counts[f.id] || 0)).join('') + seat('自建', ownSeats);
  const text = s => nums(esc(s));
  return [
    ['room', 'room', '房间', `${r.total} 人`, split || '还没有分配席位'],
    ['lineup', 'factions', '阵营', `${board.factions.length} 个`, text(own ? `${own} 个自建` : '鹅、鸭、中立')],
    ['roles', 'char', '角色', `${board.roles.length} 个`, text(mine ? `${mine} 个自创` : '都是已有职业')],
    ['wins', 'wins', '额外胜利条件', `${extra} 个`, extra ? '优先结算' : '只用原有条件']
  ];
}
function infoPage() {
  const saves = readSaves(), errs = errorCount(), when = fmtTime(board.updatedAt);
  return `<header class="ph">
  <h1>这块板子叫什么？</h1>
  <p class="ph-sub ph-saved">${icon('check')}${esc(saveNote)}</p>
  <span class="grow"></span>${undoPill()}
  <button class="btn btn-ghost btn-sm is-compact" data-act="guide" aria-label="怎么使用">${icon('help')}<span class="lbl">怎么使用</span></button>
  <button class="btn btn-ghost btn-sm" data-act="import">${icon('upload')}导入</button>
  <button class="btn btn-primary btn-sm" data-act="export">${icon('download')}导出板子</button>
</header>
<div class="pb split info">
  <section class="info-main">
   <div class="card info-card">
    <label class="fld"><span>板子名称</span><input type="text" data-field="mod-name" maxlength="40" value="${esc(board.boardName)}" autocomplete="off" enterkeyhint="done"></label>
    <label class="fld info-desc"><span><span class="fld-t">玩法介绍</span><small>选填，让别人一眼看懂这套玩法</small><i class="fld-n num" data-count="mod-desc">${[...board.description].length}/300</i></span><textarea data-field="mod-desc" maxlength="300" placeholder="例如：侦探与炸弹的欢乐对决">${esc(board.description)}</textarea></label>
    <p class="info-meta">${when ? `<span>上次修改 ${when}</span>` : ''}${board.source?.label ? `<span>规则数据 ${esc(board.source.label)}</span>` : ''}</p>
   </div>
   <div class="info-more">
    <a class="btn btn-soft btn-sm" data-switch-style="classic" href="index.html?style=classic" target="_top">${icon('swap')}切换旧样式</a>
    <button class="btn btn-ghost btn-sm" data-act="example">${icon('sparkle')}载入示例板子</button>
    <button class="btn btn-ghost btn-sm is-danger" data-act="reset-all">${icon('undo')}重置全部</button>
   </div>
  </section>
  <section class="info-side scroll" data-keep="info">
    <div class="card info-over">
      <div class="sec-h"><h2>板子概览</h2><span class="grow"></span><button class="state-chip ${errs ? 'is-bad' : 'is-ok'}" data-act="check">${icon(errs ? 'alert' : 'check')}${errs ? nums(`还有 ${errs} 项要处理`) : '可以开局'}</button></div>
      <div class="info-tiles">${infoTiles().map(([page, art, label, value, sub]) => `<button class="info-t" data-act="go" data-page="${page}" aria-label="${label}：${esc(value)}，去设置">${sticker(art)}<span><small>${label}</small><b>${nums(esc(value))}</b><em>${sub}</em></span>${icon('chevron')}</button>`).join('')}</div>
    </div>
    <div class="card info-saves">
      <div class="sec-h"><h2>本机存档<b class="num">${saves.length}</b></h2><span class="sec-note">保留最近 8 份</span><span class="grow"></span><button class="btn btn-soft btn-sm" data-act="save">${icon('save')}存一份</button></div>
      ${saves.map((x, i) => `<div class="save-row"><span><b>${nameHtml(x.name)}</b><small>${esc(new Date(x.time).toLocaleString('zh-CN'))}</small></span><button class="btn btn-soft btn-sm" data-act="load-save" data-i="${i}">打开</button><button class="icon-btn is-danger" data-act="del-save" data-i="${i}" aria-label="删除这份存档">${icon('trash')}</button></div>`).join('') || '<p class="muted info-none">还没有存档。点“存一份”，给现在的板子留个版本。</p>'}
      <div class="menu-recover"><button class="link-btn" data-act="recover">恢复上次自动保存</button><button class="link-btn" data-act="recover-prev">恢复被替换前的草稿</button></div>
    </div>
  </section>
</div>`;
}

/* ---------- 房间：人数与房规 ---------- */
function roomPage() {
  const r = board.room, {min, max} = E.ROOM_LIMITS;
  const tabs = [['pace', '节奏'], ['meeting', '会议'], ['rules', '规则']];
  const panel = ui.roomTab === 'meeting' ? meetingTab() : ui.roomTab === 'rules' ? rulesTab() : paceTab();
  return `<header class="ph">
  <h1>这局怎么玩？</h1>
  <p class="ph-sub">先定几个人，再调节奏、会议和房规。</p>
  <span class="grow"></span>${undoPill()}
  <button class="btn btn-ghost btn-sm" data-act="reset-page">${icon('undo')}重置本页</button>
</header>
<div class="pb split room">
  <section class="card tcard" data-field="total">
    ${tableViz(planTokens(), stepper('total', {cls: 'stp-hero', unit: '人', label: '房间人数'}))}
    <div class="presets" role="group" aria-label="常用人数">${[min, 6, 8, 10, 12, max].map(n => `<button class="chip ${r.total === n ? 'is-on' : ''}" data-act="preset" data-n="${n}" aria-pressed="${r.total === n}">${n} 人</button>`).join('')}</div>
    <div class="split-row">${board.factions.filter(f => r.counts[f.id] > 0).map(f => `<span class="split-i" style="${fc(f.id)}"><i></i>${esc(shortCamp(f))}<b class="num">${r.counts[f.id]}</b></span>`).join('') || '<span class="split-i">还没有分配席位</span>'}</div>
    <div class="tcard-acts">${seatGapTag()}<button class="link-btn" data-act="go" data-page="lineup">调整各阵营人数${icon('chevron')}</button></div>
  </section>
  <section class="side">
    ${segmented('room', tabs, ui.roomTab)}
    <div class="card side-card" role="tabpanel">${panel}</div>
  </section>
</div>`;
}
function rangeRow(key, label, ic, unit, help) {
  const [lo, hi] = D.custom[0][key], v = board.room[key];
  return `<div class="rng-row" data-field="${key}">
  <div class="rng-top"><span class="lab">${icon(ic)}<span>${label}<small>${help}</small></span></span>${stepper('room:' + key, {unit, label})}</div>
  <div class="rng-line"><span>${lo}</span><input class="rng" type="range" min="${lo}" max="${hi}" value="${clamp(v, lo, hi)}" data-bind="room:${key}" aria-label="${label}"><span>${hi}</span></div>
</div>`;
}
function paceTab() {
  return `<div class="pace">${rangeRow('hit_cd', '击倒冷却', 'swords', '秒', '两次击倒之间要等多久')}${rangeRow('task', '任务总数', 'check', '', '鹅阵营做完全部任务就能赢')}</div>`;
}
function meetingTab() {
  return `<div class="opts">${ROOM_TABS.meeting.map(key => { const d = E.ROOM_FIELDS[key]; return `<div class="opt" data-field="${key}"><span class="lab">${icon(ROOM_ICON[key])}${d.label}</span>${stepper('opt:' + key, {unit: d.unit, label: d.label})}</div>`; }).join('')}
  <p class="opt-hint">加减按常用值跳，点数字可以输入别的值。拍铃次数全房间共用，每人最多一次；报告鸡腿不占次数。</p></div>`;
}
function rulesTab() {
  const r = board.room;
  return `<div class="togs">${['allow_speak', 'discuss_chat', 'discuss_emojis', 'allow_report_dead'].map(key => switchRow(key, E.ROOM_FIELDS[key].label, r[key], '允许', '禁止', ROOM_ICON[key])).join('')}${switchRow('hide', '放逐后身份', r.hide, '隐藏', '公开', ROOM_ICON.hide)}
  <p class="opt-hint">这些规则对所有阵营都生效。关闭「报告鸡腿」后，发现鸡腿不能发起会议。</p></div>`;
}

/* ---------- 阵容：阵营、席位、角色 ---------- */
function poolNote(f, p) {
  if (!p.seats) return {text: p.candidates ? `${p.candidates} 个角色待命，这局不出场` : '这局不出场'};
  if (p.capacity === p.seats) return {text: `${p.candidates} 个角色，每局都会出场`};
  return {text: `${p.candidates} 个角色里，每局随机出场 ${p.seats} 个`};
}
function roleToken(r) {
  const bad = roleHasIssue(r.uid) || E.compatibilityIssues(r).length > 0;
  const uid = esc(r.uid), name = esc(r.name);
  return `<span class="tok-wrap" style="${fc(r.camp)}">
    <button type="button" class="tok ${bad ? 'is-bad' : ''}" data-act="role" data-uid="${uid}" aria-label="编辑${name}">${avatar(r.templateCareerId, r.camp)}<span class="tok-n">${nameHtml(r.name)}</span>${r.count > 1 ? `<i class="tok-cap">≤${r.count}</i>` : ''}${bad ? '<i class="tok-warn" aria-label="有问题">!</i>' : ''}</button>
    <button type="button" class="tok-remove" data-act="remove-role" data-uid="${uid}" aria-label="移出${name}" title="移出${name}">${icon('x')}</button>
  </span>`;
}
function lane(f) {
  const p = E.poolStats(board, f.id), members = rolesOf(f.id), custom = f.kind === 'custom';
  const bad = laneIssue(f.id), note = bad ? {bad: true, text: bad.text} : poolNote(f, p), fix = bad?.fix;
  const noWin = custom && !E.campRule(board, f.id)?.events.length;
  return `<article class="lane" data-lane="${f.id}" style="${fc(f.id)}">
  <div class="lane-h">
    <button class="lane-id" data-act="faction" data-camp="${f.id}" aria-label="${esc(f.name)}：查看与设置">${emblem(f)}<span class="lane-name"><b>${nameHtml(f.name)}</b><small>${f.id === 3 ? '各自获胜' : '共同获胜'}${custom ? ' · 自建阵营' : ''}</small></span>${icon(custom ? 'pencil' : 'chevron')}</button>
    <div class="lane-seats">${stepper('seat:' + f.id, {pre: '出场', unit: '人', label: f.name + '出场人数', cls: 'stp-ink'})}</div>
  </div>
  <div class="lane-b">
    <p class="lane-note ${note.bad ? 'is-bad' : ''}">${note.bad ? icon('alert') : ''}<span>${nums(esc(note.text))}</span>${fix ? `<button class="link-btn" data-act="fix" data-i="${checkReport.indexOf(bad.issue)}">${nums(esc(fix.label))}</button>` : ''}${noWin ? `<button class="link-btn is-warn" data-act="go-wins" data-camp="${f.id}">${icon('alert')}还没有胜利条件</button>` : ''}</p>
    <div class="toks">${members.map(roleToken).join('')}<button class="tok tok-add" data-act="add-role" data-camp="${f.id}" aria-label="给${esc(f.name)}添加角色"><span class="ava">${icon('plus')}</span><span class="tok-n">添加</span></button></div>
  </div>
</article>`;
}
function lineupPage() {
  const full = board.factions.length >= E.MAX_FACTIONS;
  return `<header class="ph">
  <h1>谁和谁是一队？</h1>
  <div class="ph-seats">${seatGapTag()}${seatBar()}${stepper('total', {cls: 'stp-sm', unit: '人', label: '房间人数'})}</div>
  <span class="grow"></span>${undoPill()}
  <button class="icon-btn" data-act="reset-page" aria-label="重置本页">${icon('undo')}</button>
  <button class="btn btn-primary btn-sm" data-act="add-faction" ${full ? 'disabled' : ''}>${icon('plus')}新阵营</button>
</header>
<div class="pb scroll lineup" data-keep="lineup">
  ${board.factions.map(lane).join('')}
  <button class="lane-new" data-act="add-faction" ${full ? 'disabled' : ''}><span class="lane-new-plus">${icon('plus')}</span><span><b>${full ? nums('已有 ' + E.MAX_FACTIONS + ' 个阵营，到上限了') : '新增一个阵营'}</b><small>自己的队伍：起个名字，分几个席位，放进角色，再定怎么赢。</small></span></button>
</div>`;
}

/* ---------- 角色：创造新角色，或者挑一个角色换技能 ---------- */
function roleFilters() {
  const mine = board.roles.filter(r => E.isCustom(r)).length;
  return [['all', '全部', board.roles.length], ['custom', '自创', mine], ...board.factions.map(f => [String(f.id), shortCamp(f), rolesOf(f.id).length])];
}
function roleCard(r) {
  const custom = E.isCustom(r), f = E.faction(board, r.camp), n = E.equippedSkills(r).length;
  const bad = roleHasIssue(r.uid) || E.compatibilityIssues(r).length > 0;
  return `<button class="rc ${bad ? 'is-bad' : ''}" data-act="role" data-uid="${esc(r.uid)}" data-rc="${esc(r.uid)}" style="${fc(r.camp)}" aria-label="编辑${esc(r.name)}">
  <span class="rc-av">${avatar(r.templateCareerId, r.camp)}${bad ? '<i class="tok-warn" aria-label="有问题">!</i>' : ''}</span>
  <span class="rc-m"><span class="rc-top"><b>${nameHtml(r.name)}</b>${custom ? '<i class="tag is-gold">自创</i>' : ''}</span><small><i class="rc-dot"></i><span>${nameHtml(f ? shortCamp(f) : '未知阵营')}</span><em>${n ? nums(n + ' 个技能') : '还没有技能'}</em></small></span>
  ${icon('chevron', 'rc-go')}
</button>`;
}
function rolesPage() {
  const filters = roleFilters(); if (!filters.some(x => x[0] === ui.roleFilter)) ui.roleFilter = 'all';
  const key = ui.roleFilter, camp = /^\d+$/.test(key) ? Number(key) : 0;
  const byCamp = board.factions.flatMap(f => rolesOf(f.id));
  const list = key === 'all' ? [...byCamp.filter(r => E.isCustom(r)), ...byCamp.filter(r => !E.isCustom(r))] : key === 'custom' ? byCamp.filter(r => E.isCustom(r)) : rolesOf(camp);
  const canNew = camp !== 3, full = board.roles.length >= E.MAX_POOL_ROLES, campAttr = camp ? `data-camp="${camp}"` : '';
  const make = canNew ? `<button class="rc-new" data-act="create-role" ${campAttr} ${full ? 'disabled' : ''}>${artImg(CUSTOM_ICON, 'rc-new-art', '', false)}<span><b>新建角色</b><small>${full ? nums('角色池最多 ' + E.MAX_POOL_ROLES + ' 个角色') : '从零开始：起名字、选阵营、挑技能'}</small></span><i class="rc-plus">${icon('plus')}</i></button>` : '';
  const none = key === 'custom' && !list.length ? '<p class="rc-none">还没有自创角色。新建一个，它会带着你挑的技能加入阵营。</p>' : '';
  return `<header class="ph">
  <h1>谁有什么本事？</h1>
  <p class="ph-sub">创造新角色，或者点一个角色换技能。</p>
  <span class="grow"></span>${undoPill()}
  <button class="btn btn-ghost btn-sm" data-act="add-career" ${campAttr} ${full ? 'disabled' : ''}>${icon('users')}添加已有职业</button>
  <button class="btn btn-primary btn-sm" data-act="create-role" ${campAttr} ${full ? 'disabled' : ''}>${icon('plus')}新建角色</button>
</header>
<div class="pb roles">
  <div class="chips-x rc-filters" role="group" aria-label="筛选角色">${filters.map(([k, label, n]) => `<button class="chip ${k === key ? 'is-on' : ''}" data-act="role-filter" data-key="${k}" aria-pressed="${k === key}">${nameHtml(label)}<b class="num">${n}</b></button>`).join('')}</div>
  <div class="scroll rc-scroll" data-keep="roles">
    <div class="rc-grid">${make}${list.map(roleCard).join('')}</div>
    ${none}
    ${camp === 3 ? `<p class="note rc-note">${icon('info')}<span>中立阵营只能放已有职业，不能新建角色；已有职业的技能照样可以调整。</span></p>` : ''}
  </div>
</div>`;
}

/* ---------- 角色 › 编辑一个角色：名字、阵营、出场上限、技能 ---------- */
// 一张技能卡的状态：是否可用、是否调整过参数。判断口径与规则引擎一致。
function skillState(r, s) {
  const all = E.allIds(r), info = E.skillScope(s.sourceId), outside = !info?.inScope;
  const duplicate = E.equivalentSkillIssues(r).length && s.equivalentIds.filter(key => all.includes(key)).length > 1;
  const incomplete = !s.complete || s.hasRuntimeAction || duplicate;
  const rawIds = [...s.memberIds, ...s.runtimeIds, ...s.equivalentIds].filter(key => all.includes(key));
  const restricted = rawIds.some(key => E.skillMountIssue(r, key));
  const tuned = [...s.memberIds, ...s.equivalentIds].some(key => r.skillOverrides[key] && Object.keys(r.skillOverrides[key]).length);
  return {outside, incomplete, restricted, broken: outside || incomplete || restricted, tuned};
}
function skillCard(r, s) {
  const st = skillState(r, s), passive = s.type === 1;
  const problem = passive && !E.isNativeSkill(r, s.sourceId) ? '非自带被动，请移除' : st.outside || st.restricted ? '暂不可用' : '配置不完整';
  return `<button class="sk ${st.broken ? 'is-bad' : ''}" data-act="skill" data-id="${s.id}" aria-label="${esc(s.name)}：查看与调整">
  ${skillIcon(s.id)}
  <span class="sk-m"><b>${esc(s.name)}</b><small>${esc(s.des || '暂无说明')}</small></span>
  <span class="sk-t">${st.broken ? `<i class="tag is-bad">${problem}</i>` : ''}${st.tuned ? '<i class="tag is-gold">已调整</i>' : ''}${!passive && s.skill_kind === 0 ? '<i class="tag">会议中用</i>' : ''}</span>
  ${icon('chevron', 'sk-go')}
</button>`;
}
function rolePage() {
  const r = role(), custom = E.isCustom(r), f = E.faction(board, r.camp), c = custom ? null : E.careers.get(r.templateCareerId), a = roleArt(r);
  const active = E.equippedSkills(r, {type: 'active'}), passive = E.equippedSkills(r, {type: 'passive'});
  const used = active.length, over = used > E.MAX_ACTIVE_SKILLS;
  const broken = E.compatibilityIssues(r).length > 0 || E.workshopSkillIssues(r).some(i => i.code !== 'SKILL_SLOT_LIMIT'), unique = E.isUniqueNeutral(r);
  return `<header class="ph">
  <button class="btn btn-ghost btn-sm ph-back" data-act="back">${icon('chevron-left')}${ui.roleBack === 'lineup' ? '阵容' : '角色'}</button>
  <h1>${nameHtml(r.name)}</h1>
  <span class="tag is-fc" style="${fc(r.camp)}">${nameHtml(f?.name || '未知阵营')}${custom ? ' · 自创' : ''}</span>
  <span class="grow"></span>${undoPill()}
  ${custom ? `<button class="btn btn-ghost btn-sm" data-act="copy-role">${icon('copy')}复制</button>` : ''}
  <button class="btn btn-ghost btn-sm" data-act="reset-role">${icon('undo')}${custom ? '清空技能' : '恢复预设技能'}</button>
  <button class="btn btn-ghost btn-sm is-danger" data-act="remove-role">${icon('trash')}移出</button>
</header>
<div class="pb split role">
  <aside class="idc" style="${fc(r.camp)}">
    <button class="idc-art ${a?.portrait ? '' : 'is-icon'}" data-act="art" aria-label="查看角色图像与技能">${a?.portrait ? artImg(a.portrait, '', r.name + '立绘', false) : artImg(a?.icon, '', r.name + '图标', false)}</button>
    <label class="idc-name"><input type="text" value="${esc(r.name)}" maxlength="20" data-field="role-name" aria-label="角色名称" autocomplete="off" enterkeyhint="done">${icon('pencil')}</label>
    ${custom ? `<button class="idc-camp" data-act="move-role" aria-label="所属阵营：${esc(f?.name || '')}，点这里更换">${f ? emblem(f, 'xs') : ''}<span>${nameHtml(f?.name || '请选择阵营')}</span>${icon('swap')}</button>` : `<span class="idc-camp is-fixed">${f ? emblem(f, 'xs') : ''}<span>${nameHtml(f?.name || '')}</span>${icon('lock')}</span>`}
    <div class="idc-cap">${unique ? `<span class="idc-lock">${icon('lock')}中立职业每局最多 1 人</span>` : `<span class="idc-cap-l">每局最多几人拿到这个角色</span>${stepper('cap:' + r.uid, {unit: '人', label: '每局最多几人拿到这个角色', cls: 'stp-ink'})}`}</div>
  </aside>
  <section class="skills scroll" data-keep="skills">
    ${over ? `<div class="banner is-warn">${icon('alert')}<span>${nums(`这个角色有 ${used} 个主动技能，最多保留 ${E.MAX_ACTIVE_SKILLS} 个。请先移除 ${used-E.MAX_ACTIVE_SKILLS} 个，再调整技能或试玩。`)}</span></div>` : ''}
    ${broken ? `<div class="banner is-warn">${icon('alert')}<span>这个角色带着暂时不能用的技能，移除后才能开局。</span><button class="btn btn-primary btn-sm" data-act="strip-skills">移除不可用的技能</button></div>` : ''}
    <p class="quote">${custom ? '自创角色从空白开始：起个名字，挑几个技能。它怎么赢，跟着所属阵营走。' : esc(c.des.trim())}</p>
    <div class="sec-h"><h2>主动技能<b class="num" data-active-count>${used}/${E.MAX_ACTIVE_SKILLS}</b></h2><span class="grow"></span><button class="btn btn-primary btn-sm" data-act="skill-lib">${icon(used >= E.MAX_ACTIVE_SKILLS ? 'gear' : 'plus')}${used >= E.MAX_ACTIVE_SKILLS ? '管理技能' : '添加技能'}</button></div>
    ${active.length ? `<div class="sk-grid">${active.map(s => skillCard(r, s)).join('')}</div>` : `<button class="sk-empty" data-act="skill-lib">${icon('plus')}<span>还没有主动技能，点这里挑一个</span></button>`}
    ${passive.length ? `<div class="sec-h"><h2>被动效果<b class="num">${passive.length}</b></h2><span class="sec-note">不占主动技能名额</span></div><div class="sk-grid">${passive.map(s => skillCard(r, s)).join('')}</div>` : ''}
  </section>
</div>`;
}

/* ---------- 胜利：每个阵营怎么赢 ---------- */
function sortedEvents(camp) { return [...(E.campRule(board, camp)?.events || [])].sort((a, b) => b.weight - a.weight); }
function originalText(f) { return f.id === 3 ? '每个中立角色按自己的原条件，各自获胜。' : E.careers.get(f.id === 1 ? 1 : 101).win_condition_des; }
function condHolders(type) { return board.factions.filter(f => E.campRule(board, f.id)?.events.some(e => e.type === type)); }
// 中立阵营各算各的：把条件说明里的“阵营／成员”换成“本人”。
function campEventCopy(text, camp) {
  if (camp !== 3) return text;
  return text.replace('队友投中同一人只计一次。', '本人对同一目标只计一次。').replace('每个行动回合本阵营最多计一次。', '本人每个行动回合最多计一次。').replace('同一场会议本阵营最多计一次。', '本人每场会议最多计一次。').replaceAll('一名成员', '本人').replace('中立只看本人，', '').replace('仍存活成员的个人记录，不相加', '本人存活时的个人记录，不与其他中立相加').replace('存活成员个人连续记录', '本人存活时的连续记录');
}
function condRow(f, e) {
  const d = E.eventCatalog[e.type], blocked = blockedIssue(f.id, e.type);
  return `<button class="cond ${blocked ? 'is-bad' : ''}" data-act="cond" data-id="${esc(e.id)}" data-cond="${esc(e.id)}" aria-label="${esc(d.name)}：调整目标与权重">
  <span class="cond-ic">${icon(condIcon(e.type))}</span>
  <span class="cond-m"><b>${esc(d.name)}</b><small>${blocked ? nums(`目标 ${e.value} 做不到`) : nums(`目标 ${e.value} ${esc(d.unit)}`)}</small></span>
  <span class="cond-w" title="权重：数字越大越优先">${icon('crown')}${e.weight}</span>
</button>`;
}
function winCol(f) {
  const events = sortedEvents(f.id), custom = f.kind === 'custom', seats = board.room.counts[f.id] || 0, missing = custom && !events.length, full = events.length >= E.MAX_CAMP_EVENTS;
  const base = custom ? `<div class="wbase is-none">${icon('info')}<div><em>没有原有条件</em><p>新阵营只靠额外条件获胜，至少要加一个。</p></div></div>`
    : f.id === 3 ? `<div class="wbase">${icon('lock')}<div><em>原有条件</em><p>${originalText(f)}</p><button class="link-btn" data-act="neutral-base">看看各自的原条件</button></div></div>`
    : `<div class="wbase">${icon('lock')}<div><em>原有条件</em><p>${esc(originalText(f))}</p></div></div>`;
  return `<article class="wcol ${missing ? 'is-missing' : ''}" data-wcol="${f.id}" style="${fc(f.id)}">
  <header class="wcol-h">${emblem(f)}<div><b>${nameHtml(f.name)}</b><small>${nums(seats ? seats + ' 人' : '这局不出场')} · ${f.id === 3 ? '各自获胜' : '共同获胜'}</small></div></header>
  <div class="wcol-b">
    ${base}
    <div class="wextra-h"><em>额外条件</em><span>${events.length > 1 ? '完成任意一个就赢' : events.length ? '达成就赢' : custom ? '必填' : '可以不加'}</span><b class="num">${events.length}/${E.MAX_CAMP_EVENTS}</b></div>
    ${events.map(e => condRow(f, e)).join('')}
    <button class="cond-add ${missing ? 'is-need' : ''}" data-act="add-cond" data-camp="${f.id}" ${full ? 'disabled' : ''}>${icon('plus')}${full ? '已经加满了' : '添加条件'}</button>
  </div>
</article>`;
}
function winsPage() {
  return `<header class="ph">
  <h1>怎样才算赢？</h1>
  <p class="ph-sub">额外条件谁先达成谁赢；都没达成，再看原有条件。</p>
  <span class="grow"></span>${undoPill()}
  <button class="btn btn-ghost btn-sm" data-act="win-help">${icon('help')}规则说明</button>
  <button class="icon-btn" data-act="reset-page" aria-label="重置本页">${icon('undo')}</button>
</header>
<div class="pb scroll wins" data-keep="wins"><div class="wcols">${board.factions.map(winCol).join('')}</div></div>`;
}

/* ---------- 试玩：抽一桌、怎样算赢、试算胜负 ---------- */
function castTab() {
  if (drawError) return `<p class="note bad">${icon('alert')}<span>${esc(uiCopy(drawError))}</span></p>`;
  if (!draw) {
    const errs = errorCount();
    return emptyState(errs ? '先处理待办' : '还没抽名单', errs ? nums(`还有 ${errs} 项问题，处理完才能抽出一桌。`) : '点左边桌子中间的骰子，按各阵营人数随机抽出这一局谁出场。', errs ? `<button class="btn btn-primary btn-sm" data-act="check">${icon('alert')}看看要处理什么</button>` : '');
  }
  return `<div class="cast">${E.campIds(board).map(c => {
    const seats = draw.seats.filter(s => s.camp === c), f = E.faction(board, c); if (!f) return '';
    return `<section class="cast-g" style="${fc(c)}"><h3>${emblem(f, 'xs')}<span>${nameHtml(f.name)}</span><b class="num">${seats.length} 人</b></h3>${seats.length ? `<div class="cast-l">${seats.map(s => `<button class="cast-i" data-act="role" data-uid="${esc(s.roleUid)}" aria-label="查看${esc(s.name)}">${avatar(s.templateCareerId, c, 'sm')}<span><b>${nameHtml(s.name)}</b><small>${nums('席位 ' + (draw.seats.indexOf(s) + 1) + (s.copy > 1 ? ' · 第 ' + s.copy + ' 个' : ''))}</small></span></button>`).join('')}</div>` : '<p class="muted">这局不出场</p>'}</section>`;
  }).join('')}</div>`;
}
function winsTab() {
  const extras = board.campEvents.reduce((n, r) => n + r.events.length, 0);
  return `<p class="side-lead">${extras ? '额外条件先达成就先结算，权重大的优先；都没达成时，按原有条件判定。' : '各阵营沿用原有条件，还没有添加额外条件。'}<button class="link-btn" data-act="go" data-page="wins">去调整</button></p>
<div class="wsum">${board.factions.map(f => {
    const events = sortedEvents(f.id), seats = board.room.counts[f.id] || 0, custom = f.kind === 'custom', missing = custom && !events.length;
    let base;
    if (custom) base = missing ? `<p class="wsum-miss">${icon('alert')}还没有胜利条件，这个阵营赢不了。</p>` : '';
    else if (f.id === 3) {
      const roles = board.roles.filter(r => r.camp === 3 && !E.isCustom(r));
      base = roles.length ? `<ul class="wsum-roles">${roles.map(r => { const drawn = draw?.seats.some(s => s.roleUid === r.uid); return `<li class="${drawn ? 'is-drawn' : ''}">${avatar(r.templateCareerId, 3, 'xs')}<span><b>${nameHtml(r.name)}${drawn ? '<em>本局出场</em>' : ''}</b><small>${esc(E.careers.get(r.templateCareerId).win_condition_des)}</small></span></li>`; }).join('')}</ul>` : '<p class="wsum-base">每个角色按自己的原条件，各自获胜。</p>';
    } else base = `<p class="wsum-base">${icon('lock')}${esc(originalText(f))}</p>`;
    return `<article class="wsum-c ${seats ? '' : 'is-idle'}" style="${fc(f.id)}"><h3>${emblem(f, 'xs')}<span class="nm">${nameHtml(f.name)}</span><b class="num">${seats ? seats + ' 人' : '不出场'}</b></h3>${base}${events.length ? `<ol class="wsum-goals">${events.map(e => { const d = E.eventCatalog[e.type]; return `<li><span class="cond-ic">${icon(condIcon(e.type))}</span><b>${esc(d.name)}</b><span class="num">${e.value} ${esc(d.unit)}</span><small>权重 ${e.weight}</small></li>`; }).join('')}</ol>` : ''}</article>`;
  }).join('')}</div>`;
}
function simGroups() {
  if (!draw) return [];
  return E.campIds(board).filter(c => c !== 3 && draw.seats.some(s => s.camp === c)).map(c => ({key: 'camp-' + c, camp: c, label: campName(c)}))
    .concat(draw.seats.filter(s => s.camp === 3).map(s => ({key: s.uid, camp: 3, roleUid: s.roleUid, seatId: s.uid, label: s.name + ' · 席位 ' + (draw.seats.indexOf(s) + 1)})));
}
function simResult() {
  const groups = simGroups(), g = groups.find(g => g.key === simGroup); if (!g) return '';
  const seats = draw.seats, original = groups.find(x => x.key === scenario.originalWinner);
  const ids = x => x.camp === 3 ? [x.seatId] : seats.filter(s => s.camp === x.camp).map(s => s.uid), actorIds = ids(g);
  const state = {finalized: true, seats, campProgress: g.camp === 3 ? {} : {[g.camp]: scenario.progress}, playerProgress: g.camp === 3 ? {[g.seatId]: scenario.progress} : {}, aliveSeatIds: seats.map(s => s.uid).filter(id => scenario.eligibleAlive || !actorIds.includes(id)), originalWinners: original && original.camp <= 3 ? ids(original) : [], baseConditionMatches: original?.camp > 3 ? [{camp: original.camp, presetId: E.faction(board, original.camp).baseVictory, actorSeatId: ids(original)[0]}] : []};
  if (g.camp !== 3 && actorIds.length) { const p = {}; for (const [type, d] of Object.entries(E.eventCatalog)) if (d.aggregation === 'personalMax') p[type] = scenario.progress[type] || 0; state.playerProgress[actorIds[0]] = p; }
  const result = E.resolveVictory(board, state);
  const title = result.source === 'extra' ? '额外条件优先获胜' : result.source === 'original' ? '按原有条件获胜' : result.source === 'pending' ? '还不能结算' : '暂时无人获胜';
  const text = result.invalid ? result.reason : result.source === 'extra' ? result.reason : result.source === 'original' ? '额外条件尚未达成，按原有条件获胜。' : result.source === 'none' ? '继续游戏。' : '等待结算。';
  return `<div class="sim-res is-${result.source}" role="status">${icon(result.winners.length ? 'trophy' : 'info')}<div><h3>${title}</h3><p>${nums(esc(uiCopy(text)))}</p>${result.winners.length ? `<p class="sim-win">${result.winners.map(id => esc(seats.find(s => s.uid === id)?.name || id)).join('、')}</p>` : ''}</div></div>`;
}
function simTab() {
  const groups = simGroups();
  if (!groups.length) return emptyState('先抽一桌', '试算要用到这一局的出场名单。', `<button class="btn btn-primary btn-sm" data-act="draw" ${errorCount() ? 'disabled' : ''}>${icon('dice')}抽一桌</button>`);
  if (!groups.some(g => g.key === simGroup)) simGroup = groups[0].key;
  if (!scenario) scenario = {progress: {}, eligibleAlive: true, originalWinner: ''};
  const g = groups.find(g => g.key === simGroup), rule = E.campRule(board, g.camp, g.roleUid);
  const originals = groups.filter(x => x.camp > 3 ? !!E.faction(board, x.camp).baseVictory : x.camp !== 3 || !E.isCustom(board.roles.find(r => r.uid === x.roleUid)));
  return `<p class="side-lead">假设对局进行到某一刻：填上进度，看看按规则谁获胜。</p>
<div class="sim-f"><span class="lab">替谁试算</span><div class="chips">${groups.map(x => `<button class="chip ${x.key === simGroup ? 'is-on' : ''}" data-act="sim-group" data-key="${esc(x.key)}" style="${fc(x.camp)}" aria-pressed="${x.key === simGroup}">${nameHtml(x.label)}</button>`).join('')}</div></div>
${rule.events.length ? rule.events.map(e => { const d = E.eventCatalog[e.type], key = d.counter || e.type; return `<div class="sim-row"><span class="lab">${icon(condIcon(e.type))}<span>${esc(d.name)}${g.camp !== 3 && d.aggregation === 'personalMax' ? '（个人最高）' : ''}<small>${nums(`目标 ${e.value} ${esc(d.unit)}`)}</small></span></span>${stepper('sim:' + key, {unit: d.unit, label: d.name + '进度'})}</div>`; }).join('') : `<p class="note">${icon('info')}<span>${nameHtml(g.camp === 3 ? '中立阵营' : campName(g.camp))}没有额外条件，只看原有条件。</span></p>`}
<label class="tog sim-alive"><span class="tog-l"><b>${g.camp === 3 ? '本人还活着' : '这个阵营还有人活着'}</b><em class="tog-s ${scenario.eligibleAlive ? 'is-on' : ''}">${scenario.eligibleAlive ? '是' : '否'}</em></span><span class="sw"><input type="checkbox" role="switch" data-sim-alive ${scenario.eligibleAlive ? 'checked' : ''}><i aria-hidden="true"></i></span></label>
<div class="sim-f"><span class="lab">原有条件也达成的一方</span><div class="chips"><button class="chip ${scenario.originalWinner ? '' : 'is-on'}" data-act="sim-orig" data-key="">还没有</button>${originals.map(x => `<button class="chip ${scenario.originalWinner === x.key ? 'is-on' : ''}" data-act="sim-orig" data-key="${esc(x.key)}" style="${fc(x.camp)}">${nameHtml(x.label)}</button>`).join('')}</div></div>
<div class="sim-go"><button class="btn btn-primary" data-act="sim-run">${icon('trophy')}看看谁获胜</button></div>
${simRun ? simResult() : ''}`;
}
function playPage() {
  const errs = errorCount(), warns = warnCount();
  const mid = `<button class="draw-btn" data-act="draw" ${errs ? 'disabled' : ''} aria-label="${draw ? '再抽一次' : '随机抽一桌'}">${icon('dice')}<span>${draw ? '再抽一次' : '抽一桌'}</span></button>`;
  const tabs = [['cast', '本局名单'], ['wins', '怎样算赢'], ['sim', '试算胜负']];
  const panel = ui.playTab === 'wins' ? winsTab() : ui.playTab === 'sim' ? simTab() : castTab();
  return `<header class="ph">
  <h1>抽一桌看看</h1>
  <button class="state-chip ${errs ? 'is-bad' : 'is-ok'}" data-act="check">${icon(errs ? 'alert' : 'check')}<span>${nums(errs ? errs + ' 项待处理' : '检查通过' + (warns ? '，' + warns + ' 条提醒' : ''))}</span></button>
  <span class="grow"></span>${undoPill()}
  ${draw || drawError ? `<button class="btn btn-ghost btn-sm" data-act="reset-page">${icon('undo')}清空名单</button>` : ''}
  <button class="btn btn-primary btn-sm" data-act="export">${icon('download')}导出板子</button>
</header>
<div class="pb split play">
  <section class="card tcard">
    ${tableViz(draw ? draw.seats : planTokens(), mid, !!draw)}
    <div class="pool-row">${E.campIds(board).map(c => { const p = E.poolStats(board, c), f = E.faction(board, c); return `<span class="split-i" style="${fc(c)}"><i></i>${esc(shortCamp(f))}<b class="num">${p.candidates}</b>选<b class="num">${p.seats}</b></span>`; }).join('')}</div>
    <p class="tcard-hint">${draw ? nums(draw.omitted.length ? `这局 ${draw.seats.length} 人就位，另有 ${draw.omitted.length} 个角色没轮到。板子有改动时要重抽。` : `这局 ${draw.seats.length} 人就位，角色池里的角色全部出场。板子有改动时要重抽。`) : '每个阵营从自己的角色池里随机出场。'}</p>
  </section>
  <section class="side">
    ${segmented('play', tabs, ui.playTab)}
    <div class="card side-card scroll" role="tabpanel" data-keep="play-${ui.playTab}">${panel}</div>
  </section>
</div>`;
}
