(function(root){
'use strict';
const L=root.EditorEngine,clone=L.clone,SCHEMA='goose-duck-board-draft/1.8',PREVIOUS_SCHEMA='goose-duck-board-draft/1.7',MAX_FACTIONS=24;
const ROOM_FIELDS=Object.freeze({
 discuss_cd:{label:'讨论时长',type:'number',unit:'秒',choices:[15,30,45,60,90,100]},
 vote_cd:{label:'投票时长',type:'number',unit:'秒',choices:[15,30,45,60,90,120,150]},
 meeting_amount:{label:'紧急会议总次数',type:'number',unit:'次',choices:[0,1,2,3,4,5,6,7,8,9,10]},
 first_bell_cd:{label:'首次拍铃等待',type:'number',unit:'秒',choices:[1,15,30,60,90,120,180,300]},
 meeting_cd:{label:'再次拍铃冷却',type:'number',unit:'秒',choices:[1,10,16,30,45,60,90,100]},
 meeting_hit_cd:{label:'会议后击倒冷却',type:'number',unit:'秒',choices:[5,10,15,18,20,30,45,60]},
 meeting_destroy_cd:{label:'会议后破坏冷却',type:'number',unit:'秒',choices:[5,10,14,20,30,45,60,100]},
 allow_speak:{label:'投票时发言',type:'boolean'},
 discuss_chat:{label:'轮麦时文字聊天',type:'boolean'},
 discuss_emojis:{label:'会议表情',type:'boolean'},
 hide:{label:'放逐后隐藏身份',type:'boolean'},
 allow_report_dead:{label:'报告鸡腿',type:'boolean'}
});
function roomDefaults(room){for(const [key,d] of Object.entries(ROOM_FIELDS))if(room[key]===undefined)room[key]=L.D.custom[0][d.type==='boolean'?key:key+'_default'];return room;}
const BUILTINS=[{id:1,name:'鹅阵营',kind:'builtin',baseVictory:'original'},{id:2,name:'鸭阵营',kind:'builtin',baseVictory:'original'},{id:3,name:'中立阵营',kind:'builtin',baseVictory:'original'}];
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const integer=(n,min=0,max=100000)=>Number.isInteger(n)&&n>=min&&n<=max;
const stable=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const equal=(a,b)=>stable(a)===stable(b);
const baseVictoryOptions=L.victoryPresets.filter(p=>L.classicCareerIds.has(p.sourceCareerId));
const baseVictory=id=>baseVictoryOptions.find(p=>p.id===id);
const faction=(b,id)=>b.factions.find(f=>f.id===Number(id));
const campIds=b=>b.factions.map(f=>f.id);
const campName=(b,id)=>faction(b,id)?.name||'未知阵营';
const newRule=camp=>({key:'camp-'+camp,camp,join:'any',events:[]});
function assertKeys(o,keys,message){if(!o||typeof o!=='object'||Array.isArray(o)||Object.keys(o).some(k=>!keys.includes(k)))throw Error(message);}
function upgrade(b){const next=clone(b);next.schema=SCHEMA;next.factions=clone(BUILTINS);roomDefaults(next.room);delete next.drawPreview;return next;}
function defaultBoard(){return upgrade(L.defaultBoard());}
function poolExample(){return upgrade(L.poolExample());}
function ensureCampRules(b){const previous=b.campEvents||[];b.campEvents=b.factions.map(f=>previous.find(r=>r.camp===f.id)||newRule(f.id));return b.campEvents;}
function campRule(b,id){return b.campEvents.find(r=>r.camp===Number(id))||null;}
function addFaction(b,name){
 if(b.factions.length>=MAX_FACTIONS)throw Error('最多保留24个阵营。');
 let n=1;while(b.factions.some(f=>f.name==='新阵营'+n))n++;
 name=(name||'新阵营'+n).trim();checkName(b,name);
 const f={id:Math.max(...campIds(b))+1,name,kind:'custom',baseVictory:null};
 b.factions.push(f);b.room.counts[f.id]=0;ensureCampRules(b);return f;
}
function checkName(b,name,except){if(typeof name!=='string'||!name.trim()||name.length>20)throw Error('阵营名称需要1–20个字。');if(b.factions.some(f=>f.id!==except&&f.name===name.trim()))throw Error('已有同名阵营，请换一个名称。');}
function renameFaction(b,id,name){const f=faction(b,id);if(!f||f.kind!=='custom')throw Error('原有阵营名称固定。');checkName(b,name,id);f.name=name.trim();}
function removeFaction(b,id){
 const f=faction(b,id);if(!f||f.kind!=='custom')throw Error('鹅、鸭和中立阵营不能删除。');
 if(b.room.counts[id]>0||b.roles.some(r=>r.camp===id))throw Error('请先把阵营人数调为0，并将阵营内角色移出或改换归属，再删除阵营。');
 b.factions=b.factions.filter(f=>f.id!==id);delete b.room.counts[id];ensureCampRules(b);
}
function setBaseVictory(b,id,presetId){const f=faction(b,id);if(!f||f.kind!=='custom')throw Error('原有阵营的原胜利条件固定，不能修改。');if(presetId!==null&&!baseVictory(presetId))throw Error('请选择有效的原有胜利条件。');f.baseVictory=presetId;}
function makeCustomRole(b,camp=1){if(!b||!faction(b,camp))throw Error('请先创建或选择一个阵营。');if(camp===3)throw Error('中立阵营只能添加已有职业。空白角色请选择鹅、鸭或新阵营。');const r=L.makeCustomRole(b,camp<=3?camp:1);r.camp=camp;r.win={mode:'camp',camp};return r;}
function setRoleCamp(b,r,camp){if(!L.isCustom(r))throw Error('已有职业的阵营固定，只能调整技能。');if(!faction(b,camp))throw Error('阵营不存在。');if(camp===3)throw Error('中立阵营只能添加已有职业。');r.camp=camp;r.win={mode:'camp',camp};}
function removeRole(b,id){b.roles=b.roles.filter(r=>r.uid!==id);}
function addCampEvent(b,camp,type){
 if(!own(L.eventCatalog,type))throw Error('请选择新增目标；原有条件需在上方单独选择。');
 const r=campRule(b,camp);if(!r)throw Error('请先选择一个阵营。');
 if(r.events.some(e=>e.type===type))throw Error('已添加这个目标，可直接修改数量。');
 if(r.events.length>=L.MAX_CAMP_EVENTS)throw Error('每个阵营最多10个新增目标。');
 const event={id:L.uid(),type,value:L.eventCatalog[type].defaultValue};r.events.push(event);return event;
}
function removeCampEvent(b,camp,id){const r=campRule(b,camp);if(!r)throw Error('阵营不存在。');r.events=r.events.filter(e=>e.id!==id);}
// Legacy validation is reused only for role/skill payloads. New teams are projected
// into neutral for that check; draw and victory always use their original team IDs.
function legacyProjection(b){
 const flat=clone(b);flat.schema=L.SCHEMA;delete flat.factions;
 flat.room.counts={1:b.room.counts[1],2:b.room.counts[2],3:campIds(b).filter(c=>c>=3).reduce((n,c)=>n+b.room.counts[c],0)};
 for(const r of flat.roles)if(r.camp>3){r.camp=3;r.win={mode:'camp',camp:3};}
 flat.campEvents=[1,2,3].map(newRule);return flat;
}
function validateShape(input){
 if(!input||typeof input!=='object')throw Error('草稿格式不正确。');
 if(input.schema===PREVIOUS_SCHEMA){const b=clone(input);b.schema=SCHEMA;roomDefaults(b.room);return validateShape(b);}
 if(input.schema!==SCHEMA){const b=upgrade(L.validateShape(input));b.migration={...(b.migration||{}),from:input.schema,notes:[...(b.migration?.notes||[]),'阵营分配与胜利条件已拆分；原三阵营、角色、席位与新增目标完整保留。']};return validateShape(b);}
 const b=clone(input);
 if(!Array.isArray(b.factions)||b.factions.length<3||b.factions.length>MAX_FACTIONS)throw Error('阵营数量需要在3–24个之间。');
 const ids=new Set(),names=new Set();
 for(const f of b.factions){
  assertKeys(f,['id','name','kind','baseVictory'],'阵营定义格式不正确。');
  if(!integer(f.id,1,999999)||ids.has(f.id)||typeof f.name!=='string'||!f.name.trim()||f.name!==f.name.trim()||f.name.length>20||names.has(f.name))throw Error('阵营标识或名称无效、重复。');
  ids.add(f.id);names.add(f.name);
  if(f.id<=3){if(!equal(f,BUILTINS[f.id-1]))throw Error('原有阵营和原胜利条件不能更改。');}
  else if(f.kind!=='custom'||f.baseVictory!==null&&!baseVictory(f.baseVictory))throw Error('新阵营的基础胜利条件无效。');
 }
 if([1,2,3].some(id=>!ids.has(id)))throw Error('必须保留鹅、鸭、中立阵营。');
 if(!b.room?.counts||Object.keys(b.room.counts).length!==ids.size||Object.keys(b.room.counts).some(k=>String(Number(k))!==k||!ids.has(Number(k)))||[...ids].some(id=>!integer(b.room.counts[id],0,24)))throw Error('每个阵营需要0–24个席位，不能引用不存在的阵营。');
 for(const [key,d] of Object.entries(ROOM_FIELDS)){const valid=d.type==='boolean'?typeof b.room[key]==='boolean':integer(b.room[key],...L.D.custom[0][key]);if(!valid)throw Error(d.label+'设置无效，请重新选择。');}
 if(!Array.isArray(b.roles)||!Array.isArray(b.campEvents))throw Error('角色或阵营目标列表不正确。');
 for(const r of b.roles){if(!ids.has(r.camp))throw Error('角色引用了不存在的阵营。');if(L.isCustom(r)&&!equal(r.win,{mode:'camp',camp:r.camp}))throw Error('自创角色的胜利必须跟随所属阵营。');}
 const keys=new Set(),eventIds=new Set();
 for(const r of b.campEvents){
  assertKeys(r,['key','camp','join','events'],'阵营目标不能包含额外的判定字段。');
  if(!ids.has(r.camp)||r.key!=='camp-'+r.camp||keys.has(r.key)||!['any','all'].includes(r.join)||!Array.isArray(r.events)||r.events.length>L.MAX_CAMP_EVENTS)throw Error('阵营目标绑定、数量或完成方式不正确。');
  keys.add(r.key);const types=new Set();
  for(const e of r.events){assertKeys(e,['id','type','value'],'新增目标不能覆写原条件或优先级。');if(typeof e.id!=='string'||!e.id||e.id.length>80||eventIds.has(e.id)||!own(L.eventCatalog,e.type)||types.has(e.type)||!integer(e.value,1,999))throw Error('新增目标的类型、数量或标识不正确。');eventIds.add(e.id);types.add(e.type);}
 }
 if(keys.size!==ids.size)throw Error('每个阵营都需要一组胜利设置。');
 const projected=legacyProjection(b);
 // Sum may be invalid in a recoverable draft; avoid a projected neutral count
 // above the legacy field limit while leaving the real counts untouched.
 projected.room.counts[3]=Math.min(24,projected.room.counts[3]);
 const checked=L.validateShape(projected);
 b.roles.forEach((r,i)=>{r.slots=checked.roles[i].slots;});b.selection=checked.selection;delete b.drawPreview;return b;
}
function validate(b,{checkPool=true}={}){
 try{b=validateShape(b);}catch(e){return [{level:'error',code:'SCHEMA',text:e.message}];}
 const projected=legacyProjection(b);projected.room.counts[3]=Math.min(24,projected.room.counts[3]);
 const out=L.validate(projected,{checkPool:false}).filter(x=>!['CAMP_SUM','POOL_CAPACITY','POOL_INACTIVE','CUSTOM_NEUTRAL_NO_WIN','RUNTIME_BOUNDARY'].includes(x.code));
 const add=(level,code,text,camp)=>out.push({level,code,text,camp});
 for(const r of b.roles.filter(r=>r.camp===3&&L.isCustom(r)))out.push({level:'error',code:'CUSTOM_NEUTRAL_FORBIDDEN',uid:r.uid,text:r.name+'：中立阵营仅限已有职业，请更换阵营。'});
 const sum=campIds(b).reduce((n,c)=>n+b.room.counts[c],0);
 if(sum!==b.room.total)add('error','CAMP_SUM',`阵营人数合计 ${sum}，与房间 ${b.room.total} 人不一致。`);
 for(const f of b.factions){
  const c=f.id,active=b.room.counts[c]>0,p=L.poolStats(b,c),r=campRule(b,c);
  if(p.capacity<p.seats)add('error','POOL_CAPACITY',`${f.name}需要抽取 ${p.seats} 人，候选池最多可供 ${p.capacity} 席。`,c);
  if(!p.seats&&p.candidates)add('info','POOL_INACTIVE',`${f.name}本局0人，候选保留但不抽取。`,c);
  if(active&&f.kind==='custom'&&!f.baseVictory&&!r.events.length)add('error','CUSTOM_FACTION_NO_WIN',`${f.name}尚无胜利条件，请选择一种原有条件或添加新增目标。`,c);
  const opponents=b.room.total-(c===3?1:b.room.counts[c]),investigations=b.room.total-(c===3||b.room.counts[c]<2?1:0);
  const unreachable=r.events.map(e=>['kills','voteOuts'].includes(e.type)&&e.value>opponents||e.type==='reports'&&e.value>b.room.total-1||e.type==='investigations'&&e.value>investigations);
  const unavailable=r.events.filter(e=>e.type==='reports'&&!b.room.allow_report_dead||e.type==='emergencyCalls'&&e.value>Math.min(b.room.meeting_amount,c===3?1:b.room.counts[c]));
  const blocked=r.events.filter((e,i)=>unreachable[i]||unavailable.includes(e));
  if(blocked.length)add(active&&(r.join==='all'||blocked.length===r.events.length)?'error':'warn',unavailable.length?'MEETING_GOAL_UNREACHABLE':'EXTRA_UNREACHABLE',`${f.name}的「${blocked.map(e=>L.eventCatalog[e.type].name).join('、')}」无法按当前设置完成，请调整目标数量或会议设置。`,c);
  if(r.events.some(e=>['kills','reports','skillUses','ventTrips','investigations'].includes(e.type)))add('info','EVENT_ABILITY',`${f.name}的目标需要对应技能或地图通道。`,c);
  if(active&&f.kind==='custom'&&f.baseVictory){
   const preset=baseVictory(f.baseVictory),target=preset.sourceCareerId===1?2:preset.sourceCareerId===101?1:null;
   if(target&&!b.room.counts[target])add('error','BASE_OPENING',`${f.name}采用的「${preset.name}」在目标阵营无人时开局即成立，请分配目标阵营席位或更换条件。`,c);
   if([202,205,206,210].includes(preset.sourceCareerId))add('warn','BASE_DEPENDENCY',`${f.name}采用「${preset.name}」，请配置相应技能或角色关系；选择条件不会自动获得技能。`,c);
  }
 }
 if(checkPool&&!out.some(x=>x.level==='error')){const draw=L.findLineup(b);if(!draw.ok)add(draw.status==='search-limit'?'warn':'error',draw.status==='skill-cap'?'SKILL_FAMILY_POOL':'POOL_NO_COMBINATION',draw.status==='search-limit'?'组合较复杂，请尝试抽取或精简候选。':'当前人数无法组成合法一桌，请检查各阵营候选、互斥和技能持有者上限。');}
 out.push({level:'info',code:'RUNTIME_BOUNDARY',text:'原有条件由游戏运行时判定；编辑器支持阵营配置、随机抽取和新增目标试算。'});return out;
}
function drawPool(b,seed){b=validateShape(b);const errors=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(errors.length)throw Error('请先修正配置：'+errors[0].text);const result=L.findLineup(b,seed||L.uid());if(!result.ok)throw Error('当前候选池没有找到合法组合，请调整候选或人数。');return result;}
function checkProgress(p){if(p===undefined)return;if(!p||typeof p!=='object'||Array.isArray(p))throw Error('进度格式不正确。');for(const k of Object.keys(L.eventCatalog))if(own(p,k)&&!integer(p[k]))throw Error('事件进度必须是0–100000之间的整数。');}
function resolveVictory(b,state){
 const result=(source,reason,more={})=>({source,winners:[],matchedGroups:[],reason,...more});
 if(state?.finalized!==true)return result('pending','先处理完本批全部效果，再统一判胜。');
 try{
  b=validateShape(b);const issues=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(issues.length)throw Error(issues[0].text);const scope=b.roles.flatMap(L.phaseOneIssues);if(scope.length)throw Error(scope[0].text);
  if(!Array.isArray(state.seats)||!Array.isArray(state.aliveSeatIds)||!Array.isArray(state.originalWinners))throw Error('需要完整出场名单、存活名单和原胜利结果。');
  const seatIds=new Set();for(const seat of state.seats){const r=b.roles.find(x=>x.uid===seat.roleUid);if(!r||typeof seat.uid!=='string'||!seat.uid||seatIds.has(seat.uid)||seat.camp!==r.camp)throw Error('出场席位与角色池不一致。');seatIds.add(seat.uid);}
  const lineup=L.lineupIssues(b,state.seats);if(lineup.length)throw Error(lineup[0].text);
  if(state.aliveSeatIds.some(id=>!seatIds.has(id))||state.originalWinners.some(id=>!seatIds.has(id)))throw Error('判胜引用了未出场玩家。');
  for(const id of state.originalWinners){const seat=state.seats.find(s=>s.uid===id),r=b.roles.find(r=>r.uid===seat.roleUid);if(seat.camp>3)throw Error('新阵营必须提供所选原条件的达成记录。');if(seat.camp===3&&L.isCustom(r))throw Error('自创中立没有原胜利条件。');}
  for(const table of [state.campProgress,state.playerProgress])if(table!==undefined&&(!table||typeof table!=='object'||Array.isArray(table)))throw Error('事件进度列表不正确。');
  for(const [id,p] of Object.entries(state.playerProgress||{})){if(!seatIds.has(id))throw Error('进度引用了未出场玩家。');checkProgress(p);}
  for(const [id,p] of Object.entries(state.campProgress||{})){if(!faction(b,Number(id)))throw Error('进度引用了不存在的阵营。');checkProgress(p);}
  const baseMatches=state.baseConditionMatches||[];if(!Array.isArray(baseMatches))throw Error('原条件达成记录不正确。');
  for(const m of baseMatches){assertKeys(m,['camp','presetId','actorSeatId'],'原条件达成记录不正确。');const f=faction(b,m.camp),actor=state.seats.find(s=>s.uid===m.actorSeatId);if(!f||f.kind!=='custom'||!f.baseVictory||m.presetId!==f.baseVictory||!actor||actor.camp!==f.id)throw Error('新阵营只能按自己选定的原条件及本阵营成员结算。');}
  const alive=new Set(state.aliveSeatIds),groups=[],checks=[];
  for(const camp of campIds(b).filter(c=>c!==3)){
   const seats=state.seats.filter(s=>s.camp===camp);if(!seats.length)continue;const p=clone(state.campProgress?.[camp]||{});
   for(const [type,d] of Object.entries(L.eventCatalog))if(d.aggregation==='personalMax')p[type]=Math.max(0,...seats.filter(s=>alive.has(s.uid)).map(s=>state.playerProgress?.[s.uid]?.[type]||0));
   const verdict=L.evaluateCamp(b,camp,p,{alive:seats.some(s=>alive.has(s.uid))});checks.push({key:'camp-'+camp,camp,...verdict});
   if(verdict.matched)groups.push({key:'camp-'+camp,camp,eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:seats.map(s=>s.uid)});
  }
  for(const seat of state.seats.filter(s=>s.camp===3)){const verdict=L.evaluateCamp(b,3,state.playerProgress?.[seat.uid]||{},{alive:alive.has(seat.uid)});checks.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,...verdict});if(verdict.matched)groups.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,ruleKey:'camp-3',eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:[seat.uid]});}
  if(groups.length)return result('extra',groups.length>1?'同批多个阵营达成新增目标，并列获胜；本批不再检查原有条件。':'新增目标优先达成，本批不再检查原有条件。',{winners:[...new Set(groups.flatMap(g=>g.winners))],matchedGroups:groups,tie:groups.length>1,checks});
  const baseCamps=new Set(baseMatches.map(m=>m.camp)),winners=[...new Set([...state.originalWinners,...state.seats.filter(s=>baseCamps.has(s.camp)).map(s=>s.uid)])];
  if(winners.length)return result('original','无人达成新增目标，按运行时确认的原有条件结算；新阵营达成所选条件后全员获胜。',{winners,checks});
  return result('none','尚未达成胜利条件，继续游戏。',{checks});
 }catch(e){return result('pending',e.message,{invalid:true});}
}
function exportDraft(b){
 const clean=validateShape(b);clean.updatedAt=new Date().toISOString();clean.source={label:L.D.meta.label,tables:clone(L.D.meta.sourceFiles)};
 const issues=clean.roles.flatMap(r=>L.compatibilityIssues(r).map(x=>({...x,roleUid:r.uid})));clean.scope={id:L.PHASE_ONE.id,catalogVersion:L.PHASE_ONE.version,stage:'scope-and-skill-compatibility-only',eligibleForPlay:!issues.length,issues};
 clean.integration={status:'prototype-only',proposedFields:['factions','factions[].baseVictory','room.counts','roles[].camp','campEvents','baseConditionMatches'],priority:'extraFirst',sameBatchExtra:'shared',neutralProgress:'independent-per-seat',customFactionProgress:'shared-per-faction',customFactionWinners:'all-members',eventCounters:clone(L.eventCatalog),requires:['鹅鸭和原中立的原胜利条件固定；已有职业阵营固定','新阵营是独立团队，可容纳多个自创角色和多个玩家；人数与候选角色数量独立，按阵营随机抽取','新阵营可选一种现有原条件、最多10项原创目标，或同时使用；引用原条件不授予原职业技能，任一成员满足该条件后全阵营共享胜利','原条件的触发事件、目标及阈值沿用所选模板；团队进度读取当前新阵营，个人条件检查当前阵营成员；目标阵营不自动改写','运行时提供新阵营基础条件匹配记录：camp、presetId、actorSeatId；编辑器只验证归属与所选条件，不将假设结果冒充技能模拟','所有新增目标优先于所有原有条件；同批新增目标并列时共享获胜；无新增目标成立才处理原结果','中立阵营仅接纳已有职业；旧空白中立保留可编辑但不得抽取或判胜，须移至鹅鸭或新阵营','会议参数写入room，沿用custom范围和默认值；meeting_amount是全局拍铃总数，每人仍限一次，报告不占次数','召集会议只计成功拍铃；积极参会按个人累计；积极表决按会议去重；存活计时仅含行动阶段秒数；地图探索按区域去重且排除出生区域；多才多艺按不同主动技能去重，多段合为一种','原中立统一配置新增目标、逐玩家独立累计及获胜；新增阵营共享累计和全员获胜','事件计数需运行时完成敌我识别、有效性校验与去重；个人计数类目标取仍存活成员最大值，禁止相加','所有阵营的技能持有者安全上限合并检查；第一期经典技能白名单持续生效']};return clean;
}
root.EditorEngine={...L,SCHEMA,MAX_FACTIONS,ROOM_FIELDS,baseVictoryOptions,baseVictory,faction,campIds,campName,addFaction,renameFaction,removeFaction,setBaseVictory,defaultBoard,poolExample,ensureCampRules,campRule,makeCustomRole,setRoleCamp,removeRole,addCampEvent,removeCampEvent,validateShape,validate,drawPool,resolveVictory,exportDraft};
})(typeof window!=='undefined'?window:globalThis);
