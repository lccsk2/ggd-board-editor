(function(root){
'use strict';
const L=root.EditorEngine, clone=L.clone;
const SCHEMA='goose-duck-board-draft/1.3';
const defaultId=camp=>'faction-'+camp+'-default';
const counters={tasks:'已完成任务数',kills:'击杀不同玩家人数',assists:'助攻次数',skillUses:'技能成功使用次数',reports:'有效报告次数',meetings:'经历会议次数',votes:'累计获得票数',revives:'成功复活次数',rescues:'成功救援次数',bodies:'消化数量',guesses:'猜中身份次数',survivalSeconds:'连续存活秒数'};
Object.assign(L.defs,{
 tasks:{name:'完成任务达到指定数量',value:true,counter:'tasks'},
 kills:{name:'击杀不同玩家达到指定人数',value:true,target:true,anyTarget:true,counter:'kills',help:'每名玩家只计一次，助攻不计入；复活后重复击杀不重复计数。'},
 assists:{name:'累计助攻达到指定次数',value:true,counter:'assists'},
 skillUses:{name:'成功使用技能达到指定次数',value:true,counter:'skillUses',help:'只统计成功生效的技能，冷却中或无效点击不计入。'},
 reports:{name:'有效报告达到指定次数',value:true,counter:'reports'},
 meetings:{name:'经历会议达到指定次数',value:true,counter:'meetings'},
 votes:{name:'累计获得票数达到指定数量',value:true,counter:'votes'},
 revives:{name:'成功复活玩家达到指定次数',value:true,counter:'revives'},
 rescues:{name:'成功救援玩家达到指定次数',value:true,counter:'rescues'},
 surviveTime:{name:'本人连续存活达到指定秒数',value:true,counter:'survivalSeconds',personal:true},
 bodies:{name:'累计消化达到指定数量',value:true,counter:'bodies'},
 guesses:{name:'累计猜中身份达到指定次数',value:true,counter:'guesses'},
 timer:{name:'对局总时间达到指定秒数',value:true}
});
Object.assign(L.events,{skill:'技能生效后',report:'有效报告后',rescue:'救援或复活后',tick:'时间更新后'});
const presetNames={1:['team_tasks','完成任务或清除鸭阵营'],101:['team_sabotage','淘汰所有鹅或破坏成功'],201:['voted_out','本人被会议放逐'],202:['infect_all','感染全部其他存活玩家'],203:['swallow_final','生存到最后（鹈鹕固定判定）'],204:['last_survivor','生存到最后（猎鹰固定判定）'],205:['consume_goal','消化收集'],206:['duel_then_vote','完成决斗后被放逐'],207:['survival_final','生存到最后（布谷鸟固定判定）'],209:['raven_final','生存到最后（渡鸦固定判定）'],210:['guess_goal','猜中身份目标']};
const victoryPresets=L.fixedWinOptions.map(f=>({id:presetNames[f.id]?.[0]||'fixed_'+f.id,name:presetNames[f.id]?.[1]||'固定规则 · '+f.description,description:f.description,sourceCareerId:f.id,sourceCamp:f.sourceCamp,beneficiary:f.beneficiary}));
const presetById=id=>victoryPresets.find(p=>p.id===id);
function defaultLoss(){return {mode:'default',join:'any',conditions:[L.rule('dead')],event:'any',simultaneous:'manual'};}
function makeScheme(camp,id=L.uid(),name='新增胜利方案'){
 const conditions=camp===1?[L.rule('eliminate',2),L.rule('tasks',2,30)]:camp===2?[L.rule('ratio',1)]:[L.rule('sole')];
 return {id,name,camp,win:{mode:'custom',join:'any',conditions,event:'any',beneficiary:camp===3?'self':'camp',counterScope:camp===3?'self':'camp',requireAlive:camp===3,priority:camp===3?100:camp===2?30:20,reset:'never'},loss:defaultLoss()};
}
function defaultSchemes(b){return [1,2,3].map(c=>{const s=makeScheme(c,defaultId(c),c===1?'任务与清场':c===2?'人数压制':'各自为战 · 最后存活');if(c===1)s.win.conditions[1].value=b.room.task;return s;});}
function defaultBoard(){const b=L.defaultBoard();b.schema=SCHEMA;b.factionRules=defaultSchemes(b);return b;}
function schemesFor(b,camp){return b.factionRules.filter(s=>s.camp===Number(camp));}
function schemeFor(b,r){return L.isCustom(r)?b.factionRules?.find(s=>s.id===r.win?.ruleId&&s.camp===r.camp):null;}
function makeCustomRole(b,camp=3,ruleId){const r=L.makeCustomRole();r.camp=camp;r.win={mode:'faction',ruleId:ruleId||schemesFor(b||{factionRules:defaultSchemes({room:{task:30}})},camp)[0]?.id};r.loss=defaultLoss();return r;}
function setRoleCamp(b,r,camp){if(!L.isCustom(r))throw Error('已有职业的阵营固定，只能调整技能。');if(![1,2,3].includes(camp))throw Error('阵营无效');r.camp=camp;r.win={mode:'faction',ruleId:schemesFor(b,camp)[0].id};}
function assignRule(b,r,id){if(!L.isCustom(r))throw Error('已有职业的胜利条件固定。');const s=b.factionRules.find(x=>x.id===id&&x.camp===r.camp);if(!s)throw Error('请选择当前阵营的胜利方案');r.win={mode:'faction',ruleId:id};}
function addScheme(b,camp){if(schemesFor(b,camp).length>=12)throw Error('每个阵营最多12个胜利方案');const s=makeScheme(camp);if(camp===1)s.win.conditions[1].value=b.room.task;b.factionRules.push(s);return s;}
function removeScheme(b,id){const s=b.factionRules.find(x=>x.id===id);if(!s)return;if(b.roles.some(r=>L.isCustom(r)&&r.win.ruleId===id))throw Error('此方案仍被角色采用，请先为这些角色更换方案。');if(schemesFor(b,s.camp).length===1)throw Error('每个阵营至少保留一个胜利方案');b.factionRules=b.factionRules.filter(x=>x.id!==id);}
function setSchemeMode(s,mode){if(!['fixed','custom'].includes(mode))throw Error('胜利模式无效');s.win.mode=mode;if(mode==='fixed'&&!presetById(s.win.presetId))s.win.presetId=victoryPresets.find(p=>p.sourceCamp===s.camp).id;}
function setSchemePreset(s,id){if(!presetById(id))throw Error('固定条件无效');s.win.presetId=id;s.win.mode='fixed';}
function resolveRole(b,r){const s=schemeFor(b,r);if(!s)return r;return {...r,win:s.win,loss:s.loss,ruleId:s.id,ruleName:s.name};}
function ruleSummary(s){if(s.win.mode==='fixed')return presetById(s.win.presetId)?.name||'未选择固定条件';return s.win.conditions.map(x=>L.defs[x.type].name+(L.defs[x.type].target?' · '+(x.targetCamp===0?'任意阵营':L.camps[x.targetCamp]+'阵营'):'')+(L.defs[x.type].value?' '+x.value:'')).join(s.win.join==='all'?' ＋ ':s.win.join==='sequence'?' → ':' 或 ');}
function originalLocked(r){const original=L.makeRole(r.templateCareerId);return r.camp===original.camp&&Object.keys(original.win).every(k=>JSON.stringify(r.win?.[k])===JSON.stringify(original.win[k]))&&r.loss?.mode==='default';}
const integer=(v,min=0,max=100000)=>Number.isInteger(v)&&v>=min&&v<=max;
function checkConditions(list){if(!Array.isArray(list)||list.length>12)throw Error('条件数量应为0–12条');for(const c of list){if(!L.defs[c.type]||!integer(c.value)||!integer(c.targetCamp,L.defs[c.type]?.anyTarget?0:1,3))throw Error('胜负事件类型、目标或阈值无效');}}
function checkScheme(s){
 if(!s||typeof s.id!=='string'||!s.id||s.id.length>80||typeof s.name!=='string'||!s.name.trim()||s.name.length>30||![1,2,3].includes(s.camp))throw Error('阵营胜利方案标识不正确');
 const w=s.win,l=s.loss;
 if(!w||!['custom','fixed'].includes(w.mode)||!['any','all','sequence'].includes(w.join)||!L.events[w.event]||!['self','camp'].includes(w.beneficiary)||!['self','camp'].includes(w.counterScope)||!integer(w.priority,0,999)||typeof w.requireAlive!=='boolean'||!['never','meeting'].includes(w.reset))throw Error('阵营胜利方案结构不正确');
 if(w.mode==='fixed'&&!presetById(w.presetId)||w.presetId!==undefined&&!presetById(w.presetId))throw Error('固定胜利条件不存在');
 checkConditions(w.conditions);
 if(!l||!['default','custom'].includes(l.mode)||!['any','all'].includes(l.join)||!L.events[l.event]||!['manual','winFirst','lossFirst'].includes(l.simultaneous))throw Error('失败规则结构不正确');
 checkConditions(l.conditions);
}
function legacyWin(w){const v=clone(w);if(v.mode==='fixed'){v.fixedCareerId=presetById(v.presetId)?.sourceCareerId;delete v.presetId;}if(v.join==='sequence')v.join='all';return v;}
function migrate(input){
 const b=L.validateShape(input),changes=[];b.factionRules=defaultSchemes(b);
 for(const r of b.roles){
  if(!L.isCustom(r)){if(!originalLocked(r)){changes.push({roleUid:r.uid,name:r.name,previousCamp:r.camp,previousWin:clone(r.win),previousLoss:clone(r.loss)});const o=L.makeRole(r.templateCareerId);r.camp=o.camp;r.win=o.win;r.loss=o.loss;}continue;}
  const s=makeScheme(r.camp,L.uid(),(r.name+'的迁移方案').slice(0,30));s.win=clone(r.win);s.win.counterScope='self';s.loss=clone(r.loss||defaultLoss());
  if(s.win.fixedCareerId){s.win.presetId=victoryPresets.find(p=>p.sourceCareerId===s.win.fixedCareerId)?.id;delete s.win.fixedCareerId;}
  const equivalent=b.factionRules.find(x=>x.camp===s.camp&&JSON.stringify(x.win)===JSON.stringify(s.win)&&JSON.stringify(x.loss)===JSON.stringify(s.loss));
  if(!equivalent)b.factionRules.push(s);r.win={mode:'faction',ruleId:(equivalent||s).id};r.loss=defaultLoss();
 }
 b.schema=SCHEMA;b.migration={from:input.schema,notes:['自创角色原胜利条件已移入所属阵营的方案，技能与候选池保留。',...(changes.length?['已有职业的阵营及胜负条件已恢复原设定；之前的改动保存在迁移备份中。']:[])],previousOverrides:changes};return b;
}
function validateShape(input){
 if(!input||typeof input!=='object')throw Error('草稿格式不正确');
 if(input.schema!==SCHEMA){if(!['goose-duck-board-draft/1','goose-duck-board-draft/1.1','goose-duck-board-draft/1.2'].includes(input.schema))throw Error('不支持的草稿格式／版本');return validateShape(migrate(input));}
 const b=clone(input),ids=new Set();if(!Array.isArray(b.factionRules)||b.factionRules.length>303)throw Error('阵营胜利方案列表不正确');
 for(const s of b.factionRules){checkScheme(s);if(ids.has(s.id))throw Error('阵营胜利方案ID重复');ids.add(s.id);}
 if([1,2,3].some(c=>!schemesFor(b,c).length))throw Error('每个阵营至少需要一个胜利方案');
 if(!Array.isArray(b.roles))throw Error('角色列表不正确');
 const flat=clone(b);flat.schema=L.SCHEMA;
 for(let i=0;i<b.roles.length;i++){const r=b.roles[i];if(L.isCustom(r)){
   if(r.win?.mode!=='faction'||Object.keys(r.win).some(k=>!['mode','ruleId'].includes(k)))throw Error('自创角色的胜利必须引用阵营方案');
   const s=schemeFor(b,r);if(!s)throw Error('自创角色引用了不存在或其他阵营的胜利方案');
   if(r.loss?.mode!=='default')throw Error('自创角色的失败条件应在阵营方案内配置');
   flat.roles[i].win=legacyWin(s.win);flat.roles[i].loss=clone(s.loss);
  }else{if(!L.careers.has(r.templateCareerId))throw Error('未知职业');if(!originalLocked(r))throw Error('已有职业的阵营与胜负条件不能更改');}
 }
 // Keep the established strict role/skill/room validation, then retain faction references.
 for(const r of flat.roles)for(const group of [r.win,r.loss])for(const c of group.conditions||[])if(c.targetCamp===0)c.targetCamp=1;
 const validated=L.validateShape(flat);
 b.room=validated.room;b.selection=validated.selection;b.resolution=validated.resolution;
 for(let i=0;i<b.roles.length;i++){b.roles[i].slots=validated.roles[i].slots;}
 delete b.drawPreview;return b;
}
function progressValue(type,r,w,s){
 const data=w.counterScope==='camp'?(s.campProgress?.[r.camp]||s):(s.personalProgress||s);
 return Number((type==='survivalSeconds'?s.personalProgress?.survivalSeconds??s.survivalSeconds:data[type])||0);
}
function metric(c,r,w,s){if(c.type==='kills'&&c.targetCamp){const data=w.counterScope==='camp'?(s.campProgress?.[r.camp]||s):(s.personalProgress||s);return Number(data.killsByCamp?.[c.targetCamp]||0);}return progressValue(L.defs[c.type]?.counter,r,w,s);}
function matches(c,r,b,s,w,baseline){
 const alive=Object.values(s.alive||{}).reduce((n,v)=>n+v,0),d=L.defs[c.type];
 if(d?.counter){let value=metric(c,r,w,s);if(baseline)value-=metric(c,r,w,baseline);return (c.type!=='surviveTime'||s.actorAlive)&&Math.max(0,value)>=c.value;}
 switch(c.type){
 case 'eliminate':return s.alive[c.targetCamp]===0;
 case 'ratio':return s.alive[r.camp]>0&&s.alive[r.camp]>=s.alive[c.targetCamp];
 case 'voted':return s.votedUid===r.uid&&!s.actorAlive;
 case 'dead':return !s.actorAlive;
 case 'sole':return s.actorAlive&&alive===1;
 case 'infection':return s.actorAlive&&alive>1&&Number(s.infected||0)>=alive-1;
 case 'survive':return s.actorAlive&&alive>0&&alive<=c.value;
 case 'emergency':return !!s.emergency;
 case 'timer':return Number(s.seconds||0)>=c.value;
 default:return false;
 }
}
function sequenceChecks(r,b,s,w){
 const history=s.history||[];let done=0,baseline=null,lastSeconds=-1;const seen=new Set();
 if(!history.length)return {done:0,reason:'顺序规则需要逐条记录事件，不能只凭最终快照判胜。'};
 const comparable=x=>{const y=clone(x);delete y.history;delete y.eventId;return y;};
 if(JSON.stringify(comparable(history.at(-1)))!==JSON.stringify(comparable(s)))return {done:0,invalid:true,reason:'当前快照尚未记录，请记录当前事件后再试算。'};
 for(const frame of history){
  if(frame.eventId!==undefined&&seen.has(frame.eventId))continue;
  if(Number(frame.seconds||0)<lastSeconds)return {done:0,invalid:true,reason:'事件时间不能倒退，请清空历史后重新记录。'};
  seen.add(frame.eventId);lastSeconds=Number(frame.seconds||0);
  if(w.reset==='meeting'&&frame.event==='meeting'){done=0;baseline=clone(frame);continue;}
  if(done>=w.conditions.length||!frame.finalized)continue;
  const c=w.conditions[done];
  if(c.type==='surviveTime'&&baseline&&(!frame.actorAlive||metric(c,r,w,frame)<metric(c,r,w,baseline))){baseline={...baseline,survivalSeconds:0,personalProgress:{...(baseline.personalProgress||{}),survivalSeconds:0}};}
  if((w.event==='any'||w.event===frame.event)&&matches(c,r,b,frame,w,baseline)){done++;baseline=clone(frame);}
 }
 return {done,reason:done===w.conditions.length?'已按顺序完成全部事件':`已完成 ${done}/${w.conditions.length} 步；继续记录下一事件。`};
}
function evaluate(r,b,s){
 if(!s.finalized)return {matched:false,checks:[],reason:'请先确认整批死亡、复活和释放效果均已处理。'};
 if(!L.isCustom(r))return {matched:false,unsupported:true,checks:[],reason:'已有职业固定沿用原胜利条件，由游戏运行时结算；更换技能不会改变判胜。'};
 const scheme=schemeFor(b,r);if(!scheme)return {matched:false,checks:[],reason:'请先选择当前阵营的胜利方案。'};
 const w=scheme.win,l=scheme.loss,lossChecks=l.conditions.map(c=>({condition:c,matched:matches(c,r,b,s,w)}));
 let defeated=l.mode==='custom'&&(l.event==='any'||l.event===s.event)&&lossChecks.length>0&&(l.join==='all'?lossChecks.every(x=>x.matched):lossChecks.some(x=>x.matched));
 if(w.mode==='fixed'){const p=presetById(w.presetId);return {matched:false,defeated,unsupported:true,checks:[],lossChecks,reason:`「${scheme.name}」采用固定条件：${p.description}。固定条件由游戏运行时判定。`,beneficiary:p.beneficiary,ruleId:scheme.id};}
 const sequence=w.join==='sequence'?sequenceChecks(r,b,s,w):null;
 const checks=w.conditions.map((c,i)=>({condition:c,matched:sequence?i<sequence.done:matches(c,r,b,s,w)}));
 const reached=checks.length>0&&(w.join==='any'?checks.some(x=>x.matched):checks.every(x=>x.matched));
 const phase=w.event==='any'||w.event===s.event,alive=!w.requireAlive||s.actorAlive;
 let matched=reached&&phase&&alive,conflict=false;
 if(matched&&defeated){if(l.simultaneous==='winFirst')defeated=false;else if(l.simultaneous==='lossFirst')matched=false;else{matched=false;defeated=false;conflict=true;}}
 return {matched,defeated,conflict,checks,lossChecks,priority:w.priority,beneficiary:w.beneficiary,ruleId:scheme.id,sequence,
 reason:conflict?'胜负同时成立，等待裁决。':defeated?'已触发本方案的失败条件。':!phase?'未到方案设定的结算时机。':!alive?'结算时本人需要存活。':sequence?.invalid?sequence.reason:matched?'满足阵营方案的胜利条件。':sequence?sequence.reason:'尚未满足阵营方案的条件。'};
}
function validateScheme(b,s){
 const out=[],add=(level,code,text)=>out.push({level,code,text:`「${s.name}」：${text}`,schemeId:s.id});const w=s.win;
 const assigned=b.roles.filter(r=>L.isCustom(r)&&r.win.ruleId===s.id&&r.camp===s.camp),active=assigned.length&&b.room.counts[s.camp]>0;
 const error=(code,text)=>add(active?'error':'warn',code,text+(active?'':'（当前未被出场候选采用）'));
 if(w.mode==='fixed'){if(s.loss.mode==='custom'){if(!s.loss.conditions.length)error('EMPTY_LOSS','至少添加一个失败条件。');if(s.loss.conditions.some(c=>L.defs[c.type].value&&c.value<1))error('LOSS_THRESHOLD','失败阈值必须大于0。');const actor=assigned[0]||{uid:'preview',kind:'custom',templateCareerId:null,camp:s.camp,win:{mode:'faction',ruleId:s.id}};if(evaluate(actor,b,{event:s.loss.event,alive:b.room.counts,actorAlive:true,finalized:true}).defeated)error('OPENING_LOSS','失败条件在开局已满足。');}const p=presetById(w.presetId);if((p.sourceCareerId===1&&!b.room.counts[2])||(p.sourceCareerId===101&&!b.room.counts[1]))error('FIXED_OPENING','固定清场条件在开局已满足。');add('info','FIXED_RUNTIME','固定条件保留原完整判定，需要游戏运行时接入。');return out;}
 if(!w.conditions.length)error('EMPTY_WIN','至少添加一个胜利事件。');
 const impossible=[];
 for(const c of w.conditions){
  const d=L.defs[c.type];
  if(d.value&&c.value<1)error('ZERO_THRESHOLD','事件阈值必须大于0。');
  const maxKill=c.targetCamp?(b.room.counts[c.targetCamp]-(c.targetCamp===s.camp&&w.counterScope==='self'?1:0)):b.room.total-(w.counterScope==='self'?1:0);
  const no=c.type==='tasks'&&c.value>b.room.task||c.type==='kills'&&c.value>maxKill;
  impossible.push(no);
  if(no)add('warn','EVENT_UNREACHABLE',`${d.name}的目标超过当前可达到的数量。`);
 }
 if(impossible.length&&(w.join!=='any'?impossible.some(Boolean):impossible.every(Boolean)))error('WIN_UNREACHABLE','当前组合含必需但无法达到的任务或击杀目标。');
 const dead=w.conditions.some(c=>['dead','voted'].includes(c.type)),live=w.conditions.some(c=>['sole','survive','surviveTime','infection'].includes(c.type));
 if(w.join==='all'&&dead&&(live||w.requireAlive)||w.join==='any'&&w.conditions.length&&w.conditions.every(c=>['dead','voted'].includes(c.type))&&w.requireAlive)error('WIN_CONTRADICTION','同一次判定不能既已出局又要求本人存活。');
 if(w.join==='sequence'&&w.conditions.length&&['dead','voted'].includes(w.conditions.at(-1).type)&&w.requireAlive)error('WIN_CONTRADICTION','最后一步要求出局时，不能同时要求本人存活。');
 const actor=assigned[0]||{uid:'rule-preview',camp:s.camp,kind:'custom',templateCareerId:null,win:{mode:'faction',ruleId:s.id}};
 const opening={event:w.event,alive:{...b.room.counts},actorAlive:true,finalized:true,seconds:0,history:[],votedUid:'',infected:0};
 if(w.join!=='sequence'&&evaluate(actor,b,opening).matched)error('OPENING_WIN','条件在开局状态已经满足。');
 if(w.join==='sequence'&&w.conditions.length&&w.conditions.every(c=>matches(c,actor,b,opening,w)))error('OPENING_WIN','所有步骤在开局已成立，不能用事件顺序规避开局即胜利检查。');
 if(s.loss.mode==='custom'){
  if(!s.loss.conditions.length)error('EMPTY_LOSS','启用失败规则后需要至少一个条件。');
  if(s.loss.conditions.some(c=>L.defs[c.type].value&&c.value<1))error('LOSS_THRESHOLD','失败阈值必须大于0。');
  if(evaluate(actor,b,{...opening,event:s.loss.event}).defeated)error('OPENING_LOSS','失败条件在开局已满足。');
 }
 if(w.counterScope==='camp')add('info','CAMP_PROGRESS','累计维度统计本阵营所有玩家的有效进度；本人存活/出局仍逐人检查。');
 if(w.beneficiary==='camp')add('info','RULE_FOLLOWERS','共享胜利只授予同阵营采用本方案的自创角色，已有职业不加入此结算。');
 return out;
}
function validate(b,{checkPool=true}={}){
 try{validateShape(b);}catch(e){return [{level:'error',code:'SCHEMA',text:e.message}];}
 const flat=clone(b);flat.schema=L.SCHEMA;
 for(const r of flat.roles)if(L.isCustom(r)){r.win=L.makeCustomRole().win;r.loss=defaultLoss();}
 const out=L.validate(flat,{checkPool:false}).map(x=>x.code==='ORIGINAL_OPENING'?{...x,text:'原版鹅胜利依赖鸭阵营；请配置鸭阵营席位，或将已有鹅职业移出候选池。'}:x).filter(x=>!['NEUTRAL_SHARED','RUNTIME_BOUNDARY'].includes(x.code));
 if(b.room.counts[2]>0&&!b.room.counts[1]&&b.roles.some(r=>!L.isCustom(r)&&r.camp===2))out.push({level:'error',code:'ORIGINAL_DUCK_OPENING',text:'已有鸭职业的清场条件在开局已满足；请分配鹅阵营席位，或移出这些鸭职业。'});
 for(const s of b.factionRules)out.push(...validateScheme(b,s));
 if(checkPool&&!out.some(x=>x.level==='error')){const result=L.findLineup(b);if(!result.ok){const skillLimited=result.status==='skill-cap';out.push({level:result.status==='search-limit'?'warn':'error',code:skillLimited?'SKILL_FAMILY_POOL':'POOL_NO_COMBINATION',text:skillLimited?'候选数量虽然足够，但技能持有者上限使当前人数无法组成合法一桌；请增加其他候选或降低带该技能角色的单局上限。':result.status==='search-limit'?'组合较复杂，请试抽或精简互斥候选。':'候选池无法满足本局人数、技能配套及原职业互斥／依赖要求。'});}}
 out.push({level:'info',code:'RUNTIME_BOUNDARY',text:'规则事件、计数去重及阵营方案需接入游戏服务端；本编辑器提供配置、抽取和事件试算。'});return out;
}
function drawPool(b,seed){const errors=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(errors.length)throw Error('请先修正配置：'+errors[0].text);const d=L.findLineup(b,seed||L.uid());if(!d.ok)throw Error(d.status==='skill-cap'?'技能持有者上限使当前人数无法组成合法一桌，请补充其他候选或降低单局上限。':'本次未找到合法组合，请重抽或调整候选池。');return d;}
function exportDraft(b){const clean=validateShape(b);clean.updatedAt=new Date().toISOString();clean.source={label:L.D.meta.label,tables:clone(L.D.meta.sourceFiles)};clean.integration={status:'prototype-only',proposedFields:['factionRules','roles[].win.ruleId','factionRules[].win.counterScope','factionRules[].win.join','selection','roles[].slots','roles[].skillOverrides'],requires:['原职业身份与判胜不可覆写，只允许实例技能重配','自创角色仅引用所属阵营的胜利方案','同阵营采用相同方案的自创角色才参与方案共享获胜','有效事件去重、阵营累计计数及顺序步骤进度由服务端维护','顺序计数从进入该步时起累计；会议重置会清空已完成步骤','服务端随机抽取与技能兼容联调']};return clean;}
function poolExample(){return migrate(L.poolExample());}
function recipients(b,ruleId,camp,actorSeat,seats){const s=b.factionRules.find(s=>s.id===ruleId&&s.camp===camp);if(!s)return [];const benefit=s.win.mode==='fixed'?presetById(s.win.presetId).beneficiary:s.win.beneficiary;const eligible=seats.filter(seat=>{const r=b.roles.find(x=>x.uid===seat.roleUid);return r&&L.isCustom(r)&&r.camp===camp&&r.win.ruleId===ruleId;});return eligible.filter(seat=>benefit==='camp'||seat.uid===actorSeat).map(seat=>seat.uid);}
root.EditorEngine={...L,SCHEMA,counters,victoryPresets,presetById,makeScheme,defaultBoard,makeCustomRole,schemesFor,schemeFor,setRoleCamp,assignRule,addScheme,removeScheme,setSchemeMode,setSchemePreset,resolveRole,ruleSummary,validateShape,validate,validateScheme,evaluate,drawPool,exportDraft,poolExample,recipients,
 setWinMode(){throw Error('胜利条件请在所属阵营的方案中编辑。');},setFixedWin(){throw Error('固定条件请在所属阵营的方案中选择。');}};
})(typeof window!=='undefined'?window:globalThis);
