(function(root){
'use strict';
const L=root.EditorEngine,clone=L.clone,SCHEMA='goose-duck-board-draft/1.6',PREVIOUS_SCHEMA='goose-duck-board-draft/1.5',RETIRED_SCHEMA='goose-duck-board-draft/1.4',MAX_CAMP_EVENTS=10;
const RESOLUTION=Object.freeze({tie:'shared',batch:'afterAllEffects',priority:'extraFirst'});
const eventCatalog=Object.freeze({
 kills:Object.freeze({name:'击倒对手',category:'对抗与推理',aggregation:'team',unit:'名对手',defaultValue:2,counter:'kills',description:'击倒不同敌对玩家；友军、自杀和环境死亡不计，同一目标只计一次。',hint:'需配置可击倒对手的技能。'}),
 voteOuts:Object.freeze({name:'精准归票',category:'对抗与推理',aggregation:'team',unit:'名对手',defaultValue:2,counter:'voteOuts',description:'有效投票命中本轮被投出局的对手；队友投中同一人只计一次。',hint:'按最终有效选票和实际投票淘汰结果计算。'}),
 reports:Object.freeze({name:'现场报告',category:'行动与技能',aggregation:'team',unit:'名被报告者',defaultValue:2,counter:'reports',description:'本人主动报告不同被击倒玩家；重复报告、紧急按铃和被动自动报告不计。',hint:'需配置报告技能并主动成功报告；加拿大鹅等被动报告不计。'}),
 skillUses:Object.freeze({name:'技能达人',category:'行动与技能',aggregation:'team',unit:'次',defaultValue:5,counter:'skillUses',description:'主动技能成功生效才计数；多段施放算一次，失败、冷却点击和被动不计。',hint:'需为可能出场的成员配置可用主动技能。'}),
 ventTrips:Object.freeze({name:'暗道转移',category:'行动与技能',aggregation:'team',unit:'次',defaultValue:3,counter:'ventTrips',description:'通过通道从另一出口离开；原地进出不计，每个行动回合本阵营最多计一次。',hint:'需遁入技能及支持连通出口的地图；盔甲原地藏身不计。'}),
 investigations:Object.freeze({name:'线索收集',category:'对抗与推理',aggregation:'team',unit:'名玩家',defaultValue:2,counter:'investigations',description:'通过调查或查验获得不同玩家的信息；同一目标跨技能也只计一次。',hint:'需侦探的调查或殡仪员的查验技能；仅成功获得信息才计数。'}),
 crisisRepairs:Object.freeze({name:'解除危机',category:'行动与技能',aggregation:'team',unit:'次',defaultValue:2,counter:'crisisRepairs',description:'亲自完成有效紧急任务操作，且危机最终解除；每个行动回合本阵营最多计一次。',hint:'所有存活玩家可参与；普通任务、伪造任务和激活破坏不计。'}),
 surviveMeetings:Object.freeze({name:'平安归来',category:'会议与生存',aggregation:'personalMax',unit:'次会议',defaultValue:3,counter:'surviveMeetings',description:'一名成员连续参加并存活通过指定次数会议；中立只看本人，缺席或出局后连续次数清零。',hint:'采用仍存活成员的个人记录，不相加；缺席或出局都会中断。'}),
 zeroVoteMeetings:Object.freeze({name:'零票过会',category:'会议与生存',aggregation:'personalMax',unit:'次会议',defaultValue:3,counter:'zeroVoteMeetings',description:'本人连续参加完成正常投票的会议，获得零张有效票且会后存活；得票、缺席或出局都会清零。',hint:'无投票或提前结束的特殊会议不计；采用存活成员个人连续记录。'}),
 votedSurvivalMeetings:Object.freeze({name:'险中脱身',category:'会议与生存',aggregation:'team',unit:'次会议',defaultValue:2,counter:'votedSurvivalMeetings',description:'收到对手的有效投票后仍存活通过会议；同一场会议本阵营最多计一次。',hint:'至少收到一名敌对玩家的票；队友互投和会中出局不计。'})
});
const PREVIOUS_TYPES=Object.freeze(['kills','skillUses','reports','revives','rescues','surviveMeetings']);
const RETIRED_TYPES=Object.freeze(['revives','rescues']);
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const integer=(n,min=0,max=100000)=>Number.isInteger(n)&&n>=min&&n<=max;
const stable=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const equal=(a,b)=>stable(a)===stable(b);
const groupKey=camp=>'camp-'+camp;
const legacyGroupKey=(camp,roleUid)=>camp===3?'neutral-'+roleUid:groupKey(camp);
const defaultLoss=()=>({mode:'default',join:'any',conditions:[L.rule('dead')],event:'any',simultaneous:'manual'});
const newRule=camp=>({key:groupKey(camp),camp,join:'any',events:[]});

function ensureCampRules(b){
 const present=Array.isArray(b.campEvents)?b.campEvents:[],wanted=[1,2,3].map(newRule);
 b.campEvents=wanted.map(r=>present.find(x=>x.key===r.key)||r);return b.campEvents;
}
function campRule(b,camp,roleUid){
 return b.campEvents?.find(x=>x.key===groupKey(Number(camp)))||null;
}
function addCampEvent(b,camp,type,roleUid){
 if(!own(eventCatalog,type))throw Error('请选择新增胜利事件，原胜利条件不能添加或修改。');
 ensureCampRules(b);const r=campRule(b,camp,roleUid);if(!r)throw Error('请先选择一个阵营。');
 if(r.events.length>=MAX_CAMP_EVENTS)throw Error('每个阵营最多添加'+MAX_CAMP_EVENTS+'个胜利事件。');
 if(r.events.some(x=>x.type===type))throw Error('这个事件已经添加，可直接修改目标数量。');
 const e={id:L.uid(),type,value:eventCatalog[type].defaultValue};r.events.push(e);return e;
}
function removeCampEvent(b,camp,id,roleUid){const r=campRule(b,camp,roleUid);if(!r)throw Error('找不到这个阵营。');r.events=r.events.filter(e=>e.id!==id);}
function eventSummary(e,camp){const d=eventCatalog[e.type];return d?d.name+' · '+e.value+' '+d.unit:'';}
function toCurrent(input,withMigration){
 const b=clone(input),oldRules=clone(b.factionRules||[]),previousRoleRules=b.roles.filter(L.isCustom).map(r=>({uid:r.uid,win:clone(r.win),loss:clone(r.loss)}));
 b.schema=SCHEMA;delete b.factionRules;delete b.drawPreview;b.campEvents=[];b.resolution=clone(RESOLUTION);
 for(const r of b.roles)if(L.isCustom(r)){r.win={mode:'camp',camp:r.camp};r.loss=defaultLoss();}
 ensureCampRules(b);
 if(withMigration)b.migration={...(b.migration||{}),from:input.schema,previousFactionRules:oldRules,previousRoleRules,notes:['已按阵营管理新增胜利事件，原职业胜利条件固定保留。','旧胜利方案完整保存在迁移备份中，没有自动扩大到整个阵营；请重新选择需要的原创事件。','中立目标统一设置，每名出场玩家独立累计、独立获胜；同角色多份出场也不合并。']};
 return b;
}
function defaultBoard(){return toCurrent(L.defaultBoard(),false);}
function makeCustomRole(b,camp=3){if(![1,2,3].includes(camp))throw Error('阵营无效。');const r=L.makeCustomRole(b&&b.factionRules?b:undefined,camp);r.win={mode:'camp',camp};r.loss=defaultLoss();return r;}
function setRoleCamp(b,r,camp){if(!L.isCustom(r))throw Error('已有职业的阵营固定，只能调整技能。');if(![1,2,3].includes(camp))throw Error('阵营无效。');r.camp=camp;r.win={mode:'camp',camp};ensureCampRules(b);}
function removeRole(b,uid){b.roles=b.roles.filter(r=>r.uid!==uid);ensureCampRules(b);}
function asLegacy(b){
 const flat=clone(b),defaults=L.defaultBoard();flat.schema=L.SCHEMA;flat.factionRules=defaults.factionRules;delete flat.campEvents;flat.resolution={tie:'shared',batch:'afterAllEffects'};
 for(const r of flat.roles)if(L.isCustom(r)){r.win={mode:'faction',ruleId:flat.factionRules.find(x=>x.camp===r.camp).id};r.loss=defaultLoss();}
 return flat;
}
function assertKeys(obj,keys,message){if(!obj||typeof obj!=='object'||Array.isArray(obj)||Object.keys(obj).some(k=>!keys.includes(k)))throw Error(message);}
function migrateNeutralRules(input){
 const hasRetired=input.schema===RETIRED_SCHEMA,b=validateCampShape(input,hasRetired?PREVIOUS_TYPES:Object.keys(eventCatalog),hasRetired?6:MAX_CAMP_EVENTS,true);
 const previousNeutralCampEvents=clone(b.campEvents.filter(r=>r.camp===3)),nonempty=previousNeutralCampEvents.filter(r=>r.events.length);
 // 事件顺序和内部ID不改变逻辑；单个目标的任一/全部也等价。空组随共享配置继承。
 const signature=r=>stable({join:r.events.length===1?'any':r.join,events:r.events.map(({type,value})=>({type,value})).sort((a,z)=>a.type.localeCompare(z.type))});
 const conflict=new Set(nonempty.map(signature)).size>1,retiredGroups=[];
 if(hasRetired)for(const r of b.campEvents)if(r.events.some(e=>RETIRED_TYPES.includes(e.type))){retiredGroups.push(clone(r));r.events=[];}
 const shared=newRule(3),source=!conflict&&nonempty.length?b.campEvents.find(r=>r.key===nonempty[0].key):null;
 if(source){shared.join=source.join;shared.events=clone(source.events);}
 b.campEvents=[b.campEvents.find(r=>r.camp===1),b.campEvents.find(r=>r.camp===2),shared];b.schema=SCHEMA;delete b.integration;
 const notes=(b.migration?.notes||[]).filter(note=>!note.includes('中立角色各有独立阵营'));
 if(retiredGroups.length)notes.push('救援行动、起死回生已下架；含这些目标的阵营组合已整体备份并清空，请重新选择。');
 notes.push(conflict?'旧中立角色使用了不同的新增目标，已完整备份并清空中立统一设置，请重新选择。':source?.events.length?'已将旧中立的相同目标设为统一目标；原先未设目标的中立也会采用，旧配置已完整备份。':'中立目标已改为统一设置，旧中立配置已完整备份，可在中立页添加目标。');
 notes.push('中立目标统一设置，每名出场玩家独立累计、独立获胜；同角色多份出场也不合并。');
 b.migration={...(b.migration||{}),from:input.schema,previousNeutralCampEvents,retiredCampEvents:[...(b.migration?.retiredCampEvents||[]),...retiredGroups],notes:[...new Set(notes)]};
 if(conflict)b.migration.neutralRuleConflict=true;else delete b.migration.neutralRuleConflict;
 return validateCampShape(b);
}
function validateShape(input){
 if(!input||typeof input!=='object')throw Error('草稿格式不正确。');
 if([PREVIOUS_SCHEMA,RETIRED_SCHEMA].includes(input.schema))return migrateNeutralRules(input);
 if(input.schema!==SCHEMA){
  if(!['goose-duck-board-draft/1','goose-duck-board-draft/1.1','goose-duck-board-draft/1.2',L.SCHEMA].includes(input.schema))throw Error('不支持的草稿版本。');
  return validateShape(toCurrent(L.validateShape(input),true));
 }
 return validateCampShape(input);
}
function validateCampShape(input,allowedTypes=Object.keys(eventCatalog),maxEvents=MAX_CAMP_EVENTS,legacyNeutral=false){
 const b=clone(input);if(own(b,'factionRules'))throw Error('旧职业胜利方案不能写入新版阵营设置。');
 if(!Array.isArray(b.roles)||!Array.isArray(b.campEvents))throw Error('角色或阵营列表不正确。');
 if(!equal(b.resolution,RESOLUTION))throw Error('新增事件必须先于原胜利条件判定，同批新增目标达成固定并列获胜。');
 for(const r of b.roles){
  if(L.isCustom(r)){if(!equal(r.win,{mode:'camp',camp:r.camp})||!equal(r.loss,defaultLoss()))throw Error('自创角色的胜利只绑定阵营，不能单独覆写。');}
  else {const c=L.careers.get(r.templateCareerId);if(!c)throw Error('未知职业。');const original=L.makeRole(c.id);if(r.camp!==c.camp||!equal(r.win,original.win)||!equal(r.loss,original.loss))throw Error('已有职业的阵营和原胜利条件不可编辑。');}
 }
 const expected=new Set(legacyNeutral?['camp-1','camp-2',...b.roles.filter(r=>r.camp===3).map(r=>'neutral-'+r.uid)]:['camp-1','camp-2','camp-3']),keys=new Set(),eventIds=new Set();
 for(const r of b.campEvents){
  assertKeys(r,legacyNeutral?['key','camp','roleUid','join','events']:['key','camp','join','events'],'阵营事件结构不正确。');
  if(![1,2,3].includes(r.camp)||r.key!==(legacyNeutral?legacyGroupKey(r.camp,r.roleUid):groupKey(r.camp))||!expected.has(r.key)||keys.has(r.key)||r.camp!==3&&own(r,'roleUid'))throw Error('阵营事件绑定无效或重复。');
  keys.add(r.key);if(!['any','all'].includes(r.join)||!Array.isArray(r.events)||r.events.length>maxEvents)throw Error('每个阵营可添加最多'+maxEvents+'个事件，关系只能是任一或全部。');
  const types=new Set();for(const e of r.events){
   assertKeys(e,['id','type','value'],'新增事件不允许设置原条件、优先级或其他参数。');
   if(typeof e.id!=='string'||!e.id||e.id.length>80||eventIds.has(e.id)||!allowedTypes.includes(e.type)||types.has(e.type)||!integer(e.value,1,999))throw Error('新增事件类型、目标数量或标识不正确。');
   eventIds.add(e.id);types.add(e.type);
  }
 }
 if(keys.size!==expected.size)throw Error(legacyNeutral?'旧草稿的中立角色配置不完整。':'请保留鹅、鸭、中立三组阵营设置。');
 const checked=L.validateShape(asLegacy(b));b.room=checked.room;b.selection=checked.selection;
 b.roles.forEach((r,i)=>{r.slots=checked.roles[i].slots;});delete b.drawPreview;return b;
}
function evaluateCamp(b,camp,progress={},options={}){
 const r=campRule(b,camp,options.roleUid),alive=options.alive!==false;
 if(!r)return {matched:false,checks:[],reason:'请先选择一个阵营。'};
 const checks=r.events.map(event=>({event,matched:integer(progress[event.type])&&progress[event.type]>=event.value}));
 const reached=checks.length>0&&(r.join==='all'?checks.every(x=>x.matched):checks.some(x=>x.matched));
 return {matched:alive&&reached,checks,groupKey:r.key,reason:!alive?'该阵营已无人存活，不触发新增胜利。':!checks.length?'未添加额外目标，保留原胜利条件。':reached?'新增目标已达成，先于原胜利条件结算。':'新增目标尚未达成，继续保留原胜利判定。'};
}
function checkProgress(p){
 if(p===undefined)return;
 if(!p||typeof p!=='object'||Array.isArray(p))throw Error('事件进度需要使用有效计数字段。');
 for(const key of Object.keys(eventCatalog))if(own(p,key)&&!integer(p[key]))throw Error('事件进度必须是0至100000之间的整数。');
}
function resolveVictory(b,state){
 const result=(source,reason,more={})=>({source,winners:[],matchedGroups:[],reason,...more});
 if(state?.finalized!==true)return result('pending','先处理完本批击倒、投票和技能效果，再统一判胜。');
 try{
  b=validateShape(b);
  if(!Array.isArray(state.seats)||!Array.isArray(state.aliveSeatIds)||!Array.isArray(state.originalWinners))throw Error('请提供完整出场名单、存活名单和原胜利结果。');
  const seatIds=new Set();for(const seat of state.seats){const r=b.roles.find(x=>x.uid===seat.roleUid);if(!r||typeof seat.uid!=='string'||!seat.uid||seatIds.has(seat.uid)||seat.camp!==r.camp)throw Error('出场席位与角色池不一致。');seatIds.add(seat.uid);}
  if(state.seats.length!==b.room.total||[1,2,3].some(c=>state.seats.filter(s=>s.camp===c).length!==b.room.counts[c]))throw Error('请先按本局人数完整抽取出场角色。');
  const lineupProblems=L.lineupIssues(b,state.seats);if(lineupProblems.length)throw Error(lineupProblems[0].text);
  if(state.aliveSeatIds.some(id=>!seatIds.has(id))||state.originalWinners.some(id=>!seatIds.has(id)))throw Error('判胜结果引用了未出场的玩家。');
  if(state.originalWinners.some(id=>{const seat=state.seats.find(s=>s.uid===id),role=b.roles.find(r=>r.uid===seat.roleUid);return seat.camp===3&&L.isCustom(role);}))throw Error('自创中立没有原胜利条件，只能通过自己的新增胜利事件获胜。');
  for(const table of [state.campProgress,state.playerProgress])if(table!==undefined&&(!table||typeof table!=='object'||Array.isArray(table)))throw Error('事件进度列表格式不正确。');
  for(const [id,p] of Object.entries(state.playerProgress||{})){if(!seatIds.has(id))throw Error('事件进度引用了未出场的玩家。');checkProgress(p);}
  for(const p of Object.values(state.campProgress||{}))checkProgress(p);
  const alive=new Set(state.aliveSeatIds),groups=[],checks=[];
  for(const camp of [1,2]){
   const seats=state.seats.filter(s=>s.camp===camp);if(!seats.length)continue;
   const p=clone(state.campProgress?.[camp]||{});
   // 个人连续目标只取仍存活成员最大值，绝不合并队友记录或采纳团队伪造值。
   for(const [type,definition] of Object.entries(eventCatalog))if(definition.aggregation==='personalMax')p[type]=Math.max(0,...seats.filter(s=>alive.has(s.uid)).map(s=>state.playerProgress?.[s.uid]?.[type]||0));
   const verdict=evaluateCamp(b,camp,p,{alive:seats.some(s=>alive.has(s.uid))});checks.push({key:'camp-'+camp,camp,...verdict});
   if(verdict.matched)groups.push({key:'camp-'+camp,camp,eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:seats.map(s=>s.uid)});
  }
  for(const seat of state.seats.filter(s=>s.camp===3)){
   const verdict=evaluateCamp(b,3,state.playerProgress?.[seat.uid]||{},{alive:alive.has(seat.uid),roleUid:seat.roleUid});checks.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,...verdict});
   if(verdict.matched)groups.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,ruleKey:groupKey(3),eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:[seat.uid]});
  }
  if(groups.length)return result('extra',groups.length>1?'同批多个独立阵营达成新增目标，并列获胜；本批原胜利条件不再执行。':'新增目标优先成立；本批原胜利条件不再执行。',{winners:[...new Set(groups.flatMap(g=>g.winners))],matchedGroups:groups,tie:groups.length>1,checks});
  if(state.originalWinners.length)return result('original','没有新增目标达成，按游戏运行时提供的原胜利结果结算。',{winners:[...new Set(state.originalWinners)],checks});
  return result('none','本批没有新增目标或原胜利结果成立，继续游戏。',{checks});
 }catch(e){return result('pending',e.message,{invalid:true});}
}
function validate(b,{checkPool=true}={}){
 try{b=validateShape(b);}catch(e){return [{level:'error',code:'SCHEMA',text:e.message}];}
 const out=L.validate(asLegacy(b),{checkPool:false}).filter(x=>!x.schemeId&&!['RUNTIME_BOUNDARY','RULE_FOLLOWERS','CAMP_PROGRESS','NEUTRAL_SHARED'].includes(x.code));
 const add=(level,code,text,r)=>out.push({level,code,text,camp:r.camp,roleUid:r.roleUid,groupKey:r.key});
 for(const r of b.campEvents){
  const active=b.room.counts[r.camp]>0;
  if(active&&r.camp===3&&b.roles.some(x=>x.camp===3&&L.isCustom(x))&&!r.events.length)add('error','CUSTOM_NEUTRAL_NO_WIN','候选池中有自创中立角色，请在中立统一设置中添加至少一个原创胜利事件。',r);
  const opponentCapacity=b.room.total-(r.camp===3?1:b.room.counts[r.camp]);
  const investigationCapacity=b.room.total-(r.camp===3||b.room.counts[r.camp]<2?1:0);
  const unreachable=r.events.map(e=>['kills','voteOuts'].includes(e.type)&&e.value>opponentCapacity||e.type==='reports'&&e.value>b.room.total-1||e.type==='investigations'&&e.value>investigationCapacity);
  if(unreachable.some(Boolean))add(active&&(r.join==='all'||unreachable.every(Boolean))?'error':'warn','EXTRA_UNREACHABLE',L.camps[r.camp]+'阵营的目标数量超过本局可计数的不同玩家数，请降低目标。',r);
  if(r.events.some(e=>['kills','reports','skillUses','ventTrips','investigations'].includes(e.type)))add('info','EVENT_ABILITY','部分新增目标需要对应技能或地图通道；请按目标提示为可能出场的成员配置。',r);
 }
 for(const camp of [1,2])if(b.room.counts[camp]>0&&!b.room.counts[camp===1?2:1]&&b.roles.some(r=>r.camp===camp&&L.isCustom(r))&&!out.some(x=>['ORIGINAL_OPENING','ORIGINAL_DUCK_OPENING'].includes(x.code)))out.push({level:'error',code:'ORIGINAL_CAMP_OPENING',camp,text:L.camps[camp]+'阵营的原清场条件在开局已成立，请分配对方阵营席位。'});
 if(checkPool&&!out.some(x=>x.level==='error')){const draw=L.findLineup(b);if(!draw.ok){const skillLimited=draw.status==='skill-cap';out.push({level:draw.status==='search-limit'?'warn':'error',code:skillLimited?'SKILL_FAMILY_POOL':'POOL_NO_COMBINATION',text:skillLimited?'候选数量虽然足够，但技能持有者上限使当前人数无法组成合法一桌；请补充其他候选或降低带该技能角色的单局上限。':draw.status==='search-limit'?'组合较复杂，请试抽或减少互斥候选。':'候选池无法按本局人数组成合法一桌。'});}}
 out.push({level:'info',code:'RUNTIME_BOUNDARY',text:'工坊提供配置、随机抽取和事件试算；原职业特殊判胜及有效事件统计仍需接入游戏运行时。'});return out;
}
function drawPool(b,seed){b=validateShape(b);const errors=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(errors.length)throw Error('请先修正配置：'+errors[0].text);const d=L.findLineup(b,seed||L.uid());if(!d.ok)throw Error(d.status==='skill-cap'?'技能持有者上限使当前人数无法组成合法一桌，请补充其他候选或降低单局上限。':'本次未找到合法组合，请重抽或调整候选池。');return d;}
function poolExample(){const b=toCurrent(L.poolExample(),false);if(b.roles.some(r=>r.camp===3&&L.isCustom(r)))addCampEvent(b,3,'skillUses');return b;}
function exportDraft(b){
 const clean=validateShape(b);clean.updatedAt=new Date().toISOString();clean.source={label:L.D.meta.label,tables:clone(L.D.meta.sourceFiles)};
 clean.integration={status:'prototype-only',proposedFields:['campEvents','roles[].win.camp','resolution.priority'],priority:'extraFirst',sameBatchExtra:'shared',neutralIdentity:'one-independent-faction-per-drawn-seat',neutralConfiguration:'shared-camp-3',neutralProgress:'independent-per-seat',neutralWinners:'independent-per-seat',eventCounters:clone(eventCatalog),counterInput:'server-validated-and-deduplicated',requires:['原职业原判胜不可覆写；自创鹅/鸭沿用对应阵营基础判胜，自创中立须配置原创事件','鹅、鸭、中立各有一组新增目标；中立统一设置适用于所有中立原职业和自创角色，每名玩家独立累计、独立获胜，同角色多份出场也不合并；鹅鸭全体成员共享阵营进度','本批全部效果处理完毕后，先检查所有新增目标；任何新增目标成立都不再执行本批原判胜','同批多个额外目标达成的阵营并列；未达标中立不会随其他中立获胜','击倒按敌对目标去重，自杀和环境死亡不计；精准归票按最终有效票命中实际被投出的敌方，团队对同一目标只计一次','报告仅本人主动成功报告，按被报告玩家去重；紧急按铃、加拿大鹅等被动自动报告不计；调查#15/查验#16按目标玩家跨技能去重，必须成功获得有效信息','主动技能只计成功施放，每次多段施放算一次；暗道转移须从另一有效出口离开，同入口进出及原地藏身不计，每行动回合鹅鸭各阵营最多一次，中立每名玩家最多一次','解除危机须本人完成有效紧急任务操作且危机最终解除；按危机实例去重，每行动回合鹅鸭各阵营最多一次，中立每名玩家最多一次；普通、伪造、激活破坏任务不计','平安归来与零票过会取仍存活成员的个人连续最大值，不相加；平安归来缺席或出局清零；零票过会仅本人参加完成正常投票阶段且会后存活，得票、缺席、死亡清零；超级金水铃等无正常投票、提前结束或未进入有效投票的会议不能计作零票记录；险中脱身须收到敌方有效票且会后存活，按会议去重','所有事件的去重与次数限制均按鹅鸭各阵营、中立每名出场玩家分别执行，不能合并中立进度；以上去重与有效性过滤由游戏运行时完成，编辑器只接收有效计数，不模拟战斗采集或原职业特殊结算']};return clean;
}
const retired=()=>{throw Error('胜利事件已改为直接绑定阵营，请在“阵营与胜利”页添加。');};
root.EditorEngine={...L,SCHEMA,RESOLUTION,MAX_CAMP_EVENTS,eventCatalog,campRule,ensureCampRules,addCampEvent,removeCampEvent,eventSummary,defaultBoard,makeCustomRole,setRoleCamp,removeRole,validateShape,validate,evaluateCamp,resolveVictory,drawPool,poolExample,exportDraft,
 addScheme:retired,removeScheme:retired,setSchemeMode:retired,setSchemePreset:retired,assignRule:retired,setWinMode:retired,setFixedWin:retired};
})(typeof window!=='undefined'?window:globalThis);
