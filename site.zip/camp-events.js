(function(root){
'use strict';
const L=root.EditorEngine,clone=L.clone,SCHEMA='goose-duck-board-draft/1.4';
const RESOLUTION=Object.freeze({tie:'shared',batch:'afterAllEffects',priority:'extraFirst'});
const eventCatalog=Object.freeze({
 kills:Object.freeze({name:'猎手挑战',unit:'名对手',defaultValue:2,counter:'kills',description:'击杀不同对手；友军不计，同一人复活后再次被击杀也只计一次。'}),
 skillUses:Object.freeze({name:'技能达人',unit:'次',defaultValue:5,counter:'skillUses',description:'主动技能成功生效才计数；一次多段施放只算一次，冷却点击和被动触发不计。'}),
 reports:Object.freeze({name:'现场调查',unit:'名被报告者',defaultValue:2,counter:'reports',description:'有效报告不同的被击倒玩家；重复报告同一人、紧急会议不计。'}),
 revives:Object.freeze({name:'起死回生',unit:'名玩家',defaultValue:1,counter:'revives',description:'成功复活不同玩家；对同一玩家重复复活只计一次。'}),
 rescues:Object.freeze({name:'救援行动',unit:'名玩家',defaultValue:2,counter:'rescues',description:'成功救出不同受困玩家；同一玩家反复获救只计一次。'}),
 surviveMeetings:Object.freeze({name:'平安归来',unit:'次会议',defaultValue:3,counter:'surviveMeetings',description:'至少一名成员连续存活通过指定次数会议；中立只看本人，出局后本人连续次数清零。'})
});
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const integer=(n,min=0,max=100000)=>Number.isInteger(n)&&n>=min&&n<=max;
const stable=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const equal=(a,b)=>stable(a)===stable(b);
const groupKey=(camp,roleUid)=>camp===3?'neutral-'+roleUid:'camp-'+camp;
const defaultLoss=()=>({mode:'default',join:'any',conditions:[L.rule('dead')],event:'any',simultaneous:'manual'});
const newRule=(camp,roleUid)=>({key:groupKey(camp,roleUid),camp,...(camp===3?{roleUid}:{}),join:'any',events:[]});

function ensureCampRules(b){
 const present=Array.isArray(b.campEvents)?b.campEvents:[],wanted=[newRule(1),newRule(2),...b.roles.filter(r=>r.camp===3).map(r=>newRule(3,r.uid))];
 b.campEvents=wanted.map(r=>present.find(x=>x.key===r.key)||r);return b.campEvents;
}
function campRule(b,camp,roleUid){
 if(Number(camp)===3&&!roleUid)return b.campEvents?.find(x=>x.camp===3)||null;
 return b.campEvents?.find(x=>x.key===groupKey(Number(camp),roleUid))||null;
}
function addCampEvent(b,camp,type,roleUid){
 if(!own(eventCatalog,type))throw Error('请选择新增胜利事件，原胜利条件不能添加或修改。');
 ensureCampRules(b);const r=campRule(b,camp,roleUid);if(!r)throw Error('请先选择一个阵营。');
 if(r.events.length>=6)throw Error('每个阵营最多添加6个胜利事件。');
 if(r.events.some(x=>x.type===type))throw Error('这个事件已经添加，可直接修改目标数量。');
 const e={id:L.uid(),type,value:eventCatalog[type].defaultValue};r.events.push(e);return e;
}
function removeCampEvent(b,camp,id,roleUid){const r=campRule(b,camp,roleUid);if(!r)throw Error('找不到这个阵营。');r.events=r.events.filter(e=>e.id!==id);}
function eventSummary(e,camp){const d=eventCatalog[e.type];return d?d.name+' · '+e.value+' '+d.unit:'';}
function toCurrent(input,withMigration){
 const b=clone(input),oldRules=clone(b.factionRules||[]),previousRoleRules=b.roles.filter(L.isCustom).map(r=>({uid:r.uid,win:clone(r.win),loss:clone(r.loss)}));
 b.schema=SCHEMA;delete b.factionRules;delete b.drawPreview;b.campEvents=[];b.resolution=clone(RESOLUTION);
 for(const r of b.roles)if(L.isCustom(r)){r.win={mode:'camp',camp:r.camp};r.loss=defaultLoss();}
 ensureCampRules(b);
 if(withMigration)b.migration={...(b.migration||{}),from:input.schema,previousFactionRules:oldRules,previousRoleRules,notes:['已按阵营管理新增胜利事件，原职业胜利条件固定保留。','旧胜利方案完整保存在迁移备份中，没有自动扩大到整个阵营；请重新选择需要的原创事件。','中立角色各有独立阵营；同角色多份出场也分别累计、分别判胜。']};
 return b;
}
function defaultBoard(){return toCurrent(L.defaultBoard(),false);}
function makeCustomRole(b,camp=3){if(![1,2,3].includes(camp))throw Error('阵营无效。');const r=L.makeCustomRole(b&&b.factionRules?b:undefined,camp);r.win={mode:'camp',camp};r.loss=defaultLoss();return r;}
function setRoleCamp(b,r,camp){if(!L.isCustom(r))throw Error('已有职业的阵营固定，只能调整技能。');if(![1,2,3].includes(camp))throw Error('阵营无效。');r.camp=camp;r.win={mode:'camp',camp};ensureCampRules(b);}
function removeRole(b,uid){b.roles=b.roles.filter(r=>r.uid!==uid);ensureCampRules(b);}
function asLegacy(b){
 const flat=clone(b),defaults=L.defaultBoard();flat.schema=L.SCHEMA;flat.factionRules=defaults.factionRules;delete flat.campEvents;flat.resolution={tie:'shared',batch:'afterAllEffects'};
 for(const r of flat.roles)if(L.isCustom(r)){r.win={mode:'faction',ruleId:flat.factionRules.find(x=>x.camp===r.camp).id};r.loss=defaultLoss();}
 return flat;
}
function assertKeys(obj,keys,message){if(!obj||typeof obj!=='object'||Array.isArray(obj)||Object.keys(obj).some(k=>!keys.includes(k)))throw Error(message);}
function validateShape(input){
 if(!input||typeof input!=='object')throw Error('草稿格式不正确。');
 if(input.schema!==SCHEMA){
  if(!['goose-duck-board-draft/1','goose-duck-board-draft/1.1','goose-duck-board-draft/1.2',L.SCHEMA].includes(input.schema))throw Error('不支持的草稿版本。');
  return validateShape(toCurrent(L.validateShape(input),true));
 }
 const b=clone(input);if(own(b,'factionRules'))throw Error('旧职业胜利方案不能写入新版阵营设置。');
 if(!Array.isArray(b.roles)||!Array.isArray(b.campEvents))throw Error('角色或阵营列表不正确。');
 if(!equal(b.resolution,RESOLUTION))throw Error('新增事件必须先于原胜利条件判定，同批新增目标达成固定并列获胜。');
 for(const r of b.roles){
  if(L.isCustom(r)){if(!equal(r.win,{mode:'camp',camp:r.camp})||!equal(r.loss,defaultLoss()))throw Error('自创角色的胜利只绑定阵营，不能单独覆写。');}
  else {const c=L.careers.get(r.templateCareerId);if(!c)throw Error('未知职业。');const original=L.makeRole(c.id);if(r.camp!==c.camp||!equal(r.win,original.win)||!equal(r.loss,original.loss))throw Error('已有职业的阵营和原胜利条件不可编辑。');}
 }
 const expected=new Set(['camp-1','camp-2',...b.roles.filter(r=>r.camp===3).map(r=>'neutral-'+r.uid)]),keys=new Set(),eventIds=new Set();
 for(const r of b.campEvents){
  assertKeys(r,['key','camp','roleUid','join','events'],'阵营事件结构不正确。');
  if(![1,2,3].includes(r.camp)||r.key!==groupKey(r.camp,r.roleUid)||!expected.has(r.key)||keys.has(r.key)||r.camp!==3&&own(r,'roleUid'))throw Error('阵营事件绑定无效或重复。');
  keys.add(r.key);if(!['any','all'].includes(r.join)||!Array.isArray(r.events)||r.events.length>6)throw Error('每个阵营可添加最多6个事件，关系只能是任一或全部。');
  const types=new Set();for(const e of r.events){
   assertKeys(e,['id','type','value'],'新增事件不允许设置原条件、优先级或其他参数。');
   if(typeof e.id!=='string'||!e.id||e.id.length>80||eventIds.has(e.id)||!own(eventCatalog,e.type)||types.has(e.type)||!integer(e.value,1,999))throw Error('新增事件类型、目标数量或标识不正确。');
   eventIds.add(e.id);types.add(e.type);
  }
 }
 if(keys.size!==expected.size)throw Error('请为每个中立角色保留独立阵营设置。');
 const checked=L.validateShape(asLegacy(b));b.room=checked.room;b.selection=checked.selection;
 b.roles.forEach((r,i)=>{r.slots=checked.roles[i].slots;});delete b.drawPreview;return b;
}
function evaluateCamp(b,camp,progress={},options={}){
 const r=campRule(b,camp,options.roleUid),alive=options.alive!==false;
 if(!r)return {matched:false,checks:[],reason:'请先选择一个阵营。'};
 const checks=r.events.map(event=>({event,matched:integer(progress[event.type])&&progress[event.type]>=event.value}));
 const reached=checks.length>0&&(r.join==='all'?checks.every(x=>x.matched):checks.some(x=>x.matched));
 return {matched:alive&&reached,checks,groupKey:r.key,reason:!alive?'该阵营已无人存活，不触发新增胜利。':!checks.length?'未添加额外目标，保留原胜利条件。':reached?'新增目标已达成，先于原胜利条件结算。':'新增目标尚未达成，继续保留原胜利判定。'};
}
function checkProgress(p){
 if(p===undefined)return;
 if(!p||typeof p!=='object'||Array.isArray(p))throw Error('事件进度需要使用有效计数字段。');
 for(const key of Object.keys(eventCatalog))if(own(p,key)&&!integer(p[key]))throw Error('事件进度必须是0至100000之间的整数。');
}
function resolveVictory(b,state){
 const result=(source,reason,more={})=>({source,winners:[],matchedGroups:[],reason,...more});
 if(state?.finalized!==true)return result('pending','先处理完本批死亡、复活和救援，再统一判胜。');
 try{
  validateShape(b);
  if(!Array.isArray(state.seats)||!Array.isArray(state.aliveSeatIds)||!Array.isArray(state.originalWinners))throw Error('请提供完整出场名单、存活名单和原胜利结果。');
  const seatIds=new Set();for(const seat of state.seats){const r=b.roles.find(x=>x.uid===seat.roleUid);if(!r||typeof seat.uid!=='string'||!seat.uid||seatIds.has(seat.uid)||seat.camp!==r.camp)throw Error('出场席位与角色池不一致。');seatIds.add(seat.uid);}
  if(state.seats.length!==b.room.total||[1,2,3].some(c=>state.seats.filter(s=>s.camp===c).length!==b.room.counts[c]))throw Error('请先按本局人数完整抽取出场角色。');
  const lineupProblems=L.lineupIssues(b,state.seats);if(lineupProblems.length)throw Error(lineupProblems[0].text);
  if(state.aliveSeatIds.some(id=>!seatIds.has(id))||state.originalWinners.some(id=>!seatIds.has(id)))throw Error('判胜结果引用了未出场的玩家。');
  if(state.originalWinners.some(id=>{const seat=state.seats.find(s=>s.uid===id),role=b.roles.find(r=>r.uid===seat.roleUid);return seat.camp===3&&L.isCustom(role);}))throw Error('自创中立没有原胜利条件，只能通过自己的新增胜利事件获胜。');
  for(const table of [state.campProgress,state.playerProgress])if(table!==undefined&&(!table||typeof table!=='object'||Array.isArray(table)))throw Error('事件进度列表格式不正确。');
  for(const [id,p] of Object.entries(state.playerProgress||{})){if(!seatIds.has(id))throw Error('事件进度引用了未出场的玩家。');checkProgress(p);}
  for(const p of Object.values(state.campProgress||{}))checkProgress(p);
  const alive=new Set(state.aliveSeatIds),groups=[],checks=[];
  for(const camp of [1,2]){
   const seats=state.seats.filter(s=>s.camp===camp);if(!seats.length)continue;
   const p=clone(state.campProgress?.[camp]||{});
   // 连续会议数只能取仍存活成员的个人记录，不汇总队友次数。
   p.surviveMeetings=Math.max(0,...seats.filter(s=>alive.has(s.uid)).map(s=>state.playerProgress?.[s.uid]?.surviveMeetings||0));
   const verdict=evaluateCamp(b,camp,p,{alive:seats.some(s=>alive.has(s.uid))});checks.push({key:'camp-'+camp,camp,...verdict});
   if(verdict.matched)groups.push({key:'camp-'+camp,camp,eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:seats.map(s=>s.uid)});
  }
  for(const seat of state.seats.filter(s=>s.camp===3)){
   const verdict=evaluateCamp(b,3,state.playerProgress?.[seat.uid]||{},{alive:alive.has(seat.uid),roleUid:seat.roleUid});checks.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,...verdict});
   if(verdict.matched)groups.push({key:'seat-'+seat.uid,camp:3,seatId:seat.uid,ruleKey:groupKey(3,seat.roleUid),eventIds:verdict.checks.filter(x=>x.matched).map(x=>x.event.id),winners:[seat.uid]});
  }
  if(groups.length)return result('extra',groups.length>1?'同批多个独立阵营达成新增目标，并列获胜；本批原胜利条件不再执行。':'新增目标优先成立；本批原胜利条件不再执行。',{winners:[...new Set(groups.flatMap(g=>g.winners))],matchedGroups:groups,tie:groups.length>1,checks});
  if(state.originalWinners.length)return result('original','没有新增目标达成，按游戏运行时提供的原胜利结果结算。',{winners:[...new Set(state.originalWinners)],checks});
  return result('none','本批没有新增目标或原胜利结果成立，继续游戏。',{checks});
 }catch(e){return result('pending',e.message,{invalid:true});}
}
function validate(b,{checkPool=true}={}){
 try{validateShape(b);}catch(e){return [{level:'error',code:'SCHEMA',text:e.message}];}
 const out=L.validate(asLegacy(b),{checkPool:false}).filter(x=>!x.schemeId&&!['RUNTIME_BOUNDARY','RULE_FOLLOWERS','CAMP_PROGRESS','NEUTRAL_SHARED'].includes(x.code));
 const add=(level,code,text,r)=>out.push({level,code,text,camp:r.camp,roleUid:r.roleUid,groupKey:r.key});
 for(const r of b.campEvents){
  const active=b.room.counts[r.camp]>0,owner=r.camp===3?b.roles.find(x=>x.uid===r.roleUid):null;
  if(active&&owner&&L.isCustom(owner)&&!r.events.length)add('error','CUSTOM_NEUTRAL_NO_WIN',owner.name+'是新的独立阵营，请添加至少一个原创胜利事件。',r);
  // 多人团队可以互相报告、复活或救援，理论上能够覆盖全场；单人不能把自己计为操作目标。
  const targetCapacity=b.room.total-(r.camp===3||b.room.counts[r.camp]<2?1:0);
  const unreachable=r.events.map(e=>e.type==='kills'&&e.value>b.room.total-(r.camp===3?1:b.room.counts[r.camp])||['reports','revives','rescues'].includes(e.type)&&e.value>targetCapacity);
  if(unreachable.some(Boolean))add(active&&(r.join==='all'||unreachable.every(Boolean))?'error':'warn','EXTRA_UNREACHABLE',(owner?owner.name+'的独立阵营':L.camps[r.camp]+'阵营')+'的目标数量超过本局可计数的不同玩家数，请降低目标。',r);
  if(r.events.some(e=>['kills','revives','rescues'].includes(e.type)))add('info','EVENT_ABILITY','新增目标需要对应的击杀、复活或救援能力；请在技能页为可能出场的成员配置。',r);
 }
 for(const camp of [1,2])if(b.room.counts[camp]>0&&!b.room.counts[camp===1?2:1]&&b.roles.some(r=>r.camp===camp&&L.isCustom(r))&&!out.some(x=>['ORIGINAL_OPENING','ORIGINAL_DUCK_OPENING'].includes(x.code)))out.push({level:'error',code:'ORIGINAL_CAMP_OPENING',camp,text:L.camps[camp]+'阵营的原清场条件在开局已成立，请分配对方阵营席位。'});
 if(checkPool&&!out.some(x=>x.level==='error')){const draw=L.findLineup(b);if(!draw.ok)out.push({level:draw.status==='search-limit'?'warn':'error',code:'POOL_NO_COMBINATION',text:draw.status==='search-limit'?'组合较复杂，请试抽或减少互斥候选。':'候选池无法按本局人数组成合法一桌。'});}
 out.push({level:'info',code:'RUNTIME_BOUNDARY',text:'工坊提供配置、随机抽取和事件试算；原职业特殊判胜及有效事件统计仍需接入游戏运行时。'});return out;
}
function drawPool(b,seed){const errors=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(errors.length)throw Error('请先修正配置：'+errors[0].text);const d=L.findLineup(b,seed||L.uid());if(!d.ok)throw Error('本次未找到合法组合，请重抽或调整候选池。');return d;}
function poolExample(){const b=toCurrent(L.poolExample(),false);for(const r of b.roles.filter(r=>r.camp===3&&L.isCustom(r)))addCampEvent(b,3,'skillUses',r.uid);return b;}
function exportDraft(b){
 const clean=validateShape(b);clean.updatedAt=new Date().toISOString();clean.source={label:L.D.meta.label,tables:clone(L.D.meta.sourceFiles)};
 clean.integration={status:'prototype-only',proposedFields:['campEvents','roles[].win.camp','resolution.priority'],priority:'extraFirst',sameBatchExtra:'shared',neutralIdentity:'one-independent-faction-per-drawn-seat',requires:['原职业原判胜不可覆写；自创鹅/鸭沿用对应阵营基础判胜，自创中立须配置原创事件','新增事件仅按出场席位的阵营判定，鹅鸭全体成员共享，中立逐席位独立','本批全部后续效果处理完毕后，先检查所有新增目标；任何新增目标成立都不再执行本批原判胜','同批多个额外目标达成的阵营并列；未达标中立不会随其他中立获胜','击杀只统计不同敌对玩家，自杀和环境死亡不计，复活重复击杀不重复；报告/复活/救援分别按目标玩家去重','技能仅计成功主动施放，每次多段施放算一次；会议连续生存次数取仍存活成员个人值，死亡清零','原胜利结果由原游戏逻辑提供，编辑器不以简化算法冒充原职业特殊结算']};return clean;
}
const retired=()=>{throw Error('胜利事件已改为直接绑定阵营，请在“阵营与胜利”页添加。');};
root.EditorEngine={...L,SCHEMA,RESOLUTION,eventCatalog,campRule,ensureCampRules,addCampEvent,removeCampEvent,eventSummary,defaultBoard,makeCustomRole,setRoleCamp,removeRole,validateShape,validate,evaluateCamp,resolveVictory,drawPool,poolExample,exportDraft,
 addScheme:retired,removeScheme:retired,setSchemeMode:retired,setSchemePreset:retired,assignRule:retired,setWinMode:retired,setFixedWin:retired};
})(typeof window!=='undefined'?window:globalThis);
