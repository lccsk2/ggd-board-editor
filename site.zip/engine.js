
(function(root){
'use strict';
const D=root.CATALOG, clone=x=>JSON.parse(JSON.stringify(x));
const careers=new Map(D.career.map(x=>[x.id,x])), skills=new Map(D.skill.map(x=>[x.id,x])), subs=new Map(D.subskill.map(x=>[x.id,x]));
const camps={1:'鹅',2:'鸭',3:'中立'};
const ROOM_LIMITS=Object.freeze({min:5,max:15});
// Never fall back to the unrestricted raw skill table when scope metadata is missing.
const PHASE_ONE=D.phaseOne;
if(PHASE_ONE?.id!=='classic-only/v1'||!Array.isArray(PHASE_ONE.entries))throw Error('第一期经典技能白名单未加载，请重新加载编辑器。');
const classicCareerIds=new Set(PHASE_ONE.careerIds),classicSkillIds=new Set(PHASE_ONE.skillIds),scopeEntries=new Map(PHASE_ONE.entries.map(s=>[s.id,s]));
function skillScope(id){return scopeEntries.get(Number(id));}
// A reviewed release policy is required in addition to the classic-mode scope.
// Missing entries never fall back to unrestricted raw skills.
const SKILL_MOUNT_POLICY=D.skillMountPolicy;
if(SKILL_MOUNT_POLICY?.id!=='classic-mount/phase-1-v1'||!Array.isArray(SKILL_MOUNT_POLICY.entries)||!SKILL_MOUNT_POLICY.rawPolicies||typeof SKILL_MOUNT_POLICY.rawPolicies!=='object')throw Error('技能开放清单未加载，请重新加载编辑器。');
const mountEntries=new Map(),mountEntriesByRaw=new Map();
for(const entry of SKILL_MOUNT_POLICY.entries){
 if(!Number.isInteger(entry.id)||mountEntries.has(entry.id)||!Array.isArray(entry.skillIds)||!['active','passive'].includes(entry.type)||!['open','conditional','native-only'].includes(entry.status))throw Error('技能开放清单格式不正确，请重新加载编辑器。');
 mountEntries.set(entry.id,entry);
 for(const id of entry.skillIds){if(mountEntriesByRaw.has(Number(id)))throw Error('技能开放清单重复，请重新加载编辑器。');mountEntriesByRaw.set(Number(id),entry);}
}
function skillMountPolicy(id){
 id=Number(id);const entry=mountEntriesByRaw.get(id),raw=SKILL_MOUNT_POLICY.rawPolicies[id];
 if(!entry||!raw||!['open','conditional','native-only','context-only'].includes(raw.status))return null;
 return {...entry,...raw,id:entry.id,rawId:id,entryStatus:entry.status,mountStatus:raw.status,mountReason:raw.reason||entry.reason||''};
}
// Player abilities use skill IDs. Subskill IDs remain private stage references.
// Some complete abilities span multiple skill rows in the 1029 snapshot.
// Runtime actions belong to recipients/state transitions, not the caster's slots.
const SKILL_UNITS=[
 {id:25,name:'投放炸弹',members:[25],runtime:[3],des:'向一名玩家投放炸弹。持弹者可以继续传递，倒计时结束后爆炸。'},
 {id:61,name:'狙击',members:[61,62],runtime:[],des:'瞄准远处目标后开枪，击倒瞄准镜范围内的玩家；也可以收枪取消瞄准。'},
 {id:76,name:'击倒（渡鸦）',members:[76],runtime:[77,78]},
 {id:80,name:'梦境穿梭（渡鸦）',members:[80,79],runtime:[],des:'会议期间离开会议进入地图，并可返回会议。'},
 {id:92,name:'链接',members:[92],runtime:[93],des:'连接两名玩家，使他们同生共死。被链接者可以主动解除关系。'},
 {id:105,name:'梦境穿梭',members:[105,104],runtime:[],des:'会议期间进入地图自由行动，并可返回会议。'},
 {id:119,name:'追踪狙击',members:[119,120],runtime:[]}
];
const skillUnits=new Map();
for(const unit of SKILL_UNITS)for(const id of [...unit.members,...unit.runtime])skillUnits.set(id,unit);
// Equivalent alternatives are NOT bundles: one original row implements each ability.
// Keep native rows and overrides intact; only the player-facing identity is shared.
const SKILL_EQUIVALENTS=[
 {id:39,name:'报告',ids:[39,44,45],des:'发现被击倒玩家留下的鸡腿后，报告并发起会议。'},
 {id:2,name:'遁入',ids:[2,41],des:'使用地图中的通风口、盔甲等通道，进入或离开。'},
 {id:22,name:'击倒',ids:[13,22,33,51,107],des:'击倒一名可选中的玩家。'}
];
const skillEquivalents=new Map();
for(const group of SKILL_EQUIVALENTS)for(const id of group.ids)skillEquivalents.set(id,group);
function playerSkill(id){
 id=Number(id);const unit=skillUnits.get(id),primary=unit?.id||id,s=skills.get(primary),group=skillEquivalents.get(primary);
 if(!s)return null;
 const policy=mountEntriesByRaw.get(primary);
 return {...s,id:group?.id||primary,sourceId:primary,name:policy?.name||group?.name||unit?.name||skillScope(primary)?.displayName||s.name,des:policy?.description||group?.des||unit?.des||skillScope(primary)?.displayDescription||s.des,equivalentIds:group?.ids||[primary],memberIds:unit?.members||[primary],runtimeIds:unit?.runtime||[],module:policy?.module||skillScope(primary)?.module,mountStatus:policy?.status||'conditional',mountReason:policy?.reason||'暂未开放。'};
}
function equippedSkills(r,{type='all'}={}){
 const entries=slotEntries(r).flatMap(([slot,,ids])=>ids.map(id=>({slot,id}))),seen=new Set(),out=[];
 for(const entry of entries){const s=playerSkill(entry.id);if(!s||seen.has(s.id))continue;seen.add(s.id);
  if(type!=='all'&&(s.type===1?'passive':'active')!==type)continue;
  const primary=entries.find(x=>x.id===s.sourceId)||entry;
  out.push({...s,slot:primary.slot,complete:s.memberIds.every(id=>entries.some(x=>x.id===id)),hasRuntimeAction:s.runtimeIds.some(id=>entries.some(x=>x.id===id))});
 }return out;
}
function resetSkillParameters(r,id){const s=playerSkill(id);if(s)for(const key of [...s.memberIds,...s.runtimeIds,...s.equivalentIds])delete r.skillOverrides[key];}
function equivalentSkillIssues(r){
 const active=new Set(allIds(r));
 return SKILL_EQUIVALENTS.filter(g=>g.ids.filter(id=>active.has(id)).length>1).map(g=>({code:'SKILL_EQUIVALENT_DUPLICATE',text:'重复装备了「'+g.name+'」，请移除后只添加一次。'}));
}
function phaseOneIssues(r){
 const out=[];
 if(!isCustom(r)&&!classicCareerIds.has(r.templateCareerId))out.push({code:'CAREER_OUT_OF_SCOPE',text:r.name+' 不在第一期经典自定义职业白名单，旧配置已保留，请移出候选池。'});
 for(const id of new Set(allIds(r)))if(!classicSkillIds.has(Number(id))){const info=skillScope(id);out.push({code:'SKILL_OUT_OF_SCOPE',text:(skills.get(Number(id))?.name||'未知技能')+' #'+id+' 不在第一期经典技能池'+(info?.domain?'（'+info.domain+'）':'')+'，请移除后再抽取。'});}
 return out;
}
function librarySkills({search='',type='all',module='all'}={}){
 const q=String(search).trim().toLowerCase();
 return SKILL_MOUNT_POLICY.entries.filter(entry=>classicSkillIds.has(entry.id)&&skillScope(entry.id)?.inScope&&(type==='all'||entry.type===type)&&(module==='all'||entry.module===module)).map(entry=>{
  const s=playerSkill(entry.id);if(!s)return null;
  return {...s,name:entry.name,module:entry.module,mountStatus:entry.status,mountReason:entry.reason||'暂未开放。',defaultRawId:entry.defaultRawId};
 }).filter(s=>s&&(!q||[s.name,s.des,...(mountEntries.get(s.id)?.skillIds||[s.id]).map(String),...(mountEntries.get(s.id)?.skillIds||[s.id]).flatMap(id=>skillScope(id)?.sourceCareerIds||[]).map(id=>careers.get(id)?.name||'')].some(text=>String(text||'').toLowerCase().includes(q))));
}
// 技能兼容边界。这里的限制只针对编辑器可验证的死局风险：
// 候选池仍可放入多个候选，真正抽取席位时才按实际持有者数量检查上限。
const SKILL_COMPAT={
 families:{
  swallow:{label:'吞噬',ids:[31],maxHolders:1,reason:'本局暂只支持1名吞噬持有者，避免肚内玩家、释放与语音状态互相冲突。'},
  infection:{label:'感染',ids:[30,114],maxHolders:1,reason:'普通感染与强效感染按同一感染能力族计算，本局暂只支持1名实际持有者。'},
  possession:{label:'附身操控',ids:[97],maxHolders:1,reason:'本局暂只支持1名附身操控持有者，避免多来源控制权互相覆盖。'},
  superpower:{label:'超能力附身',ids:[75],maxHolders:1,reason:'本局暂只支持1名超能力持有者，避免延迟击杀与远程语音来源冲突。'},
  cupid:{label:'丘比特链接',ids:[92],maxHolders:1,reason:'本局暂只支持1名链接施法者；该施法者仍可建立多对关系。'}
 },
 // 这些技能会改变全局阶段、会议权限、判胜时刻或依赖动态上下文，暂不作为普通自由技能挂载。
 systemOnly:[32,34,55,79,80,81,90,99,129],
 contextOnly:[3,93],
 bundles:[
  {code:'SNIPER_PAIR',ids:[61,62],label:'狙击',message:'瞄准 #61 与开枪 #62 必须成组配置；添加其中一个时会自动补齐另一个。'},
  {code:'SKILL_BUNDLE',ids:[104,105],label:'清醒梦者出入梦',message:'入梦 #105 与出梦 #104 必须成套配置，避免进入地图后无法返回会议。'},
  {code:'SKILL_BUNDLE',ids:[80,79],label:'渡鸦梦境穿梭',message:'渡鸦入梦与返回会议必须完整保留。'},
  {code:'SKILL_BUNDLE',ids:[119,120],label:'追踪子弹',message:'追踪子弹 #119 与开枪 #120 必须成套配置。'}
 ],
 stateConflicts:[
  {ids:[18,75,97],label:'出窍／附身控制',message:'出窍 #18、超能力 #75、附身 #97 会争用视角、输入和声音控制，同一角色暂不能同时装备。'}
 ]
};
const skillFamilies=new Map(),skillBundles=new Map();
for(const [key,f] of Object.entries(SKILL_COMPAT.families))for(const id of f.ids)skillFamilies.set(id,{key,...f});
for(const b of SKILL_COMPAT.bundles)for(const id of b.ids)skillBundles.set(id,b);
const defs={
 eliminate:{name:'目标阵营全部出局',target:true}, ratio:{name:'本阵营人数达到目标阵营',target:true},
 tasks:{name:'鹅任务达到指定数量',value:true}, voted:{name:'本人被会议投票放逐'}, dead:{name:'本人已出局'}, sole:{name:'本人成为唯一存活者'},
 infection:{name:'感染全部其他存活玩家'}, bodies:{name:'累计消化尸体',value:true}, guesses:{name:'累计猜中身份',value:true},
 survive:{name:'本人存活且总存活不超过',value:true}, emergency:{name:'紧急任务超时'}, timer:{name:'对局时间达到（秒）',value:true}
};
const events={any:'任意相关事件处理后',deathBatch:'整批死亡处理后',meeting:'会议放逐处理后',task:'任务进度更新后',progress:'个人进度更新后',emergency:'紧急任务结算后',roundEnd:'对局结束时'};
let serial=0;
function uid(){return 'r-'+Date.now().toString(36)+'-'+(++serial);}
function rule(type='eliminate',targetCamp=2,value=1){return {type,targetCamp,value};}
function winDefault(c){return {mode:'original',join:'any',conditions:[rule('eliminate',c.camp===2?1:2)],event:'deathBatch',beneficiary:c.camp===3?'self':'camp',requireAlive:false,priority:c.camp===3?100:c.camp===2?30:20,reset:'never'};}
function makeRole(id){const c=careers.get(Number(id));if(!c)throw Error('未知职业');const slots={main_key:clone(c.main_key||[]).filter(Boolean),meeting_skill:clone(c.meeting_skill||[]).filter(Boolean),talent:clone(c.talent||[]).filter(Boolean)};for(let i=1;i<=10;i++)slots['assistant_key'+i]=c['assistant_key'+i]||0;
 return {uid:uid(),templateCareerId:c.id,name:c.name,camp:c.camp,count:1,slots,skillOverrides:{},win:winDefault(c),loss:{mode:'default',join:'any',conditions:[rule('dead')],event:'any',simultaneous:'manual'}};
}
function isCustom(r){return r.kind==='custom'&&r.templateCareerId===null;}
const fixedWinOptions=[1,101,...D.eligibleCareerIds.filter(id=>careers.get(id)?.camp===3)].map(id=>{const c=careers.get(id);return {id,name:id===1?'鹅阵营固定胜利':id===101?'鸭阵营固定胜利':c.name+'胜利',description:c.win_condition_des,sourceCamp:c.camp,beneficiary:c.camp===3?'self':'camp'};});
function fixedWin(r){return fixedWinOptions.find(x=>x.id===r.win.fixedCareerId);}
function setFixedWin(r,id){if(!isCustom(r)||!fixedWinOptions.some(x=>x.id===id))throw Error('请选择已有的固定胜利条件');r.win.fixedCareerId=id;r.win.mode='fixed';}
function setWinMode(r,mode){if(!['original','custom','fixed'].includes(mode)||isCustom(r)&&mode==='original'||!isCustom(r)&&mode==='fixed')throw Error('当前身份不支持此胜利模式');if(mode==='fixed'){setFixedWin(r,r.win.fixedCareerId||({1:1,2:101,3:201}[r.camp]));return;}r.win.mode=mode;}
function makeCustomRole(){const slots={main_key:[],meeting_skill:[],talent:[]};for(let i=1;i<=10;i++)slots['assistant_key'+i]=0;
 return {uid:uid(),kind:'custom',templateCareerId:null,name:'自创角色',camp:3,count:1,slots,skillOverrides:{},win:{mode:'custom',join:'any',conditions:[rule('sole')],event:'deathBatch',beneficiary:'self',requireAlive:true,priority:100,reset:'never'},loss:{mode:'default',join:'any',conditions:[rule('dead')],event:'any',simultaneous:'manual'}};
}
function defaultBoard(){return {schema:SCHEMA,selection:clone(SELECTION),boardName:'嘎嘎的周末实验室',description:'10人经典底板 · 自由换技能，创造你的新板子',source:{label:D.meta.label,tables:clone(D.meta.sourceFiles)},room:{total:10,counts:{1:6,2:2,3:2},rangeMode:'current',hit_cd:20,discuss_cd:45,vote_cd:45,task:30},roles:[1,2,4,6,10,21,101,106,201,202].map(makeRole),resolution:{tie:'manual',batch:'afterAllEffects'},updatedAt:new Date().toISOString()};}
function allIds(r){return [...r.slots.main_key,...Array.from({length:10},(_,i)=>r.slots['assistant_key'+(i+1)]),...r.slots.meeting_skill,...r.slots.talent].filter(Boolean);}
function slotEntries(r){return [['main_key','主键',r.slots.main_key],...Array.from({length:10},(_,i)=>['assistant_key'+(i+1),'副键 '+(i+1),[r.slots['assistant_key'+(i+1)]].filter(Boolean)]),['meeting_skill','会议',r.slots.meeting_skill],['talent','天赋',r.slots.talent]];}
function nativeSkillIds(r){const c=careers.get(r?.templateCareerId);if(!c)return new Set();return new Set([...(c.main_key||[]),...(c.meeting_skill||[]),...(c.talent||[]),...Array.from({length:10},(_,i)=>c['assistant_key'+(i+1)]||0)].filter(Boolean));}
function isNativeSkill(r,id){return nativeSkillIds(r).has(Number(id));}
function resolveSkillRawId(id,r){
 id=Number(id);const group=skillEquivalents.get(id),entry=mountEntries.get(id);
 // Only a canonical library request selects an implementation. Explicit raw
 // requests retain their identity so protected variants cannot gain permission.
 if(group&&id===group.id){const native=group.ids.find(key=>isNativeSkill(r,key));if(native!==undefined)return native;}
 return entry&&Number.isInteger(entry.defaultRawId)&&entry.skillIds.includes(entry.defaultRawId)?entry.defaultRawId:id;
}
function skillMountIssue(r,id){
 id=Number(id);const name=skills.get(id)?.name||'技能';
 if(!classicSkillIds.has(id)||!skillScope(id)?.inScope)return {code:'SKILL_OUT_OF_SCOPE',skillId:id,text:name+' #'+id+' 不属于第一期经典技能池，请移除。'};
 const policy=skillMountPolicy(id);
 if(!policy)return {code:'SKILL_RELEASE_MISSING',skillId:id,text:name+' #'+id+' 没有有效的开放记录，暂不可添加。'};
 if(isNativeSkill(r,id)||policy.mountStatus==='open')return null;
 const code=policy.mountStatus==='context-only'?'SKILL_CONTEXT_ONLY':policy.mountStatus==='native-only'?'SKILL_NATIVE_ONLY':'SKILL_NOT_RELEASED';
 return {code,skillId:id,text:(policy.name||name)+' #'+id+'：'+(policy.mountReason||'暂未开放自由搭配，请移除后继续。')};
}
function roleSkillFamilies(r){const out=new Set();for(const id of allIds(r)){const f=skillFamilies.get(Number(id));if(f)out.add(f.key);}return [...out];}
function skillCompatibility(id,r,{raw=false}={}){
 const requestedId=Number(id);id=raw?requestedId:resolveSkillRawId(requestedId,r);
 if(!skills.has(id))return {level:'error',code:'SKILL_MISSING',short:'未知技能',text:'未知技能。',skillId:id};
 const group=skillEquivalents.get(id);
 if(allIds(r).includes(id)||group&&allIds(r).some(key=>group.ids.includes(key)))return {level:'equipped',code:'SKILL_EQUIPPED',short:'已装备',text:'该角色已经装备此技能。',skillId:id};
 const issue=skillMountIssue(r,id);
 if(issue){const policy=skillMountPolicy(id),short=issue.code==='SKILL_NOT_RELEASED'?'后续开放':issue.code==='SKILL_NATIVE_ONLY'?'暂不可自由搭配':issue.code==='SKILL_CONTEXT_ONLY'?'需在对局中触发':issue.code==='SKILL_OUT_OF_SCOPE'?'不属于第一期经典技能':'暂未开放';return {level:'error',...issue,short,text:issue.text,mountStatus:policy?.mountStatus||'conditional',mountReason:policy?.mountReason||issue.text};}
 const family=skillFamilies.get(id);
 if(family&&roleSkillFamilies(r).includes(family.key))return {level:'error',code:'SKILL_FAMILY_CONFLICT',short:'同一能力只能选一个版本',text:family.label+'能力同一角色只能选择一个版本。',skillId:id};
 for(const conflict of SKILL_COMPAT.stateConflicts)if(conflict.ids.includes(id)&&conflict.ids.some(x=>allIds(r).includes(x)))return {level:'error',code:'SKILL_STATE_DEADLOCK',short:'会争用控制状态',text:conflict.message,skillId:id};
 const bundle=skillBundles.get(id),missing=bundle?bundle.ids.filter(x=>x!==id&&!allIds(r).includes(x)):[];
 return {level:'available',code:missing.length?'SKILL_BUNDLE':'',short:missing.length?'会自动补齐配套技能':'可添加',text:missing.length?bundle.message:'技能可以添加。',bundle:bundle?.ids||[],missing,skillId:id,requestedId};
}
function addToSlot(r,id,slot){const s=skills.get(id);if(!slot||!Object.prototype.hasOwnProperty.call(r.slots,slot))throw Error('没有可用槽位，请先移除技能或选择其他位置');if(Array.isArray(r.slots[slot]))r.slots[slot].push(id);else if(r.slots[slot]===0)r.slots[slot]=id;else throw Error('该槽位已有技能，请先移除');return slot;}
function autoSlot(r,id){const s=skills.get(id);return s.type===1?'talent':s.skill_kind===0?'meeting_skill':Array.from({length:10},(_,i)=>'assistant_key'+(i+1)).find(x=>!r.slots[x]);}
function addSkill(r,id,slot='auto',{raw=false}={}){
 id=raw?Number(id):resolveSkillRawId(Number(id),r);if(!skills.has(id))throw Error('未知技能');if(allIds(r).includes(id))throw Error('该角色已装备此技能');
 const compat=skillCompatibility(id,r,{raw:true});if(compat.level==='equipped')throw Error('该角色已装备此技能');if(compat.level==='error')throw Error(`${compat.code}: ${compat.text}`);
 const bundle=skillBundles.get(id),missing=bundle?bundle.ids.filter(x=>x!==id&&!allIds(r).includes(x)):[];
 for(const companion of missing){const check=skillCompatibility(companion,r,{raw:true});if(check.level==='error')throw Error(`${check.code}: ${check.text}`);}
 const placements=[];let requested=slot||'auto';const primary=requested==='auto'?autoSlot(r,id):requested;if(!primary)throw Error('10个副键已满，请移除技能或选择主键');placements.push([id,primary]);
 const reserved=new Set([primary]);for(const companion of missing){const place=autoSlot({...r,slots:{...r.slots,...Object.fromEntries([...reserved].filter(k=>k.startsWith('assistant_key')).map(k=>[k,1]))}},companion);if(!place||reserved.has(place)&&!Array.isArray(r.slots[place]))throw Error(`${bundle.label}缺少可用槽位，请先移除技能或选择其他位置`);placements.push([companion,place]);reserved.add(place);}
 for(const [skillId,target] of placements)addToSlot(r,skillId,target);
 return primary;
}
function compatibilityIssues(r){
 const active=allIds(r),issues=[...phaseOneIssues(r),...equivalentSkillIssues(r)],seen=new Set();
 const add=(code,text,skillId)=>{const key=code+'|'+text;if(!seen.has(key)){seen.add(key);issues.push({code,text,...(skillId===undefined?{}:{skillId})});}};
 for(const id of new Set(active)){const issue=skillMountIssue(r,id);if(issue&&issue.code!=='SKILL_OUT_OF_SCOPE')add(issue.code,issue.text,issue.skillId);}
 for(const bundle of SKILL_COMPAT.bundles){const present=bundle.ids.filter(id=>active.includes(id));if(present.length&&present.length!==bundle.ids.length)add(bundle.code,bundle.label+'需要成组配置：'+bundle.ids.map(id=>'#'+id).join(' + ')+'。');}
 for(const family of Object.values(SKILL_COMPAT.families)){const present=family.ids.filter(id=>active.includes(id));if(present.length>1)add('SKILL_FAMILY_CONFLICT','同一角色同时装备了'+family.label+'能力的多个版本，请只保留一个。');}
 for(const group of SKILL_COMPAT.stateConflicts)if(group.ids.filter(id=>active.includes(id)).length>1)add('SKILL_STATE_DEADLOCK',group.message);
 return issues;
}
function removeSkill(r,id,slot){
 const s=playerSkill(id),remove=new Set(s?[...s.memberIds,...s.runtimeIds,...s.equivalentIds]:[Number(id)]);
 for(const [key] of slotEntries(r))if(Array.isArray(r.slots[key]))r.slots[key]=r.slots[key].filter(x=>!remove.has(x));else if(remove.has(r.slots[key]))r.slots[key]=0;
 for(const key of remove)delete r.skillOverrides[key];
}
function effective(r,id){const s=clone(skills.get(id)),o=r.skillOverrides[id]||{};for(const k of ['get_cd','use_time','meeting_use_time'])if(o[k]!==undefined)s[k]=o[k];s.stages=[s.stage1,s.stage2,s.stage3].filter(Boolean).map(id=>({...clone(subs.get(id)),...(o.stages?.[id]||{})}));return s;}
function modified(r){if(isCustom(r))return true;const c=careers.get(r.templateCareerId);return r.camp!==c.camp||r.name!==c.name||JSON.stringify(slotEntries(r).map(([k,,v])=>[k,v]))!==JSON.stringify(slotEntries(makeComparable(c)).map(([k,,v])=>[k,v]))||Object.keys(r.skillOverrides).length>0||r.win.mode==='custom'||r.loss?.mode==='custom';}
function makeComparable(c){return {slots:{main_key:(c.main_key||[]).filter(Boolean),meeting_skill:(c.meeting_skill||[]).filter(Boolean),talent:(c.talent||[]).filter(Boolean),...Object.fromEntries(Array.from({length:10},(_,i)=>['assistant_key'+(i+1),c['assistant_key'+(i+1)]||0]))}};}
function validate(b,{checkPool=true}={}){const out=[];const add=(level,code,text,uid)=>out.push({level,code,text,uid});const sum=Object.values(b.room.counts).reduce((a,n)=>a+n,0);if(sum!==b.room.total)add('error','CAMP_SUM',`阵营人数合计 ${sum}，与房间 ${b.room.total} 人不一致。`);
 if(!Number.isInteger(b.room.total)||b.room.total<ROOM_LIMITS.min||b.room.total>ROOM_LIMITS.max)add('error','TOTAL_RANGE',`房间总人数需要在 ${ROOM_LIMITS.min}–${ROOM_LIMITS.max} 人之间。`);
 for(const c of [1,2,3])if(!Number.isInteger(b.room.counts[c])||b.room.counts[c]<0||b.room.counts[c]>ROOM_LIMITS.max)add('error','CAMP_COUNT',`${camps[c]}阵营人数需要在 0–${ROOM_LIMITS.max} 人之间。`);
 for(const c of [1,2,3]){const p=poolStats(b,c);if(p.capacity<p.seats)add('error','POOL_CAPACITY',`${camps[c]}阵营需要抽取 ${p.seats} 人，候选池有效容量仅 ${p.capacity} 席，请增加候选或提高允许重复角色的单局上限。`);if(!p.seats&&p.candidates)add('info','POOL_INACTIVE',`${camps[c]}阵营本局0人，池内 ${p.candidates} 个候选保留但不参与抽取。`);}
 for(const k of ['hit_cd','discuss_cd','vote_cd','task']){const range=D.custom[0][k];if(b.room[k]<range[0]||b.room[k]>range[1])add('error','ROOM_PARAM',`${k} 应在 ${range[0]}–${range[1]} 范围内。`);}
 if(!b.roles.length)add('error','EMPTY','至少添加一个角色。');
 out.push(...neutralRoleIssues(b));
 const ids=new Set(b.roles.map(r=>r.templateCareerId));
 if([...ids].some(id=>[...(repels.get(id)||[])].some(x=>ids.has(x))||id===206))add('info','POOL_CONSTRAINTS','池中候选可以互斥；抽取结果会遵守原职业互斥、依赖、中立职业唯一要求。');
 for(const r of b.roles)for(const issue of [...phaseOneIssues(r),...equivalentSkillIssues(r),...[...new Set(allIds(r))].map(id=>skillMountIssue(r,id)).filter(issue=>issue&&issue.code!=='SKILL_OUT_OF_SCOPE')])add('error',issue.code,r.name+'：'+issue.text,r.uid);
 for(const r of b.roles){if(!b.room.counts[r.camp])continue;const c=careers.get(r.templateCareerId),active=allIds(r);
  if(c){
  if(!isUniqueNeutral(r)&&r.count>careerLimit(r))add('warn','COPY_CAP',`${r.name} 的单局上限仍受原职业复数限制，实际最多出现 ${careerLimit(r)} 人。`,r.uid);
  if(!D.eligibleCareerIds.includes(c.id))add('warn','CAREER_POOL',`${r.name} 的原职业不在本次经典自定义角色池，请检查模式、扩展包和角色可用性。`,r.uid);
  if(r.camp!==c.camp)add('warn','CAMP_OVERRIDE',`${r.name} 改换了阵营；技能目标与身份机制不会自动改写。`,r.uid);
  if(r.win.mode==='original'&&r.camp!==c.camp)add('error','WIN_CAMP',`${r.name} 已换阵营，请同时配置自定义胜利条件。`,r.uid);
  }else if(!isCustom(r)||!['custom','fixed'].includes(r.win.mode))add('error','CUSTOM_IDENTITY',`${r.name} 的自创身份或胜利规则不正确。`,r.uid);
  if(r.win.mode==='fixed'){
   const f=fixedWin(r);if(!isCustom(r)||!f)add('error','FIXED_WIN',`${r.name} 的固定胜利条件无效。`,r.uid);
   else{add('info','FIXED_RUNTIME',`${r.name} 采用「${f.name}」；仅引用胜利判定，不继承该职业的身份和技能。`,r.uid);
    if(f.sourceCamp!==r.camp)add('warn','FIXED_CAMP',`${r.name} 的固定条件来源于${camps[f.sourceCamp]}阵营，当前归属${camps[r.camp]}；目标仍按固定条件，获胜归属为${f.beneficiary==='self'?'仅本人':'当前归属阵营共享'}。`,r.uid);
    if(f.id===1&&!b.room.counts[2]||f.id===101&&!b.room.counts[1])add('error','FIXED_OPENING',`${r.name} 的固定胜利条件目标阵营无人，会在开局满足淘汰目标。`,r.uid);
    if([202,205,206,210].includes(f.id))add('warn','FIXED_DEPENDENCY',`${f.name} 需要对应的进度或角色关系；选择条件不会自动挂载技能，原版阈值及特殊结算需游戏运行时接入。`,r.uid);
   }
  }
  if(active.some(id=>!skills.has(id)))add('error','SKILL_MISSING',`${r.name} 引用了不存在的技能。`,r.uid);
  if(new Set(active).size!==active.length)add('error','SKILL_DUPLICATE',`${r.name} 重复装备了同一技能。`,r.uid);
  for(const bundle of SKILL_COMPAT.bundles){const present=bundle.ids.filter(id=>active.includes(id));if(present.length&&present.length!==bundle.ids.length)add('error',bundle.code,`${r.name} 的${bundle.label}需要成组配置：${bundle.ids.map(id=>'#'+id).join(' + ')}。`,r.uid);}
  for(const family of Object.values(SKILL_COMPAT.families)){const present=family.ids.filter(id=>active.includes(id));if(present.length>1)add('error','SKILL_FAMILY_CONFLICT',`${r.name} 同时装备了${family.label}能力的多个版本，请只保留一个。`,r.uid);}
  for(const group of SKILL_COMPAT.stateConflicts){if(group.ids.filter(id=>active.includes(id)).length>1)add('error','SKILL_STATE_DEADLOCK',`${r.name} 同时装备${group.ids.map(id=>skills.get(id)?.name||('#'+id)).join('、')}，这些技能会争用同一控制状态。`,r.uid);}
  if(slotEntries(r).filter(([k,,v])=>k.startsWith('assistant')&&v.length).length>4)add('warn','SLOT_LAYOUT',`${r.name} 超过 4 个副键；配置有 10 个字段，动态按钮布局需验证。`,r.uid);
  for(const [slot,,arr] of slotEntries(r))for(const id of arr){const s=skills.get(id);if(!s)continue;if(s.type===1?slot!=='talent':slot==='talent'||(s.skill_kind===0?slot!=='meeting_skill':slot==='meeting_skill')){const native=c&&slotEntries(makeComparable(c)).some(([k,,ids])=>k===slot&&ids.includes(id));add(native?'warn':'error','SKILL_SLOT',native?`${r.name} 的原配置将 ${s.name} #${id} 挂在 ${slot}，与技能类型标记不一致；原始绑定已保留。`:`${r.name} 的 ${s.name} #${id} 与 ${slot} 槽位类型不符。`,r.uid);}
   const e=effective(r,id);if(e.get_cd<0||e.use_time< -1||e.meeting_use_time< -1)add('error','SKILL_PARAM',`${r.name} 的 ${s.name} 参数不合法。`,r.uid);
   for(const st of e.stages){const negative=['meeting_cd','cd_type_param_1','cd_type_param_2','cd_type_param_3','cd_type_param_4'].filter(k=>st[k]<0);if(negative.length){const inherited=negative.every(k=>st[k]===subs.get(st.id)?.[k]&&r.skillOverrides[id]?.stages?.[st.id]?.[k]===undefined);add(inherited?'warn':'error','CD_PARAM',inherited?`${r.name} 的 ${s.name} 原配置含负值冷却参数，已保留；运行含义需联调确认。`:`${r.name} 的 ${s.name} 分段冷却覆写不能为负。`,r.uid);}}
  }
  if(modified(r))add('warn','ABILITY_COMPAT',isCustom(r)?`${r.name} 为独立自创身份；所挂技能的状态及跨阵营兼容性需联调。`:`${r.name} 有自定义改动：原身份专属机制、状态矩阵及技能跨阵营兼容性需联调。`,r.uid);
  if(r.win.mode==='custom'){
   const w=r.win;if(!w.conditions.length)add('error','EMPTY_WIN',`${r.name} 没有胜利条件。`,r.uid);
   if(r.camp===3&&w.beneficiary==='camp')add('warn','NEUTRAL_SHARED',`${r.name} 选择中立阵营共享获胜，改变了原版中立各自结算规则。`,r.uid);
   if(w.join==='all'&&w.conditions.some(x=>['voted','dead'].includes(x.type))&&w.requireAlive||w.join==='any'&&w.conditions.length>0&&w.conditions.every(x=>['voted','dead'].includes(x.type))&&w.requireAlive)add('error','WIN_UNREACHABLE',`${r.name} 的出局类胜利条件与“结算时需存活”不能同时成立。`,r.uid);
   if(w.join==='all'&&w.conditions.some(x=>x.type==='voted')&&w.conditions.some(x=>['sole','survive'].includes(x.type)))add('error','WIN_CONTRADICTION',`${r.name} 的被放逐与存活类条件无法同时成立。`,r.uid);
   const requiredEvent={voted:'meeting',tasks:'task',infection:'progress',bodies:'progress',guesses:'progress',emergency:'emergency',timer:'roundEnd'};
   for(const x of w.conditions){if(x.targetCamp===r.camp&&['eliminate','ratio'].includes(x.type))add('warn','SELF_TARGET',`${r.name} 的目标是自身阵营，请确认设计意图。`,r.uid);
    if(defs[x.type]?.target&&!b.room.counts[x.targetCamp])add('error','NO_TARGET',`${r.name} 的目标阵营没有玩家，条件会在开局直接满足。`,r.uid);
    if(defs[x.type]?.value&&x.value<=0)add('error','ZERO_THRESHOLD',`${r.name} 的胜利阈值必须大于 0。`,r.uid);
    if(x.type==='tasks'&&x.value>b.room.task)add('error','TASK_THRESHOLD',`${r.name} 的任务阈值超过房间总任务数。`,r.uid);
    if(x.type==='infection'&&!active.includes(30)&&!active.includes(113))add('warn','INFECT_SKILL',`${r.name} 使用感染胜利条件，请确认拥有对应感染能力及事件来源。`,r.uid);
    if(x.type==='bodies'&&!active.includes(35))add('warn','BODY_SKILL',`${r.name} 使用消化胜利条件，请确认对应的消化能力。`,r.uid);
    if(w.event!=='any'&&requiredEvent[x.type]&&requiredEvent[x.type]!==w.event)add('warn','EVENT_TIMING',`${r.name} 的“${defs[x.type].name}”仅在“${events[w.event]}”检查，可能延迟或错过触发。`,r.uid);
   }
   const opening={event:w.event,alive:{...b.room.counts},actorAlive:true,votedUid:'',tasks:0,infected:0,bodies:0,guesses:0,seconds:0,emergency:false,finalized:true};
   if(evaluate(r,b,opening).matched)add('error','OPENING_WIN',`${r.name} 的自定义条件在开局状态已满足。`,r.uid);
  }
  if(r.loss?.mode==='custom'){
   const l=r.loss;if(!l.conditions.length)add('error','EMPTY_LOSS',`${r.name} 开启自定义失败却没有条件。`,r.uid);
   if(l.conditions.some(x=>defs[x.type].value&&x.value<=0))add('error','LOSS_THRESHOLD',`${r.name} 的失败阈值必须大于0。`,r.uid);
   const opening={event:l.event,alive:{...b.room.counts},actorAlive:true,votedUid:'',tasks:0,infected:0,bodies:0,guesses:0,seconds:0,emergency:false,finalized:true};
   if(lossResult(r,b,opening).matched)add('error','OPENING_LOSS',`${r.name} 的自定义失败条件在开局状态已经满足。`,r.uid);
   if(r.win.mode==='custom'&&JSON.stringify(r.win.conditions)===JSON.stringify(l.conditions)&&r.win.join===l.join&&(r.win.event===l.event||r.win.event==='any'||l.event==='any'))add('warn','WIN_LOSS_CONFLICT',`${r.name} 的胜负条件相同，触发时会按所选冲突策略处理。`,r.uid);
  }
 }
 if(b.room.counts[1]>0&&b.roles.some(r=>r.win.mode==='original'&&r.camp===1)&&!b.room.counts[2])add('error','ORIGINAL_OPENING','原版鹅胜利依赖鸭阵营，请配置鸭或改写胜利条件。');
 if(checkPool&&!out.some(x=>x.level==='error')){const plan=findLineup(b);if(!plan.ok){const skillLimited=plan.status==='skill-cap';add(plan.status==='search-limit'?'warn':'error',skillLimited?'SKILL_FAMILY_POOL':plan.status==='search-limit'?'POOL_SEARCH_LIMIT':'POOL_NO_COMBINATION',skillLimited?'候选数量虽然足够，但本局实际抽取的技能持有者会超过安全上限；请增加不带该技能的候选，或降低带该技能角色的单局上限。':plan.status==='search-limit'?'组合较复杂，暂未确认可用一桌；请尝试随机抽取或精简互斥候选。':'候选容量足够，但互斥、依赖、技能配套或复数限制使当前人数无法组成合法一桌。');}}
 add('info','RUNTIME_BOUNDARY','静态检查覆盖人数、已知互斥、依赖及基础可达性；不能证明组合平衡或游戏运行逻辑已兼容。');return out;
}
function conditionMatch(x,r,b,s){const alive=Object.values(s.alive).reduce((n,x)=>n+x,0);switch(x.type){case 'eliminate':return s.alive[x.targetCamp]===0;case 'ratio':return s.alive[r.camp]>0&&s.alive[r.camp]>=s.alive[x.targetCamp];case 'tasks':return s.tasks>=x.value;case 'voted':return s.votedUid===r.uid&&!s.actorAlive;case 'dead':return !s.actorAlive;case 'sole':return s.actorAlive&&alive===1;case 'infection':return s.actorAlive&&alive>1&&s.infected>=alive-1;case 'bodies':return s.bodies>=x.value;case 'guesses':return s.guesses>=x.value;case 'survive':return s.actorAlive&&alive>0&&alive<=x.value;case 'emergency':return s.emergency;case 'timer':return s.seconds>=x.value;default:return false;}}
function lossResult(r,b,s){const l=r.loss;if(!l||l.mode!=='custom')return {matched:false,checks:[]};const checks=l.conditions.map(c=>({condition:c,matched:conditionMatch(c,r,b,s)}));return {matched:s.finalized&&(l.event==='any'||l.event===s.event)&&checks.length>0&&(l.join==='all'?checks.every(x=>x.matched):checks.some(x=>x.matched)),checks};}
function evaluate(r,b,s){const w=r.win;if(!s.finalized)return {matched:false,reason:'请先确认整批死亡与复活／释放效果已处理完成。',checks:[]};
 const loss=lossResult(r,b,s);
 if(w.mode==='fixed'){const f=fixedWin(r);return {matched:false,defeated:loss.matched,unsupported:true,reason:f?`已选择「${f.name}」：${f.description}。固定条件由游戏运行时判定，本试算台不把自定义草稿当作固定条件执行。${loss.matched?'已触发独立失败条件。':''}`:'固定胜利条件无效。',checks:[],lossChecks:loss.checks,fixedCareerId:w.fixedCareerId,beneficiary:f?.beneficiary};}
 if(w.mode==='original')return {matched:false,defeated:loss.matched,unsupported:true,reason:loss.matched?'已触发新增失败条件；原职业胜利结算仍依赖游戏运行时。':'原职业结算沿用游戏运行时；此处只演算自定义规则，避免把简化逻辑当作原版。',checks:[],lossChecks:loss.checks};
 const checks=w.conditions.map(c=>({condition:c,matched:conditionMatch(c,r,b,s)}));const ok=checks.length>0&&(w.join==='all'?checks.every(x=>x.matched):checks.some(x=>x.matched));const phase=w.event==='any'||w.event===s.event,alive=!w.requireAlive||s.actorAlive;let matched=ok&&phase&&alive,defeated=loss.matched,conflict=false;
 if(matched&&defeated){if(r.loss.simultaneous==='winFirst')defeated=false;else if(r.loss.simultaneous==='lossFirst')matched=false;else{matched=false;defeated=false;conflict=true;}}
 return {matched,defeated,conflict,checks,lossChecks:loss.checks,reason:conflict?'胜负条件同时成立，需要裁决。':defeated?'触发自定义失败条件。':!phase?'未到配置的结算时机':!alive?'结算时本人需要存活':matched?'满足本条自定义胜利规则':'尚未满足条件',priority:w.priority,beneficiary:w.beneficiary};}
function validateShape(input){const x=input&&typeof input==='object'?clone(input):input;if(!x||![D.meta.schema,'goose-duck-board-draft/1.1',SCHEMA].includes(x.schema))throw Error('不支持的草稿格式／版本');if(x.selection&&(x.selection.mode!==SELECTION.mode||x.selection.algorithm!==SELECTION.algorithm||x.selection.roleCountMeaning!==SELECTION.roleCountMeaning))throw Error('不支持的角色抽取规则');x.schema=SCHEMA;x.selection=clone(SELECTION);delete x.drawPreview;const num=(v,min,max)=>typeof v==='number'&&Number.isFinite(v)&&Number.isInteger(v)&&v>=min&&v<=max;
 const text=(v,max)=>typeof v==='string'&&v.length<=max;
 if(!text(x.boardName,40)||!x.boardName.trim()||!text(x.description,300))throw Error('板子名称或介绍格式不正确');
 // Keep older 16–24-player drafts editable; validate() blocks play until corrected.
 if(!x.room||!num(x.room.total,2,24)||!['current','experiment'].includes(x.room.rangeMode)||![1,2,3].every(c=>num(x.room.counts?.[c],0,24))||Object.keys(x.room.counts).sort().join(',')!=='1,2,3')throw Error('房间人数格式不正确');
 for(const k of ['hit_cd','discuss_cd','vote_cd','task'])if(!num(x.room[k],0,10000))throw Error('房间参数格式不正确');
 if(!Array.isArray(x.roles)||x.roles.length>MAX_POOL_ROLES)throw Error('角色清单格式不正确');const uids=new Set();
 for(const r of x.roles){if(!text(r.uid,80)||uids.has(r.uid)||!(isCustom(r)||careers.has(r.templateCareerId)&&(!r.kind||r.kind==='template'))||!text(r.name,20)||!r.name.trim()||![1,2,3].includes(r.camp)||!num(r.count,1,24))throw Error('角色标识、人数或名称不正确');uids.add(r.uid);
  if(r.slots)for(const k of ['main_key','meeting_skill','talent'])if(Array.isArray(r.slots[k]))r.slots[k]=r.slots[k].filter(id=>id!==0);
  if(!r.slots||!['main_key','meeting_skill','talent'].every(k=>Array.isArray(r.slots[k])&&r.slots[k].length<=30&&r.slots[k].every(id=>skills.has(id))))throw Error('技能列表不正确');
  for(let i=1;i<=10;i++)if(r.slots['assistant_key'+i]!==0&&!skills.has(r.slots['assistant_key'+i]))throw Error('副键技能不存在');
  if(!r.loss)r.loss={mode:'default',join:'any',conditions:[rule('dead')],event:'any',simultaneous:'manual'};
  const l=r.loss;if(!['default','custom'].includes(l.mode)||!['all','any'].includes(l.join)||!events[l.event]||!['manual','winFirst','lossFirst'].includes(l.simultaneous)||!Array.isArray(l.conditions)||l.conditions.length>12)throw Error('失败规则结构不正确');
  for(const c of l.conditions)if(!defs[c.type]||!num(c.value,0,100000)||![1,2,3].includes(c.targetCamp))throw Error('失败条件格式不正确');
  const w=r.win;if(isCustom(r)&&!['custom','fixed'].includes(w?.mode))throw Error('自创角色请选择固定条件或自定义规则');if(w?.mode==='fixed'&&(!isCustom(r)||!fixedWin(r)))throw Error('固定胜利条件不正确');if(w?.fixedCareerId!==undefined&&(!isCustom(r)||!fixedWin(r)))throw Error('固定胜利条件来源无效');if(!w||!['original','custom','fixed'].includes(w.mode)||!['all','any'].includes(w.join)||!events[w.event]||!['self','camp'].includes(w.beneficiary)||!num(w.priority,0,999)||typeof w.requireAlive!=='boolean'||!['never','meeting'].includes(w.reset)||!Array.isArray(w.conditions)||w.conditions.length>12)throw Error('胜利规则结构不正确');
  for(const c of w.conditions)if(!defs[c.type]||!num(c.value,0,100000)||![1,2,3].includes(c.targetCamp))throw Error('胜利条件格式不正确');
  if(!r.skillOverrides||typeof r.skillOverrides!=='object'||Array.isArray(r.skillOverrides))throw Error('技能覆写格式不正确');
  for(const [id,o] of Object.entries(r.skillOverrides)){if(!allIds(r).includes(+id)||!o||typeof o!=='object')throw Error('存在未装备技能的参数覆写');for(const k of Object.keys(o)){if(k==='stages'){if(!o.stages||typeof o.stages!=='object')throw Error('分段参数格式不正确');for(const [st,values] of Object.entries(o.stages)){if(![skills.get(+id).stage1,skills.get(+id).stage2,skills.get(+id).stage3].includes(+st)||!values||typeof values!=='object')throw Error('子技能关联不正确');for(const [key,val] of Object.entries(values))if(!['meeting_cd','cd_type_param_1','cd_type_param_2','cd_type_param_3','cd_type_param_4'].includes(key)||!num(val,0,100000))throw Error('子技能覆写字段不正确');}}
    else if(!['get_cd','use_time','meeting_use_time'].includes(k)||!num(o[k],k==='get_cd'?0:-1,100000))throw Error('技能参数字段不正确');}
  }
 }
 if(!x.resolution||!['manual','shared'].includes(x.resolution.tie)||x.resolution.batch!=='afterAllEffects')throw Error('结算设置不正确');return clone(x);
}
function exportDraft(b){const clean=validateShape(b);clean.updatedAt=new Date().toISOString();clean.source={label:D.meta.label,tables:clone(D.meta.sourceFiles)};clean.integration={status:'prototype-only',proposedFields:['selection','roles[].count（单局上限）','roles[].kind','roles[].camp','roles[].skillOverrides','roles[].win','roles[].win.fixedCareerId','roles[].loss','resolution'],requires:['固定胜利条件按来源ID接入原判胜逻辑，团队胜利受益人为角色当前阵营，个人胜利仅本人；不继承原职业身份或技能','服务端按阵营人数抽取合法角色实例','实例级技能绑定与状态兼容','可执行胜负规则服务端引擎','地图及扩展包可用性校验','服务器存档与分享']};return clean;}
// Appended to the existing editor engine by implement_candidate_pool.py.
const SCHEMA='goose-duck-board-draft/1.2';
const SELECTION={mode:'randomPool',algorithm:'randomized-valid-lineup/v1',roleCountMeaning:'maxCopies'};
const MAX_POOL_ROLES=300;
const repels=new Map(),dependencies=new Map();
for(const d of D.custom_depend_repel){
 dependencies.set(d.id,(d.depend||[]).filter(id=>id!==d.id));
 for(const id of d.repel||[]){if(!repels.has(d.id))repels.set(d.id,new Set());if(!repels.has(id))repels.set(id,new Set());repels.get(d.id).add(id);repels.get(id).add(d.id);}
}
function isUniqueNeutral(r){return r.camp===3&&!isCustom(r);}
function careerLimit(r){return isUniqueNeutral(r)?(r.templateCareerId===206?0:1):Infinity;}
function careerAddStatus(b,id){
 const c=careers.get(Number(id));
 if(!c||!classicCareerIds.has(c.id))return {allowed:false,reason:'请选择经典玩法职业'};
 if(c.camp===3&&c.id===206)return {allowed:false,reason:'需要双人，暂不可用'};
 if(c.camp===3&&b.roles.some(r=>isUniqueNeutral(r)&&r.templateCareerId===c.id))return {allowed:false,reason:'已添加 · 中立职业限1名'};
 if(b.roles.length>=MAX_POOL_ROLES)return {allowed:false,reason:'候选角色已达上限'};
 return {allowed:true,reason:''};
}
function addCareer(b,id){const status=careerAddStatus(b,id);if(!status.allowed)throw Error(status.reason);const r=makeRole(Number(id));b.roles.push(r);return r;}
function setRoleCount(r,count){
 if(!Number.isInteger(count)||count<1||count>ROOM_LIMITS.max)throw Error('出场上限需要为1–'+ROOM_LIMITS.max+'的整数');
 if(isUniqueNeutral(r)&&count!==1)throw Error('同一中立职业每局只能出现1名');
 r.count=count;
}
function neutralRoleIssues(b){
 const issues=[],seen=new Set();
 for(const r of b.roles.filter(isUniqueNeutral)){
  if(r.templateCareerId===206)issues.push({level:'error',code:'NEUTRAL_PAIR_UNSUPPORTED',uid:r.uid,camp:3,text:'决斗呆呆鸟需要两名相同职业，与中立职业唯一规则冲突，请移出候选池。'});
  if(r.count!==1)issues.push({level:'error',code:'NEUTRAL_ROLE_COUNT',uid:r.uid,camp:3,text:r.name+'：中立职业的单局出场上限只能为1人。'});
  if(seen.has(r.templateCareerId))issues.push({level:'error',code:'NEUTRAL_ROLE_DUPLICATE',uid:r.uid,camp:3,text:(careers.get(r.templateCareerId)?.name||r.name)+'在中立候选池中重复，请只保留一个。'});
  seen.add(r.templateCareerId);
 }
 return issues;
}
function campIds(b){return b.factions?b.factions.map(f=>f.id):[1,2,3];}
function campLabel(b,id){return b.factions?.find(f=>f.id===id)?.name||camps[id]||('阵营'+id);}
function poolStats(b,camp){
 const entries=b.roles.filter(r=>r.camp===camp),groups=new Map();let capacity=0;
 for(const r of entries){if(isCustom(r))capacity+=r.count;else{const id=r.templateCareerId;groups.set(id,Math.min(careerLimit(r),(groups.get(id)||0)+r.count));}}
 for(const n of groups.values())capacity+=n;
 return {camp,candidates:entries.length,capacity,seats:b.room.counts[camp]};
}
function seededRandom(seed){let a=2166136261;for(const c of String(seed)){a^=c.charCodeAt(0);a=Math.imul(a,16777619);}return ()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
function randomSeed(){if(root.crypto?.getRandomValues){const a=new Uint32Array(2);root.crypto.getRandomValues(a);return [...a].map(x=>x.toString(16)).join('-');}return Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);}
function shuffled(items,rng){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function lineupIssues(b,seats){
 const issues=[],add=(code,text)=>issues.push({level:'error',code,text});
 const used=new Map(),ids=new Map(),seen=new Set(),familyCounts=new Map(),checkedRoles=new Set();
 for(const s of seats){const r=b.roles.find(r=>r.uid===s.roleUid);if(!r||s.camp!==r.camp){add('DRAW_ROLE','抽取结果引用了无效候选。');continue;}used.set(r.uid,(used.get(r.uid)||0)+1);if(!isCustom(r))ids.set(r.templateCareerId,(ids.get(r.templateCareerId)||0)+1);if(!checkedRoles.has(r.uid)){for(const issue of compatibilityIssues(r))add(issue.code,`${r.name}：${issue.text}`);checkedRoles.add(r.uid);}for(const family of roleSkillFamilies(r))familyCounts.set(family,(familyCounts.get(family)||0)+1);}
 for(const [key,family] of Object.entries(SKILL_COMPAT.families))if((familyCounts.get(key)||0)>family.maxHolders)add('SKILL_FAMILY_HOLDER_CAP',`${family.label}能力实际持有者为 ${familyCounts.get(key)} 名，当前版本最多支持 ${family.maxHolders} 名；请重新抽取或补充其他候选。`);
 for(const c of campIds(b))if(seats.filter(s=>s.camp===c).length!==b.room.counts[c])add('DRAW_COUNT',`${campLabel(b,c)}抽取人数与目标不一致。`);
 if(seats.length!==b.room.total)add('DRAW_COUNT','抽取总人数与房间人数不一致。');
 for(const [key,n] of used){const r=b.roles.find(r=>r.uid===key);if(n>r.count)add('DRAW_LIMIT',`${r.name} 超过单局上限。`);}
 for(const [id,n] of ids){if(id===206)add('NEUTRAL_PAIR_UNSUPPORTED','决斗呆呆鸟不适用中立职业唯一规则。');if(careers.get(id)?.camp===3&&n>1)add('NEUTRAL_ROLE_DUPLICATE',`${careers.get(id)?.name} 不允许重复出场。`);
  for(const other of repels.get(id)||[])if(ids.has(other)){const key=[id,other].sort((a,b)=>a-b).join('-');if(!seen.has(key)){seen.add(key);add('ROLE_REPEL',`${careers.get(id)?.name} 与 ${careers.get(other)?.name} 不能同时出场。`);}}
  for(const need of dependencies.get(id)||[])if(!ids.has(need))add('ROLE_DEPEND',`${careers.get(id)?.name} 缺少依赖职业 ${careers.get(need)?.name||need}。`);
 }
 return issues;
}
function findLineup(b,seed='pool-validation',maxNodes=12000){
 const allCamps=campIds(b);
 const rng=seededRandom(seed),roles=b.roles,remaining={...b.room.counts},used=new Array(roles.length).fill(0),ids=new Map(),familyCounts=new Map(),memo=new Set(),roleIssues=new Map();let nodes=0,limited=false,skillLimited=false;
 for(const r of roles)roleIssues.set(r.uid,compatibilityIssues(r));
 const capacity=i=>{const r=roles[i],id=r.templateCareerId;if(remaining[r.camp]<=0)return 0;const copies=Math.max(0,Math.min(r.count-used[i],careerLimit(r)-(isCustom(r)?0:ids.get(id)||0)));if(!copies)return 0;if(roleIssues.get(r.uid)?.length){skillLimited=true;return 0;}if(!isCustom(r)&&[...(repels.get(id)||[])].some(x=>ids.has(x)))return 0;for(const family of roleSkillFamilies(r)){const max=SKILL_COMPAT.families[family].maxHolders;if((familyCounts.get(family)||0)+1>max){skillLimited=true;return 0;}}return copies;};
 function visit(){
  if(++nodes>maxNodes){limited=true;return false;}
  const key=used.join(',');if(memo.has(key))return false;
  const choices=Object.fromEntries(allCamps.map(c=>[c,[]])),caps=Object.fromEntries(allCamps.map(c=>[c,0])),groupCaps=Object.fromEntries(allCamps.map(c=>[c,new Map()]));
  for(let i=0;i<roles.length;i++){const n=capacity(i);if(!n)continue;const r=roles[i];choices[r.camp].push(i);if(isCustom(r))caps[r.camp]+=n;else{const id=r.templateCareerId,g=groupCaps[r.camp];g.set(id,Math.min(careerLimit(r)-(ids.get(id)||0),(g.get(id)||0)+n));}}
  for(const c of allCamps){for(const n of groupCaps[c].values())caps[c]+=n;if(caps[c]<remaining[c]){memo.add(key);return false;}}
  for(const [id,n] of ids){const needed=new Map((dependencies.get(id)||[]).filter(x=>!ids.has(x)).map(x=>[x,1]));if(id===206&&n<2)needed.set(206,2-n);
   for(const [need,amount] of needed){const byCamp=Object.fromEntries(allCamps.map(c=>[c,0]));for(let i=0;i<roles.length;i++)if(roles[i].templateCareerId===need)byCamp[roles[i].camp]+=capacity(i);if(allCamps.reduce((n,c)=>n+Math.min(remaining[c],byCamp[c]),0)<amount){memo.add(key);return false;}}
  }
  const campsLeft=allCamps.filter(c=>remaining[c]>0);if(!campsLeft.length)return true;
  campsLeft.sort((a,b)=>(caps[a]-remaining[a])-(caps[b]-remaining[b]));const camp=campsLeft[0];
  for(const i of shuffled(choices[camp],rng)){const r=roles[i],id=r.templateCareerId;used[i]++;remaining[camp]--;for(const family of roleSkillFamilies(r))familyCounts.set(family,(familyCounts.get(family)||0)+1);if(!isCustom(r))ids.set(id,(ids.get(id)||0)+1);
   if(visit())return true;
   used[i]--;remaining[camp]++;for(const family of roleSkillFamilies(r)){const n=familyCounts.get(family)-1;if(n)familyCounts.set(family,n);else familyCounts.delete(family);}if(!isCustom(r)){const n=ids.get(id)-1;if(n)ids.set(id,n);else ids.delete(id);}if(limited)return false;
  }
  memo.add(key);return false;
 }
 const ok=visit();if(!ok)return {ok:false,status:limited?'search-limit':skillLimited?'skill-cap':'impossible',seed:String(seed),nodes,seats:[]};
 const seats=[];for(const c of allCamps){const picked=[];for(let i=0;i<roles.length;i++)if(roles[i].camp===c)for(let copy=1;copy<=used[i];copy++)picked.push({roleUid:roles[i].uid,name:roles[i].name,camp:c,copy,templateCareerId:roles[i].templateCareerId});for(const s of shuffled(picked,rng))seats.push({uid:'seat-'+(seats.length+1),...s});}
 const problems=lineupIssues(b,seats);if(problems.length)throw Error('抽取校验失败：'+problems[0].text);
 return {ok:true,status:'complete',seed:String(seed),algorithm:SELECTION.algorithm,nodes,seats,omitted:roles.filter((r,i)=>!used[i]).map(r=>r.uid)};
}
function drawPool(b,seed=randomSeed()){
 const errors=validate(b,{checkPool:false}).filter(x=>x.level==='error');if(errors.length)throw Error('请先修正配置：'+errors[0].text);
 const draw=findLineup(b,seed);if(!draw.ok)throw Error(draw.status==='search-limit'?'组合过于复杂，本次未找到合法结果；可重新抽取或减少互斥候选。':draw.status==='skill-cap'?'候选数量虽然足够，但技能持有者上限使当前人数无法组成合法一桌；请补充其他候选或降低带该技能角色的单局上限。':'候选数量虽然足够，但互斥、依赖、技能配套或复数限制使当前人数无法组成合法一桌。');return draw;
}
function poolExample(){
 const b=defaultBoard();b.boardName='58候选 · 10人随机局';b.description='鹅30选6、鸭20选2、中立8选2；每次从各自角色池随机抽取。';b.roles=[];
 for(const [camp,target] of [[1,30],[2,20],[3,8]]){const originals=D.eligibleCareerIds.map(id=>careers.get(id)).filter(c=>c.camp===camp&&c.id!==206).slice(0,target);for(const c of originals){const r=makeRole(c.id);if(c.id===206)r.count=2;b.roles.push(r);}for(let i=originals.length;i<target;i++){const r=makeCustomRole();r.name=camps[camp]+'自创候选'+(i-originals.length+1);r.camp=camp;addSkill(r,39,'auto');b.roles.push(r);}}
 return b;
}

root.EditorEngine={ROOM_LIMITS,PHASE_ONE,SKILL_MOUNT_POLICY,skillMountPolicy,skillMountIssue,resolveSkillRawId,nativeSkillIds,isNativeSkill,classicCareerIds,classicSkillIds,skillScope,phaseOneIssues,librarySkills,SKILL_UNITS,SKILL_EQUIVALENTS,equivalentSkillIssues,playerSkill,equippedSkills,resetSkillParameters,fixedWinOptions,fixedWin,setFixedWin,setWinMode,SKILL_COMPAT,skillCompatibility,compatibilityIssues,roleSkillFamilies,SCHEMA,SELECTION,MAX_POOL_ROLES,poolStats,careerLimit,isUniqueNeutral,careerAddStatus,addCareer,setRoleCount,neutralRoleIssues,lineupIssues,findLineup,drawPool,poolExample,D,careers,skills,subs,camps,defs,events,clone,rule,uid,makeRole,makeCustomRole,isCustom,defaultBoard,allIds,slotEntries,addSkill,removeSkill,effective,modified,validate,evaluate,validateShape,exportDraft};
})(typeof window!=='undefined'?window:globalThis);


