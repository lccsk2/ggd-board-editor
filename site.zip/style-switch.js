"use strict";
(function(){
 const shell=!!document.querySelector('iframe[name="ggd-iphone17-screen"]');
 function save(){
  if(shell){try{const inner=document.querySelector('iframe').contentWindow;return typeof inner.GgdSaveForStyle==='function'?inner.GgdSaveForStyle():true;}catch{return true;}}
  if(typeof board==='undefined'||typeof E==='undefined')return true;
  try{document.activeElement?.blur();localStorage.setItem(AUTOSAVE,JSON.stringify(E.exportDraft(board)));return true;}
  catch{if(typeof toast==='function')toast('当前草稿未能保存，请先导出板子再切换。');return false;}
 }
 window.GgdSaveForStyle=save;
 document.addEventListener('click',function(e){const a=e.target.closest?.('a[data-switch-style]');if(a&&!save())e.preventDefault();},true);
})();